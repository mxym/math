# Dimension obstructions from realized convex bodies

Date: 7 October 2026. This is a local research report, not a publication or a priority claim. The arguments below are written proofs; the accompanying rational computation checks finite examples only.

## Main results

Let

\[
 e(K)=a(K)-\frac1{d+1}=\frac{B-A}{(d+1)A},\qquad
 \mathcal R_d(K,S)=\frac{E(K,S)}{e(K)^{1/(d-1)}}.
\]

The simplex case, where both numerator and denominator vanish, is omitted from ratios.

1. **A stronger explicit lower bound:** for every \(d\ge3\),
   \[
   \boxed{G_d\ge (d+1)[d(d+1)]^{1/(d-1)}.}
   \]
   It is attained by a specified maximum simplex in an iterated pyramid over a parallelogram. It improves the small-truncation lower bound in the supplied proof in every dimension \(d\ge3\). Its asymptotics are
   \[
   d+1+2\log d+O((\log d)^2/d).
   \]
   This is a stronger constant, not a stronger order than linear growth.

2. **Exact answer throughout a broad construction class:** among all product/join expressions containing at least one Cartesian product of two positive-dimensional bodies, the supremum of \(\mathcal R_d(K,S)\), allowing every maximum simplex, is exactly
   \[
   (d+1)[d(d+1)]^{1/(d-1)}.
   \]
   The leaves may be arbitrary convex bodies. Thus products, joins, and pyramiding cannot produce a superlinear-order obstruction within this class.

3. **Global anisotropic-truncation bound:** for a simplex with one vertex cut at arbitrary positive edge intercepts, every maximum simplex satisfies
   \[
   \mathcal R_d(K,S)\le
   (d+1)\left[\frac{d(d+1)^2}{2}\right]^{1/(d-1)}=d+O(\log d).
   \]
   This is uniform in the intercepts, so even dimension-dependent severe anisotropy does not yield a larger order.

4. **Local simultaneous anisotropic truncations:** cutting any subset of the vertices of one simplex, with independently chosen fixed positive intercept profiles and a common small scale, gives a local endpoint ratio no greater than the original single equal-intercept truncation constant. The statement holds uniformly over the choice of maximum simplex at each small scale.

These results do **not** prove a polynomial bound for arbitrary convex bodies, exclude all more complicated multiscale perturbations, or optimize the general anchor theorem.

## Sources used

- `research_math/sharp_simplex_publication_20261007/payload/notes/sharp-simplex-stability/proof.tex`: definitions, cone-law representation, affine invariance, and the original equal-intercept truncation formula.
- `research_math/sharp_simplex_publication_20261007/payload/notes/sharp-simplex-stability/sources/entry005-v3.md`: arbitrary-body extension and rigidity.
- `research_math/lower_truncation_independent_audit/public_sources/v2-paper.md`, Sections 3–5: exact product, join, and pyramid formulas. In particular,
  \[
  a(A\times B)=\frac{r a(A)+s a(B)}{r+s},\qquad
  \frac1{a(A*B)}=\frac1{a(A)}+\frac1{a(B)},
  \]
  and a point has the formal join value \(a=1\).

All counterexamples below are explicit full-dimensional polytopes. No arbitrary probability law is passed off as a realizable cone law.

## 1. An elementary global bound on the geometric excess

If \(S=\operatorname{conv}(v_0,\ldots,v_d)\) is maximum-volume in \(K\), its barycentric coordinates satisfy
\[
 |\alpha_i(x)|\le1\qquad(x\in K).
\]
Indeed, replacing \(v_i\) by \(x\) multiplies volume by \(|\alpha_i(x)|\).
Centroid dilation has the exact characterization
\[
 x\in z_S+(1+t)(S-z_S)
 \quad\Longleftrightarrow\quad
 \alpha_i(x)\ge-\frac{t}{d+1}\ \text{for every }i.
\]
Consequently
\[
 \boxed{E(K,S)\le d+1.} \tag{1}
\]
This applies to every maximum simplex without a normalization or a small-deficit hypothesis. It is much sharper than the coarse outer-radius bound used as the large-deficit branch in the supplied proof.

## 2. Product/join defect calculus

For a \(d\)-body set
\[
 \delta(K)=d+1-\frac1{a(K)}.
\]
The known lower bound on \(a\) gives \(\delta\ge0\), with equality precisely for a simplex. Solving for the original deficit gives
\[
 \boxed{e(K)=\frac{\delta(K)}{(d+1)(d+1-\delta(K))}.} \tag{2}
\]

### Joins

Since the dimension-plus-one is additive under joins and \(1/a\) is additive,
\[
 \delta(A*B)=\delta(A)+\delta(B). \tag{3}
\]
This includes joins with points, for which \(\delta=0\). Pyramiding therefore leaves \(\delta\) unchanged.

### Nontrivial Cartesian products

For \(r,s\ge1\), put \(d=r+s\). The product identity and \(a(A)\ge1/(r+1)\), \(a(B)\ge1/(s+1)\) imply
\[
 a(A\times B)\ge\frac1d\left(\frac r{r+1}+\frac s{s+1}\right)\ge\frac1d.
\]
Thus
\[
 \boxed{\delta(A\times B)\ge1.} \tag{4}
\]
A product node in any expression supplies this lower bound; a later product supplies it again independently, while a later join preserves it by addition of nonnegative quantities. Therefore every expression containing a nontrivial product has \(\delta\ge1\) at its root. Equations (1)–(2) give
\[
 e(K)\ge\frac1{d(d+1)},\qquad
 \mathcal R_d(K,S)\le(d+1)[d(d+1)]^{1/(d-1)}. \tag{5}
\]
The arbitrary leaves of the expression do not need to belong to a recursively point-generated class.

## 3. An exact extremizer for the whole product-containing class

Take
\[
 C_d=\operatorname{conv}(0,e_1,e_2,e_1+e_2,e_3,\ldots,e_d),\qquad
 S_d=\operatorname{conv}(0,e_1,\ldots,e_d).
\]
This is the standard unit square followed by \(d-2\) pyramids. The square has \(a=1/2\), and each pyramid adds one to \(1/a\), so
\[
 a(C_d)=\frac1d,\qquad e(C_d)=\frac1{d(d+1)}. \tag{6}
\]

To check maximality directly, a full-dimensional vertex simplex must contain every \(e_3,\ldots,e_d\), since no other vertex has a nonzero corresponding coordinate. It must also contain exactly three square vertices. Every such triangle has area \(1/2\), so every full-dimensional vertex simplex has volume \(1/d!\). The absolute determinant is separately convex in its vertices, hence no simplex with arbitrary vertices in \(C_d\) has larger volume. In particular, \(S_d\) is maximum.

The point \(e_1+e_2\) has barycentric coordinates
\[
 (-1,1,1,0,\ldots,0)
\]
in \(S_d\). Hence \(E(C_d,S_d)\ge d+1\), with equality by (1). Combining with (6) proves equality in (5), and gives the lower bound in the summary.

There is also a direct facet certificate for (6), independent of the pyramid recursion. Put \(c=1/(d-1)!\). The facet area-normal/support pairs are
\[
 (-c e_1,0),\quad(-c e_2,0),\quad(-2c e_i,0)\ (3\le i\le d),
\]
\[
 \left(c(e_1+\sum_{i=3}^d e_i),c\right),\qquad
 \left(c(e_2+\sum_{i=3}^d e_i),c\right).
\]
The corresponding halfspaces describe the square cross-sections
\(0\le x_1,x_2\le1-\sum_{i=3}^d x_i\).
Its volume is \(2/d!\). Direct maximal-minor sums give
\[
 H=c^d d2^{d-1},\qquad L=c^{d+1}2^d,
\]
so \(a=L/(d|C_d|H)=1/d\). To count \(L\), only the four subsets obtained by omitting either top facet or either of the first two coordinate facets contribute, each by \(c^{d+1}2^{d-2}\). For \(H\), the contributions with zero, one, or two top facets are respectively \(1,d,d-1\), all multiplied by \(c^d2^{d-2}\).

The lower bound from the supplied small-truncation family is
\[
 L_d^{\rm small}=(d+1)\left[\frac{(d+1)^2}{d(d-1)}\right]^{1/(d-1)}.
\]
The new bound is strictly larger since
\[
 \left(\frac{L_d^{\rm square}}{L_d^{\rm small}}\right)^{d-1}
 =\frac{d^2(d-1)}{d+1}>1\qquad(d\ge3).
\]
For example, the new bounds for \(d=3,4,5\) are approximately \(13.8564,13.5721,14.0421\), respectively. Numerical values are illustrative only; the formula is exact.

## 4. Exact anisotropic one-vertex truncations

Fix
\[
 0<t_1\le t_2\le\cdots\le t_d<1,
\]
and define the actual polytope
\[
 K_{\boldsymbol t}=
 \left\{x_i\ge0,\ \sum_i x_i\le1,\ \sum_i\frac{x_i}{t_i}\ge1\right\}.
\]
Its vertices are \(e_i,t_i e_i\). Set
\[
 T=\prod_i t_i,\quad q_i=T/t_i,\quad r_i=1-q_i,\quad
 p_i=\frac{q_i}{1-q_i}=\frac{T}{t_i-T},\quad
 P=\sum_i p_i,\quad D_p=\sum_{i<j}|p_i-p_j|.
\]
Then \(p_1\ge\cdots\ge p_d>0\).

### Facet determinant formula

Up to the common factor \(c=1/(d-1)!\), the facet area-normal/support pairs are
\[
 (-r_i e_i,0),\qquad (\mathbf1,1),\qquad (-\boldsymbol q,-T).
\]
The volume is \((1-T)/d!\). Write \(R=\prod_i r_i\). The horizontal and lifted sums, with their common factors removed, are
\[
 H=R[d+1+2P+D_p],\qquad
 L=R[1-(d-1)T+(1-T)P]. \tag{7}
\]
For the first identity, sum the all-coordinate subset, the subsets containing exactly one top/bottom facet, and the subsets containing both. The last group contributes
\(\sum_{i<j}|q_i-q_j|\prod_{k\ne i,j}r_k\), and
\(|q_i-q_j|/(r_i r_j)=|p_i-p_j|\).
For the lifted sum the all-coordinate terms give \((1+T)R\), while omitting coordinate \(i\) gives \((q_i-T)\prod_{k\ne i}r_k\). Here \(q_i-T>0\), so the signs are determined.

Consequently
\[
 a(K_{\boldsymbol t})=
 \frac{1+P-(d-2)T/(1-T)}{d+1+2P+D_p},
\]
and
\[
 \boxed{
 e(K_{\boldsymbol t})=
 \frac{2\sum_{i=2}^d(i-1)p_i-(d+1)(d-2)T/(1-T)}
 {(d+1)[d+1+2P+D_p]}.
 } \tag{8}
\]
We used \((d-1)P-D_p=2\sum_i(i-1)p_i\). Formula (8) reduces to the supplied equal-intercept expression when all \(t_i=t\).

### Every maximum simplex can be characterized

Any full-dimensional vertex simplex must meet all \(d\) coordinate rays, with exactly one ray doubled. Its determinant magnitude is
\[
 (1-t_j)\prod_{i\in I}t_i,
\]
where ray \(j\) is doubled and \(I\) indexes the other rays represented by their bottom rather than their top vertex. Since all \(t_i<1\), the maximum is \(1-t_1\), attained only by taking all top vertices and one shortest-intercept bottom vertex.

This also characterizes maximum simplices whose vertices are not polytope vertices. Express each of their vertices as a convex combination of polytope vertices, and sample independently from those combinations. Multilinearity and equality in the absolute-determinant bound force every positive-probability sampled tuple to be a maximum vertex simplex, with the same determinant sign. Every such tuple has exactly one bottom vertex. The sum of the independent bottom indicators is therefore identically one, so its variance is zero: one column is always bottom and every other column is always top. The \(d\) top columns must always choose distinct rays; their supports are disjoint nonempty subsets of a set of size \(d\), so each is a single distinct top vertex. The bottom column is supported only on the shortest-intercept bottom vertices.

Thus every maximum simplex is, up to ordering,
\[
 S=\operatorname{conv}(e_1,\ldots,e_d,b),\qquad
 b\in\operatorname{conv}\{t_1e_j:t_j=t_1\}. \tag{9}
\]
For the vertex choice \(b=t_1e_1\), its barycentric coordinates are
\[
 \beta_0=\frac{1-\sum_i x_i}{1-t_1},\quad
 \beta_1=x_1-t_1\beta_0,\quad \beta_i=x_i\ (i\ge2).
\]
It follows that, with
\[
 w=\frac{t_1(1-t_2)}{1-t_1},
\]
\[
 E(K_{\boldsymbol t},S)\le(d+1)w \tag{10}
\]
for every maximum simplex, with equality for a vertex maximum. If the shortest intercept is unique this is the only maximum simplex as a set. If it is tied, \(t_2=t_1\) and (9) gives \(E=(d+1)\max_i b_i\le(d+1)t_1\).

### A uniform polynomial upper bound for this entire family

Let \(N\) be the numerator in (8). Since \(p_i\ge T/(1-T)\),
\[
 N\ge2p_2+
 \left[d(d-1)-2-(d+1)(d-2)\right]\frac{T}{1-T}=2p_2.
\]
Also \(D_p\le(d-1)P\) and \(P\le d p_1\), giving
\[
 e\ge\frac{2p_2}{(d+1)^2(1+d p_1)}. \tag{11}
\]
Now
\[
 \frac{p_2}{1+d p_1}
 =\frac{T(t_1-T)}{(t_2-T)[t_1+(d-1)T]}
 \ge\frac1d\frac T{t_2}\frac{1-T/t_1}{1-T/t_2}.
\]
Put \(q=T/t_1\). Since \(q\le t_2\) and \(t_1/t_2\le1\), the function
\((1-q)/(1-(t_1/t_2)q)\) is nonincreasing in \(q\), so
\[
 \frac{1-T/t_1}{1-T/t_2}\ge\frac{1-t_2}{1-t_1}=r\in(0,1].
\]
Furthermore \(T/t_2\ge t_1^{d-1}\) and \(r\ge r^{d-1}\). Therefore
\[
 \boxed{e(K_{\boldsymbol t})\ge\frac{2}{d(d+1)^2}\,w^{d-1}.} \tag{12}
\]
Combining (10)–(12) proves the global bound in the summary. All inequalities are uniform, including regimes where the intercept ratios or proximity to one depend on dimension.

### Local optimum among anisotropic cuts

For fixed \(0<a_1\le\cdots\le a_d\), set \(t_i=\varepsilon a_i\). With \(m=d-1\), (8) gives
\[
 e(K_{\varepsilon\boldsymbol a})
 =c(\boldsymbol a)\varepsilon^m+O(\varepsilon^{m+1}),\quad
 c(\boldsymbol a)=\frac{2}{(d+1)^2}
   \sum_{i=2}^d(i-1)\frac{\prod_j a_j}{a_i}.
\]
Since \((\prod_j a_j)/a_i\ge a_1^m\),
\[
 c(\boldsymbol a)\ge\frac{d(d-1)}{(d+1)^2}a_1^m.
\]
Also (10) gives \(E\le(d+1)\varepsilon a_1+O(\varepsilon^2)\). Thus
\[
 \limsup_{\varepsilon\downarrow0}\mathcal R_d
 \le(d+1)\left[\frac{(d+1)^2}{d(d-1)}\right]^{1/m}, \tag{13}
\]
with equality for equal intercepts and a vertex maximum.

## 5. Simultaneous anisotropic cuts: a local theorem for every maximum

Let \(P\) be a simplex with barycentric coordinates \(\lambda_0,\ldots,\lambda_d\). Choose a subset \(J\) of vertices to cut. For each \(j\in J\), choose fixed numbers \(a_{ji}>0\), \(i\ne j\), and retain the halfspace
\[
 \sum_{i\ne j}\frac{\lambda_i}{a_{ji}}\ge\varepsilon.
\]
For sufficiently small \(\varepsilon>0\), these corner cuts are pairwise disjoint. Denote the remaining polytope by \(K_\varepsilon\). Define
\[
 \mu_j=\min_{i\ne j}a_{ji}\quad(j\in J),\qquad \mu_j=0\quad(j\notin J),
 \qquad\mu_* =\max_j\mu_j.
\]
Assume \(J\ne\varnothing\).

### Additive leading defect

For each \(j\), apply the preceding one-corner formula in affine simplex coordinates centered at vertex \(j\), and call its coefficient \(c_j\). Then
\[
 e(K_\varepsilon)
 =\varepsilon^{d-1}\sum_{j\in J}c_j+O(\varepsilon^d),\qquad
 c_j\ge\frac{d(d-1)}{(d+1)^2}\mu_j^{d-1}. \tag{14}
\]
Here is why additivity is legitimate despite the absolute values in determinant sums. A new cut facet has its entire area-normal/support vector of size \(O(\varepsilon^{d-1})\). The original facet area vectors are their original vectors plus the sum of the reductions caused by disjoint corner cuts. An original facet's support hyperplane is unchanged, so its support component has the same scalar change. The horizontal and lifted minors containing only original facets have nonzero determinants at \(\varepsilon=0\), so their first-order perturbations are additive. A minor containing one new facet has its leading term determined by that facet and unperturbed original facets. A minor containing two or more new facets is \(O(\varepsilon^{2d-2})=O(\varepsilon^d)\) for \(d\ge2\). Volume loss is \(O(\varepsilon^d)\). Thus the coefficient of \(\varepsilon^{d-1}\) is exactly the sum of the separate one-corner coefficients. This argument does not differentiate an absolute value at a zero determinant without controlling the corresponding term.

### First-order location of every maximizing vertex

Write the barycentric coordinate columns of any maximum simplex in \(K_\varepsilon\) as the nonnegative column-stochastic matrix \(W\). A comparison simplex formed by moving each cut vertex along one shortest-intercept edge has
\[
 \det W_{\rm cmp}=1-\varepsilon\sum_j\mu_j+O(\varepsilon^2).
\]
Thus \(|\det W|\ge1-O(\varepsilon)\). The standard near-permutation argument for stochastic matrices gives, after relabeling columns,
\[
 W=I+O(\varepsilon),
\]
uniformly over the maximizing simplices. For completeness: Hadamard bounds each column norm below by \(1-O(\varepsilon)\); its largest entry is at least its squared norm because the column sums to one. These largest entries occur in distinct rows, since otherwise the permanent, and hence the absolute determinant, would be \(O(\varepsilon)\).

Let \(s_j=1-W_{jj}\). The cut constraint at vertex \(j\) implies
\[
 s_j=\sum_{i\ne j}W_{ij}\ge\varepsilon\mu_j.
\]
Since \(W-I=O(\varepsilon)\), determinant expansion gives
\[
 \det W=1-\sum_j s_j+O(\varepsilon^2).
\]
Comparison with \(W_{\rm cmp}\) and the separate lower bounds therefore imply
\[
 s_j=\varepsilon\mu_j+O(\varepsilon^2)\qquad\text{for every }j. \tag{15}
\]
All constants may depend on the fixed intercept profiles and dimension, but not on the choice of maximum simplex.

For any \(x\in K_\varepsilon\), its barycentric coordinates in that maximum simplex are \(\beta=W^{-1}\lambda(x)\). Using
\(W^{-1}=I-(W-I)+O(\varepsilon^2)\), nonnegativity of \(\lambda\), and (15), yields
\[
 \beta_i\ge-\varepsilon\mu_*+O(\varepsilon^2),\qquad
 E(K_\varepsilon,S)\le(d+1)\varepsilon\mu_*+O(\varepsilon^2). \tag{16}
\]
Combining (14)–(16),
\[
 \limsup_{\varepsilon\downarrow0}\sup_{S\text{ maximum in }K_\varepsilon}
 \mathcal R_d(K_\varepsilon,S)
 \le
 (d+1)\left[\frac{(d+1)^2}{d(d-1)}\right]^{1/(d-1)}
 \frac{\mu_*}{(\sum_{j\in J}\mu_j^{d-1})^{1/(d-1)}}.
\]
The final fraction is at most one. Therefore simultaneous corner cutting cannot improve the local endpoint obstruction, even when each corner has its own anisotropic profile.

The fixed-profile qualification is important: (14)–(16) are local asymptotics, not a global bound uniform over profiles varying with \(\varepsilon\). Section 4 supplies that stronger uniform statement for a single cut only.

## 6. Why merely ill-conditioning the original simplex cannot help

Both \(a\) and \(E\) are invariant under an invertible affine change of coordinates, with the chosen maximum simplex transported by that change. Consequently applying arbitrarily ill-conditioned affine maps to any of the above bodies produces exactly the same endpoint ratio. This applies even when the map depends on dimension or on the truncation scale. Only genuine affine-shape changes matter; anisotropic intercepts are such changes, and were treated separately above.

## 7. Reproduction and remaining gap

The companion file `check_obstructions.py` independently enumerates horizontal and lifted facet minors with exact rational arithmetic for 75 anisotropic cases in dimensions 2–6. It also enumerates all vertex simplices, checks the maximum determinant, verifies (7)–(8), and checks the lower bound (12). It additionally checks the square-pyramid facet certificate in dimensions 2–12. Its output is in `check_obstructions.log`. These finite tests support arithmetic consistency; the proofs above establish the quantified statements.

The useful rigorous conclusions are a stronger realized lower bound and exact/polynomial limitations on natural construction classes. No superpolynomial body obstruction has been found. No argument here closes the very large gap between a general sharp-exponent upper constant and the \(d+O(\log d)\) lower bounds.
