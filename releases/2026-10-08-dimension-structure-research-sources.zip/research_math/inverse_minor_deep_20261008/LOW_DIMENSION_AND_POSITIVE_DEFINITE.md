# Exact low-dimensional and positive-definite cases

8 October 2026. Let W>=0 be invertible and column-stochastic; set B=W^{-1}. Let M_k be the largest absolute k-minor of B and suppose M_k<=c^k for the orders under discussion.

## 1. A sharp two-minor identity in order three

**Theorem.** For n=3,

1-min_{i,j} B_ij <= M_2.                             (1)

This assertion is special to this dimension; the corresponding proposed bound with max(M_1,M_2) is false in order five.

**Proof.** Row/column permutations of W preserve its stochasticity and the quantities in (1). First make det W=D>0. Independent even row and column permutations are transitive on the three indices, so any chosen entry of B can then be placed at position (3,1) while preserving D>0. Write

W=[[u,v,z],[r,s,t],[1-u-r,1-v-s,1-z-t]].

If C_13 is the cofactor in row 1, column 3, direct expansion gives

D-C_13=(s-r)(1-z)+t(v-u)
      =(1-z-t)(s-r)+t[(v+s)-(u+r)]+z*0.

This is a convex combination because z,t,1-z-t are the entries of the third stochastic column. Its three values are

s-r,  W_31-W_32,  0.

Each is at most m=max_{i,j}W_ij. Since B_31=C_13/D,

1-B_31<=(m/D).

Jacobi's complementary-minor identity gives M_2=m/D. Applying the same argument to every entry proves (1). QED.

Thus a=max(0,-min B)<=c^2-1 whenever M_2<=c^2. Combining this with a<=M_1<=c gives

a<=min(c,c^2-1)<=phi^2(c-1),

where phi=(1+sqrt(5))/2. The last coefficient is optimal: the two bounds cross at c=phi.

The same conclusions hold for direct sums of blocks of orders at most three, after independent row and column permutations. For a block of order two, writing a column-stochastic inverse as [[x,y],[1-x,1-y]] shows directly that every negative entry is accompanied in its column by a positive entry larger by one. Hence a<=M_1-1<=c-1. Blocks of order one are [1].

## 2. Exact all-order golden-ratio extremizer

Let p=1/phi and define

W=[[0,p,1/2],[p,0,1/2],[1-p,1-p,0]].

Then det W=p(1-p)=phi^{-3}, and

B=[[-phi/2,phi/2,phi^2/2],
   [phi/2,-phi/2,phi^2/2],
   [1,1,-phi]].

Its column sums are one and W is nonnegative column-stochastic. Exhaustively, or by Jacobi,

M_1=phi,  M_2=phi^2,  M_3=phi^3.

Therefore the all-order root bound is exactly c=phi, while a=phi. Equality holds both in a=c^2-1 and in

a=phi^2(c-1).

Consequently any universal global theorem a<=C(c-1), valid for all c>=1, must have C>=phi^2. This is an exact finite-dimensional obstruction to small constants. It is **not** a counterexample as c decreases to one.

## 3. Symmetric positive-definite stochastic matrices

**Theorem.** If W is additionally symmetric and positive definite, then the one-entry bound M_1<=c alone implies

a<=c-1.                                             (2)

**Proof.** A nonnegative column-stochastic W has spectral radius at most one; symmetry and positive definiteness put all its eigenvalues in (0,1]. Hence H=B-I is positive semidefinite. In particular 0<=H_ii=B_ii-1<=c-1, and every two-coordinate principal PSD restriction gives

|B_ij|=|H_ij|<=sqrt(H_ii H_jj)<=c-1  (i!=j).

The diagonal entries B_ii are at least one and are not negative. This proves (2).

The coefficient one is sharp even with all-order minor bounds: for 0<s<1/2, use W=[[1-s,s],[s,1-s]]. Its inverse has negative size a=s/(1-2s), diagonal 1+a, and determinant 1+2a. Thus c_all=1+a because (1+a)^2>=1+2a.

For the geometric cap reduction described in EDGE_SUPPORTED_RIGIDITY.md, this gives the all-scale bound E(K,S)<=4n rho whenever the prescribed W is symmetric positive definite. It follows by E/n<=min(1,c-1), c=(1-2rho)^{-1}, splitting at rho=1/4. The assumption is coordinate-dependent and must be verified, not inferred from positivity of W's entries.

## 4. A local permutation basin, without symmetry or sparse support

Suppose independent row and column permutations put W into a form with

s=max_j(1-W_jj)<1/4.

Then M_1<=c implies

a<=(c-1)/(1-4s).                                   (3)

Indeed put H=I-W. Its induced column norm is ||H||_1=2s and its maximum entry modulus is at most s. The Neumann expansion gives, for k>=1,

max|H^k_ij|<=s(2s)^{k-1}.

Thus a<=s/(1-2s). At an index j with H_jj=s,

B_jj>=1+s-2s^2/(1-2s)
     =1+s(1-4s)/(1-2s).

Since B_jj<=c, dividing these inequalities yields (3). In particular s<=1/8 gives a<=2(c-1). This lemma does not prove that a suitable permutation exists; establishing a dimension-free entry into such a basin would itself be a substantive missing step in the general problem.
