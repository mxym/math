# Inverse-minor rigidity: proved structural cases

8 October 2026. Standalone continuation; the earlier source files are unchanged.

## Main result

For an invertible nonnegative column-stochastic W with at most two positive entries per column, B=W^{-1}, and one-/two-minor bounds M_1<=c, M_2<=c^2:

- c<sqrt(2) implies max(0,-min B)<=c^2-1.
- Every c>=1 gives max(0,-min B)<=(2+sqrt(2))(c-1).

The support graph is a union of unicyclic components. Weighted-cycle formulas handle the cores; exact inverse recursions handle all attached trees. This includes arbitrarily large matrices, not only bounded-size blocks.

For K inside an n-vertex simplex P with near-vertex radius rho, this proves

E(K,S)<=(4+2sqrt(2))n rho

when the originally prescribed maximum simplex S is edge-supported relative to P. If every extreme point of K is edge-supported (hence K is a polytope), determinant averaging proves the same bound for **every** prescribed maximum S, including those whose own vertices are not edge-supported.

The corresponding original actual-defect coefficient is

(4+2sqrt(2))(d+1) H_d^(1/(d-1)),

**conditional on an enclosing simplex admitted by the existing actual-defect chain having the stated edge-support property.** Existence of such a compatible simplex is not proved in general.

## Other exact results

- In order three, 1-min B<=M_2; hence the all-scale linear constant is phi^2.
- An explicit 3 by 3 golden-ratio matrix has M_k=phi^k and -min B=phi. Therefore any unrestricted global coefficient C in -min B<=C(c-1) must satisfy C>=phi^2.
- Symmetric positive-definite stochastic W obey -min B<=c-1 from entry bounds alone; constant one is sharp.
- A quantitative local-permutation-basin estimate is provided, without claiming the missing dominant-matching theorem.
- A localized minor-completion/occupancy inequality and a one-way uniform-inverse reduction are recorded separately.

## Files

- `EDGE_SUPPORTED_RIGIDITY.md`: full support-two proof, geometric theorem, arbitrary-maximum averaging, conditional actual-defect corollary, and open obstruction.
- `LOW_DIMENSION_AND_POSITIVE_DEFINITE.md`: order-three theorem, exact golden-ratio witness, PSD theorem, and local permutation basin.
- `theory_worker/rigorous_partial_results.md`: localized occupancy lemma, independently checked support-two argument, and uniform-inverse reduction.
- `theory_worker/FINAL_FOCUSED_AUDIT.md`: focused independent review, PASS after the stated extreme-point clarification.
- `check_exact_results.py` and `EXACT_CHECKS.json`: exact symbolic/rational checks. Run `python research_math/inverse_minor_deep_20261008/check_exact_results.py` from the workspace root.
- `exploratory/`: retained numerical search artifacts only, not proof inputs.
- `SHA256SUMS`: hashes of the final proof, check, and review files.

The checker verifies the golden-ratio extremizer, the arbitrary-maximizer averaging identity on a square example, the geometric threshold constant, 140 rational order-three instances, and 287 rational support-two instances, including 149 in the near-endpoint regime. It also recomputes both previously known false-lemma counterexamples exactly. Rational regression is a consistency check, not a substitute for the written proofs.

## Unresolved question

No dimension-free C is proved for unrestricted W, and no exact family with c decreasing to one and a fixed negative inverse entry is constructed. Three-supported columns can create interacting cycles; the unicyclic decomposition and unique inverse-path recursion then fail. Neither a dimension-free dominant matching nor an alternative replacement for that structure has been established. The stronger uniform-almost-nonnegative-inverse formulation is likewise not solved.

No numerical optimum is asserted to be a theorem. No new Lean formalization, kernel check, publication, Git operation, or modification of frozen source material is claimed.
