# Inverse-minor rigidity for edge-supported simplices

8 October 2026. This note proves structural cases of the inverse-minor problem. It does **not** prove the unrestricted dimension-free theorem.

Let W be an invertible nonnegative column-stochastic n by n matrix and B=W^{-1}. Put

M_1=max_{i,j}|B_ij|,   M_2=max_{|I|=|J|=2}|det B_{I,J}|,

and suppose M_1<=c and M_2<=c^2, with c>=1. (For n=1 only M_1 is needed.) Write a=max(0,-min B).

## 1. Main sparse-support theorem

**Theorem.** If every column of W has at most two nonzero entries, then

1. If 1<=c<sqrt(2), then a<=c^2-1.
2. For every c>=1, a<=(2+sqrt(2))(c-1).

Only minors of orders one and two are used. The size of the matrix, the lengths of its cycles, and the sizes of its trees do not enter the constants.

The two conclusions also hold after arbitrary independent row and column permutations of W, since these only independently permute the rows and columns of B and change signs of its minors.

### 1.1 Weighted cyclic blocks

First consider a cycle block of order m>=2. After row and column relabeling it has the form

W=(I+P R_d)D,

where P is a cyclic permutation, D=diag(d_i), R_d=diag(r_i), d_i=1/(1+r_i), and r_i>0. Thus column i gives mass d_i to its own row and mass r_i d_i to the next row. Write R=product_i r_i. Left multiplication by P^{-1} interchanges the two matchings and replaces the product R by R^{-1}. We may therefore choose the orientation with R<=1. In even order the equality R=1 is excluded by invertibility. Set

L=1-(-1)^m R>0.

The finite geometric identity gives

B=D^{-1}[I-P R_d+(P R_d)^2-...+(-1)^{m-1}(P R_d)^{m-1}]/L.

In particular,

B_ii=(1+r_i)/L.

For any distinct i,j, Jacobi's identity, or a direct expansion, gives the positive principal two-minor

det B_{ {i,j},{i,j} }=(1+r_i)(1+r_j)/L.                 (1)

To see the complementary determinant directly when m>2, delete vertices i,j from the directed cycle. The remaining principal submatrix is acyclic triangular after a topological ordering, with determinant equal to the product of its d_l. For m=2, (1) is just det B=1/(d_1 d_2 L).

**Case A: all r_i<=1.** In odd order, R<=r_i, hence B_ii>=1; in even order L<=1, so the same conclusion holds. In each row, the absolute inverse entries are the common positive factor (1+r_i)/L times products of consecutive r's. Negative entries correspond to odd-length paths. Every such product is no larger than the final one-edge factor r_j, where j is the predecessor of i. Thus each row's largest negative entry occurs on its incoming edge:

-B_ij=(1+r_i)r_j/L.

The principal two-minor on i,j equals

(1+r_i)(1+r_j)/L=B_ii+(-B_ij)>=1+(-B_ij).

Consequently a<=M_2-1<=c^2-1.

**Case B: some r_i>=1.** Choose the largest two ratios x>=y and use the chosen orientation R<=1. Then R<=xy: if y<=1, all remaining ratios are at most one; if y>=1, xy>=1>=R. In odd order,

(1+x)(1+y)-2(1+R)
  >=(1+x)(1+R/x)-2(1+R)
  =(x-1)(1-R/x)>=0.

Thus (1) is at least two. In even order, (1)>=(1+x)(1+y)>=2 because L<=1. Therefore M_2>=2, and necessarily c>=sqrt(2).

It follows that c<sqrt(2) forces Case A. For c>=sqrt(2), the trivial bound a<=M_1<=c gives

a/(c-1)<=c/(c-1)<=2+sqrt(2).

For c<sqrt(2), Case A instead gives a/(c-1)<=c+1<1+sqrt(2). This proves both asserted bounds for a cyclic block. Zero coefficients can be included by continuity, although the graph decomposition below makes it unnecessary to regard zero-weight edges as genuine cyclic edges.

### 1.2 Why all column-two matrices reduce to cycles and trees

Associate a graph to W: its vertices are row indices; a column with two positive entries is an edge between those two rows; a column with one positive entry is a loop at that row. Distinct columns may give parallel edges. The graph's connected components partition both the rows and the columns of W.

Each corresponding matrix block must be square. Indeed, a block with unequal numbers of rows and columns has rank at most their minimum; summing these rank bounds over the blocks would make the whole square matrix singular. Thus in each connected component the numbers of edges and vertices agree. Such a connected multigraph is unicyclic, with loops and doubled edges included as cycles of lengths one and two.

Remove all trees attached to the unique cycle. Pair each non-core vertex with the edge joining it to its parent toward the core. Order core rows and columns first and tree vertices in parent-before-child order. The matrix has block form

W=[[W_C,E],[0,T]],

where T is triangular. The column attached to a tree vertex v has weight d_v>0 at v and weight 1-d_v at its parent. Let r_v=(1-d_v)/d_v. The diagonal entry of the full inverse at v is exactly 1/d_v, so

r_v=1/d_v-1<=c-1.                                    (2)

The core inverse B_C=W_C^{-1} is a submatrix of B, so it inherits the same one- and two-minor bounds. A loop core has B_C=[1]; all other cores satisfy the cyclic result above.

For completeness, the inverse-column recursion is exact. If b_v=B e_v and p(v) is the parent row, then BW e_v=e_v gives

b_v=d_v^{-1}e_v-r_v b_{p(v)}.                         (3)

For a core row p, the vector b_p has core part B_C e_p and zero tree part. Repeated use of (3) shows that every off-diagonal entry in a tree column is a product of at least one r_v, times either a core inverse entry or the diagonal 1/d_u at a tree ancestor u. All the latter starting factors have absolute value at most c.

If c<sqrt(2), then (2) gives 0<=r_v<=c-1<1. Therefore every such tree-column off-diagonal entry has absolute value at most

c(c-1)<=c^2-1.

The diagonal tree entries are positive; the core negative entries are at most c^2-1 by Section 1.1. This proves the near-endpoint assertion. The same trivial a<=c argument as above proves the global assertion.

## 2. Geometric consequence for a prescribed maximum simplex

Let P have n vertices, and use its barycentric coordinates. Let S be the originally prescribed maximum-volume simplex of an arbitrary convex body K subset P. Suppose:

- every vertex of S lies on an edge of P, allowing vertices of P themselves;
- K contains n points whose barycentric matrix Q is nonnegative column-stochastic and has Q_ii>=1-rho.

Let W be the barycentric vertex matrix of S, B=W^{-1}, A=BQ. Maximum-volume optimality implies that every square minor of A has absolute value at most one. For rho<1/2, the established Neumann/Cauchy-Binet reduction gives the one- and two-minor bounds of the theorem with

c=(1-2rho)^{-1}.

For any x in K, let z be its nonnegative P-barycentric coordinate vector. Its S-barycentric coordinate vector is Bz, so every coordinate is at least min B. Single-replacement maximality also bounds every S-coordinate of every x in K below by -1. The original-centroid homothety formula therefore gives E(K,S)<=n min(1,a). This argument controls all of K, not only the finite hull of the selected Q-points.

Set rho_0=(1-1/sqrt(2))/2. For 0<=rho<rho_0,

E(K,S)/n<=c^2-1=4rho(1-rho)/(1-2rho)^2
                 <=(4+2sqrt(2))rho.

Here the quotient 4(1-rho)/(1-2rho)^2 is increasing on this interval and equals 4+2sqrt(2) at rho_0. For rho>=rho_0, E<=n and 1/rho_0=4+2sqrt(2). Consequently the all-scale result is

**E(K,S)<=(4+2sqrt(2)) n rho.**                       (4)

The simplex S is never replaced by a more convenient maximizer. The sparse-support condition in this first version is a hypothesis on this prescribed S. The result applies to arbitrary K subject to that hypothesis; it does not require K to have few vertices.

## 3. A body-level version retaining every maximum simplex

**Theorem.** Suppose instead that K is a full-dimensional polytope, every vertex of K lies on an edge of P, and the same near-vertex cap hypothesis holds. Then (4) holds for **every prescribed maximum-volume simplex S of K**, even when the vertices of S itself do not lie on edges of P.

The passage from vertex-supported maximizers to arbitrary maximizers is exact and is included to avoid a quantifier loss.

Let v_1,...,v_N be the vertices of K. Express each vertex s_j of the prescribed S as a convex combination sum_l lambda_lj v_l. Independently sample T_j=v_l with probabilities lambda_lj. Use homogeneous affine coordinates, so the determinant of the n columns is proportional to oriented simplex volume. Choose the order of S so that det S=D>0. Multilinearity gives

E[det T]=det S=D.

Maximality of S implies |det T|<=D for every sampled tuple. Therefore every positive-probability sample has det T=D: all of them are nondegenerate, have the same orientation, and are themselves maximum vertex simplices.

For any x in K, Cramer's rule and multilinearity in the unreplaced columns now give, for each index j,

alpha_j^S(x)
  =det(S with column j replaced by x)/D
  =E[det(T with column j replaced by x)]/D
  =E[alpha_j^T(x)].                                  (5)

Every sampled T is edge-supported, so Section 2 gives alpha_j^T(x)>=-(4+2sqrt(2))rho for all x and j. Averaging in (5) gives exactly the same bound for the original S. The centroid formula uses S's own original centroid throughout; no centroid of a sampled simplex is substituted for it.

There is no genuine extension needed to handle continuous edge segments. If a compact convex K has all its extreme points on the finite one-skeleton of P, then each edge contains at most two extreme points of K, namely endpoints of K's intersection with that edge. Thus there are finitely many extreme points and K is already their convex hull. The same conclusion plainly holds if K is given as the convex hull of finitely many closed segments on P's edges.

## 4. Conditional corollary for the original actual Entry005 defect

Retain precisely the original invariant

e(K)=(d/(d+1))^d R(pyr K)/R(K)-1-1/(d+1),
R(L)=V(Pi L)/V(L)^(dim L-1),

and let H_d=3d^2(d+1)^3(d+2), n=d+1, d>=3. The previously established actual-defect chain supplies an enclosing simplex P, relative projection deficit at most delta=H_d e(K), and near-vertex radius rho=delta^(1/(d-1)) when 0<=e(K)<=H_d^{-1}.

**Additional compatibility hypothesis:** at least one enclosing simplex P admitted by that actual-defect/projection/cap chain has the property that every extreme point of K lies on P's one-skeleton. In particular K is a polytope by Section 3; for a polytope this says exactly that every vertex is edge-supported. This is stronger than merely having some enclosing simplex with edge-supported vertices. This note does not establish that the chain's P can always be chosen in this way.

Under this explicit compatibility hypothesis, Section 3 gives, for every original prescribed maximum S,

E(K,S)<=(4+2sqrt(2))(d+1) H_d^(1/(d-1)) e(K)^(1/(d-1)).  (6)

Using the retained bound H_d^(1/(d-1))<=144 and d+1<=4d/3 gives the coarser coefficient

E(K,S)<=(768+384sqrt(2))d e(K)^(1/(d-1)).              (7)

For e(K)>H_d^{-1}, the universal E<=d+1 proves (6) directly and no edge-support or enclosing-simplex hypothesis is needed in that large-defect branch. The e=0 endpoint also follows from the cap theorem with rho=0.

A prescribed-simplex version of (6) only needs that this prescribed S is edge-supported relative to an admissible P; then Section 2 applies directly. The body-level compatibility hypothesis above is what makes the assertion uniform over **all** maximum simplices without checking their supports.

These are conditional corollaries of the original actual invariant and its existing enclosing-simplex chain. They are not an unconditional theorem for all convex bodies. The exact coefficient in (6) is asymptotic to (4+2sqrt(2))d.

## 5. What remains open

The argument uses the unicyclic support decomposition in an essential way. A column with three or more nonzero entries does not reduce to the same path recursion, and this note gives no reduction from arbitrary W to the column-two case. Neither the unrestricted inverse-minor theorem nor a counterexample to it is established.

The conjectured all-order inequality a<=c^2-1 remains open in general. Even the analogous assertion using only one- and two-minor bounds is known to be false in order five, so no extension should invoke it without a new proof.
