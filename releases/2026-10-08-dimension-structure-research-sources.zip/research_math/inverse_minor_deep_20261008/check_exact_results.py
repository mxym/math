#!/usr/bin/env python3
"""Exact algebra/regression checks; mathematical proofs are in the companion notes.

Random rational tests are regression tests, never a replacement for the proofs.
No network, source edits, publication, or formal-proof claim is involved.
"""
from itertools import combinations
from pathlib import Path
import json
import random
import sympy as sp

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
R = sp.Rational


def minor_max(M, k):
    n = M.rows
    if k == 1:
        return max(abs(x) for x in M)
    if k == 2:
        return max(abs(M[i,j]*M[h,l]-M[i,l]*M[h,j])
                   for i,h in combinations(range(n),2)
                   for j,l in combinations(range(n),2))
    return max(abs(M.extract(I,J).det())
               for I in combinations(range(n),k)
               for J in combinations(range(n),k))


def stochastic_check(W):
    assert all(x >= 0 for x in W)
    assert all(sum(W[:,j]) == 1 for j in range(W.cols))
    assert W.det() != 0


def verify_known_obstructions():
    p = ROOT / 'research_math/linear_retention_investigation_20261008/false_sharp_two_minor_bound.json'
    data = json.loads(p.read_text())
    W = sp.Matrix(data['W_integer_numerator']) / data['W_denominator']
    B = W.inv()
    assert B == sp.Matrix([[R(x) for x in row] for row in data['B']])
    a = -min(B)
    m1, m2 = minor_max(B,1), minor_max(B,2)
    assert 1+a > max(m1,m2)
    p = ROOT / 'research_math/full_minor_rigidity_exploration_20261008/false_squared_two_minor_bound.json'
    data2 = json.loads(p.read_text())
    W2 = sp.Matrix(data2['N']) / data2['denominator']
    B2 = W2.inv()
    assert B2 == sp.Matrix([[R(x) for x in row] for row in data2['B']])
    a2 = -min(B2)
    h2 = max(minor_max(B2,1)**2, minor_max(B2,2))
    assert 1+a2 > h2
    return {'constant_one_two_minor_gap': str(1+a-max(m1,m2)),
            'squared_two_minor_gap': str(1+a2-h2)}


def golden_check():
    phi = (1+sp.sqrt(5))/2
    p = 1/phi
    W = sp.Matrix([[0,p,R(1,2)],[p,0,R(1,2)],[1-p,1-p,0]])
    B = sp.Matrix([[-phi/2,phi/2,phi**2/2],
                   [phi/2,-phi/2,phi**2/2],[1,1,-phi]])
    assert (W*B-sp.eye(3)).applyfunc(sp.simplify) == sp.zeros(3)
    assert sp.simplify(W.det()-phi**-3) == 0
    # Compare algebraic numbers exactly using SymPy's real algebraic ordering.
    for k in (1,2,3):
        vals = [sp.simplify(abs(B.extract(I,J).det()))
                for I in combinations(range(3),k)
                for J in combinations(range(3),k)]
        assert all(sp.simplify(phi**k-v) >= 0 for v in vals)
        assert any(sp.simplify(phi**k-v) == 0 for v in vals)
    assert sp.simplify(phi-phi**2*(phi-1)) == 0
    return {'phi': str(phi), 'M1': 'phi', 'M2': 'phi^2', 'M3': 'phi^3',
            'global_linear_coefficient_lower_bound': 'phi^2'}


def low_dimension_checks(rng):
    count = 0
    for _ in range(140):
        W = sp.Matrix(3,3,lambda i,j:rng.randrange(0,15))
        if any(sum(W[:,j]) == 0 for j in range(3)):
            continue
        for j in range(3):
            W[:,j] = W[:,j] / sum(W[:,j])
        if not W.det():
            continue
        B = W.inv()
        assert 1-min(B) <= minor_max(B,2)
        count += 1
    return count


def support_two_checks(rng):
    count = near = 0
    for n in range(2,11):
        for iteration in range(32):
            m = rng.randrange(1,n+1)
            W = sp.zeros(n)
            if m == 1:
                W[0,0] = 1
            else:
                for j in range(m):
                    # Alternate near-permutation and genuinely mixed instances.
                    d = R(rng.randrange(82,100),100) if iteration%2 else R(rng.randrange(1,100),100)
                    W[j,j] = d
                    W[(j+1)%m,j] = 1-d
            for j in range(m,n):
                parent = rng.randrange(j)
                d = R(rng.randrange(82,100),100) if iteration%2 else R(rng.randrange(1,100),100)
                W[j,j] = d
                W[parent,j] = 1-d
            if not W.det():
                continue
            stochastic_check(W)
            assert all(sum(int(bool(W[i,j]>0)) for i in range(n)) <= 2 for j in range(n))
            B = W.inv()
            a = max(sp.Integer(0),-min(B))
            m1, m2 = minor_max(B,1), minor_max(B,2)
            h = max(m1*m1,m2)  # c^2 for the least 1+2-minor admissible c.
            assert m1 >= 1
            if h < 2:
                assert a <= h-1
                near += 1
            # The large-c branch of the global theorem uses this exact bound.
            assert a <= m1
            count += 1
    return {'rational_matrices': count, 'near_endpoint_matrices': near}


def averaging_check():
    # K=[0,1]^2, P=conv((0,0),(2,0),(0,2)).  Every K vertex
    # is on a P edge.  The maximizer's third vertex (1/2,1) is not.
    def bary(x,y):
        return sp.Matrix([1-x/2-y/2,x/2,y/2])
    a,b = bary(R(0),R(0)),bary(R(1),R(0))
    T0 = sp.Matrix.hstack(a,b,bary(R(0),R(1)))
    T1 = sp.Matrix.hstack(a,b,bary(R(1),R(1)))
    S = (T0+T1)/2
    assert S.det() == T0.det() == T1.det() != 0
    assert S.inv() == (T0.inv()+T1.inv())/2
    return {'same_oriented_determinant': str(S.det()),
            'exact_inverse_averaging': True,
            'prescribed_third_vertex_cartesian': ['1/2','1']}


def cap_constant_check():
    rho = sp.symbols('rho',real=True)
    rho0 = (1-1/sp.sqrt(2))/2
    C = 4+2*sp.sqrt(2)
    f = 4*(1-rho)/(1-2*rho)**2
    assert sp.simplify(f.subs(rho,rho0)-C) == 0
    assert sp.simplify(1/rho0-C) == 0
    assert sp.simplify(sp.diff(f,rho)-4*(3-2*rho)/(1-2*rho)**3) == 0
    assert sp.simplify(C*192-(768+384*sp.sqrt(2))) == 0
    return {'rho_threshold': str(rho0), 'all_scale_geometric_constant': str(C)}


def main():
    rng = random.Random(202610080548)
    report = {
        'status': 'PASS',
        'scope': 'Exact symbolic identities and exact rational regression; no formal proof or numerical proof claim.',
        'known_false_lemmas_rechecked': verify_known_obstructions(),
        'golden_all_order_extremizer': golden_check(),
        'order_three_rational_cases': low_dimension_checks(rng),
        'support_two_regression': support_two_checks(rng),
        'arbitrary_maximum_averaging_example': averaging_check(),
        'cap_constant': cap_constant_check(),
    }
    out = HERE/'EXACT_CHECKS.json'
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
