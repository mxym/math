# Focused independent audit

Scope: EDGE_SUPPORTED_RIGIDITY.md Sections 2–4; LOW_DIMENSION_AND_POSITIVE_DEFINITE.md Sections 1–2. Date: 8 October 2026.

## Verdict

PASS. The initially identified Section 4 wording issue has been corrected and the revision verified: the compatibility hypothesis now requires every extreme point of K to lie on the admissible P's one-skeleton. Section 3 therefore makes K a polytope, so the body-level quantifiers are precise. No unresolved mathematical issue remains in the audited scope.

The Entry005 statement is checked as a conditional consequence of the stated existing actual-defect/projection/cap chain. This audit does not independently re-prove that upstream chain.

## Detailed checks

1. **All-K coordinate control: PASS.** For any x in K subset P, its P-coordinate vector z is nonnegative with sum one, so every component of Bz is bounded below by min B. Replacement of a single prescribed S vertex by x additionally gives |alpha_i^S(x)|<=1. The original-centroid homothety criterion is alpha_i>=-E/n, yielding E<=n min(1,a) for the whole body, not merely the finite hull of Q's columns.

2. **Minor reduction: PASS.** A=BQ has all minors at most one because each is the determinant ratio of a simplex with a selected subset of S vertices replaced by selected Q-points in K. Since ||Q-I||_1<=2rho, ||Q^{-1}||_1<=c=(1-2rho)^{-1}. Cauchy-Binet and the injection expansion of determinants give every k-minor of B at most c^k. In particular the required k=1,2 bounds hold.

3. **Geometric constants: PASS.** rho_0=(1-1/sqrt(2))/2 satisfies c(rho_0)^2-1=1. The quotient 4(1-rho)/(1-2rho)^2 increases on [0,rho_0] and equals 4+2sqrt(2) at the endpoint. Also 1/rho_0=4+2sqrt(2), so the universal E<=n handles every rho>=rho_0, including rho>=1/2 where the Neumann reduction is not invoked. Thus E<=(4+2sqrt(2))n rho is valid at all scales.

4. **Arbitrary prescribed maximizer: PASS.** Independence and determinant multilinearity give E det T=D. Each tuple has det T<=D, so every positive-probability tuple has exactly det T=D. Hence no such tuple is degenerate or oppositely oriented. Cramer's rule then has the same denominator D for every sample. Averaging each replaced-column determinant gives the prescribed S coordinate exactly. The original S and its own centroid are retained; the argument does not select a favorable maximizer or substitute a sampled centroid.

5. **Compact one-skeleton reduction: PASS.** K intersected with each edge is an interval, a point, or empty. A point in its relative interior cannot be an extreme point of K. Therefore each edge contributes at most two extreme points; the finite one-skeleton contributes finitely many. The finite-dimensional compact convex hull theorem then makes K a polytope. This is the appropriate bridge for a statement about general compact convex bodies.

6. **Conditional actual-defect corollary: PASS, with the extreme-point wording now corrected.** With n=d+1, rho=(H_d e)^{1/(d-1)}, and H_d=3d^2(d+1)^3(d+2), substitution yields coefficient (4+2sqrt(2))(d+1)H_d^{1/(d-1)}. The coarse calculation uses 144*(4/3)=192 and is exactly 768+384sqrt(2). The retained bound H_d^{1/(d-1)}<=144 is valid: H_3=8640<144^2, and H_{d+1}/H_d<=25/6<144 for d>=3 gives an immediate induction. The e>H_d^{-1} branch follows from E<=d+1 without a compatible enclosing simplex, and e=0 is covered by the stated zero-radius cap conclusion. H_d^{1/(d-1)} tends to one, so the exact coefficient is asymptotic to (4+2sqrt(2))d.

7. **Order-three cofactor proof: PASS.** Direct expansion yields D-C_13=(s-r)(1-z)+t(v-u). Its convex-combination form has weights 1-z-t,t,z and values s-r, W_31-W_32,0, each <=max W. Independent even permutations are transitive on row and column indices in order three, so any inverse entry can be targeted while retaining D>0. Jacobi gives M_2=max W/D, proving 1-min B<=M_2.

8. **Golden-ratio extremizer: PASS.** For p=phi^{-1}, det W=p(1-p)=phi^{-3}; the displayed B is exactly W^{-1} and has column sums one. Its largest absolute entry is phi. Jacobi gives M_2=p/det W=phi^2, while M_3=phi^3. Hence c_all=phi and a=phi, with a=c^2-1=phi^2(c-1). The resulting global constant lower bound C>=phi^2 is exact. The optimization min(c,c^2-1)/(c-1) peaks where c=phi and has value phi^2.

No incorrect algebraic constants or lost prescribed-simplex quantifiers remain. The sole terminology issue identified during the audit was corrected before this final report.
