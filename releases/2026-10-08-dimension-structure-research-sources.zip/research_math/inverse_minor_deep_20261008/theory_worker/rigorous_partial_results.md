# Rigorous partial results for inverse-minor rigidity

Let W be an invertible nonnegative column-stochastic n by n matrix, B=W^{-1}, and assume every k by k minor of B has absolute value at most c^k, c >= 1. The dimension-free inequality -min B <= C(c-1) is NOT established in this note. No counterexample to that inequality is established either.

## 1. Localized minor-completion / occupancy inequality

Let R,S be disjoint subsets of row labels, with |R|=k and |S|=l. Let J be any column set of cardinality k. Independently draw Y_s from the distribution W_{:,s} for each s in S. Then

|det B_{R,J}| <= c^{k+l} Pr( Y_s are pairwise distinct, and Y_s do not belong to J for every s in S ).

Proof: Order the coordinates R union S with R first. The determinant of the matrix whose first k columns are B_{R union S,J} and whose last l columns are the coordinate vectors e_s restricted to R union S is, up to a fixed ordering sign, det B_{R,J}. Substitute e_s = sum_h W_{h,s} B_{:,h} and expand by multilinearity. Every term with a repeated selected h or an h in J vanishes. Every remaining determinant is a (k+l)-minor of B and hence has magnitude <= c^{k+l}. The sum of its nonnegative product weights is exactly the stated event probability.

In particular, for any entry B_{ij} and any S subset of [n] minus {i},

|B_{ij}| <= c^{|S|+1} Pr( Y_s distinct and all different from j )
             <= c^{|S|+1} product_{s in S}(1-W_{j,s}).

The collision-free term is stronger than the product bound. Taking k=0 recovers the familiar injection-probability bound 1 <= c^{|S|} Pr(Y_s pairwise distinct). The localized inequality retains the fixed minor and its forbidden column set.

## 2. Arbitrarily weighted cycles have dimension-free linear stability

This extension was supplied by the parent worker and checked here.

Suppose W has a single directed cycle pattern: W=(I+P R)D, where P is an n-cycle, D=diag(d_i), R=diag(r_i), d_i>0, r_i>=0, and d_i(1+r_i)=1. Let Rprod=product_i r_i. Permuting rows and reversing the cycle exchanges the two cyclic diagonals and replaces the product by its reciprocal. Thus we may assume Rprod<=1. If a diagonal coefficient initially vanishes, one may either exchange cyclic diagonals when possible or obtain the statement as a limit of strictly positive coefficient choices.

Put L=1-(-1)^n Rprod. Invertibility means L is nonzero. The diagonal entries are

B_{ii}=(1+r_i)/L,

and for distinct i,j every principal 2-minor is

(1+r_i)(1+r_j)/L.

More generally an inverse entry along a directed path of length k is

(-1)^k (1+r_i) product(path ratios)/L.

If all r_i<=1, then Rprod<=r_i and B_{ii}>=1 (for even n this is immediate from L<=1). For each fixed row i the largest-magnitude negative entry is its preceding adjacent entry, because every longer odd path multiplies by additional ratios <=1. Calling that magnitude a_i, the principal 2-minor on i and its predecessor is exactly B_{ii}+a_i. Therefore

max_i a_i <= c^2-1.

If some ratio is >=1, let x>=y be the two largest ratios. The product of all remaining ratios is <=1: either at most one ratio exceeds 1, or xy>=1 and Rprod/(xy)<=1. Hence Rprod<=xy and y>=Rprod/x. For odd n,

(1+x)(1+y)-2(1+Rprod)
 >= (x-1)(1-Rprod/x) >=0.

The corresponding principal 2-minor is at least 2, so c>=sqrt(2). For even n, L<=1 and (1+x)(1+y)>=2 already yield the same conclusion.

Consequently every weighted cycle with c<sqrt(2) obeys the sharp-form bound

-min B <= c^2-1.

For c>=sqrt(2), the entry bound -min B<=c yields

-min B <= (2+sqrt(2))(c-1).

Combining the two regimes proves the dimension-free global estimate

-min B <= (2+sqrt(2))(c-1)

for all weighted single-cycle matrices, using only minor orders one and two. A block diagonal union of such cycles has the same conclusion. This does not address general stochastic matrices.

## 3. Uniformly almost-nonnegative inverse reduces to the stochastic problem

Suppose A is invertible, every minor of A has absolute value <=1, 1^T A=1^T, and V=A^{-1} satisfies V_{ij}>=-eta/n. Let J=11^T and define

W=(V+(eta/n)J)/(1+eta),
B=W^{-1}=A Q,
Q=(1+eta)I-(eta/n)J.

Then W is nonnegative and column-stochastic. Moreover

B_{ij}-A_{ij}=eta[A_{ij}-(1/n)sum_h A_{ih}],

so |B_{ij}-A_{ij}| <= 2 eta.

For a fixed k-element column set, the only nonzero k-minors of Q use either the same row set or a row set obtained by exchanging one index. The principal minor is

(1+eta)^{k-1}(1+eta-k eta/n),

and each of the k(n-k) one-index-exchange minors has magnitude

(eta/n)(1+eta)^{k-1}.

Cauchy-Binet therefore gives the exact convenient upper bound

|det B_{I,J}| <= (1+eta)^{k-1}[1+eta+eta k(n-k-1)/n]
              <= (1+eta)^{k-1}[1+(k+1)eta]
              <= (1+2eta)^k.

The last inequality follows by Bernoulli:

(1+2eta)^k/(1+eta)^{k-1}
  =(1+eta)(1+eta/(1+eta))^k
  >=1+(k+1)eta.

Thus the uniform-inverse setting maps into the original setting with c=1+2eta and an entrywise change <=2eta. In particular, a bound -min B<=C(c-1) for the original stochastic theorem would imply -min A<=(2C+2)eta here. This is only a one-way reduction; it does not prove that arbitrary original instances admit the stronger regularized representation in the other direction.

## 4. Conditional elementary stability from a dominant matching

If, after a row permutation, W_{ii} >= 1-epsilon for every i, with epsilon<1/2, then

||B-I||_1 <= 2epsilon/(1-2epsilon).

Indeed ||I-W||_1 <=2epsilon because W is nonnegative and column-stochastic, and the Neumann series bounds ||W^{-1}-I||_1 <= ||I-W||_1/(1-||I-W||_1). Hence the negative entries obey the same bound. A dimension-free dominant-matching theorem W_{i,pi(i)}>=1-O(c-1) would therefore settle the target. This note does not establish that matching theorem.

## 5. Audited extension: at most two positive entries per stochastic column

The weighted-cycle theorem extends to every invertible column-stochastic W with at most two positive entries in each column. This extension was supplied by the parent worker and independently checked here.

Represent each row as a graph vertex, each two-supported column as an edge between its two supporting rows, and each singleton column as a loop. Different columns may form parallel edges. Each connected component of the support graph produces a rectangular block of W. Invertibility of the whole matrix forces every such block to have the same number of columns and rows: otherwise the sum of the component ranks would be strictly less than n. Thus each connected component has E=V and is a unicyclic multigraph.

Remove attached trees to expose its unique core cycle. A loop core gives the one-by-one stochastic matrix [1]; a two-edge core is the even n=2 case above. Order the core first, then tree vertices with every parent preceding its child. Assign each tree-edge column to its child. Its two entries are d_j>0 at the child and 1-d_j at the parent. In block upper-triangular form, the diagonal inverse at every tree vertex is 1/d_j. Hence the entry bound gives

r_j=(1-d_j)/d_j <= c-1.

The core inverse is a submatrix of B, so it obeys the same first- and second-order bounds. Every inverse entry involving a nontrivial tree path is, up to sign, a product of the ratios r_j along that unique path times either a core-inverse entry or an ancestor diagonal inverse 1/d_i. This follows from W_tree=(I+N)D, with N_parent,child=r_child, and the finite expansion of (I+N)^{-1}. A nontrivial path contains at least one ratio.

For c<sqrt(2), every tree ratio is below 1, so every such entry has magnitude at most c(c-1)<=c^2-1. Negative core entries have the same c^2-1 bound by Section 2; tree diagonal entries are positive. Therefore

-min B <= c^2-1 when 1<=c<sqrt(2),

and, by the order-one estimate for c>=sqrt(2),

-min B <= (2+sqrt(2))(c-1) for every c>=1.

Only minor orders one and two are needed for this support-two theorem. It does not claim the same sharp inequality for unrestricted stochastic supports.
