已实际核对：工具恢复，独立审计代理已完成。**独立编译30/30；131个公开证明仅依赖标准三公理；完整空环境 Lean kernel 重放已终止并通过，返回码0**，于23:24:10 UTC结束，用时462.37秒。伪造证明的实际 kernel 拒绝测试返回码1。23:41的读写及 Lean 导入复查也通过。没有仍在运行的验证任务或本地阻塞。

已重新核对交付文件：

- [完整独立验证包](/workspace/entry005-quadratic-independent-release-5izx6mfo/entry005-quadratic-main-independent-rebuild-20261007.zip)，567373字节，SHA256：`f7fd2a283f9171268e2f712d5169727f18102f6e6b6a446faa157c0ee9b5b631`
- [可读精确补丁](/workspace/entry005-quadratic-independent-release-5izx6mfo/entry005-quadratic-main-independent-rebuild-20261007-readable.patch)，3498534字节，SHA256：`ab7ac19fdb8a88730226c301ecd271942b3705b6d8f8a951aee7fdceb08b546f`
- [独立审计报告](/workspace/entry005-independent-r9nfsj4t/INDEPENDENT_VERIFICATION_REPORT_20261007.md)及[断连后检查记录](/workspace/entry005-quadratic-independent-release-5izx6mfo/POST_DISCONNECT_STATUS_20261007.json)。

原139份冻结源码及原候选包未改变；Page/Library写入未重试。以下直接给出完整证明文本。第8节保留作者验证记录；上述独立空缓存重建及空环境 kernel 结果是后来完成的追加验证。

# Entry005: sharp deficit exponent with a quadratic dimension coefficient

7 October 2026. The completed theorem is

\[
 E(K,S)\le 4096d^2\,e(K)^{1/(d-1)}\qquad(d\ge3),
\]

for **every prescribed maximum-volume inscribed simplex** \(S\) of the convex
body \(K\). Its dilation is centered at that same simplex's original centroid.
The invariant is exactly the original Entry005 invariant; no equivalent
surrogate defect is substituted. The strict Lean theorem is
`Entry005.quadratic_stability_of_prescribed_maximum`, and the literal full
target is inhabited by `Entry005.quadraticMain`. Neither theorem assumes a
cone law, assignment budget, enclosing simplex, projection deficit, near-vertex
points, or special choice of maximum simplex.

This is a complete continuation over the frozen, previously audited source
release, whose manifest SHA-256 is
`929ab9653cfb9b3e6e295fbbc841d7358e13924d25c68101d94ced43f8533fa0`.
The new patch supplies every new proof body. The frozen proof bodies and the
nine pinned packages remain explicit external inputs. The original explicit
`1/d` theorem and the frozen sharp Main are unchanged. No assertion from the
unreliable intermediate (3.11) of arXiv2603.17726v3 is used.

## Literal definitions

Let \(V\) be canonical Euclidean volume and let \(\pi_K(u)\) be canonical
\((d-1)\)-volume of the orthogonal projection onto \(u^\perp\), for unit \(u\).
The projection body is the actual intersection
\(\Pi K=\{x:\langle u,x\rangle\le\pi_K(u)\text{ for all unit }u\}\).
For a body \(L\) of dimension \(r\), write
\(R(L)=V(\Pi L)/V(L)^{r-1}\), and let
\(\operatorname{pyr}K=\operatorname{conv}((K,0)\cup\{(0,1)\})\), in dimension
\(d+1\). The original invariant is

\[
 e(K)=\left(\frac d{d+1}\right)^d
       \frac{R(\operatorname{pyr}K)}{R(K)}-1-\frac1{d+1}.
\]

For \(z=S.centroid\),
\[
 E(K,S)=\inf\{t\ge0:K\subset z+(1+t)(S-z)\}.
\]
These are `entryDefect` and `excess` from the frozen `Entry005.Targets`.

## 1. Normalize the input simplex and obtain one intrinsic assignment

Put \(n=d+1\), \(m=d-1\), \(C=n^3(n+1)\), and \(H=3d^2C\).
Use the proved affine normalization of the **input** maximum simplex \(S\)
to send its own centroid to zero and to put the closed unit ball inside its
image. Affine invariance preserves both \(e(K)\) and \(E(K,S)\), and the
image of this same \(S\) remains maximum. In this section the normalized
objects retain the names \(K,S\).

Replacing the \(i\)-th vertex of \(S\) by any \(x\in K\) gives
\(|\alpha_i^S(x)|\le1\) by the exact simplex determinant/volume formula.
Since \(\sum_i\alpha_i^S(x)=1\) and \(z=0\), the point \(-x/d\) has
\(S\)-coordinates \((1-\alpha_i^S(x))/d\ge0\). Consequently
\(-K\subset dS\subset dK\). The lower bounds \(\alpha_i^S(x)\ge-1\)
also give the universal estimate \(E(K,S)\le n\).

Define the continuous seminorm
\(N(u)=h_K(u)+h_K(-u)=h_{K-K}(u)\), where \(h_K\) is the actual support
height. Fix a compact-limit actual cone probability \(\mu\) and its strictly
increasing approximation subsequence \(\varphi\), as furnished by the frozen
actual-body existence theorem. All subsequent uses retain this law and this
subsequence. Its random vector \(X\) has mean zero, support in the unit ball,
and \(h_K(X)=1\) on its support. The proved actual brightness identities are

\[
 m_K(z):=\int\langle z,X\rangle_+\,d\mu
       =\frac{\|z\|\pi_K(z/\|z\|)}{dV(K)},\qquad
 f_K(z):=\int|\langle z,X\rangle|\,d\mu=2m_K(z),
\]
with both expressions zero at \(z=0\).

The weighted determinant witness, with this continuous seminorm, produces
affinely independent support anchors \(w_0,\ldots,w_d\), and the measurable
largest-barycentric-coordinate assignment \(I(X)\), such that

\[
 h:=\int N(X-w_{I(X)})\,d\mu
       \le\frac{Ce(K)}{1+ne(K)}.\tag{1}
\]

For completeness, the constant conversion is literal: on the support,
\(h_K(w)=1\), \(h_K(-w)\le d\), hence \(N(w)\le n\).
Differences of support points therefore have seminorm at most \(2n\).
The pointwise clipped assignment estimate is
\(N(X-w_I)\le2n\,\operatorname{assignmentCost}(\alpha(X))\).
The integrated determinant assignment cost is bounded by the witness ratio.
Volume-weighted selection bounds that ratio by
\(n(n+1)D/(2B)\), where \(D\) is the actual iid determinant defect and
\(B\) the unnormalized lifted absolute-determinant moment. The exact actual
Entry005 identity is \(D/B=ne/(1+ne)\). Multiplication yields (1), without
altering \(B\), the law, or the chosen assignment. Nonnegativity \(e\ge0\)
is the proved actual-body nonnegativity theorem.

The complete new implementations are `SeminormAssignment`,
`SeminormFirstMoment`, `ActualIntrinsicAssignment`, `CentroidAsymmetry`, and
`PrescribedIntrinsicInterface`. The packet stores equalities to the original
defect, excess and centroid, in addition to the fixed law and assignment.

## 2. Actual projection width and the intrinsic enclosing simplex

For unit \(v\), any \(u\), and \(c=\langle u,v\rangle\), the actual width
estimate is

\[
 |c|V(K)\le N(u)\pi_K(v).\tag{2}
\]

If \(c>0\), use canonical orthogonal coordinates \(x=q+tv\),
\(q\in v^\perp\). The determinant-one shear
\((q,t)\mapsto(q,t+\langle u,q\rangle/c)\) preserves the canonical product
volume. For \(x\in K\) its second coordinate is
\(\langle u,x\rangle/c\), in the interval
\([-h_K(-u)/c,h_K(u)/c]\) of length \(N(u)/c\), while its first coordinate
is in the actual projection of \(K\). Inclusion in this sheared cylinder
proves (2). Replace \(u\) by \(-u\) for \(c<0\); \(c=0\) is immediate.
The canonical normal-coordinate measure-preserving map and the shear are
proved in `IntrinsicProjectionWidth` and `ShearedCylinderBound`.

Combining (2) with the displayed brightness identity gives, for all \(z,y\),

\[
 |\langle z,y\rangle|\le d\,m_K(z)N(y).\tag{3}
\]

Let \(p_i=\mu\{I=i\}\). Positive part is 1-Lipschitz, so (3) implies
\[
 \sum_i p_i\langle z,w_i\rangle_+
       \ge(1-dh)m_K(z).\tag{4}
\]
Assume \(h<1/(2d)\). For unit \(z\), \(m_K(z)\) has a positive uniform
lower bound: \(K\) contains the unit ball, whose actual projection has
positive volume, and \(V(K)>0\). Thus (4) puts a positive ball in
\(\operatorname{conv}\{w_i\}\), by support separation. This qualitative
radius is used only to establish that the polar intersection is a genuine
simplex. Define this same-anchor simplex
\[
 P=\{z:\langle z,w_i\rangle\le1\text{ for all }i\}.
\]
Since \(h_K(w_i)=1\), \(K\subset P\), and its support at each \(w_i\) is
exactly one. For \(z\in P\), the left side of (4) is at most 1, so
\(m_K(z)\le(1-dh)^{-1}\le2\). Equation (3), for every direction \(y\),
and compact convex separation now give the literal containment

\[
 P\subset 2d(K-K).\tag{5}
\]

No Euclidean outer-radius estimate enters (5). The complete separation,
anchor-ball, and same-law enclosure proofs are in
`IntrinsicSupportContainment`, `IntrinsicAssignedDirections`,
`ActualIntrinsicConeData`, and `IntrinsicEnclosingSimplex`.

## 3. Correct the same assignment probabilities multiplicatively

Let \(\lambda_i>0\), \(\sum\lambda_i=1\), \(\sum\lambda_iw_i=0\), be the
unique zero-barycentric probabilities of the same anchors. If \(q_i\) is
the \(i\)-th polar-simplex vertex, the actual anchor coordinates satisfy
\[
 \alpha_i^w(x)=\lambda_i(1-\langle q_i,x\rangle).\tag{6}
\]
Indeed the right side is the affine function that takes values 1 at \(w_i\)
and 0 at the other anchors. The actual facet-cone probabilities of \(P\)
have these same mass/mean equations, so affine independence identifies them
with \(\lambda_i\). Thus
\(f_P(z)=\sum\lambda_i|\langle z,w_i\rangle|
=2\|z\|\pi_P(z/\|z\|)/(dV(P))\).

Put \(c=\sum p_iw_i=\int w_I\,d\mu\). Since \(\int X=0\), (5) yields
\[
 |\langle q_i,c\rangle|
 \le\int|\langle q_i,w_I-X\rangle|\,d\mu\le2dh.
\]
Evaluating (6) at \(c\) gives \(p_i=\lambda_i(1-\langle q_i,c\rangle)\).
Write \(r=2dh<1\); hence \(p_i\ge(1-r)\lambda_i\). Also (3) and the
triangle inequality give
\[
 \sum p_i|\langle z,w_i\rangle|
 \le f_K(z)+d\,m_K(z)h=(1+r/4)f_K(z).
\]
Consequently the actual, unrenormalized brightness comparison is
\[
 (1-r)\frac{\pi_P(v)}{V(P)}
 \le(1+r/4)\frac{\pi_K(v)}{V(K)}\quad(\|v\|=1).\tag{7}
\]
The auxiliary \(\lambda\)-law of \(P\) is proved from its actual facets;
it never substitutes for the actual \(K\)-law \(\mu\) or its assignment.
See `MultiplicativeAtomCorrection`, `PolarWitnessConeWeights`, and
`IntrinsicMultiplicativeBrightness` for the complete identities and proof.

## 4. Same-law volume-root control and relative projection deficit

The actual finite-body infinitesimal Brunn--Minkowski comparison proves
\[
 (V(P)/V(K))^{1/d}\le\int h_P(X)\,d\mu.\tag{8}
\]
Its proof applies the unrestricted Brunn--Minkowski theorem to finite
halfspace approximants, differentiates the exact radial volume polynomial
at zero, then passes the support integral along the **same** \(\varphi\)
and \(\mu\). The unrestricted theorem's complete real-interval,
slice-transport and induction proof bodies are included in
`OAI.Geometry.ProjectionBodies.QuadraticBMReuse`; no unprovided slice
hypothesis or inverse-Minkowski assertion is assumed. The exact first
coefficient and limit arguments are in `InfinitesimalRadialScale` and
`FiniteInfinitesimalScale`.

Using \(h_P(w_i)=1\), (5), and support subadditivity in (8) gives
\[
 (V(P)/V(K))^{1/d}\le1+2dh=1+r.\tag{9}
\]
Combine (7) and (9):
\[
 \frac{\pi_K(v)}{\pi_P(v)}
 \ge\frac{1-r}{(1+r)^d(1+r/4)}.\tag{10}
\]
All denominators are positive, since the actual enclosing simplex contains
the unit ball. For numbers \(a,b,c\in[0,1]\),
\(1-abc\le(1-a)+(1-b)+(1-c)\). Apply this to
\(a=1-r\), \(b=(1+r)^{-d}\), \(c=(1+r/4)^{-1}\).
The elementary bound \(1-t^d\le d(1-t)\) for \(0\le t\le1\) gives
\[
 1-\frac{1-r}{(1+r)^d(1+r/4)}
 \le r+dr+r/4
 =2d(d+5/4)h\le3d^2h\quad(d\ge3).
\]
Thus, literally relative to the outer simplex's projection volume,
\[
 \pi_P(v)-\pi_K(v)\le3d^2h\,\pi_P(v).\tag{11}
\]
These are `ActualIntrinsicScale`, `IntrinsicRelativeProjection`, and
`relative_projection_scalar` in `QuadraticScalarAssembly`.

If \(0\le e\le H^{-1}\), (1) implies
\(h\le Ce\le1/(3d^2)<1/(2d)\), even at equality \(e=H^{-1}\).
Consequently every preceding strict gate is valid and (11) gives (with
\(\delta=He\))
\[
 \pi_P(v)-\pi_K(v)\le\delta\pi_P(v)\quad\hbox{for all unit }v.\tag{12}
\]
`QuadraticIntrinsicPacket` derives (12) from the actual packet and its
**original** defect; no geometric or budget conclusion is passed as a final
theorem premise.

## 5. The exact simplex vertex cap gives the sharp power

Let \(\ell_i\) be the actual barycentric coordinate of the \(i\)-th vertex
of \(P\), and choose \(k_i\in K\) maximizing it. Such a point exists by
compactness. Set \(t_i=1-\ell_i(k_i)\in[0,1]\). Choose a unit projection
direction parallel to the opposite facet. Then \(\ell_i\) descends to the
projection hyperplane, and its range on the projection of \(P\) is exactly
\([0,1]\). For any \(0<s<t_i\), the apex-centered homothetic cap
\[
 q_i+s(P-q_i)
\]
projects into \(\{\ell_i\ge1-s\}\), disjoint from the projection of \(K\).
Its canonical projected volume is exactly \(s^{d-1}\pi_P(v)\). Both it
and the projection of \(K\) lie in the projection of \(P\), so (12) gives
\(s^{d-1}\le\delta\). Let \(s\uparrow t_i\); when \(t_i=0\) the
conclusion is immediate. Therefore
\[
 1-\ell_i(k_i)=t_i\le\rho:=\delta^{1/(d-1)}.\tag{13}
\]
This exact affine cap is the source of the exponent \(1/(d-1)\). No
boundary null-set assertion is needed: use strict \(s<t_i\) before the
limit. `RelativeProjectionCap` proves the general support-gap version;
`RelativeSimplexVertexCap` proves (13) for actual simplex coordinates and
actual points of \(K\), including \(\delta=0\).

## 6. Retain every prescribed maximum simplex, with its original centroid

Let \(Q\) be the matrix whose \(i\)-th column is the \(P\)-coordinate
vector of \(k_i\); let \(W\) have the \(P\)-coordinates of the originally
prescribed maximum \(S\); and let \(B=W^{-1}\) be the \(S\)-coordinates
of the vertices of \(P\). Matrices \(Q,W\) are nonnegative column
stochastic, \(Q_{ii}\ge1-\rho\), and \(BW=I\).

First suppose \(\rho\le1/(16n)\), and put \(q=2n\rho\le1/8\).
Independent column selections interpret the determinant as the expected
sign of the selected permutation (zero for collisions). The probability of
the identity selection is \(\prod Q_{ii}\ge1-n\rho\); bounding every
other sign below by \(-1\) gives
\(\det Q\ge2\prod Q_{ii}-1\ge1-q>0\).
Thus the actual points \(k_i\) span a simplex inside \(K\).
Its volume is \(\det Q\,V(P)\). Maximality of the original \(S\) gives
\(|\det W|\ge1-q\). The verified sharp column-stochastic determinant
rigidity theorem in the frozen `Mxym.StochasticRigidity` now relabels only
the vertices of that same \(S\) so that
\(W_{ii}\ge1-q\). Relabeling leaves both its carrier and centroid unchanged.

The following explicit inverse bootstrap prevents a dimension loss. Put
\(D=B-I\) and \(\beta=\max|D_{ij}|\). Let
\(r_j=1-W_{jj}=\sum_{k\ne j}W_{kj}\le q\).
From \(DW=I-W\),
\[
 |D_{ij}|\le r_j+2r_j\beta\le q+2q\beta,
 \qquad \beta\le\frac q{1-2q}\le\frac16.
\]
From the diagonal of \(BW=I\),
\[
 B_{ii}-1\ge\frac{(1-\beta)r_i}{1-r_i}\ge r_i/2.
\]
Every \(k_i\in K\) obeys the original simplex replacement bound
\(|(BQ)_{ji}|\le1\), in particular \((BQ)_{ii}\le1\).
Since \(Q_{ii}\ge1-\rho\), \(B_{ii}\le1+\beta\), and off-diagonal
\(B_{ij}\ge-\beta\), this gives
\(B_{ii}-1\le\rho(B_{ii}+\beta)\le2\rho\).
Hence \(r_i\le4\rho\). Reapply the same inverse estimate with this
improved column loss:
\[
 \beta\le\frac{4\rho}{1-8\rho}\le8\rho,
 \qquad B_{ij}\ge-8\rho.
\]
By affine averaging all \(S\)-coordinates of every point of \(P\) are
therefore at least \(-8\rho\). The centered dilation
\(z_S+(1+\tau)(S-z_S)\) is exactly the set whose \(S\)-coordinates are
at least \(-\tau/n\). Taking \(\tau=8n\rho\) yields
\[
 E(K,S)\le8n\rho\qquad(\rho\le1/(16n)).\tag{14}
\]
For \(\rho>1/(16n)\), the universal bound \(E\le n\) gives instead
\(E<16n^2\rho\). Thus for all \(\rho\ge0\),
\[
 E(K,S)\le16n^2\delta^{1/(d-1)}.\tag{15}
\]
The determinant selection calculation, arbitrary prescribed inverse
bootstrap, comparison simplex construction and exact centered dilation
are fully implemented in `StochasticSimplexBootstrap` and
`RelativeSimplexRetention`. The comparison simplex is only a volume
competitor; it does not replace \(S\). Equations (14)--(15) include
\(\rho=0\) and the local gate's equality endpoint.

## 7. Assemble all defect branches and the dimension coefficient

For \(0\le e\le H^{-1}\), equations (12)--(15) imply
\[
 E(K,S)\le16n^2H^{1/(d-1)}e^{1/(d-1)}.
\]
For \(e>H^{-1}\), the same estimate follows from \(E\le n\) and
\((He)^{1/(d-1)}\ge1\). At \(e=0\) the cap root is zero and the
same formulas give \(E\le0\); no division by the defect, cost or cap
parameter occurs anywhere.

For the elementary uniform coefficient, \(H_3=8640\le144^2\), and
\(H_{d+1}\le64H_d\) for \(d\ge1\). The latter follows directly from
\((d+1)/d\le2\), \((d+2)/(d+1)\le3/2\), and
\((d+3)/(d+2)\le4/3\) in the formula
\(H_d=3d^2(d+1)^3(d+2)\); their squared/cubed/product upper bound is
18, hence at most 64. Induction gives \(H_d\le144^{d-1}\) for \(d\ge3\).
Since \(n\le4d/3\),
\[
 16n^2H^{1/(d-1)}\le16\frac{16}{9}d^2\,144=4096d^2.
\]
`QuadraticScalarAssembly` proves each scalar step, and
`QuadraticMainResearch` constructs the packet, invokes its relative
deficit, obtains cap points, applies retention to exactly the affine image
of the original \(S\), and rewrites the stored original excess and defect
equalities. This finishes the theorem for the original body and the
original centroid of every original prescribed maximum simplex.

Combined with the independently proved truncation obstruction supplied in
the input, the deficit exponent \(1/(d-1)\) is sharp. This continuation
does not claim the dimension order \(d^2\) is sharp, or a first-discovery
priority claim. Its improvement over the original `1/d` estimate is the
deficit exponent itself, with the additional explicit quadratic coefficient.

## 8. Completed verification and retained artifacts

All 27 mathematical modules and the three audit modules have strict author
compilation evidence under Lean 4.34.1, commit
`5045d0056413266e57c625dcd7c365b10e377c52`, with
`autoImplicit=false`, `maxSynthPendingDepth=3`, and `warningAsError=true`.
The complete audit enumerates all **131 public proofs**; each has exactly
`[propext, Classical.choice, Quot.sound]`. Its compiled literal-input example
supplies only `d>=3`, `K`, `S`, and the actual maximum-simplex hypothesis.
All new mathematical source bodies were checked for the absence of `sorry`,
`admit`, `axiom`, `opaque`, `unsafe`, `native_decide`, and `sorryAx`.

Recursive source closure resolves **4,759** unique source modules, with
exactly one provider for each import. The **139 frozen formal sources**
remain byte-identical. The full source-closure report SHA-256 is
`7de13154c8efa708c9f99bd4e3ff1176323a4d923a4099f3b39e9a64f4543775`;
the packaged summary and read-only script reproduce the report from the
explicit pinned external source inputs. The source-only check does not
pretend to be kernel replay.

The actual command `leanchecker --fresh --verbose
Entry005.QuadraticMainResearch` completed with **return code 0**. It started
at `2026-10-07T22:52:42.471697+00:00` and finished at
`2026-10-07T23:00:23.953554+00:00`. This replays the entire new Main import
closure into the pinned Lean kernel's actual empty environment, whose
default trust level is 0. It created no new object cache. This is a kernel
replay using Lean's own implementation; **no external independent checker
implementation is claimed**. The checker log SHA-256 is
`25df0d7af4aac822c297b03d29b19a10b6d5b8f1e5c2b01677e61b5c41690649`.

Both separate read-only integration reviews passed. They checked the fixed
law/subsequence/assignment, actual projection-volume convention, original
defect, original simplex and centroid, zero defect, and inclusive threshold
endpoints. After an environment-disconnection notification, actual tool
read/write and a fresh Lean import/axiom probe succeeded; that result is
saved in `evidence/environment-recovery-probe.json`.

The earlier 38-file readable checkpoint patch remains unchanged at SHA-256
`21ebb054c90a1f4555c046bac2154089f0e38aa5b56700262bf7171e9e2e13d0`.
The new complete package is a separate readable exact patch. Its packaging
script checks fresh `git apply --check`, applies it in a new temporary
directory, and verifies every restored byte against its manifest. Source
and proof completion do not depend on private Page or Library delivery;
the pending Page write was not retried, and no new external write,
publication, push or author contact was attempted.
