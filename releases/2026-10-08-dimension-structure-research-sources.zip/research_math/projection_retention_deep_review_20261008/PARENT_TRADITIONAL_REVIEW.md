# Traditional review of the full-projection structure series

8 October 2026. PASS at the versions bound in REVIEW_BINDING.json. This is
an independent reading of the geometric arguments by the parent research
worker and a source/integration review, not formalization or kernel replay.
The parent supplied the uniform rho<=1/3 scalar refinement; that addition
was independently checked by the originating projection worker before it
was incorporated. The parent does not present its own contribution as an
independently authored result.

## Main proofs reviewed

1. The separator-parallel projection removes one simplex vertex by sending
   it into an opposite old edge, while the other d projected vertices remain
   affinely independent. Transversality to the deleted vertex's opposite
   facet proves this even when affine values coincide. The descended
   separating functional remains nonconstant.
2. The elementary cyclic-permutation centroid cap covers the simplex by
   m+1 measure-preserving images. Homothety about a point of the projected
   simplex supplies the stated cap fraction. A strictly absent core point
   gives an additional positive-volume strip, so the final comparison is
   strict and the non-strict threshold endpoint is valid.
3. The stronger centroid-cap proof using Brunn--Minkowski was checked:
   R(u)=Pr(L(X)>=u)^(1/m) is concave and decreasing; its inverse is concave
   and decreasing. The probability-integral transform and Jensen give
   Pr(L(X)>=E L(X))>=(m/(m+1))^m with the stated direction. The bounded,
   nonconstant scalar distribution is continuous, so no atom is silently
   passed through this transform. The constant case is separate.
4. The face-depth direction merges two vertices outside the selected
   barycentric coordinate set. The projected body is an actual simplex,
   the selected coordinate sum retains exactly r of its d coordinates,
   and the exact beta/binomial omitted fraction follows. The Bernoulli
   event supplies F(s)>=s^r, and the facet integral estimate has the stated
   endpoint restrictions. No unsupported independence of simplex
   barycentric coordinates is used.
5. The stronger finite spectrum deletes the second-largest affine-value
   vertex. The remaining zero-apex simplex cap contains the coordinate-
   edge simplex with exact product of intercepts. The denominator estimate
   uses the second-largest value to bound the active-coordinate average,
   then AM--GM and a one-variable maximum. It does not claim that every
   formal optimizer occurs in every geometric active regime.
6. For rho<=1/3, all dimensions share the same top-spectrum branch.
   For l>=2, f_l=(1-1/l)^(1-1/l) increases and comparison reduces to
   x 3^(-(x-1))<=1 for x=m/l>=1. The l=1 comparison follows from
   m 3^(1-m)<=2/3<1/sqrt(2)<=f_m. Thus tau=gamma_d rho, with gamma_d->1,
   uniformly on the stated range. The core parameter is at most 2/3,
   so the geometric positive-core gate is automatically satisfied.

## Scope and actual-e integration

The inscribed comparison simplex T has the enclosing simplex's centroid.
Its exact excess bound t/(1-t) follows from homothety. Neither source
identifies T with a prescribed maximum simplex or changes the original
maximal-simplex target. The actual-e substitution uses only the retained
all-direction relative projection chain, with its explicit small-defect
range and H_d. The full face hierarchy is necessary, not sufficient, for
projection closeness; its use to reject thin finite hulls is valid.

The elementary and sharper core proofs include delta=0 through a closed
limit, and their positive-core threshold endpoints through strict
separation. The hierarchy includes the zero and unit depth endpoints by
its exact polynomial. The vertex case is correctly separated from the
positive-dimensional face statement.

## Exact checks

- Replayed the supplied beta/binomial polynomial checker in a separate
  directory: all 189 identities passed, and its JSON output is byte-for-
  byte identical to the source output.
- Independently checked the uniform top-spectrum branch at rho=1/3 by
  integer/rational powered inequalities for 2<=m<=40 and every 1<=l<m:
  780 exact comparisons passed. This is a finite check; the proof for all
  m is the monotonicity argument above.

No unrestricted Cn rho maximum-simplex retention theorem or superlinear
actual-defect lower example is established by this series. Its positive
contribution is the stronger full-projection geometry and an exact,
sharply separated description of what the original retention problem
still requires.
