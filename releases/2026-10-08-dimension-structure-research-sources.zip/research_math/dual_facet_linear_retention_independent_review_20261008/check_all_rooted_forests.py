#!/usr/bin/env python3
"""Independent fraction-free determinants versus full rooted-forest products."""
from fractions import Fraction as F
from itertools import combinations
from math import lcm, prod
from pathlib import Path
import json

CASES=[[-1,2,2],[-3,2,1],[-1,-2,3],[-1,-2,3,3],[-2,-5,7,3],[-1,-2,-3,4,4,4],[-1,-4,2,5,5,0],[-1,-2,-3,1,2,4,4],[-2,7,7,7,7],[-3,-1,0,0,5],[-9,1,1,1],[-1,-1,-1,3,3,0]]

def bareiss_columns(cols):
    n=len(cols)
    denominators=[lcm(*(x.denominator for x in col)) for col in cols]
    a=[[int(cols[j][i]*denominators[j]) for j in range(n)] for i in range(n)]
    sign=1;last=1
    for k in range(n-1):
        j=next((j for j in range(k,n) if a[j][k]),None)
        if j is None:return F(0)
        if j!=k:a[j],a[k]=a[k],a[j];sign=-sign
        pivot=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator=pivot*a[i][j]-a[i][k]*a[k][j]
                assert numerator%last==0
                a[i][j]=numerator//last
        for i in range(k+1,n):a[i][k]=0
        last=pivot
    return F(sign*a[-1][-1],prod(denominators))

def forest_product(cols,tags,n):
    edges=[[] for _ in range(n)];roots=set()
    for j,tag in enumerate(tags):
        if tag[0]=='root':roots.add(tag[1])
        else:
            a,b=tag[1:];edges[a].append((b,j));edges[b].append((a,j))
    visited=set();out=F(1)
    for start in range(n):
        if start in visited:continue
        stack=[start];vertices=[];degree=0
        while stack:
            u=stack.pop()
            if u in visited:continue
            visited.add(u);vertices.append(u);degree+=len(edges[u])
            stack.extend(v for v,_ in edges[u] if v not in visited)
        component_roots=[u for u in vertices if u in roots]
        if degree//2!=len(vertices)-1 or len(component_roots)!=1:return F(0),False
        root=component_roots[0];stack=[(root,-1)]
        while stack:
            u,parent=stack.pop()
            for v,j in edges[u]:
                if v==parent:continue
                out*=cols[j][v]
                stack.append((v,u))
    return out,True

reports=[]
for values in CASES:
    n=len(values);I=[i for i,a in enumerate(values) if a<0];J=[i for i,a in enumerate(values) if a>0];Z=[i for i,a in enumerate(values) if a==0]
    B=max(values);Jstar={i for i in J if values[i]==B}
    D=prod((F(B,B-values[i]) for i in I),start=F(1))
    cols=[];tags=[]
    for j in J+Z:
        cols.append([F(int(i==j)) for i in range(n)]);tags.append(('root',j))
    for i in I:
        for j in J:
            a=-values[i];b=values[j];col=[F(0)]*n;col[i]=F(b,a+b);col[j]=F(a,a+b)
            cols.append(col);tags.append(('edge',i,j))
    counts={'total':0,'singular':0,'rooted_forest':0,'maxima':0,'strict_nonmax_forests':0}
    for indices in combinations(range(len(cols)),n):
        selected=[cols[i] for i in indices];selected_tags=[tags[i] for i in indices]
        determinant=abs(bareiss_columns(selected));expected,is_forest=forest_product(selected,selected_tags,n)
        assert determinant==expected,(values,indices,determinant,expected)
        assert (determinant>0)==is_forest
        counts['total']+=1
        if not is_forest:counts['singular']+=1;continue
        counts['rooted_forest']+=1
        structural_max=all(('root',j) in selected_tags for j in J+Z) and all(sum(tag[0]=='edge' and tag[1]==i and tag[2] in Jstar for tag in selected_tags)==1 for i in I)
        assert determinant<=D
        assert (determinant==D)==structural_max
        counts['maxima' if structural_max else 'strict_nonmax_forests']+=1
    reports.append({'values':values,**counts})
output={'status':'PASS','method':'Independent integer Bareiss elimination after column denominator clearing, compared with every full rooted-forest product and equality classification.','cases':reports,'totals':{key:sum(c[key] for c in reports) for key in reports[0] if key!='values'}}
Path(__file__).with_name('INDEPENDENT_FOREST_CHECKS.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output['totals']))
