# Independent traditional review of the four-part few-facet series

8 October 2026. Verdict: **PASS** for the exact mathematical source versions
bound in `REVIEW_BINDING.json`. No substantive mathematical gap was found.
This is an independent traditional proof review with exact rational/integer
cross-checks. It is not Lean formalization, compilation, kernel replay, or
an external-publication claim.

## 1. Scope and conclusions reviewed

The reviewed source directory is
`research_math/dual_facet_linear_retention_20261008/`.

1. `CLIPPED_SIMPLEX_EXACT_RETENTION.md`: for every full-dimensional one-cut
   simplex K=P intersect H, every original prescribed maximum S satisfies
   E(K,S)<=n rho_*. The vertex maxima, all nonvertex maxima, and exact
   original-centroid excess are classified.
2. `ONE_CORNER_ARBITRARY_BODY.md`: every convex K between an opposite facet
   and P has the stated exact maximum-simplex form and E<=n rho.
3. `FEW_FACET_DIMENSION_ASYMPTOTICS.md`: for K with at most d+2 facets,
   E<=n H_d^(1/(d-1)) e^(1/(d-1))<=192d e^(1/(d-1)); the exponent is sharp
   and the optimal dimensional coefficient divided by d tends to one.
4. `FEW_FACET_COFACTOR_DEFECT.md`: exact actual a, e, and delta formulas
   from the d+2 signed maximal facet cofactors, the concentration identity,
   and the explicit clipping, truncation, and square-pyramid specializations.

The review also inspected the cited finite-facet bridge in Section 5 of
`vertex_excess_sharp_exponent_20261008/SHARP_VERTEX_EXCESS_EXPONENT.md`,
the actual enclosure/cap/scalar formulas in the retained quadratic report,
and the realized square-pyramid calculations in Sections 1--3 of
`dimension_stability_investigation_20261007/obstructions.md`. It did not
re-prove or recompile the already validated entire actual-body chain.

## 2. Clipping and rooted-forest proof

The listed old and crossing-edge vertices are complete. The f_i=0 vertices
are mandatory in a full-dimensional vertex simplex, because only their own
columns have a nonzero corresponding coordinate. Positive f-values exist
by full dimension whenever any negative value exists.

Row scaling turns crossing-edge columns into weighted incidence columns.
The exact nonzero-determinant criterion is a rooted forest with exactly one
selected good-vertex root in each component. Counting the columns separately
in each component correctly excludes both unrooted components and cyclic or
multiple-root components. Leaf elimination gives the full product formula,
including the weights of nonroot good vertices.

Every bad-vertex factor is at most t_i, and every nonroot good factor is
strictly less than one. Therefore equality occurs exactly when every good
vertex is retained as a root and each bad vertex attaches directly to a
maximal positive f-value. This proves both the upper determinant bound and
its full equality classification; no omitted graph type can give another
maximum.

One initial wording said that the columns "span" the component precisely
for a rooted tree. Spanning alone would allow dependent extra columns. The
author corrected this to "form a basis". The corrected sentence and the
following count are valid, and the bound source hash reflects that fix.

## 3. Arbitrary maximum simplices and their original centroids

Representing each original S-vertex by a finite convex combination of
polytope vertices and sampling independently is legitimate. Equality in

    |E determinant| <= E |determinant| <= D_*

forces every positive-probability sampled tuple to be a vertex maximum
with the same orientation. For a mandatory vertex, independent avoidance
would have positive probability unless one column selects it surely.
The same argument for each disjoint bad-vertex group forces a unique
remaining column into that group. This yields the exact form of the same
prescribed S, including continuous nonvertex tie cases. Only relabeling
occurs; there is no replacement by a preferred maximum.

The displayed inverse barycentric formulas were checked directly. Every
possible negative coordinate occurs at a crossing-edge vertex and is
exactly one of the terms in formula (10). Monotonicity in the other good
vertex's positive f-value gives B_(-j), and convexity then covers all of K.
The exact threshold alpha_i>=-u/n for dilation about S's own original
centroid proves E=n beta. The zero-second-positive-value case, unique top,
tied tops, and zero f-coordinates are all covered.

The claimed coefficient n is attained by the equal-intercept one-vertex
truncation, a vertex maximum, and a second truncated edge. The d>=2
restriction in the sharpness statement supplies that second edge.

## 4. Arbitrary one-corner bodies

The universal cap body L has maximum volume t V(P). Compactness supplies
an actual q in K at the maximum lambda_0=t, and the hypothesis that the
entire opposite facet belongs to K provides a simplex of that volume
inside K. Thus a prescribed maximum of K is also a maximum of L, so the
complete preceding classification applies literally to it. The subsequent
barycentric calculation gives alpha_j>=-q_j>=-rho. It does not assume
polyhedral K or that q is an extreme point of K. The t=1 branch correctly
forces K=P.

The actual-defect corollary is explicitly conditional on the produced P
having the required opposite facet inside K; it does not silently assert
that condition for general K or general anchors.

## 5. Finite-facet interface and original actual-e theorem

The finite-facet bridge normalizes the original prescribed S, uses actual
irredundant K facets, and places the actual normalized normal atoms in the
unit ball. Its mass, mean, support, brightness, and determinant identities
are consistent with the original defect. The anchor selection occurs in
this finite support, so the d+1 distinct anchor halfspaces are genuinely
K-facet halfspaces. This stronger facet-incidence statement is separately
justified rather than inferred from a compact-limit law.

The same intrinsic argument supplies a bounded full-dimensional enclosing
simplex and the relative projection bound. The finite volume-root step
uses the standard mixed-volume first inequality and the actual finite
facet formula. At e=1/H_d the enclosure gate remains strict because
h<=1/(3d^2)<1/(2d).

With at most d+2 original facets, at most one irredundant halfspace remains
outside this chosen simplex, hence K=P intersect H. The exact clipping
retention theorem applies to the same original S. Both e=0 and e=1/H_d
are included. For larger e, E<=n gives the same global coefficient. The
scalar 192d follows from H_d^(1/(d-1))<=144 and n<=4d/3.

The square-pyramid body has the claimed d+2 explicit irredundant facets.
Its selected S is maximum by the mandatory pyramid-apex and equal square-
triangle determinant argument, and its omitted vertex realizes E=n. The
retained actual facet/pyramid computation gives e=1/[d(d+1)], proving the
lower bound for the supremum. The exact truncated-simplex defect gives the
fixed-d sharp exponent. Both coefficient bounds divided by d converge to
one; no uniformity of a fixed-d O-term is required for this squeeze.

## 6. Cofactor formula and its specializations

The augmented facet matrix has rank d+1: the normals span the horizontal
space, and the column sum supplies the nonzero pure last-coordinate vector.
Its signed maximal cofactors give a nonzero kernel vector. Translating the
origin into K leaves those determinants unchanged and makes the last-row
entries positive, which proves that both cofactor signs occur.

Replacing the omitted-pair column by the sum of all columns proves the
cofactor-difference identity with the stated absolute values. Combining
it with the retained actual finite-facet moment identity yields a=L/T.
The pairwise absolute-value identity gives the exact signed concentration
formula, and sorting each sign class proves the weighted formula and both
bounds on epsilon. Zero cofactors and pyramid degeneracies are permitted.

For a clipped simplex, the affine-function relation and the column-sum
identity correctly give r_i+q f_i=dV. The proposed vector
(z_c,z_i)=(1,-q f_i/r_i) is exactly in the augmented kernel. The assumption
that every listed old facet remains irredundant ensures r_i>0 and prevents
a hidden division by a vanished facet area. The one-vertex truncation and
square-pyramid substitutions agree with the original actual formulas.

## 7. Exact computational checks, and what they do not prove

The original checkers were copied to a separate review directory and
executed there, without writing into the author's source directory.

- Original clipping checker: 12 cases, all 12,769 vertex tuples passed;
  the reproduced JSON is byte-identical to the author's bound report.
- Original cofactor checker: 60 balanced rational matrix cases and 32
  exact actual-truncation formula comparisons passed; its reproduced JSON
  is also byte-identical to the author's bound report.
- Independent full-forest checker: integer Bareiss elimination after
  clearing denominators separately in each column, compared against the
  entire rooted-forest product and equality classification on all 12,769
  tuples. It found 8,050 singular tuples, 4,719 rooted forests, exactly 64
  maxima and 4,655 strict nonmaximum rooted forests; every identity passed.
- Independent cofactor checker: 210 additional exact integer augmented
  matrices in dimensions 2 through 8, with 4,830 omitted-pair minor checks,
  the kernel equation, pairwise concentration identity and scalar formula.
  Every check passed.

The balanced random augmented matrices test algebra only; they are not
claimed to be realizable actual facet data. Finite examples do not prove
the all-dimensional theorem or the arbitrary nonvertex equality cases.
Those are justified by the reviewed arguments above. There was no large
compilation or external publication.

## 8. Final disposition

All four mathematical notes pass at the versions in REVIEW_BINDING.json.
The only review correction was the resolved span-versus-basis wording.
The series gives an exact and asymptotically optimal result for at most
d+2 facets and a separate arbitrary one-corner result. It accurately leaves
the unrestricted d versus d^2 coefficient gap open.
