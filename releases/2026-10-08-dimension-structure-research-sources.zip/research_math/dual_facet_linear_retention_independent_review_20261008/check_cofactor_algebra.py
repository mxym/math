#!/usr/bin/env python3
"""Independent exact algebra checks, not realizability certificates."""
from random import Random
from itertools import combinations
from fractions import Fraction as F
from pathlib import Path
import json

def determinant(a):
    a=[r[:] for r in a];n=len(a);last=1;sign=1
    for k in range(n-1):
        p=next((j for j in range(k,n) if a[j][k]),None)
        if p is None:return 0
        if p!=k:a[k],a[p]=a[p],a[k];sign=-sign
        pivot=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator=pivot*a[i][j]-a[i][k]*a[k][j]
                assert numerator%last==0
                a[i][j]=numerator//last
        for i in range(k+1,n):a[i][k]=0
        last=pivot
    return sign*a[-1][-1]

def submatrix(rows,cols):return [[row[j] for j in cols] for row in rows]
rng=Random(20261008);reports=[];pair_checks=0
for d in range(2,9):
    n=d+1;N=d+2
    for trial in range(30):
        horizontal=[]
        for _ in range(d):
            row=[rng.randint(-11,11) for _ in range(N-1)];row.append(-sum(row));horizontal.append(row)
        supports=[rng.randint(1,17) for _ in range(N)]
        U=horizontal+[supports];volume_factor=sum(supports)
        z=[(-1)**i*determinant(submatrix(U,[j for j in range(N) if j!=i])) for i in range(N)]
        if not any(z):continue
        assert all(sum(row[i]*z[i] for i in range(N))==0 for row in U)
        H=0
        for i,j in combinations(range(N),2):
            minor=determinant(submatrix(horizontal,[k for k in range(N) if k not in (i,j)]))
            assert volume_factor*abs(minor)==abs(z[i]-z[j]),(d,trial,i,j,z,minor)
            H+=abs(minor);pair_checks+=1
        L=sum(abs(v) for v in z)
        difference_sum=sum(abs(z[i]-z[j]) for i,j in combinations(range(N),2))
        same_sign=sum(min(abs(z[i]),abs(z[j])) for i,j in combinations(range(N),2) if z[i]*z[j]>0)
        assert difference_sum==n*L-2*same_sign
        assert difference_sum==volume_factor*H
        assert F(n)-F(difference_sum,L)==F(2*same_sign,L)
        reports.append({'d':d,'trial':trial,'column_count':N,'L':L,'H':H,'volume_factor':volume_factor})
result={'status':'PASS','scope':'Algebra identities for exact integer columns with horizontal sum zero and positive last row; not a geometric realization or independent verification of the actual facet/pyramid moment identity.','cases':len(reports),'pair_minor_checks':pair_checks,'records':reports}
Path(__file__).with_name('INDEPENDENT_COFACTOR_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='records'}))
