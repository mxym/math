#!/usr/bin/env python3
"""Finite rational certificate checks; not the proof of the general theorem."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json

def det(A):
    A=[list(r) for r in A]; n=len(A); z=F(1)
    for i in range(n):
        p=next((k for k in range(i,n) if A[k][i]),None)
        if p is None:return F(0)
        if p!=i:A[p],A[i]=A[i],A[p];z=-z
        v=A[i][i];z*=v
        for k in range(i+1,n):
            r=A[k][i]/v
            for j in range(i+1,n):A[k][j]-=r*A[i][j]
    return z

def inv(A):
    n=len(A); A=[list(r)+[F(i==j) for j in range(n)] for i,r in enumerate(A)]
    for i in range(n):
        p=next(k for k in range(i,n) if A[k][i]);A[i],A[p]=A[p],A[i]
        v=A[i][i];A[i]=[x/v for x in A[i]]
        for k in range(n):
            if k!=i:
                v=A[k][i];A[k]=[x-v*y for x,y in zip(A[k],A[i])]
    return [r[n:] for r in A]

def rows(cols):return list(map(list,zip(*cols)))
def unit(n,i):return [F(i==j) for j in range(n)]
def matvec(A,x):return [sum(a*b for a,b in zip(r,x)) for r in A]

def check(values):
    f=list(map(F,values));n=len(f)
    I=[i for i,x in enumerate(f) if x<0];J=[i for i,x in enumerate(f) if x>0];Z=[i for i,x in enumerate(f) if x==0]
    B=max(f);top=[j for j in J if f[j]==B]
    verts=[];tags=[]
    for j in J+Z:verts.append(unit(n,j));tags.append(('retained',j))
    for i in I:
        for j in J:
            a=-f[i];b=f[j];v=[F(0)]*n;v[i]=b/(a+b);v[j]=a/(a+b)
            verts.append(v);tags.append(('edge',i,j))
    expected=F(1)
    for i in I:expected*=B/(B-f[i])
    found=[];total=0;largest=F(0)
    for inds in combinations(range(len(verts)),n):
        total+=1;v=abs(det(rows([verts[k] for k in inds])));largest=max(largest,v)
        pred_tags=[tags[k] for k in inds]
        predicted=all(('retained',j) in pred_tags for j in J+Z) and all(sum(t[0]=='edge' and t[1]==i and t[2] in top for t in pred_tags)==1 for i in I)
        assert (v==expected)==predicted,(f,inds,v,expected,predicted)
        if v==expected:found.append(inds)
    assert largest==expected
    rho=max((-f[i])/(B-f[i]) for i in I)
    samples=[]
    # Check each vertex maximum, and two different genuine nonvertex mixtures.
    allcols=[[verts[k] for k in inds] for inds in found]
    for mode in range(2):
        cols=[unit(n,j) for j in J+Z]
        for i in I:
            a=-f[i];v=[F(0)]*n;v[i]=B/(a+B)
            weights=[F(1,len(top))]*len(top) if mode==0 else [F(k+1,sum(range(1,len(top)+1))) for k in range(len(top))]
            for j,z in zip(top,weights):v[j]=a/(a+B)*z
            cols.append(v)
        allcols.append(cols)
    for cols in allcols:
        W=rows(cols);assert abs(det(W))==expected
        BI=inv(W);beta=max([F(0)]+[-c for x in verts for c in matvec(BI,x)])
        # Match each bad-coordinate column by its unique positive bad coordinate.
        predicted_beta=F(0)
        for i in I:
            a=-f[i];col=next(c for c in cols if c[i]>0)
            for j in top:
                z=col[j]*(a+B)/a
                Bminus=max([f[h] for h in J if h!=j]+[F(0)])
                predicted_beta=max(predicted_beta,z*a*Bminus/(B*(a+Bminus)))
        assert beta==predicted_beta and beta<=rho
        samples.append(str(beta))
    return {'facet_values':list(map(str,f)),'n':n,'vertices':len(verts),'vertex_tuples_checked':total,'maximum_vertex_simplices':len(found),'maximum_normalized_volume':str(expected),'rho_star':str(rho),'beta_checks':samples}

cases=[[-1,2,2],[-3,2,1],[-1,-2,3],[-1,-2,3,3],[-2,-5,7,3],[-1,-2,-3,4,4,4],[-1,-4,2,5,5,0],[-1,-2,-3,1,2,4,4],[-2,7,7,7,7],[-3,-1,0,0,5],[-9,1,1,1],[-1,-1,-1,3,3,0]]
report={'status':'PASS','scope':'exact rational finite checks only; all-dimensional proof is the companion note','cases':[check(c) for c in cases]}
out=Path(__file__).with_name('EXACT_CLIPPING_CHECKS.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':len(cases),'vertex_tuples_checked':sum(c['vertex_tuples_checked'] for c in report['cases']),'report':str(out)}))
