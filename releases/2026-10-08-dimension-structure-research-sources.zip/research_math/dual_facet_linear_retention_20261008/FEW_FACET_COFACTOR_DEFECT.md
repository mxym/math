# Exact actual-defect formula from d+2 facet cofactors

8 October 2026. Traditional research continuation. No formal verification or
independent full-series audit is claimed yet. This is a facet-count formula,
not the distinct spanning-two-forest formula for a d+2-vertex circuit.

## 1. Actual facet data and the scalar formula

Let K be a full-dimensional convex d-polytope with exactly N=d+2
irredundant facets. Put n=d+1. For its facets take outward unit normals
nu_i, actual facet areas s_i>0, and actual support numbers h_i. Set

    g_i=s_i nu_i,
    U_i=(g_i,s_i h_i) in R^(d+1),
    V=|K|>0.

The divergence identities give

    sum_i g_i=0, sum_i s_i h_i=dV,
    sum_i U_i=(0,...,0,dV).                                    (1)

The augmented matrix U has rank n. To see this, its horizontal rows have
rank d, since the facet normals span R^d. Its column sum has a nonzero last
coordinate and zero horizontal coordinates, supplying one further rank.

Define its signed maximal cofactors by

    z_i=(-1)^(i-1) det(U_1,...,U_(i-1),U_(i+1),...,U_N).          (2)

Then z is nonzero and sum_i z_i U_i=0. It has both positive and negative
entries: translate the origin to the interior of K, which leaves every
cofactor unchanged by an elementary row operation and makes all h_i>0;
then sum_i z_i s_i h_i=0 forces both signs.

Write

    L=sum_i |z_i|,
    T=sum_(i<j) |z_i-z_j|.

The exact original invariant obeys

    a(K)=L/T,
    delta(K):=n-1/a(K)=n-T/L,
    e(K)=delta(K)/[n(n-delta(K))].                              (3)

In particular no cone-law surrogate, normalized facet weight, or
unverified geometric deficit is introduced in this formula.

## 2. Proof of the cofactor-difference identity

Let H=sum_(i<j)|det(g_k:k outside {i,j})|, with the remaining columns in
increasing order. The existing actual finite-facet projection identity is

    a(K)=L/(dV H).                                              (4)

We now show directly that

    dV |det(g_k:k outside {i,j})|=|z_i-z_j|.                    (5)

Fix i<j. In the n-column matrix U with column i omitted, replace its
column U_j by sum_k U_k. Multilinearity says that only two terms survive:
the original term and the term in which U_j is replaced by U_i. Reordering
the latter columns and applying the signs in (2) gives the difference
z_i-z_j, up to an overall sign. On the other hand, by (1) the replacement
column is (0,...,0,dV). Expanding against that column gives, up to sign,
dV times the horizontal determinant with columns i,j omitted. Taking
absolute values proves (5). Summing (5) gives dV H=T, so (4) proves (3).
All denominators are positive by full dimension and L>0.

## 3. The defect is a signed concentration statistic

For real x,y,

    |x|+|y|-|x-y| = 2 min(|x|,|y|) if xy>0, and is zero if xy<=0.

Since each |z_i| occurs in n of the unordered pairs,

    delta(K)=(2/L) sum_(i<j, z_i z_j>0) min(|z_i|,|z_j|).         (6)

Sort the positive entries as p_1>=...>=p_p>0 and the absolute values of
the negative entries as q_1>=...>=q_q>0. Then exactly

    delta(K)=(2/L)[sum_(i=2)^p(i-1)p_i
                         +sum_(j=2)^q(j-1)q_j].                 (7)

This gives a quantitative characterization of small actual defect. Put

    epsilon=[L-p_1-q_1]/L.

Then

    2 epsilon <= delta(K)
               <=2 max(p-1,q-1) epsilon <=2d epsilon.           (8)

Thus at least 1-delta(K)/2 of the normalized absolute cofactor mass is
concentrated on one positive and one negative entry. The exact weights in
(7), not merely this two-sided comparison, determine the deficit.

The cofactor vector is defined only up to a common nonzero scale and an
overall sign if one changes conventions; (3), (6), and (8) are unchanged.
The formula includes zero cofactors, for example those arising from
pyramid facets. It does not require a generic or simple polytope.

## 4. Explicit specialization for a clipped simplex

Suppose K=P intersect {f>=0}, where P is a d-simplex with barycentric
functions lambda_i and f=sum_i f_i lambda_i. In this section assume all
n original facets and the cut facet are irredundant facets of K. Set
f_i=-a_i<0 on I, f_j=b_j>0 on J, and allow zero f-values. Use any origin.
There are unique positive scales r_i and q such that the actual augmented
area/support columns are

    U_i=r_i(-grad lambda_i,lambda_i(0)),
    U_c=q(-grad f,f(0)).

Because sum lambda_i=1 and sum U_i+U_c=(0,dV), linear independence of the
n affine barycentric functions gives

    r_i+q f_i=R, where R=dV>0.                                 (9)

In particular r_i=R-q f_i>0. The affine-function identity for f says that
a valid signed cofactor vector, up to common scale, is

    z_c=1, z_i=-q f_i/r_i.                                     (10)

Define

    alpha_i=q a_i/(R+q a_i) in (0,1) (i in I),
    beta_j=q b_j/(R-q b_j)>0        (j in J).

Then (6) becomes the particularly short exact formula

    delta(K)=2[sum_i alpha_i
                   +sum_(i<i')min(alpha_i,alpha_i')
                   +sum_(j<j')min(beta_j,beta_j')]
               /[1+sum_i alpha_i+sum_j beta_j].                (11)

Zero f-values contribute zero cofactors. Strict positivity of every r_i
is why the irredundancy assumption was stated explicitly; a clipping that
removes an entire old facet must first delete that redundant facet, rather
than divide by its vanished area.

For the equal-intercept one-vertex truncation

    K_t={x_i>=0, t<=sum_i x_i<=1}, 0<t<1,

formula (10) can be normalized to

    z_c=1, z_0=t^d,
    z_1=...=z_d=-beta,
    beta=t^(d-1)(1-t)/(1-t^(d-1)).

Indeed the original opposite facet has its full old area, each other old
facet retains the fraction 1-t^(d-1), and the cut area scale retains the
fraction t^(d-1). Hence

    delta(K_t)=2[t^d+binom(d,2)beta]/[1+t^d+d beta].              (12)

Substitution into the last identity of (3) reproduces the exact original
one-vertex-truncation formula and its leading term

    e(K_t)=[d(d-1)/(d+1)^2] t^(d-1)+O(t^d).

For a square followed by d-2 pyramids, the four nonzero cofactors are
proportional to (1,-1,1,-1), and the other d-2 cofactors are zero. Equations
(3) or (6) immediately give delta=1 and e=1/[d(d+1)], agreeing with the
independent actual facet and pyramid calculations already retained.

## 5. What this does and does not establish

This formula supplies exact original-defect calculations and a quantitative
signed-cofactor rigidity principle for the entire d+2-facet class. Together
with the independent rooted-forest maximum-simplex classification for a
single clipping, it gives a compact pair of exact geometric and invariant
parameterizations. It does not by itself optimize the sharp all-scale
constant in (1) of `FEW_FACET_DIMENSION_ASYMPTOTICS.md`, and it makes no
claim about arbitrary facet counts or arbitrary bodies.
