#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from random import Random
import json
from check_exact_clipping import det,rows
rng=Random(371902)
checks=[]
for d in range(2,7):
    N=d+2
    for seed in range(12):
        G=[[F(rng.randrange(-7,8)) for i in range(N-1)] for k in range(d)]
        for r in G:r.append(-sum(r))
        heights=[F(rng.randrange(1,9)) for i in range(N)]
        U=G+[heights]
        z=[(-1)**i*det([[r[k] for k in range(N) if k!=i] for r in U]) for i in range(N)]
        if not any(z):continue
        sv=sum(heights)
        for i,j in combinations(range(N),2):
            h=det([[r[k] for k in range(N) if k not in (i,j)] for r in G])
            assert sv*abs(h)==abs(z[i]-z[j])
        L=sum(map(abs,z));T=sum(abs(x-y) for x,y in combinations(z,2))
        gap=(N-1)-T/L
        pair=2*sum(min(abs(x),abs(y)) for x,y in combinations(z,2) if x*y>0)/L
        assert gap==pair>=0
        pos=sorted([x for x in z if x>0],reverse=True);neg=sorted([-x for x in z if x<0],reverse=True)
        eps=(L-pos[0]-neg[0])/L
        assert 2*eps<=gap<=2*max(len(pos)-1,len(neg)-1)*eps
        checks.append({'d':d,'seed':seed,'cofactor':list(map(str,z)),'gap':str(gap),'epsilon':str(eps)})
trunc=[]
for d in range(2,10):
    for t in [F(1,10),F(1,3),F(1,2),F(4,5)]:
        b=t**(d-1)*(1-t)/(1-t**(d-1))
        gap=2*(t**d+F(d*(d-1),2)*b)/(1+t**d+d*b)
        e=gap/((d+1)*(d+1-gap))
        old=t**(d-1)*(d*(d-1)-(d+1)*(d-2)*t-2*t**d)/((d+1)*(1-t**d)*(d+1+(d-1)*t**(d-1)))
        assert e==old
        trunc.append({'d':d,'t':str(t),'e':str(e)})
report={'status':'PASS','scope':'algebraic exact checks on balanced rational matrices; actual-polytope meaning comes from the written facet proof','balanced_matrix_cases':checks,'actual_truncation_cases':trunc}
p=Path(__file__).with_name('EXACT_COFACTOR_CHECKS.json');p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','balanced_matrix_cases':len(checks),'actual_truncation_cases':len(trunc)}))
