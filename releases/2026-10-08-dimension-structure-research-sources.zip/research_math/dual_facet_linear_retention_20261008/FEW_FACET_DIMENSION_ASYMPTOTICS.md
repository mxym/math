# Asymptotically optimal dimension coefficient for at most d+2 facets

8 October 2026. Traditional research continuation, not yet independently
audited or formalized. The new exact retention theorem is in
`CLIPPED_SIMPLEX_EXACT_RETENTION.md`. No frozen proof or public artifact
has been changed.

## Main theorem

Let d>=3, n=d+1, m=d-1, and H_d=3d^2(d+1)^3(d+2). For every full-dimensional
convex d-polytope K with at most d+2 facets and every prescribed
maximum-volume inscribed simplex S, the original Entry005 invariant and
original-centroid excess satisfy

    E(K,S) <= (d+1) H_d^(1/(d-1)) e(K)^(1/(d-1))
            <=192d e(K)^(1/(d-1)).                              (1)

The exponent 1/(d-1) is sharp already in this facet-count class. More
strongly, if

    G_d^fac = sup E(K,S)/e(K)^(1/(d-1)),

where the supremum ranges over this class, all prescribed maximum S,
and e(K)>0, then

    (d+1)[d(d+1)]^(1/(d-1)) <= G_d^fac
                            <= (d+1)H_d^(1/(d-1)),              (2)

and hence

    lim_(d to infinity) G_d^fac/d = 1.                          (3)

Thus the leading dimensional constant is determined for this entire
few-facet class. This does not close the unrestricted O(d) versus O(d^2)
gap and does not optimize G_d^fac for each fixed dimension.

## 1. The exact original quantities

For a body L of dimension r write R(L)=V(Pi L)/V(L)^(r-1), with the actual
canonical projection body and actual Euclidean volume. The deficit is

    e(K)=(d/(d+1))^d R(pyr K)/R(K)-1-1/(d+1).

The excess is the infimum of u>=0 such that K is contained in
z_S+(1+u)(S-z_S), where z_S is the original centroid of the prescribed
S. These are the original Entry005 quantities, not surrogate deficits.

The retained actual finite-facet enclosure chain says that if
0<=e(K)<=H_d^(-1), there is an enclosing simplex P obtained by selecting
exactly d+1 distinct irredundant K-facet halfspaces and satisfying

    pi_P(v)-pi_K(v)<=H_d e(K) pi_P(v) for every unit v.            (4)

This specific facet-supported finite-law statement is proved in Section 5
of `vertex_excess_sharp_exponent_20261008/SHARP_VERTEX_EXCESS_EXPONENT.md`.
It is not silently inferred from the compact-limit Lean theorem.

For clarity, its actual finite law has atoms X_F=n_F/h_F and probabilities
p_F=|F|h_F/(d|K|). Its determinant defect identity is exactly
(B-A)/B=n e/(1+n e). The seminorm assignment chooses anchors in this
finite support, so their polar halfspaces are actual irredundant facets.
The same intrinsic brightness and volume-root argument gives (4), with
H_d as displayed. The strict enclosure gate still holds at e=H_d^(-1).
No arbitrary cone law is substituted for the actual finite-facet law.

## 2. Apply exact clipped-simplex retention

A full-dimensional polytope has at least d+1 facets. If K has exactly
d+1 facets, it is a simplex and E=e=0. Otherwise it has d+2 facets.
The P from (4) uses d+1 of them, so

    K=P intersect H

for the one remaining K-facet halfspace H. If the extra halfspace is
redundant relative to P the same argument includes K=P.

Put rho=(H_d e(K))^(1/(d-1)). The exact affine projection-cap argument
in the retained chain gives

    1-max_(x in K) lambda_i^P(x)<=rho for every i.                (5)

The new clipped-simplex theorem now applies to this same prescribed S,
not to a selected or reoptimized maximum. It gives directly

    E(K,S)<=(d+1)rho,

including e=0 and e=H_d^(-1). For e>H_d^(-1), the universal estimate
E(K,S)<=d+1 gives the same inequality because rho>1. This proves the
first inequality in (1) at all scales. The previously established scalar
bound H_d^(1/(d-1))<=144 and d+1<=4d/3 give the second inequality.

## 3. Sharp exponent and leading dimension coefficient

The equal-intercept vertex-truncated simplex

    K_t={x_i>=0, t<=sum_i x_i<=1}, 0<t<1,

has exactly d+2 facets and has vertex maxima S_t with E(K_t,S_t)=(d+1)t.
The retained exact actual-defect formula gives

    e(K_t)=[d(d-1)/(d+1)^2] t^(d-1)+O(t^d) as t down to zero.

Thus no exponent larger than 1/(d-1) can hold uniformly in this class,
for any fixed d and any dimension-dependent constant.

For the stronger all-scale lower coefficient use the already realized
square-pyramid family

    C_d=conv(0,e_1,e_2,e_1+e_2,e_3,...,e_d),
    S_d=conv(0,e_1,...,e_d).

C_d has exactly d+2 facets: the four square facets acquire one additional
facet under each of d-2 pyramids. Equivalently, its explicit irredundant
inequalities are x_i>=0 (i=1,...,d),
x_1+sum_(i=3)^d x_i<=1, and x_2+sum_(i=3)^d x_i<=1.
Every full-dimensional vertex simplex contains the pyramid vertices and
three square vertices, so S_d is maximum. Its omitted square vertex has
S_d-coordinates (-1,1,1,0,...,0), giving E(C_d,S_d)=d+1. The original
actual invariant has e(C_d)=1/[d(d+1)], as established by the exact facet
and pyramid computations in the retained dimension-obstruction note.
This proves the left inequality in (2).

Finally H_d is a fixed polynomial in d, so H_d^(1/(d-1))->1, and likewise
[d(d+1)]^(1/(d-1))->1. Dividing (2) by d and squeezing proves (3).
No unstated uniformity in an O-term is needed.

## Sources and scope

- `research_math/quadratic_dimension_candidate_cloud_report_20261007.md`:
  original invariant, actual enclosure chain, cap theorem, universal E<=n,
  and scalar H_d^(1/(d-1))<=144.
- `research_math/vertex_excess_sharp_exponent_20261008/SHARP_VERTEX_EXCESS_EXPONENT.md`,
  Section 5: finite-facet specialization supplying actual facet selection.
- `research_math/dimension_stability_investigation_20261007/obstructions.md`,
  Sections 1--3: the realized square-pyramid invariant and lower coefficient.
- `CLIPPED_SIMPLEX_EXACT_RETENTION.md`: new all-dimensional exact retention,
  complete classification of arbitrary maxima, and exact excess formula.

No numerical computation is used to justify (1)--(3). No external paper
is being claimed as a proof of the new geometric theorem, and no novelty
or priority claim is made.
