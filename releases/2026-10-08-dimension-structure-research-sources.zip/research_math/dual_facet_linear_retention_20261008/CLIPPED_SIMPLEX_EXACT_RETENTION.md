# Exact retention for a simplex clipped by one halfspace

8 October 2026. Traditional proof. This is a new research continuation; no
independent audit or formalization is claimed in this version. All simplices
below have their own original centroids. No originally prescribed maximum
simplex is replaced by a more convenient maximum.

## 1. Statement

Let P be a full-dimensional d-simplex, let H be a closed halfspace, and
suppose K=P intersect H is full dimensional. Write n=d+1 and lambda_i for
the P-barycentric coordinates. Define the exact corner loss

    rho_* = max_i [1-max_(x in K) lambda_i(x)].

Then, for every prescribed maximum-volume simplex S in K,

    E(K,S) <= n rho_*.                                           (1)

Consequently, if all corner losses are at most rho>=0, then E(K,S)<=n rho.
The coefficient n is sharp for every d>=2 and every 0<rho<1: truncate just
one vertex with equal intercept rho on all its incident edges, and choose
one of the vertex maximum simplices.

The theorem allows a single halfspace to remove any number of P-vertices,
not only one vertex. It also classifies all maximum simplices, including
nonvertex maxima, and gives their exact excess in Section 5.

## 2. Vertices and the candidate maximum

Use affine P-coordinates, so P=conv(e_1,...,e_n) in sum x_i=1. Write H as
f(x)>=0, with affine values f_i=f(e_i). If no f_i is negative, K=P and the
statement is immediate. Full dimension implies some f_i is positive.
Partition the indices into

    I={i:f_i=-a_i<0}, J={j:f_j=b_j>0}, Z={z:f_z=0}.

Put B=max_(j in J) b_j>0 and J_*={j:b_j=B}. The vertices of K are precisely

    e_j (j in J union Z),
    v_ij=(b_j e_i+a_i e_j)/(a_i+b_j) (i in I, j in J).             (2)

Indeed, a new vertex of a simplex cut by one hyperplane lies on an old
edge crossing the hyperplane; all old retained vertices remain vertices.
Alternatively, the active-coordinate constraints leave at most two
positive coordinates, and the two-coordinate case gives (2).

Each z in Z is the only vertex of K with a nonzero z-coordinate. Hence
it is mandatory in every full-dimensional vertex simplex. Its column can
be expanded out of the determinant. We can therefore do the determinant
calculation on I union J, then adjoin all e_z. Set

    t_i=B/(a_i+B), s_i=a_i/(a_i+B)=1-t_i.

Fix j_* in J_*. The simplex with all retained e_j and the points v_(i,j_*)
for i in I has normalized determinant

    D_* = product_(i in I) t_i >0.                               (3)

The retained columns are standard vectors, so (3) follows by expansion.
Also

    max_K lambda_i=t_i for i in I,
    max_K lambda_j=1 for j in J union Z,
    rho_*=max_(i in I) s_i.                                     (4)

## 3. Weighted rooted forests classify all vertex maxima

Choose m=|I|+|J| columns from the nonzero-coordinate vertices in (2).
Associate v_ij with an edge between i in I and j in J, and associate a
chosen e_j with a root mark at j. Work in the graph with all m row indices,
including isolated vertices.

Multiply row i in I by a_i and row j in J by -b_j. Every edge column
becomes

    [a_i b_j/(a_i+b_j)] (e_i-e_j),

and every root column becomes -b_j e_j. Thus columns supported in a
connected component form a basis of its full coordinate space precisely when
that component is a tree with exactly one chosen root. Here is the count in
detail. An unrooted connected component has incidence rank v-1, hence
cannot contribute full rank v. A rooted connected component has rank at
most v; full independence and total column count m require exactly v
columns in every component. Since a connected graph has at least v-1
edges and at least one root is needed, it must have v-1 edges and one
root. Cyclic components or components with too many roots force a column
dependence. Conversely a rooted tree has determinant of absolute value
one for its unweighted incidence columns and its root column, by
successively eliminating leaves.

For a rooted forest, orient each edge toward its root. Direct leaf
elimination, before row scaling, gives the particularly simple formula

    |det W| = product_(nonroot vertices u) [edge-column entry at u]. (5)

A bad vertex i in I is never a root. If its parent is j in J, its factor
is b_j/(a_i+b_j)<=t_i. A nonroot good vertex j has a factor
a_i/(a_i+b_j)<1. Therefore

    |det W| <= product_(i in I) t_i = D_*.                        (6)

Equality holds if and only if:

- every good vertex is a root, so every e_j (j in J) is selected;
- each bad vertex i is joined directly to some j in J_*.

In particular all maximum vertex simplices are exactly

    conv({e_j:j in J union Z} union {v_(i,j_i):i in I}),
    with each j_i chosen independently from J_*.                 (7)

All their normalized oriented determinants are D_* when the columns are
ordered by the original bad indices and retained vertex indices. The
maximum over arbitrary points of K is also D_*, because separately
expanding the determinant in convex combinations of K-vertices bounds
its absolute value by the vertex maximum.

## 4. Every arbitrary maximum simplex has an explicit form

Let S be any prescribed maximum, and represent its vertices as convex
combinations of K-vertices. Sample these combinations independently.
The oriented determinant of S is the expectation of the sampled oriented
determinant. Equality at the maximum absolute value implies that every
positive-probability tuple is one of the maximum vertex simplices (7),
with the same orientation.

For any mandatory retained vertex e_j, if no column sampled it with
probability one, independence would give a positive probability that the
entire tuple omitted it. Thus it occupies a deterministic column. After
those columns are removed, each of the |I| disjoint vertex groups

    G_i={v_ij:j in J_*}

must be represented exactly once in every sampled tuple. The same
independence argument says that some column belongs to each G_i with
probability one. Distinct groups require distinct columns, so they account
for all remaining columns. Consequently, after relabeling only the
vertices of the same S, every maximum has the form

    S=conv({e_j:j in J union Z} union {w_i:i in I}),
    w_i=t_i e_i+s_i z_i,
    z_i in conv{e_j:j in J_*}.                                  (8)

Conversely every such simplex is maximum by the same determinant formula.
This classifies the continuous tie cases without pretending that every
maximizing simplex has polytope vertices.

## 5. Exact original-centroid excess

Write z_i=sum_(j in J_*) z_ji e_j, where z_ji>=0 and sum_j z_ji=1.
For x in the affine coordinate hyperplane, its S-coordinates are

    alpha_i(x)=(1+a_i/B)x_i                         (i in I),
    alpha_j(x)=x_j-sum_(i in I)(a_i/B)z_ji x_i      (j in J_*),
    alpha_j(x)=x_j                                 (j outside I union J_*).
                                                                    (9)

For j in J_*, put B_(-j)=max({b_h:h in J, h!=j} union {0}). Evaluating
(9) at (2), and using that b/(a_i+b) is increasing in b, gives the exact
largest negative coordinate magnitude

    beta(S)=max_(i in I, j in J_*)
             z_ji a_i B_(-j)/[B(a_i+B_(-j))].                    (10)

If B_(-j)=0, that term is zero. At an edge point v_ih with h!=j,
alpha_j=-z_ji a_i b_h/[B(a_i+b_h)]. At v_ij itself, alpha_j=s_i(1-z_ji)>=0;
all other possibly negative coordinates have the preceding form. The
retained vertices have nonnegative coordinates. Thus (10) is exact, and
convex averaging covers every point of K.

Since B_(-j)<=B,

    beta(S)<=max_i a_i/(a_i+B)=rho_*.

For an n-vertex simplex, dilation by 1+u about its original centroid is
exactly the set whose simplex coordinates are all at least -u/n. Therefore

    E(K,S)=n beta(S)<=n rho_*,

proving (1), with no change to the carrier or centroid of S.

Useful special cases of (10):

- If |J_*|>=2, then beta(S)=max_i s_i max_(j in J_*) z_ji. In particular
  every vertex maximum has E=n rho_*, while balanced nonvertex maxima can
  have strictly smaller excess.
- If J_*={j_*}, every maximum is the unique simplex with z_i=e_(j_*), and
  beta=max_i a_i B_2/[B(a_i+B_2)], where B_2 is the second-largest positive
  value, or zero if there is none.
- If |J|=1, K is itself a simplex and beta=0.

Equal-intercept one-vertex truncation has one a_i, at least two tied
positive b_j, and s_i=rho. A vertex maximum gives beta=rho, establishing
sharpness of the retention coefficient.

## 6. Audit boundaries

The proof is a direct determinant and barycentric-coordinate argument. It
uses neither numerical optimization nor an unproved inverse-minor bound.
It is unrelated to the false two-minor bounds already recorded elsewhere.
The graph here concerns vertices of a simplex clipped by a halfspace; it
must not be confused with the separate facet-normal spanning-two-forest
formula for polytopes with d+2 vertices. They are different constructions.

A rational checker accompanies this note and exhaustively enumerates
vertex determinants for selected finite examples. That checker is only a
certificate check, not a replacement for the all-dimensional proof above.
