# Few-facet and one-corner retention series

New traditional research results, 8 October 2026. The complete four-note
series now passed independent traditional review at the exact versions in
`../dual_facet_linear_retention_independent_review_20261008/REVIEW_BINDING.json`.
The mathematical source snapshots retain their pre-review headers; the
separate signed-off review records the later validation. No Lean
formalization or public change is claimed.

1. `CLIPPED_SIMPLEX_EXACT_RETENTION.md`: exact maximum-simplex volume,
   classification of every arbitrary maximum, exact original-centroid
   excess formula, and sharp all-scale E<=n rho for any single-halfspace
   clipping of a simplex. Uses weighted rooted bipartite forests.
2. `FEW_FACET_DIMENSION_ASYMPTOTICS.md`: actual Entry005 corollary for all
   d-polytopes with at most d+2 facets; E<=n H_d^(1/(d-1))e^(1/(d-1)) and
   the optimal coefficient satisfies G_d^fac/d -> 1. Sharp deficit exponent.
3. `ONE_CORNER_ARBITRARY_BODY.md`: arbitrary convex bodies containing an
   entire opposite facet, with no finite-vertex or finite-facet restriction.
   Every maximum uses that facet and a height-maximizing apex; E<=n rho.
4. `FEW_FACET_COFACTOR_DEFECT.md`: exact original-defect formula from the
   d+2 augmented facet cofactors, signed-cofactor concentration, and an
   explicit clipped-simplex parameter formula. Sixty balanced rational
   matrix tests and 32 actual truncation tests accompany the proof.
5. `check_exact_clipping.py`, `EXACT_CLIPPING_CHECKS.json`: exact rational
   checks of 12 cases, all 12,769 vertex tuples, the full equality
   classification, and vertex and nonvertex maximum excess formulas.

The unrestricted dimension gap remains linear lower versus quadratic
upper. None of these conclusions supplies an unrestricted O(d) theorem,
a superlinear actual-defect lower family, or a two-minor rigidity bound.
