# Exact retention for an arbitrary one-corner perturbation

8 October 2026. Traditional proof; no independent audit or formalization yet.
This extends the sharp retention coefficient beyond a single cutting
halfspace and beyond polytopes.

## Theorem

Let P=conv(v_0,...,v_d) be a full-dimensional simplex and let K be a convex
body with

    conv(v_1,...,v_d) subset K subset P.

Let lambda_0 be the barycentric coordinate of v_0 and put

    t=max_K lambda_0>0, rho=1-t.

Every prescribed maximum-volume simplex S of K has the exact form

    S=conv(v_1,...,v_d,q), with q in K and lambda_0(q)=t.           (1)

For that same S and its original centroid,

    E(K,S)<=(d+1)rho.                                            (2)

The constant d+1 is sharp for every d>=2 and rho in (0,1). In particular,
there is no restriction on the number, regularity, or geometry of the
other boundary pieces of K.

## Proof

If t=1, then v_0 in K by the simplex-coordinate maximum, so K=P and the
conclusion is immediate. Suppose 0<t<1 and define the universal cap body

    L={x in P:lambda_0(x)<=t}.

Then K subset L. The exact clipped-simplex theorem, applied with one bad
vertex and d tied good vertices, says that the maximum simplex volume in
L is t V(P), and its complete set of arbitrary maximum simplices is

    conv(v_1,...,v_d,q), lambda_0(q)=t, q in P.                    (3)

Compactness gives a q in K attaining t. Because the whole opposite facet
belongs to K, the corresponding simplex in (3) belongs to K and has
volume t V(P). Hence K and L have exactly the same maximum simplex
volume. Every prescribed maximum S of K is therefore one of the exact
maxima (3); its apex q is a vertex of S and belongs to K. This proves (1),
without selecting a different maximum or assuming its apex is an extreme
point of K.

Write the P-coordinate vector of q as (t,q_1,...,q_d), where q_j>=0 and
sum q_j=1-t=rho. The S-coordinates of x in K are

    alpha_0(x)=lambda_0(x)/t,
    alpha_j(x)=lambda_j(x)-(q_j/t)lambda_0(x) (j>=1).

Since lambda_j(x)>=0 and 0<=lambda_0(x)<=t,

    alpha_j(x)>=-q_j>=-rho.

The exact centroid-dilation formula gives (2). A stronger apex-specific
bound is E(K,S)<=(d+1)max_j q_j. Equality in (2) is attained by the
universal cap body L and an apex q on one of the truncated old edges,
using a second truncated edge to realize the negative coordinate.

## Relation to actual-defect estimates

Suppose the original actual Entry005 enclosure chain produces P and
rho=(H_d e(K))^(1/(d-1)), and this P additionally has an opposite facet
contained in K. Then (2) replaces the unrestricted quadratic retention
step by the sharp coefficient d+1. It gives the same linear-dimensional
actual-e conclusion as the few-facet theorem under that explicit geometric
hypothesis. The hypothesis is not asserted for arbitrary K or arbitrary
anchor simplices.
