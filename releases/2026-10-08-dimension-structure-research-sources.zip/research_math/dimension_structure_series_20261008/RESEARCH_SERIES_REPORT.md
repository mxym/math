# Entry005: a dimension-stability structural series

8 October 2026. Research continuation over the already validated general
quadratic-dimensional theorem. All new mathematical statements below have
written proofs; the verification record is traditional proof review and
small exact certificate checks. No new Lean compilation, kernel replay,
external publication, or change to a frozen manuscript is claimed.

The original unrestricted bounds remain

    linear lower order <= optimal dimension coefficient <= quadratic upper order.

This series does not claim to close that gap. It supplies one new complete
class with optimal leading dimension coefficient, stronger full-projection
geometry, and new dimension-free matrix rigidity classes.

## 1. New complete actual-defect theorem: at most d+2 facets

Put n=d+1, m=d-1, and H_d=3d^2(d+1)^3(d+2). For every d>=3, every full-
dimensional convex d-polytope K with at most d+2 facets, and every original
prescribed maximum-volume inscribed simplex S,

    E(K,S) <= n H_d^(1/m) e(K)^(1/m) <=192d e(K)^(1/m).

The invariant is the original actual projection-body/pyramid Entry005
invariant; E uses this same S and its original centroid. The exponent 1/m
is sharp within this facet class. Its optimal coefficient G_d^fac satisfies

    n[d n]^(1/m) <= G_d^fac <= n H_d^(1/m),
    G_d^fac/d -> 1.

This determines the leading dimensional constant for the entire class,
not only its linear order. It does not determine the exact fixed-d optimum.
The lower body is the actual square followed by d-2 pyramids, with
E=n and e=1/(dn). The sharp-exponent body is a one-vertex truncated simplex.

The genuinely new geometric theorem is sharper and fully exact. If P is
any simplex and K=P intersect H for one arbitrary halfspace, put
rho_*=max_i[1-max_K lambda_i^P]. Then

    E(K,S)<=n rho_*

for every maximum S, and the coefficient is sharp at every 0<rho_*<1.
A single halfspace may remove several P-vertices. Weighted rooted
bipartite forests give the exact largest determinant, the full set of
vertex maxima, every continuous nonvertex maximum, and an exact formula
for E. This is separate from the other d+2-vertex circuit programme.

The finite-facet specialization of the retained actual-e enclosure chain
selects d+1 actual K-facet halfspaces. With at most d+2 original facets,
only one halfspace remains, so the new exact retention theorem applies.
The facet-selection condition is explicitly supplied by the finite law,
not imported without proof from the old compact-limit Lean theorem.

A further geometric extension allows arbitrary convex bodies K, with no
finite-facet or finite-vertex assumption, whenever K contains one entire
opposite facet of P. Every maximum then consists of that facet and a
height-maximizing apex, and again E<=n rho.

Sources:
- `research_math/dual_facet_linear_retention_20261008/`
- Complete independent traditional review and bound source hashes:
  `research_math/dual_facet_linear_retention_independent_review_20261008/`

## 2. An exact actual-defect statistic for d+2 facets

Let U_i=(s_i nu_i,s_i h_i) be the actual augmented area-normal/support
columns of a d+2-facet polytope. Let z_i be their signed maximal cofactors.
Then, exactly,

    a(K)=sum_i |z_i| / sum_(i<j)|z_i-z_j|,
    delta(K):=n-1/a(K)
       =2 sum_(i<j,z_i z_j>0)min(|z_i|,|z_j|)/sum_i|z_i|,
    e(K)=delta(K)/[n(n-delta(K))].

The identity follows from sum U_i=(0,dV(K)) and a direct cofactor-difference
expansion. Small actual delta forces all but at most delta/2 of normalized
absolute cofactor mass onto one positive and one negative entry. There
are explicit clipping parameters and exact truncation/square-pyramid
specializations. This is an invariant formula, not a surrogate law or a
claim that arbitrary signed vectors are realizable facet data.

The same four-note series review covers this identity. Besides replaying
the author's exact certificates, the reviewer independently checked 210
integer cofactor matrices and 4,830 pair-minor identities.

## 3. Full projection control is much stronger than near-corner points

Suppose K subset P and every actual hyperplane projection obeys
pi_K(v)>=(1-delta)pi_P(v). Put rho=delta^(1/m).

The strongest elementary core bound in the series is the finite spectrum

    M_0=1, M_k=k^k/(k+1)^(2k+1),
    tau_d(delta)=n max_(1<=l<=m)(M_(l-1)delta)^(1/l).

If tau<=1, then the concentric simplex

    T=(1-tau)P+tau c_P

is contained in K. Uniformly in every d>=3 and rho<=1/3, the last spectrum
term is dominant, so

    tau=gamma_d rho,
    gamma_d=(m+2)/m * (1-1/m)^((m-1)/m) -> 1.

Consequently E(K,T)<=tau/(1-tau). This is a dimension-free local simplex-
approximation statement, but T has NOT been identified with an original
maximum simplex. It cannot be substituted for S in the requested target.

A separate full face hierarchy is exact. For a set I of r<=d-1 barycentric
coordinates, let s_I=min_K sum_(i in I)lambda_i. Then

    sum_(j=r)^(d-1) binom(d-1,j)s_I^j(1-s_I)^(d-1-j) <= delta,
    s_I<=delta^(1/r).

In particular, every facet is approached within
1-(1-delta)^(1/(d-1)), at most 2delta/(d-1) if delta<=1/2. These necessary
conditions rule out a broad family of thin positive-coordinate finite
countermodels whose true projection deficit is order rho rather than
rho^(d-1). They are not sufficient conditions for projection closeness.

Sources and review:
- `research_math/projection_retention_deep_20261008/`
- `research_math/projection_retention_deep_review_20261008/`

## 4. Edge-supported inverse rigidity and prescribed-maximum retention

For an invertible nonnegative column-stochastic W, put B=W^{-1}. If every
column of W has at most two nonzero entries, and its one- and two-order
inverse minors obey M_1<=c and M_2<=c^2, then

    max(0,-min B)<=c^2-1       if 1<=c<sqrt(2),
    max(0,-min B)<=(2+sqrt(2))(c-1)  for every c>=1.

The support graph has unicyclic components, possibly with attached trees.
Explicit weighted-cycle inversion handles the core, and inverse-column
recursion handles the trees. Thus arbitrary dimension and arbitrarily
large or cyclic edge support do not themselves obstruct uniform rigidity.

Combining with the exact original maximum-simplex replacement-minor
bounds gives the all-scale geometric theorem

    E(K,S)<=(4+2sqrt(2))n rho

if that prescribed S is edge-supported in P and K has the near-corner
points of radius rho. If K is a polytope and all its vertices lie on edges of P, determinant
averaging transfers the same estimate to every original maximum, including
nonvertex maxima. More generally, the condition that every extreme point
of a compact convex body lies on that finite skeleton already makes it
a polytope. The actual-e corollary is explicitly conditional on
compatibility with a P supplied by the retained actual enclosure chain;
merely having some unrelated edge-supporting simplex is insufficient.

Additional rigorous matrix results are:
- In order three, 1-min B<=M_2 exactly.
- For symmetric positive-definite stochastic W, -min B<=c-1 from M_1<=c.
- A local near-permutation basin gives an explicit O(c-1) bound, without
  claiming a dimension-independent way to enter that basin.
- An exact golden-ratio 3-by-3 example has all-order minor root c=phi and
  negative inverse size phi. A global inequality -minB<=C(c-1) therefore
  requires C>=phi^2. This is not a c->1 counterexample.

Source: `research_math/inverse_minor_deep_20261008/`.
Independent parent series review and exact replay:
`research_math/inverse_minor_deep_review_20261008/`.
The separate theoretical worker's final core/integration reviews are also
bound there.

## 5. Verification, exclusions, and remaining target

The four-part few-facet theorem series passed independent traditional
review, including the arbitrary prescribed-S quantifier and exact original
invariant interface. Exact finite checks included all 12,769 vertex tuples
in 12 rational clipping examples; an independent Bareiss implementation
verified their complete rooted-forest product and equality classification.
The full-projection series passed a separate parent traditional/integration
review, with replayed 189 beta/binomial identities and 780 exact powered
comparisons for the uniform spectrum branch. The uniform branch refinement
was contributed by the parent and cross-checked by the projection worker;
its parent review is not mislabeled as independent authorship. The inverse-
minor series passed both a separate theoretical-worker review and the
parent's complete traditional proof/integration review. Its exact replay
was byte-identical, covering 140 order-three and 287 support-two rational
matrices, symbolic golden-ratio equalities, and both known false-lemma gaps.

All new arguments avoid the known false constant-one and false squared
TWO-minor conjectures in unrestricted matrix dimension. No numerical
optimization is used as proof. No arbitrary finite determinant model is
claimed to have the actual Entry005 defect without a separate calculation.
No maximum simplex or centroid is replaced without explicit notice.

The unresolved unrestricted step is still a dimension-free estimate
E(K,S)<=C n rho under the full actual projection information, or a genuine
actual-body family disproving it and forcing superlinear dimension growth.
The strengthened core reduces one possible matrix formulation to
Q=(1-t)I+(t/n)J, while the face hierarchy imposes further necessary geometry.
The successful new matrix theorem stops at two nonzero coordinates per
column; support involving three or more coordinates is not reduced by its
unicyclic argument. These are precise remaining issues, not asserted
solutions or counterexamples.
