#!/usr/bin/env python3
"""Package reviewed written proofs and exact certificates, with a clean replay."""
from pathlib import Path
import hashlib,json,zipfile,tempfile,subprocess
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'research_math/dimension_structure_series_20261008'
DIRS=[
 'research_math/dual_facet_linear_retention_20261008',
 'research_math/dual_facet_linear_retention_independent_review_20261008',
 'research_math/projection_retention_deep_20261008',
 'research_math/projection_retention_deep_review_20261008',
 'research_math/inverse_minor_deep_20261008',
 'research_math/inverse_minor_deep_review_20261008']
paths=[]
for dr in DIRS:
 for p in (ROOT/dr).rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(ROOT)
  if '__pycache__' in rel.parts or 'exploratory' in rel.parts:continue
  if p.name=='final_focused_audit.md':continue
  if p.suffix in {'.md','.py','.json'} or p.name=='SHA256SUMS':paths.append(p)
paths += [
 ROOT/'research_math/dimension_structure_series_20261008/RESEARCH_SERIES_REPORT.md',
 Path(__file__).resolve(),
 ROOT/'research_math/quadratic_dimension_candidate_cloud_report_20261007.md',
 ROOT/'research_math/vertex_excess_sharp_exponent_20261008/SHARP_VERTEX_EXCESS_EXPONENT.md',
 ROOT/'research_math/dimension_stability_investigation_20261007/obstructions.md',
 ROOT/'research_math/linear_retention_investigation_20261008/false_sharp_two_minor_bound.json',
 ROOT/'research_math/full_minor_rigidity_exploration_20261008/false_squared_two_minor_bound.json']
paths=sorted(set(paths))
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(OUT/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=ROOT/'research_math/dimension-structure-series-20261008.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths+[OUT/'PACKAGE_MANIFEST.json']:
  info=zipfile.ZipInfo(str(p.relative_to(ROOT)),date_time=(2026,10,8,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,p.read_bytes())
replays=[]
with tempfile.TemporaryDirectory(prefix='dimension-structure-clean-') as td:
 td=Path(td)
 with zipfile.ZipFile(archive) as z:z.extractall(td)
 for name,want in manifest.items():assert hashlib.sha256((td/name).read_bytes()).hexdigest()==want,name
 for dr,script,reports in [
 ('research_math/dual_facet_linear_retention_20261008','check_exact_clipping.py',['EXACT_CLIPPING_CHECKS.json']),
 ('research_math/dual_facet_linear_retention_20261008','check_exact_cofactors.py',['EXACT_COFACTOR_CHECKS.json']),
 ('research_math/projection_retention_deep_20261008','check_face_polynomials.py',['EXACT_FACE_POLYNOMIAL_CHECKS.json']),
 ('research_math/inverse_minor_deep_20261008','check_exact_results.py',['EXACT_CHECKS.json'])]:
  run=subprocess.run(['python',str(td/dr/script)],cwd=td,capture_output=True,text=True)
  assert run.returncode==0,(script,run.stdout,run.stderr)
  for name in reports:assert (td/dr/name).read_bytes()==(ROOT/dr/name).read_bytes(),name
  replays.append({'script':dr+'/'+script,'returncode':0,'reports_byte_identical':True})
verification={'status':'PASS','scope':'Reviewed written proofs and exact certificate scripts; no Lean files or compiled objects, no public upload.','archive':str(archive.relative_to(ROOT)),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'manifest_payload_files':len(paths),'clean_extraction_hash_check':True,'exact_clean_replays':replays}
(OUT/'PACKAGE_VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
