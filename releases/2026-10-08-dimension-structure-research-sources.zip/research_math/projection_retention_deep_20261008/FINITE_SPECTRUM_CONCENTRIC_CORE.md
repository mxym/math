# An elementary finite-spectrum refinement of the concentric core

8 October 2026. This is a further structural theorem under the same actual
all-direction projection hypothesis. It does not claim prescribed-maximum
retention. No Brunn--Minkowski or centroid-cap inequality is used here.

Put n=d+1, m=d-1, and define rational constants

    M_0=1,
    M_k=k^k/(k+1)^(2k+1),  k>=1.

Define

    tau_d(delta) = n max_{1<=l<=m} (M_{l-1} delta)^(1/l).    (1)

**Theorem.** If 0<=tau_d(delta)<=1, then

    (1-tau_d(delta))P + tau_d(delta)c_P subset K.           (2)

Thus the earlier core parameter can be replaced by the smaller of any
applicable bounds. The expression in (1) is explicit and contains only
finitely many scalar powers.

Uniformly for every d>=3 and 0<=rho=delta^(1/(d-1))<=1/3, the l=m term
is the largest. In that entire branch,

    tau_d(delta) = gamma_d rho,
    gamma_d = n [(d-2)^(d-2)/(d-1)^(2d-3)]^(1/(d-1))
            = (m+2)/m * (1-1/m)^((m-1)/m) -> 1.             (3)

For d=3 the entire formula is

    tau_3(delta)=max(4 delta, sqrt(2 delta)).

In particular it is sqrt(2)rho when delta<=1/8. The uniform rho<=1/3
branch is proved in Section 4. A separate exact admissible threshold, which
can enlarge that branch in particular dimensions, is

    delta <= min_{1<=l<m}
       [M_{m-1}^l / M_{l-1}^m]^(1/(m-l)).                  (4)

## 1. A single explicit direction sees a substantial missing cap

Consider any affine function b>=0 on P, normalized so that the minimum
vertex value is zero and the sum of all vertex values is one. List the
remaining d vertex values in decreasing order as

    B >= C >= b_1 >= ... >= b_{d-2} >= 0.

For 0<s<1/n, suppose K is contained strictly in {b>s}. Project along the
line from the vertex of value C to the point of value C on the edge joining
the vertices of values 0 and B. This line is parallel to the b-levels, and
the projected P is an m-simplex D with vertex values

    0, B, b_1,...,b_{d-2}.

The vertex of value C has become redundant. Since B>=1/d>s, the cap
{b<=s} in D contains the simplex based at its zero-valued vertex whose
intercept on an edge with endpoint value a is min(1,s/a), interpreted as
one for a=0. Its relative volume is

    R = s^m / [B product_{i=1}^{d-2} max(b_i,s)].            (5)

All of this simplex is missing from the projection of K. In fact the lost
projection volume is strictly larger than R, because K lies strictly above
level s and D has positive-volume strips immediately above that level.
The same proof works at s=1/n; this remains strictly less than 1/d.

## 2. Optimize the denominator without losing a dimension factor

Let k be the number of b_i greater than s, so 0<=k<=m-1. If k=0, the
denominator of (5) is at most s^(m-1)=M_0 s^(m-1).

For k>=1 write U for the sum of those k active values. Since C is at least
each active value, C>=U/k. The normalization gives

    1 >= B+C+U >= B+(1+1/k)U.

AM--GM consequently implies

    product_active b_i <= (U/k)^k <= [(1-B)/(k+1)]^k.

The maximum over B in [0,1] of B[(1-B)/(k+1)]^k occurs at B=1/(k+1),
and is M_k. Hence in every case

    B product_i max(b_i,s)
       <= max_{0<=k<=m-1} M_k s^(m-1-k).

Combining with (5), the actual relative projection deficit is strictly
larger than

    min_{1<=l<=m} s^l/M_{l-1}.                             (6)

This denominator optimization is an upper bound and requires no assertion
that every formal optimizer occurs in every active-coordinate regime.

## 3. Apply the cap bound to a missing core point

Let t in (0,1], and suppose y=(1-t)x+t c_P is outside K for some x in P.
Choose a strict separating affine functional, orient it so K has larger
values than y, subtract its minimum vertex value, and divide by the sum
of its vertex values. This gives the b used above. It has

    b(y)=(1-t)b(x)+t/n >= t/n.

Therefore K lies strictly in {b>t/n}. Set s=t/n in (6). If
 t=tau_d(delta), every term s^l/M_{l-1} is at least delta, contradicting the
assumed projection deficit. This proves (2), including t=1.

For delta=0, take arbitrary positive t and pass to the closed limit as in
the earlier core proof. Formula (3) follows because, for fixed m and l<m,
(delta M_{l-1})^(1/l)/(delta M_{m-1})^(1/m) tends to zero as delta decreases
to zero. Rearrangement gives the explicit threshold (4).

## 4. A uniform local branch, with leading constant tending to one

Put f_l=l M_{l-1}^(1/l). Then

    f_1=1,
    f_l=(1-1/l)^(1-1/l),  l>=2.

For l>=2 this is increasing, because x log x is increasing on [1/2,1).
In particular 1/sqrt(2)<=f_m<1. For 2<=l<=m, the ratio of the l-term of
(1) to its m-term is

    (m/l)(f_l/f_m) rho^(m/l-1)
       <= (m/l) rho^(m/l-1) <= 1,   if rho<=1/3.

For the last inequality set x=m/l>=1 and use
 log x<=(x-1)<=(x-1)log 3. For l=1, the ratio is

    (m/f_m)rho^(m-1) <= sqrt(2) m 3^(1-m)
                       <= 2 sqrt(2)/3 <1.

Here m 3^(1-m) is decreasing for integer m>=2, since its next-term ratio
is (m+1)/(3m)<1. This proves the claimed uniform dominance of l=m.
The case rho=0 is immediate, without division by rho.

Moreover

    tau_d(delta)=gamma_d rho=(m+2)f_m rho/m <=2/3<1

throughout rho<=1/3, so the positive-core gate in (2) is automatic. Thus

    (1-gamma_d rho)P+gamma_d rho c_P subset K,
    E(K,T)<=gamma_d rho/(1-gamma_d rho)

for this concentric T, uniformly in d. Since gamma_d tends to one, this
is a uniform local comparison-simplex approximation with leading
coefficient tending to one. The prescribed maximum-simplex issue remains
separate.

## 5. Scope

This theorem strengthens the concentric comparison simplex and has a local
leading constant tending to one. Its centroid is still c_P, not the
centroid of a prescribed maximum simplex. It neither proves the original
Cn rho retention bound nor supplies a lower-bound counterfamily.
