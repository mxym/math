#!/usr/bin/env python3
"""Small exact algebra checks; does not certify the geometric arguments."""
from fractions import Fraction
from math import comb, factorial
import json
from pathlib import Path

def mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c

def power_one_minus(k): return [(-1)**i*comb(k,i) for i in range(k+1)]
checks=[]
for d in range(3,21):
    m=d-1
    for r in range(1,d):
        f=[0]*(m+1)
        for j in range(r,m+1):
            for k,c in enumerate(power_one_minus(m-j)):
                f[j+k]+=comb(m,j)*c
        derivative=[(i+1)*f[i+1] for i in range(m)]
        density=[0]*m
        coefficient=factorial(m)//(factorial(r-1)*factorial(d-r-1))
        for k,c in enumerate(power_one_minus(d-r-1)):
            density[r-1+k]=coefficient*c
        assert derivative==density and f[0]==0 and sum(f)==1
        for s in [Fraction(0),Fraction(1,100),Fraction(1,10),Fraction(1,3),Fraction(1,2),Fraction(1)]:
            value=sum(Fraction(c)*s**j for j,c in enumerate(f))
            assert value>=s**r
        checks.append({'d':d,'r':r,'density_identity':True,'endpoint_identity':True})
report={'status':'passed','scope':'Exact polynomial identities and rational sample inequalities only; geometric proofs are in the companion note.','cases':len(checks),'checks':checks}
Path(__file__).with_name('EXACT_FACE_POLYNOMIAL_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'Passed {len(checks)} exact beta/binomial polynomial identities.')
