# Full-projection structural refinements

The two mathematical notes establish consequences of the actual all-direction
relative projection bound K subset P, deficit delta, and rho=delta^(1/(d-1)).

- `FULL_PROJECTION_CORE_AND_FACE_HIERARCHY.md`: elementary concentric core;
  a sharper core using a fully derived Brunn--Minkowski centroid-cap lemma;
  exact beta-polynomial face-depth constraints; exclusion tests for thin
  positive-coordinate hulls; and the original-defect comparison-simplex
  sandwich, explicitly distinguished from prescribed maximum retention.
- `FINITE_SPECTRUM_CONCENTRIC_CORE.md`: fully elementary stronger finite
  spectrum tau_d(delta), with a **uniform rho<=1/3 branch**
  tau=gamma_d rho and gamma_d->1.
- `check_face_polynomials.py` / `EXACT_FACE_POLYNOMIAL_CHECKS.json`: 189
  exact beta/binomial derivative and endpoint identities, with rational
  sample checks. These finite checks do not replace the geometric proofs.

There is no claim here to have proved unrestricted E(K,S)<=C(d+1)rho for
the user's prescribed maximum S, or to have constructed a genuine
quadratic-order lower bound. No large compilation, external write, or
publication was performed.
