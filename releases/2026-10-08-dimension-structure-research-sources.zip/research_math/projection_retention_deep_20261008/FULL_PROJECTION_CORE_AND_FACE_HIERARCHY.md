# A concentric core and face-depth hierarchy forced by every projection

8 October 2026. Independent research note. All results below have traditional
proofs. No Lean compilation, external publication, or unrestricted linear
retention theorem is claimed. Existing source files are unchanged.

## 1. Setup and useful new conclusions

Let P = conv(p_0,...,p_d) be a full-dimensional d-simplex, let K be a convex
body contained in P, and assume

    pi_K(v) >= (1-delta) pi_P(v)   for every direction v,
    0 <= delta <= 1,  d >= 3.

Put n=d+1, m=d-1, rho=delta^(1/m), and c=(p_0+...+p_d)/n. Projections and
volumes are the actual Euclidean projections and their (d-1)-volumes.

The following conclusions use the full projection hypothesis, rather than
merely the existence of one point near each vertex. Section 4 also proves
the sharper core constant (d+1)/(d-1), using Brunn--Minkowski and a short
self-contained derivation of the needed centroid-cap inequality.

**Concentric-core theorem.** Define

    kappa_d = (d+1)/d * d^(1/(d-1)).

Whenever t=kappa_d rho <= 1,

    (1-t)P + t c  is contained in K.                         (1)

In particular kappa_d <= 4 sqrt(3)/3 < 7/3, uniformly for d>=3.
Thus one may select the very special comparison matrix

    Q_t = (1-t) I_n + (t/n) J_n,

rather than an arbitrary near-identity column-stochastic matrix. The
statement includes delta=0 and the positive-core threshold endpoint.

**Face-depth theorem.** For every nonempty set I of r barycentric coordinates,
where 1<=r<=d-1, let

    s_I = min_{x in K} sum_{i in I} lambda_i(x).

Then

    F_{r,d-r}(s_I) <= delta,                                (2)
    F_{r,d-r}(s) = sum_{j=r}^{d-1} C(d-1,j)s^j(1-s)^(d-1-j).

Consequently

    s_I <= delta^(1/r) = rho^((d-1)/r).                      (3)

For a facet, r=1, the exact conclusion is

    min_K lambda_i <= 1-(1-delta)^(1/(d-1))
                  <= 2 delta/(d-1),  if delta<=1/2.         (4)

This is much stronger than a near-corner estimate: it forces exponentially
small barycentric distance to each facet when rho is of order 1/d. For a
positive-dimensional face of codimension r, it forces distance of order
rho^((d-1)/r). The vertex case is intentionally separate: its sharp
projection exponent is d-1, not d.

Neither (1) nor (2) by itself proves E(K,S)<=C(d+1)rho for every prescribed
maximum simplex S. Their precise remaining use is stated in Section 6.

## 2. An elementary centroid-cap lemma

Let D be an m-simplex, with centroid g, and let H be any closed halfspace
whose boundary passes through g. Then

    |D intersect H| >= |D|/(m+1).                           (5)

This deliberately uses a weaker constant than the classical sharp centroid
inequality, in exchange for a two-line self-contained proof.

Write points of D in barycentric coordinates x_0,...,x_m, and write the
halfspace as L(x)>=0 with L(g)=0. Consider the m+1 cyclic coordinate
permutations sigma^k. Each preserves D and its volume, and

    sum_{k=0}^m L(sigma^k x) = (m+1)L(g) = 0.

At least one summand is nonnegative. Hence the m+1 inverse cyclic images of
D intersect H cover D. Comparing volumes proves (5). The assertion also
holds for a constant functional, when it is immediate.

A useful immediate consequence is the following. For any z in D and
0<=theta<=1, put y=(1-theta)z+theta g. Every halfspace H_y through y satisfies

    |D intersect H_y| >= theta^m |D|/(m+1).                 (6)

Indeed, apply the homothety x -> (1-theta)z+theta x to the parallel
centroid halfspace in (5). Its image is contained in D intersect H_y.

## 3. A separator-parallel projection turning P into a simplex

Let L be a nonconstant affine functional on P. Choose indices a,b with
L(p_a)=min_i L(p_i) and L(p_b)=max_i L(p_i). Choose any j outside {a,b}.
There is a point r on [p_a,p_b] with L(r)=L(p_j). Put

    v = p_j-r.

This is a nonzero vector parallel to the level hyperplanes of L. Orthogonal
projection along v sends p_j to the image r' of r. The other d projected
vertices are affinely independent: otherwise v would be parallel to the
facet opposite p_j, whereas p_j-r is transverse to that facet. Therefore

    D = projection_v(P)

is an (d-1)-simplex whose vertices are the projections p_i' for i!=j.
The affine functional L descends to this quotient. If g is the centroid of
D, the projection of the original centroid is exactly

    c' = (d/n) g + (1/n) r'.                                (7)

This is an actual orthogonal projection, not an auxiliary substitution for
the projection-volume hypothesis. Coincident endpoint values and repeated
extreme values cause no issue. The only requirement is d>=2, so an index j
outside the selected a,b exists.

## 4. Proof of the concentric-core theorem

Fix t in (0,1] and y in (1-t)P+t c. Suppose y is not in K. Strict separation
provides a nonconstant affine L with

    max_K L < L(y).

Use Section 3 to choose a direction v parallel to L and the projected
simplex D. Write y=(1-t)x+t c with x in P. By (7),

    y' = (1-t)x' + (t/n)r' + (td/n)g
       = (1-theta)z + theta g,
    theta=td/n,
    z=((1-t)x'+(t/n)r')/(1-td/n) in D.

The denominator is strictly positive even when t=1. Since theta>0, y' is
in the relative interior of D. The projection of K is strictly on the
lower-L side of y'. By (6), the opposite cap through y' has volume at least

    (td/n)^(d-1) |D|/d.

In fact the lost volume is strictly larger: the nonempty strip between
max_K L and L(y') has positive (d-1)-volume because y' is interior to D.
Thus

    delta > (td/n)^(d-1)/d.                                 (8)

For t=kappa_d rho, the right hand side is exactly rho^(d-1)=delta,
a contradiction. This proves (1), including t=1.

If delta=0, apply the same argument to every t>0, then let t decrease to zero
and use closedness of K. Thus K=P, also giving (1) in that case.

For the uniform constant, d <= 3^((d-1)/2) for d>=3: equality holds at d=3,
and increasing d to d+1 multiplies the left side by at most 4/3, less than
sqrt(3). Consequently d^(1/(d-1))<=sqrt(3), while (d+1)/d<=4/3.

**Sharper version, with Brunn--Minkowski as its only extra ingredient.** The
constant kappa_d can be replaced by

    kappa_d^sharp = (d+1)/(d-1) <= 2.                        (10)

Here is a proof of the precise centroid-cap inequality needed, rather than
an unproved citation of it. Let Z=L(X), where X is uniform in an m-dimensional
convex body D, and normalize E[Z]=0. Let

    F(u) = probability(Z>=u),  R(u)=F(u)^(1/m).

The inclusion

    (1-alpha)(D intersect {L>=u}) + alpha(D intersect {L>=v})
       subset D intersect {L>=(1-alpha)u+alpha v}

and Brunn--Minkowski show that R is concave. Between the minimum and maximum
of L on D, it is continuous and strictly decreasing. Its inverse T on
(0,1) is also concave and decreasing: apply concavity of R to T(s_0),T(s_1),
and then use that R is decreasing. The probability-integral transform gives
F(Z) uniform on (0,1). Thus S=R(Z) has density m s^(m-1), and

    E[S]=m/(m+1),   E[T(S)]=E[Z]=0.

Jensen's inequality for the concave T gives T(m/(m+1))>=0. Since T is
decreasing, this implies

    F(0) >= (m/(m+1))^m.                                    (11)

All random variables here are merely bounded one-dimensional integrals;
Jensen also follows by integrating a supporting line for T at m/(m+1).
The constant-functional case is immediate. This supplies the full
centroid-cap lemma with no use of an unverified specialized theorem.

Replacing 1/d in the proof of (8) by ((d-1)/d)^(d-1) now gives

    delta > [t(d-1)/(d+1)]^(d-1)

whenever a point of (1-t)P+t c is absent. Taking
 t=((d+1)/(d-1))rho proves (10), including the endpoint exactly as before.
The elementary version remains independent of Brunn--Minkowski; the sharper
version uses the standard Brunn--Minkowski theorem that is also an explicit
proved ingredient in the retained actual-body chain.

## 5. Proof of the face-depth theorem

Let I have size r<=d-1. Its complement has at least two indices a,b. Project
along the edge p_a-p_b. The projection D is a (d-1)-simplex, obtained by
identifying exactly the vertices a,b. The affine function

    f_I(x)=sum_{i in I} lambda_i(x)

descends to D and is the sum of exactly r of its d barycentric coordinates.
Since K is contained in {f_I>=s_I}, its projection omits the strip
{f_I<s_I} in D.

For a point uniformly distributed in a simplex with d vertices, the sum of
r barycentric coordinates has beta(r,d-r) distribution. A direct section
calculation gives density

    ((d-1)!/((r-1)!(d-r-1)!)) s^(r-1)(1-s)^(d-r-1).

Integrating from zero to s gives the polynomial F in (2). Equivalently,
differentiate the displayed polynomial: adjacent binomial terms telescope
to that density, and the polynomial vanishes at zero. This calculation
requires no probabilistic independence assertion about barycentric entries.
The omitted relative volume is F(s_I), proving (2).

The polynomial is also the probability that at least r of d-1 independent
Bernoulli(s) trials succeed. The event that the first r trials all succeed
has probability s^r and is contained in that event. Hence F(s)>=s^r, proving
(3). This Bernoulli interpretation is only a polynomial identity.

For r=1, F(s)=1-(1-s)^(d-1), giving the exact first inequality in (4).
For delta<=1/2,

    1-(1-delta)^(1/m)
      = integral_0^delta (1/m)(1-u)^(1/m-1) du
      <= delta/[m(1-delta)] <= 2 delta/m.

All endpoint assertions follow directly or by continuity.

## 6. Consequences for proposed finite countermodels, and the remaining gap

Let K_0 be the convex hull of any finite collection of proposed near-corner
points and interior candidate-simplex vertices. For every I, (2) can be
checked from the generating vertices alone: the minimum of f_I is their
minimum. Thus a candidate satisfying all replacement-minor constraints but
violating one of these face inequalities cannot satisfy the required actual
projection bound. No statement about its maximum simplex is needed to
exclude it.

A particularly simple rigorous obstruction is the following. If, for some
facet i, all generators have lambda_i>=epsilon, then

    delta >= 1-(1-epsilon)^(d-1)
          >= (d-1)epsilon/[1+(d-1)epsilon].                 (9)

The last inequality follows from (1-epsilon)^(-(d-1)) >=
1+(d-1)epsilon, with the epsilon=1 endpoint interpreted directly.

For example, suppose the near-corner comparison simplex is the concentric
Q_a=(1-a)I+(a/n)J, and every additional generator has every barycentric
coordinate at least b/n. Set epsilon=min(a,b)/n. Then (9) applies to every
facet. If a and b are comparable to rho, the true relative projection
deficit is bounded below by a constant times rho, rather than rho^(d-1).
These thin positive-coordinate hulls are therefore not candidate bodies for
the difficult rho~1/d regime. This directly identifies the missing
projection information in such examples.

The concentric-core theorem supplies a second, stronger computable test:
for each i, the point

    y_i=(1-kappa_d rho)p_i+kappa_d rho c

must belong to K_0. Membership is a finite linear feasibility problem. A
separating functional for a failed membership test explicitly determines,
by Section 3, a genuine projection direction violating the assumed deficit.
This test is necessary only when kappa_d rho<=1, and must not be mistaken
for a sufficient test of every-direction projection control.

For prescribed-maximum retention, maximum-volume optimality still gives
all replacement minors relative to these **central** Q_t points. That is a
stronger structured finite formulation than choosing arbitrary near-corner
points. However, proving a dimension-free lower bound on the entries of
W^(-1)Q_t, or proving that the additional face-depth conditions force such a
bound, remains open in this note. The universal estimate E<=16n^2 rho has
not been improved here to Cn rho, and no genuine quadratic lower-bound body
has been produced.

## 7. Dimension-free concentric approximation, without prescribed retention

Take the sharper t=((d+1)/(d-1))rho<1 and put T=(1-t)P+t c. Then T is a
full-dimensional simplex, its own centroid is c, and

    T subset K subset P = c + (1/(1-t))(T-c).

Thus the original centered-excess definition, applied to this particular
comparison simplex T, gives

    E(K,T) <= t/(1-t).

If t<=1/2, this is at most 2(d+1)/(d-1) rho, uniformly bounded by 4rho for
d>=3. The comparison simplex T is not asserted to be maximum-volume. It is
not the originally prescribed S. Consequently this statement cannot be
substituted for prescribed-maximum retention.

For the already established actual-body chain with delta=H_d e(K), simply
substitute

    t=((d+1)/(d-1)) H_d^(1/(d-1)) e(K)^(1/(d-1))

on the branch where that enclosing-simplex/projection packet is available
and t<1. The resulting concentric sandwich is a direct consequence of the
same actual projection data; it changes neither the defect nor its law.
It precisely separates the now dimension-free comparison-simplex
approximation from the remaining task of retaining an arbitrary prescribed
maximum simplex and its own original centroid.
