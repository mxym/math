# Parent independent traditional review of inverse-minor structural cases

8 October 2026. PASS at the source versions bound in REVIEW_BINDING.json.
The parent independently read both complete mathematical notes. This review
also incorporates the separate theoretical worker's core proof check and
its final focused integration audit, whose exact files are bound below.
No Lean or independent-kernel claim is made.

## Matrix theorem

The support-two graph decomposes into square connected blocks because
otherwise summing their maximal possible ranks gives a deficient full
rank. A connected block has equally many rows and columns and is therefore
unicyclic, with singleton columns as loops and parallel-edge cycles allowed.
The core-first row/column order and tree-parent pairing give the displayed
upper-triangular block form. Tree inverse recursion is exact, and every
nontrivial tree term contains a ratio r_v<=c-1; the remaining coefficient
is bounded by c.

For a positive weighted cycle, reversing the matching permits product
R<=1. Its inverse and principal two-minors follow directly from the finite
geometric series and complementary minors. With all ratios at most one,
a negative path product is bounded by its final one-step product, and the
corresponding principal two-minor is at least one plus that negative entry.
If one ratio exceeds one, the two largest ratios x,y satisfy R<=xy; the
odd-cycle calculation (x-1)(1-R/x)>=0 forces a two-minor at least two.
The even-cycle case is immediate. Thus the near-endpoint bound is valid,
and the entry bound supplies the stated global piecewise coefficient.
Zeros are already handled by the actual support graph, without needing
a singular limiting argument.

## Geometry and exact quantifiers

Maximum-volume replacement bounds give every square minor of A=BQ at
most one. The inverse-Q norm and Cauchy--Binet give the required inverse
minor bounds with c=(1-2rho)^(-1). For every x in K, not just selected
comparison vertices, its P-coordinate vector is nonnegative and sums to
one, so min B controls its S coordinates. The universal replacement lower
bound -1 closes the large-rho branch. The exact crossing value rho_0 and
the constant 4+2sqrt(2) were independently checked.

The determinant-averaging formula for arbitrary prescribed maxima has a
common positive determinant denominator in every sample. Therefore it
transfers the coordinate bound exactly and keeps the prescribed centroid.
The body-level result explicitly assumes a polytope, or that every extreme
point lies on the finite one-skeleton, which implies a polytope. The latter
wording in the actual-e corollary resolves the ambiguity identified by the
separate reviewer. Compatibility with a P produced by the actual chain is
stated as an additional hypothesis, not inferred from an unrelated P.

## Other exact cases

The order-three cofactor expression is a convex combination of three
values each no greater than max W; Jacobi identifies M_2. Independent even
permutations are transitive on each index and preserve the determinant
orientation. The displayed golden-ratio matrix and all-order equality are
exact, giving the necessary global coefficient phi^2 but no near-c=1
obstruction.

For symmetric positive-definite W, B-I is positive semidefinite and the
2-by-2 PSD inequalities give the claimed optimal bound c-1. The two-state
sharp example also obeys all-order minor bounds. The local permutation
basin's Neumann power estimate and diagonal lower estimate are valid, and
its matching hypothesis is not asserted without proof.

## Exact replay and final scope

Replayed the supplied exact checker in a separate directory. The output
was byte-identical to EXACT_CHECKS.json, with 140 order-three cases, 287
support-two matrices including 149 near-endpoint cases, the symbolic
phi equalities, exact arbitrary-maximum inverse averaging, the cap
constant, and both previously recorded false-lemma gaps.

These finite tests check examples and algebra, not the universal proof.
The unrestricted inverse-minor theorem, the special concentric-Q version,
and the unrestricted prescribed-maximum linear dimension bound remain
open. Three-supported or denser columns are not covered by the unicyclic
argument. No actual Entry005 counterfamily is inferred from a matrix alone.
