# What is proved here

Three arbitrary, possibly different PPT maps on M_d with **common diagonal-orthogonal covariance** have entanglement-breaking composition. The factorization is into coordinate two-qubit separable positive operators. Trace preservation and identical factors are unnecessary. This is not a universal theorem about triples of PPT maps. It does not prove that two DOC maps always suffice, nor demonstrate that three are sometimes necessary.

- [Singh & Nechita, Diagonal unitary and orthogonal symmetries in quantum theory](https://arxiv.org/abs/2010.07898): DOC parametrization, Choi structure and cone machinery.
- [Singh & Nechita, The PPT² conjecture holds for all Choi-type maps](https://arxiv.org/abs/2011.03809): the DUC/CDUC result is Theorem 4.5. Conjecture 5.1 asks explicitly about pairs of arbitrary PPT DOC maps.
- [Nechita & Park, Random covariant quantum channels](https://arxiv.org/abs/2403.03667): Corollary 6.4 allows one restricted factor; Theorem 6.5 is probabilistic. Neither states a deterministic bound of three for all DOC maps.
- [Márquez González, Toroidal-core certificates for PPT-squared diagonal orthogonal covariant channels (26 September 2026)](https://arxiv.org/abs/2609.32979): a sufficient mixing criterion and a special continuous family, not universal.
- [OpenAI, item 272](https://github.com/openai/math/blob/main/lean/docs/272.md): a counterexample to the *unrestricted two-map* statement, not an arbitrary DOC pair and not a three-map counterexample.
- [Liu–Qiao / PSI, PPT composition bound](https://github.com/physical-superintelligence/oqp-batch-2026/tree/main/ppt-composition-bound): dimension-dependent bound without DOC, not this dimension-independent constant.
- Searches of public papers and the available mxym/math snapshot as of 20 November 2026 found no earlier universal all-dimension three-map DOC theorem. This is a search result, not a certification of priority.

The proof uses no numerical premise. The PDF and its complete TeX source are included; the source uses standard LaTeX packages.
