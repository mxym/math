#!/usr/bin/env python3
"""Small exact consistency checks; not premises of the general proof. Stdlib only."""
from fractions import Fraction as F
from itertools import product
from math import prod
rng=range(2)
# C is a two-turn classical binary channel. D is uniform at each output.
# Choi entries in lexicographic order x,a,b,d (the inserted map sends a->b).

def prob(t,v): return t if v else 1-t
p=[F(1,3),F(3,5)];h=[F(i,13) for i in (1,7,2,11,4,12,10,9)]
C={(x,a,b,d):prob(p[x],a)*prob(h[4*x+2*a+b],d) for x,a,b,d in product(rng,repeat=4)}
D={k:F(1,4) for k in C}; W={k:v*v/D[k] for k,v in C.items()}
# Deterministic tester policies select x then b(a).
policies=list(product(rng,repeat=3));
def pair(W,t):
 x,*bs=t;return sum(W[x,a,bs[a],d] for a,d in product(rng,repeat=2))
assert all(pair(C,t)==pair(D,t)==1 for t in policies)
s=max(pair(W,t) for t in policies);u={(x,a):max(sum(W[x,a,b,d] for d in rng) for b in rng) for x,a in product(rng,repeat=2)}
assert s==max(sum(u[x,a] for a in rng) for x in rng)
# Complete W to s times a deterministic two-comb exactly as in Lemma 1.
u2={(x,a):u[x,a]+(s-sum(u[x,z] for z in rng))/2 for x,a in product(rng,repeat=2)}
W2={(x,a,b,d):w+(u2[x,a]-sum(W[x,a,b,z] for z in rng))/2 for (x,a,b,d),w in W.items()}
assert all(W2[k]>=W[k] for k in W2);assert all(sum(W2[x,a,b,d] for d in rng)==u2[x,a] for x,a,b in product(rng,repeat=3));assert all(sum(u2[x,a] for a in rng)==s for x in rng)
# Vary inserted stochastic channels, observe all classical output/history flags.
count=0
for ns in product([F(1,5),F(1,2),F(3,4)],repeat=2):
 for ms in product([F(1,4),F(2,5),F(4,5)],repeat=2):
  N=lambda a,b:prob(ns[a],b);M=lambda a,b:prob(ms[a],b)
  t=max(sum(N(a,b)**2/M(a,b) for b in rng) for a in rng)
  for x in rng:
   v=sum(W[x,a,b,d]*N(a,b)**2/M(a,b) for a,b,d in product(rng,repeat=3))
   assert v<=s*t;count+=1
print(f'Diagonal two-comb SDP primal = dual = {s}. Exact nested-chain instances: {count}.')
# Bell contraction of two quantum Kraus Choi vectors. Port order: (out,in).
# Use Gaussian integers (complex type is exact here since entries are small integers).
A=((1,1j),(2-1j,-1));B=((1+1j,2j),(-1j,1));ij=list(product(rng,repeat=2))
def cv(M,r,c): return M[r[0]][r[1]]*M[c[0]][c[1]].conjugate()
BA=tuple(tuple(sum(B[i][a]*A[a][j] for a in rng) for j in rng) for i in rng)
for i,j in product(ij,repeat=2):
 link=sum(cv(B,(i[0],a),(j[0],b))*cv(A,(a,i[1]),(b,j[1])) for a,b in product(rng,repeat=2))
 assert link==cv(BA,i,j)
print('All 16 Choi entries: unnormalized Bell contraction equals composition, including complex phases.')
