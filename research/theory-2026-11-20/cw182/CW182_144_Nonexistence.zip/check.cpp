#include <algorithm>
#include <array>
#include <cassert>
#include <cstdlib>

#include <cstdio>
#include <functional>
#include <iostream>
#include <map>
#include <numeric>
#include <set>
#include <vector>
using namespace std;
using V=vector<int>;using S=set<V>;
int pos(int x,int n){return (x%n+n)%n;}
int rt(int n){int x=0;while((x+1)*(x+1)<=n)++x;assert(x*x==n);return x;}
int order(int t){int x=t,k=1;while(x!=1){x=x*t%91;k++;}return k;}
int tr(int x){return (x%7==0?6:-1)*(x%13==0?12:-1);}
V phi; // Phi_91 via (1+x^7+...+x^84)/Phi_13
V reduced(V x){x.resize(max(x.size(),size_t(72)));for(int i=(int)x.size()-1;i>=72;i--){int c=x[i];if(c)for(int j=0;j<=72;j++)x[i-72+j]-=c*phi[j];}x.resize(72);return x;}
V conv(const V&a,const V&b,bool star=false){
 V z(91);for(int i=0;i<91;i++)if(a[i])for(int j=0;j<91;j++)if(b[j])z[pos(i+(star?-j:j),91)]+=a[i]*b[j];return z;
}
bool norm(const V&x,int n){const int q=x.size();for(int k=0;k<q;k++){int a=0;for(int i=0;i<q;i++)a+=x[i]*x[(i+k)%q];if(a!=(k==0?n:0))return false;}return true;}
vector<V> weil(int gen,int w){
 set<int>todo;for(int i=1;i<91;i++)if(gcd(i,91)==1)todo.insert(i);vector<V> U;
 while(!todo.empty()){int a=*todo.begin();V v;while(todo.count(a)){v.push_back(a);todo.erase(a);a=a*gen%91;}U.push_back(v);}
 int d=U.size(),T=d*w;V lab(d,-1);vector<V> G(d,V(d)),cl;for(int i=0;i<d;i++)for(int j=0;j<d;j++){int h=0;for(int a:U[i])for(int b:U[j])h+=tr(a-b);assert(h%(int)U[i].size()==0);G[i][j]=h/(int)U[i].size();}
 for(int i=0;i<d;i++)if(lab[i]<0){int k=cl.size();V b{i};lab[i]=k;for(int j=i+1;j<d;j++)if(G[i][j]<-1){assert(lab[j]<0);lab[j]=k;b.push_back(j);}assert(b.size()==3);cl.push_back(b);}
 // Recheck G=91I-k*diag(J3)-J; its other eigenvalues are d+1,1 (triple means) in these two cases.
 int k=gen==2?28:26;for(int i=0;i<d;i++)for(int j=0;j<d;j++)assert(G[i][j]==91*(i==j)-k*(lab[i]==lab[j])-1);
 assert(91-3*k-d==1); // Check: small eigenvalue=1, other triple-mean eigenvalue=d+1.
 int bd=0;while((bd+1)*(bd+1)<=T)++bd; // min eigenvalue>=1 hence |x_i|<=sqrt(T).
 V x(d);int ts=0;vector<V>out;
 function<void(int,bool)> rec=[&](int j,bool exc){
  if(j<(int)cl.size()){auto b=cl[j];for(int t=-bd;t<=bd;t++){for(int i:b)x[i]=t;rec(j+1,exc);
    if(!exc)for(int i:b)for(int e:{-1,1})if(abs(t+e)<=bd){x[i]=t+e;rec(j+1,true);x[i]=t;}}return;}
  int q=0;for(int i=0;i<d;i++)for(int j=0;j<d;j++)q+=x[i]*G[i][j]*x[j];if(q!=T)return;ts++;
  V z(91);for(int i=0;i<d;i++)for(int j:U[i])z[j]=x[i];V n=reduced(conv(z,z,true));n[0]-=w;
  if(all_of(n.begin(),n.end(),[](int v){return v==0;}))out.push_back(z);
 };
 rec(0,false);cout<<"gen "<<gen<<" weight "<<w<<" shell "<<ts<<" Weil "<<out.size()<<"\n";return out;
}
vector<V> marg(int n,int sq,int scale){
 vector<V> out;V z(n);function<void(int,int)> rec=[&](int j,int left){if(j==n){if(left||accumulate(z.begin(),z.end(),0)!=rt(sq)||!norm(z,sq))return;V a=z;for(auto&v:a)v*=scale;out.push_back(a);return;}for(int t=0;t*t<=left;t++){z[j]=t;rec(j+1,left-t*t);if(t){z[j]=-t;rec(j+1,left-t*t);}}};rec(0,sq);return out;
}
S system_rows(int wa,int wb){
 auto A=weil(2,wa),B=weil(3,wb);auto RR=marg(7,wa,rt(wb)),CC=marg(13,wb,rt(wa));map<V,V> U;
 for(auto&a:A)for(auto&b:B){auto t=conv(a,b);U.emplace(reduced(t),t);}
 S X;map<int,int>counts;
 for(auto& kv:U){auto&t=kv.second;int T[7][13];for(int i=0;i<91;i++)T[i%7][i%13]=t[i];
  int d[7][13],dr[7]={},dc[13]={};for(int i=0;i<7;i++)for(int j=0;j<13;j++){d[i][j]=T[i][j]-T[i][0]-T[0][j]+T[0][0];dr[i]+=d[i][j];dc[j]+=d[i][j];}
  for(auto&r:RR){V b(7);bool ok=true;for(int i=0;i<7;i++){int w=r[i]-r[0]-dr[i];if(w%13){ok=false;break;}b[i]=w/13;}if(!ok)continue;
   for(auto&c:CC){V a(13);bool ok=true;for(int j=0;j<13;j++){int w=c[j]-c[0]-dc[j];if(w%7){ok=false;break;}a[j]=w/7;}if(!ok)continue;
    int h=r[0]-accumulate(a.begin(),a.end(),0);if(h%13)continue;h/=13;V row(91);int m=0;
    for(int i=0;i<91;i++){row[i]=h+b[i%7]+a[i%13]+d[i%7][i%13];m=max(m,abs(row[i]));}counts[m]++;
    assert(norm(row,wa*wb));if(m<=2)X.insert(row);
   }
  }
 }
 cout<<"distinct primitive "<<U.size()<<"; margins "<<RR.size()<<" x "<<CC.size()<<"; lift maxima";
 for(auto it:counts){cout<<" "<<it.first<<":"<<it.second;}cout<<"; bounded rows "<<X.size()<<"\n";return X;
}
int main(){
 V f(85);for(int i=0;i<=84;i+=7)f[i]=1;phi.assign(73,0);for(int k=84;k>=12;k--){int c=f[k];phi[k-12]=c;for(int j=0;j<=12;j++)f[k-12+j]-=c;}assert(*max_element(f.begin(),f.end())==0&&*min_element(f.begin(),f.end())==0&&phi.back()==1);
 auto ctrl=system_rows(4,9);int ct=0;for(auto&v:ctrl)if(all_of(v.begin(),v.end(),[](int a){return abs(a)<=1;}))ct++;assert(ct==16);
 auto A=system_rows(16,9);assert(A.size()==32);int minimum[2]={91,91},tested[2]={};S all;for(auto r:A)for(int i=0;i<91;i++){all.insert(r);rotate(r.begin(),r.begin()+1,r.end());}
 for(auto&v:A)for(auto&w:all){int z=0,ones=0;bool same=true;for(int i=0;i<91;i++){if((v[i]-w[i])%2){same=false;break;}ones+=abs(v[i])%2;z+=(abs(v[i])==2&&abs(w[i])==2);}if(!same)continue;int h=(ones!=0);tested[h]++;minimum[h]=min(minimum[h],z);}
 cout<<"translated rows "<<all.size()<<" parity-compatible pairs "<<tested[0]<<" + "<<tested[1]<<"; minimum shared double sites (even,odd) = "<<minimum[0]<<","<<minimum[1]<<"\n";
 assert(all.size()==2912&&minimum[0]==5&&minimum[1]==27);cout<<"NO CW(182,144)\n";
}
