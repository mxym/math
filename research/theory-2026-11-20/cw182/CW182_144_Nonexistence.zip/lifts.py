from periods import *
from collections import defaultdict,Counter
from functools import lru_cache
from math import isqrt
from itertools import product
@lru_cache(None)
def margin(n,w,sc): # signed tuple with squared-norm w and sum positive sqrt(w)
 d={}
 output=[]
 def rec(a,need,s):
  left=n-len(a)
  if left==0:
   if need==s==0 and all(sum(a[i]*a[(i+k)%n] for i in range(n))==0 for k in range(1,n//2+1)):output.append(tuple(t*sc for t in a))
   return
  for k in range(-isqrt(need),isqrt(need)+1):
   if (s-k)**2<=(left-1)*(need-k*k) and (need-k*k-(s-k))%2==0:rec(a+[k],need-k*k,s-k)
 rec([],w,isqrt(w));return output
def all_arrays(wa,wb=9):
 D=json.loads(pathlib.Path(__file__).with_name('periods.json').read_text()); a,b=map(isqrt,(wa,wb));s=a*b
 A=[lift(orb(2),c) for c in D[str((2,wa))]]
 B=[lift(orb(3),c) for c in D[str((3,wb))]]
 normed=set(tuple(mul(x,y)) for x,y in product(A,B));del A,B
 print('distinct primitive char normalized',len(normed),flush=True)
 R,C=defaultdict(list),defaultdict(list)
 for f in margin(7,wa,b):R[tuple((x-f[0])%13 for x in f[1:])].append(f)
 for f in margin(13,wb,a):C[tuple((x-f[0])%7 for x in f[1:])].append(f)
 print('marginal cuts',sum(map(len,R.values())),sum(map(len,C.values())),flush=True)
 allU=[]; stats=Counter()
 for al in normed:
  d=[[0]*13]+[[0]+list(al[i*12:i*12+12]) for i in range(6)]
  r=list(map(sum,d));c=list(map(sum,zip(*d)));tot=sum(r)
  rs=R.get(tuple(x%13 for x in r[1:]),[]);cs=C.get(tuple(x%7 for x in c[1:]),[])
  for rr,cc in product(rs,cs):
   U=[[(91*d[i][j]+7*(rr[i]-r[i])+13*(cc[j]-c[j])+tot-s) for j in range(13)] for i in range(7)]
   assert all(x%91==0 for y in U for x in y)
   u=tuple(U[k%7][k%13]//91 for k in range(91))
   m=max(map(abs,u));stats[m]+=1
   if m<=2:allU.append(u)
 print('lift maximum histogram',dict(stats),'bounded distinct',len(set(allU)),flush=True)
 return sorted(set(allU))
def cert(x,w):return all(sum(x[i]*x[(i+k)%len(x)] for i in range(len(x)))==w*(k==0) for k in range(len(x)))
def canon(x):
 n=len(x)
 return min(x[i:]+x[:i] for i in range(n))
def control():
 D=json.loads(pathlib.Path(__file__).with_name('positive-controls.json').read_text())
 A=all_arrays(4); targets={canon(x) for x in A if max(map(abs,x))<=1}
 print('controls',len(targets))
 for P,N in D['CW(91,6)']:
  x=tuple(int(i in P)-int(i in N) for i in range(91))
  if sum(x)<0:x=tuple(-v for v in x)
  assert cert(x,36) and canon(x) in targets
 lookup={canon(x) for x in A}
 for P,N in D['CW(182,6)']:
  w=tuple(int(i in P)-int(i in N) for i in range(182))
  assert cert(w,36)
  aa=[w[i if not i%2 else i+91] for i in range(91)]
  dd=[w[i if i%2 else i+91] for i in range(91)]
  B,C=[tuple(x+sign*y for x,y in zip(aa,dd)) for sign in (1,-1)]
  assert all(canon(v if sum(v)>0 else tuple(-i for i in v)) in lookup for v in (B,C))
  assert all((x-y)%2==0 and not abs(x)==abs(y)==2 for x,y in zip(B,C))
  assert tuple((B[i%91]+(-1)**i*C[i%91])//2 for i in range(182))==w
 print('recovered 2 stored CW(91,36) rows and both layer pairs of 2 stored CW(182,36)',flush=True)
def search():
 A=all_arrays(16);assert all(cert(x,144) for x in A)
 pathlib.Path(__file__).with_name('normalized-icw.json').write_text(json.dumps(A,separators=(',',':'))+'\n')
 # For potential pairs, allow independent translations, then require equal parity
 # support and no coordinate on which both have modulus two.
 D=defaultdict(list);seen=set()
 for x in A:
  for j in range(91):
   y=x[j:]+x[:j]
   if y in seen:continue
   seen.add(y)
   h=sum(((a%2)<<i) for i,a in enumerate(y));double=sum(((abs(a)==2)<<i) for i,a in enumerate(y))
   D[h].append((double,y))
 print('translated ICW',len(seen),'parities',len(D),'largest bin',max(map(len,D.values()),default=0),flush=True)
 for x in A:
  h=sum(((a%2)<<i) for i,a in enumerate(x));double=sum(((abs(a)==2)<<i) for i,a in enumerate(x))
  for d,y in D[h]:
   if d&double:continue
   z=tuple((x[i%91]+(-1)**i*y[i%91])//2 for i in range(182))
   assert max(map(abs,z))<=1 and cert(z,144)
   print('FOUND',z,flush=True);pathlib.Path(__file__).with_name('cw182_witness.json').write_text(json.dumps(z));return
 print('NO COMPATIBLE PAIR',flush=True)
if __name__=='__main__':control();search()
