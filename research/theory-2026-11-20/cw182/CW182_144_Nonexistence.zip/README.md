# No circulant weighing matrix of order 182 and weight 144

Start with **cw182.pdf**. The 4-page paper proves that all candidate rows are reached; the companion source is the finite verification of the resulting small integer enumeration. Both proper and improper matrices are excluded. No unproved computational hypothesis is used.

## Independent replays

Python 3.9+ with standard library only (assertions enabled):
```sh
python3 periods.py
python3 lifts.py
```

C++17, entirely independent of the Python code and saved candidate data:
```sh
g++ -std=c++17 -O2 -Wall -Wextra check.cpp -o check
./check
```

The exact Python period search uses rational LDL and a bivariate tensor model; the C++ program uses a short Gram shell bound and a univariate cyclotomic model. Row reconstruction also differs. The small-weight controls run automatically. Calls overwrite periods.json and normalized-icw.json with deterministic regenerated copies.

## Files

- cw182.pdf, cw182.tex: theorem and proof.
- periods.py, lifts.py, check.cpp: independent scripts/program described above.
- periods.json, normalized-icw.json: generated shell/row certificates. Rows use indices 0,...,90 in cyclic order, sign fixed to positive total. Allow all translations to recover every such bounded row.
- positive-controls.json: support pairs of two rows each at (91,36) and (182,36), from Daniel M. Gordon’s La Jolla database; keys use square-root weight, not weight. See PRIOR.md and DATA_LICENSE.txt.
- python.out, cpp.out: expected reference outputs.
- SHA256SUMS: integrity hashes of all other files.

Both implementations find 32 normalized bounded rows at (91,144). Their 2,912 translations admit no compatible pair for order 182. The C++ replay prints the exact obstruction minima (5 and 27). Python directly checks all autocorrelations of the known rows and reconstructs the two known order-182 control examples; C++ independently checks the smaller-weight classification and all regenerated lifts. The source is self-contained apart from the Python fixture and regenerated period JSON; no numerical solver or external math library is required.
