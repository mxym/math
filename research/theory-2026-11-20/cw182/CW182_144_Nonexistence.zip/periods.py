"""Exact Gaussian-period basis and bounded trace enumeration for K=Q(zeta7,zeta13).
Coordinates (i,j) use 1<=i<=6, 1<=j<=12; exponent zero is minus the sum of the nonzero powers.
"""
from functools import lru_cache
from fractions import Fraction as F
from math import gcd,isqrt
from itertools import product
import json, pathlib
pairs=list(product(range(1,7),range(1,13)))
def ind(i,j):return (i-1)*12+j-1
def orb(t):
 left=set(pairs);o=[]
 while left:
  i,j=min(left);row=[]
  while (i,j) in left:
   row.append((i,j));left.remove((i,j));i,j=i*t%7,j*t%13
  o.append(row)
 return o
def gram(O):
 d=len(O);L=72//d
 return [[sum((6 if i==h else -1)*(12 if j==k else -1) for i,j in a for h,k in b)//L for b in O] for a in O]
@lru_cache(None)
def expansion(i,j):
 return tuple((ind(a,b),(1 if i else -1)*(1 if j else -1)) for a in ([i] if i else range(1,7)) for b in ([j] if j else range(1,13)))
def mul(a,b,conj=False):
 C=[0]*72; aa=[(i,j,w) for (i,j),w in zip(pairs,a) if w];bb=[(i,j,w) for (i,j),w in zip(pairs,b) if w]
 for i,j,w in aa:
  for h,k,x in bb:
   r,t=(i-h)%7,(j-k)%13
   if not conj:r,t=(i+h)%7,(j+k)%13
   for idx,sg in expansion(r,t):C[idx]+=sg*w*x
 return C
def lift(O,c):
 a=[0]*72
 for o,w in zip(O,c):
  for i,j in o:a[ind(i,j)]=w
 return a
def shell(G,T):
 # G=L D L^t; quadratic energy=sum D_i(x_i+sum_{j>i}L_{ji}x_j)^2.
 n=len(G);L=[[F(i==j) for j in range(n)] for i in range(n)];d=[F(0)]*n
 for i in range(n):
  d[i]=G[i][i]-sum((L[i][k]**2*d[k] for k in range(i)),F(0))
  for j in range(i+1,n):
   L[j][i]=(G[j][i]-sum((L[i][k]*L[j][k]*d[k] for k in range(i)),F(0)))/d[i]
 assert all(v>0 for v in d)
 x=[0]*n
 def rec(i,R):
  if i<0:
   if R==0:yield tuple(x)
   return
  c=sum((L[j][i]*x[j] for j in range(i+1,n)),F(0));low=c.numerator//c.denominator
  lim=isqrt(int(R/d[i]))+1
  for k in range(-low-lim-1,-low+lim+1):
   t=R-(c+k)**2*d[i]
   if t>=0:
    x[i]=k;yield from rec(i-1,t)
 yield from rec(n-1,F(T))
def calc(t,w):
 O=orb(t);G=gram(O)
 raw=list(shell(G,w*len(O))); good=[v for v in raw if mul(lift(O,v),lift(O,v),True)==[w]*72]
 print('period',t,'dim',len(O),'weight',w,'traceshell',len(raw),'Weil',len(good),flush=True)
 return good
if __name__=='__main__':
 D={}
 for t,w in ((2,16),(3,9),(2,4)):
  D[str((t,w))]=calc(t,w)
 pathlib.Path(__file__).with_name('periods.json').write_text(json.dumps(D))
