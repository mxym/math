# Two qutrits: the second upper SDP attains the exact PPT entanglement cost

**Claim.** For every complex state on C³ ⊗ C³, κ₂(ρ) = χ₂(ρ) = 2^E_exact(ρ). The first equality is the new assertion; the second is Song–Zong–Yang's theorem. We do not infer equality of χ₁ and χ₂.

The accompanying three-page PDF / TeX describes an exact extension of the preprint's published matrix certificates. In the κ₂ dual the one unjustified positive input of the old certificate can be indefinite. Replacing it by a positive matrix costs a known rational matrix on each box. All 126 original boxes have enough slack for that cost, rigorously retaining more than 1/100000 of the identity in each finite region. Near the missing endpoint the paper's independent analytic lemma already has precisely the weaker hypotheses needed. This is a private review package, not an independently published or peer-reviewed claim.

## Reproduce

The original data and upstream code are not redistributed in this package. The source is the [authors' November 2026 certificate release](https://github.com/wei-song527/qutrit-ppt-cost/tree/482e41dfb6a325f00da84b2880bcff8eaf3f37dc), accompanying [arXiv:2611.12993v1, Secs. III–V](https://arxiv.org/html/2611.12993v1). From this directory, on Python 3.9 or later:

```sh
git clone https://github.com/wei-song527/qutrit-ppt-cost.git
git -C qutrit-ppt-cost checkout --detach 482e41dfb6a325f00da84b2880bcff8eaf3f37dc
python3 verify_kappa2.py qutrit-ppt-cost
python3 qutrit-ppt-cost/verify_boundary.py
```

No optimization solver, NumPy, or floating-point spectral estimate is needed. The new script checks SHA-256 hashes of the three data files and the original residual-verification code before use. It calls the upstream per-region and domain-coverage checkers with both complex matrix-unit orientations enabled. It independently recovers the offending completely positive map on the identity from its integer Gram factors, then tests the new strict matrix bounds by exact positive rational Schur pivots. Every relevant original and corrected box inequality is thus recomputed rather than read from an upstream success log. The separately run boundary checker is only a supporting test of the published analytic lemma; that lemma, not sampling, is the reason the continuum 0 < t ≤ 1/640 is covered. See verified.txt for the new replay output and SHA256SUMS for file integrity.
