#!/usr/bin/env python3
"""Verify the new two-qutrit comparison using SZY's separately supplied certificate checkout.
Only the Python standard library is needed. Usage: python3 verify_kappa2.py /path/to/qutrit-ppt-cost
"""
import hashlib, importlib.util, json, sys
from fractions import Fraction as F
from pathlib import Path

PIN="482e41dfb6a325f00da84b2880bcff8eaf3f37dc"
HASH={
 "verify_certificates.py":"80a430a5d89be10d249fb3a5c80319c0f5677b3de0bf027e2ff46b5a2a458276",
 "data/middle.json":"6d670ac3e76de8101409fcee68bd1cd6c331ecb6b6b90e40e741e70c67064308",
 "data/dyadic.json":"d26f7c3fa65aaa83f88c207988851fb408bb1151f0281f13b1448842f23ba2d9",
 "data/upper.json":"77abbf87c9abd40a5e608d1b58064daa5913e682cb6a82c5a6199bbe9bc132e9",
}
GRAM_DIAG=(1,1,1,2,2,2,2,2,2)
FLOOR=F(1,100000)

def map_identity(record):
    """Independently trace out the input index of the Choi Gram matrix for the V map."""
    dim=9; d=record["maps"]["V"]; den=record["gram_denominator"]
    assert d["input_dimension"]==d["output_dimension"]==dim
    m=[[0]*dim for _ in range(dim)]
    for b in d["blocks"]:
        ids=b["indices"]; grams=b["gram_numerators"]
        assert len(grams)==len(ids)
        for i, a in enumerate(ids):
            for j, c in enumerate(ids):
                if a//dim==c//dim:
                    m[a%dim][c%dim]+=sum(x*y for x,y in zip(grams[i],grams[j]))
    return [[F(x,den*den) for x in row] for row in m]

def definite(m):
    """Positivity by successively taking the Schur complement of a positive pivot."""
    assert all(m[i][j]==m[j][i] for i in range(len(m)) for j in range(len(m)))
    for _ in range(len(m)):
        assert m[0][0]>0, "nonpositive exact pivot"
        m=[[m[i][j]-m[i][0]*m[0][j]/m[0][0] for j in range(1,len(m))]
           for i in range(1,len(m))]

def main(path):
    root=Path(path)
    for f,h in HASH.items():
        assert hashlib.sha256((root/f).read_bytes()).hexdigest()==h,f
    source=root/'verify_certificates.py'
    spec=importlib.util.spec_from_file_location('szy_certificate',source)
    szy=importlib.util.module_from_spec(spec);spec.loader.exec_module(szy)
    szy.AUDIT_ALL_UNITS=True
    checked=0
    for group in ("middle","dyadic","upper"):
        data=json.loads((root/("data/"+group+".json")).read_bytes())
        records=[data] if group=="upper" else data["records"]
        results={}
        for i,r in enumerate(records):
            # Reconstruct every coefficient residual, including all complex adjoint units,
            # plus SZY's original scalar polynomial/box bounds. Do not trust reported logs.
            if group=="upper":
                assert r["amplitude_box"]==[["13/16","1"]]*3
                result=szy.balanced(r); excess=F(1)
            else:
                assert r["id"]==i
                result=szy.regional(r); results[i]=result
                xl,xu,tl,tu=result["box"]; excess=min(F(1),2*xu*xu+tu*tu-2)
                assert excess>=0
            margin=result["margin"]; penalty=map_identity(r)
            a=[[(margin-FLOOR)*(GRAM_DIAG[i] if i==j else 0)-excess*penalty[i][j]
                for j in range(9)] for i in range(9)]
            definite(a);checked+=1
        if group=="middle":
            assert szy.tree_check(data,results)==(243,119,3)
        if group=="dyadic":
            assert len(results)==6
            for i,rr in results.items():
                u=F(1,10*2**i);assert rr["box"]==[1-u*u/2,F(1),u/2,u]
        print(f'{group}: {len(records)} corrected residuals strictly exceed N/100000',flush=True)
    assert checked==126
    assert szy.EVALUATIONS['upper_units']==17010 and szy.EVALUATIONS['lower_audit_units']==13608
    print('PASS: 126 corrected full-domain inequalities; 30,618 original matrix-unit residuals audited.')
if __name__=="__main__":
    if not __debug__:raise SystemExit("Run without -O")
    if len(sys.argv)!=2:raise SystemExit(__doc__)
    main(sys.argv[1])
