"""Elementary propagated upper bounds assuming only the just-proved r_3(7)<=281."""
from math import comb
v=lambda i:(3**i-1)//2
m=281
for d,N,p,q in [(8,748,-951,4),(9,2013,-1934,3),(10,5478,-1763,1)]:
 low=None;ct=0
 for a in range((N+2)//3,m+1):
  for b in range((N-a+1)//2,min(a,N-a)+1):
   t=(a,b,N-a-b);X=v(d)*sum(comb(n,2) for n in t)-v(d-1)*comb(N,2);Y=v(d)*sum(comb(n,3) for n in t)-v(d-2)*comb(N,3)
   val=p*X+q*Y;low=val if low is None else min(low,val);ct+=1
 assert low>0
 print(d, 'prior dimension upper',m,'triples',ct,'minimum',low,'new upper',N-1);m=N-1
