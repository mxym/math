"""Positive control on the known 236-set, independent pure Python."""
from itertools import product,combinations
from collections import Counter
from math import comb
V=list(product(range(3),repeat=6)); Q=[v for v in V if any(v) and next(x for x in v if x)==1]; assert len(Q)==364
des={'123','124','135','146','156','236','245','256','345','346'}
def label(v):
 w=sum(bool(i) for i in v)
 if w==1:return [2]
 if w==3:return [int(''.join(str(i+1) for i,x in enumerate(v) if x) not in des)]
 if w==6 and v.count(1)%2==0:return [0,1]
 return []
S={(t,)+v for v in V for t in label(v)}
assert len(S)==236 and all(tuple((-a-b)%3 for a,b in zip(x,y)) not in S for x,y in combinations(S,2))
maps=Counter(); total=[0]*8
for q in Q:
 A=[[0]*3 for t in range(3)]
 for t,*v in S:A[t][sum(x*y for x,y in zip(v,q))%3]+=1
 maps[tuple(sorted(A[0]))]+=1
 m=[1]
 for a in A:
  m.extend(sum(comb(z,i) for z in a) for i in (2,3))
 m.append(sum(A[0][i]*A[1][j]*A[2][(-i-j)%3] for i in range(3) for j in range(3)))
 total=[a+b for a,b in zip(total,m)]
assert maps==Counter({(22,45,45):56,(36,36,40):308})
T=[364]
for s in (112,112,12):T.extend([121*comb(s,2),40*comb(s,3)])
T.append(121*112*112*12)
assert total==T
print('Verified 236-cap, all 364 mixed moment contributions, and both full Hill section types.')

H={s[1:] for s in S if s[0]==0}; sec=Counter(tuple((-a-b)%3 for a,b in zip(x,y)) for x,y in combinations(H,2));assert min(sec[x] for x in V if x not in H)>=3
print("Verified minimum external secant multiplicity",min(sec[x] for x in V if x not in H))
