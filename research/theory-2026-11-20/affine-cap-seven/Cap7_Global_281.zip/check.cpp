// Independent, deterministic C++17 verification. Usage: ./replay < bound285.txt
#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;using I=long long;using R=array<int,3>;using V=array<I,8>;
I choose2(I x){return x*(x-1)/2;} I choose3(I x){return x*(x-1)*(x-2)/6;}
I f2(R x){return choose2(x[0])+choose2(x[1])+choose2(x[2]);}
I f3(R x){return choose3(x[0])+choose3(x[1])+choose3(x[2]);}
bool upper(R x){sort(x.begin(),x.end());auto n=x[0]+x[1]+x[2];if(x[2]>45||n>112)return false;if(n<110)return true;
  R m={22,45,45},k={36,36,40};bool a=true,b=true;for(int i=0;i<3;i++){a&=x[i]<=m[i];b&=x[i]<=k[i];}return a||b;}
bool seven(R r){sort(r.begin(),r.end());return r[2]<=112&&(r[1]+r[2]<222||r[0]<=55);}
int dim=7;
set<R>bans,sevenbans;bool faces(R x){sort(x.begin(),x.end());if(dim==7){R y={x[2],x[1],x[0]};return upper(x)&&!bans.count(y);}
int s=x[0]+x[1]+x[2];if(x[2]>20||s>45)return false;if(s<=41)return true;if((x[0]<=9&&x[2]<=18)||x[2]<=15)return true;
static const set<R> ex={{6,16,20},{6,18,18},{7,17,18},{8,16,18},{11,15,16},{12,14,16},{14,14,14},{12,12,18}};
return s==42&&ex.count(x);}
vector<R> ls(int s){vector<R>o;for(int a=0;a<=45;a++)for(int b=0;b<=45;b++){int c=s-a-b;if(c>=0&&c<=45&&faces({a,b,c}))o.push_back({a,b,c});}return o;}
I dot(V a,V b){I t=0;for(int j=0;j<8;j++)t+=a[j]*b[j];return t;}
void verify(map<R,pair<V,I>>&inputs,set<R>&expect){ assert(expect.size()==inputs.size());for(auto s:expect){assert(inputs.count(s));auto [cs,l]=inputs[s];I best=LLONG_MAX,cnt=0;array<vector<R>,3> row={ls(s[0]),ls(s[1]),ls(s[2])};
 for(auto a:row[0])for(auto b:row[1])for(auto c:row[2]){array<R,3> z={a,b,c};bool ok=true;for(int slope=0;slope<3&&ok;slope++){R r;for(int slot=0;slot<3;slot++){
 R line;for(int t=0;t<3;t++)line[t]=z[t][(slot+slope*t)%3];if(!faces(line)){ok=false;break;}r[slot]=line[0]+line[1]+line[2];}
 if(ok&&dim==7){sort(r.rbegin(),r.rend());if(!seven(r)||sevenbans.count(r))ok=false;}}if(!ok)continue;
 I cross=0;for(int i=0;i<3;i++)for(int j=0;j<3;j++)for(int t=0;t<3;t++)if((i+j+t)%3==0)cross+=I(a[i])*b[j]*c[t];
 best=min(best,dot(cs,V{1,f2(a),f3(a),f2(b),f3(b),f2(c),f3(c),cross}));cnt++;}
 I F=dim==7?364:121,G=dim==7?121:40,J=dim==7?40:13;
 V totals={F,G*choose2(s[0]),J*choose3(s[0]),G*choose2(s[1]),J*choose3(s[1]),G*choose2(s[2]),J*choose3(s[2]),G*s[0]*s[1]*s[2]};auto delta=F*l-dot(cs,totals);
 assert(cnt>0 && best==l && F*best-dot(cs,totals)>0);delta=F*best-dot(cs,totals);cout<<s[0]<<"+"<<s[1]<<"+"<<s[2]<<": "<<cnt<<" planes; min="<<best<<" gap="<<delta<<"\n";}
 }
void get(int k,map<R,pair<V,I>>&m){for(int i=0;i<k;i++){R r;for(auto &a:r)cin>>a;V v;for(auto&a:v)cin>>a;I l;cin>>l;assert(m.emplace(r,make_pair(v,l)).second);}}
int main(){int k;cin>>k;dim=6;map<R,pair<V,I>>six;get(k,six);set<R> sx;for(auto &[s,val]:six)sx.insert(s);verify(six,sx);bans=sx;dim=7;int n,p,q,k2;cin>>n>>p>>q>>k>>k2;map<R,pair<V,I>>inputs,extra;get(k,inputs);get(k2,extra); set<R> expect;for(int a=0;a<=112;a++)for(int b=0;b<=a;b++){int c=n-a-b;R r={a,b,c};if(c<0||c>b||!seven(r))continue;I x=1093*f2(r)-364*choose2(n),y=1093*f3(r)-121*choose3(n);if(p*x+q*y<=0)expect.insert(r);}
set<R> e1,e2;for(auto &[r,v]:inputs)e1.insert(r);for(auto &[r,v]:extra)e2.insert(r);assert(e1.size()+e2.size()==expect.size());for(auto r:expect)assert(e1.count(r)+e2.count(r)==1);verify(inputs,e1);sevenbans=e1;verify(extra,e2);cout<<"No "<<n<<"-cap; upper bound "<<n-1<<"\n";}