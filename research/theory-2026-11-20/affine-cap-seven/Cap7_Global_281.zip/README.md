# Recursive cap-set upper bound, dimension seven (20 November 2026)

Private research result. Every cap in F3^7 has at most 281 points. The construction of 236 is unchanged. Upper bound 288 was previously obtained by Thackeray (2022). The exact value is open. This bound uses no unverified higher-dimensional result, and does not depend on the two-Hill scan. See proof.pdf for the geometric proof and primary sources.

~~~
g++ -std=c++17 -O3 check.cpp -o check
./check < chain282.txt
python3 control.py
python3 corollaries.py
~~~

Do not use -DNDEBUG. check.cpp recomputes each exact minimum and strictly positive separation. The first 68 certificates exclude six-flat profiles independently, using the published four-/five-dimensional restrictions. Only then does the verifier exclude size 282 using 16 seven-dimensional certificates and 2 further certificates which may also use exactly those first 16 exclusions. The first three integers on each certificate row are the ordered layer sizes, followed by eight signed integer coefficients and the exact minimum. The line separating the two blocks is: 282 -177 2 16 2. out282.txt is the completed independent replay. Nonnegative integer arrays are tested without imposing any geometric realizability beyond the necessary properties stated in the proof. The code uses only integer arithmetic and the C++ standard library.

The positive control explicitly verifies the Calderbank–Fishburn cap, its slice profiles, all 364 mixed moment contributions, and the external secant condition for the 112-cap. Recent check: November 2026's https://leapsinbounds.org/constants/cap-set-7/ still cites 236–288; https://arxiv.org/abs/2611.19543 changes dimensions nine and eleven, not seven. Current source and mxym/math/openai/math duplicate screens did not find a prior copy of this bound, but do not amount to a guarantee of priority.

The elementary corollaries script checks positive integer separating scores for every permissible hyperplane triple and successively gives upper bounds 747, 2012 and 5477 in dimensions 8, 9 and 10. They propagate the new dimension-seven number, and are not independent constructions or exact determinations. For historical comparison, N. Versluis (2017) Table 13 previously obtained 771, 2070 and 5619 starting from 291 in dimension seven: https://repository.tudelft.nl/file/File_03ab6991-f67e-48c7-87cd-bf4f2a0237d4 .
