'''Standard-library sanity checks; the manuscript proofs are independent of this script.'''
from fractions import Fraction as Q
from itertools import combinations, product
from collections import Counter
from math import comb

def forest(n,edges):
    parent=list(range(n))
    def f(i):
        while i!=parent[i]:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    for u,v in edges:
        u,v=f(u),f(v)
        if u==v:return False
        parent[u]=v
    return True

def verify(m,n):
    v=m+n;edges=[(i,m+j) for i in range(m) for j in range(n)]
    # Uniform spanning-tree primal and uniform LP dual, both exact.
    trees=[t for t in combinations(edges,v-1) if forest(v,t)]
    assert len(trees)==m**(n-1)*n**(m-1)
    count=Counter(e for t in trees for e in t)
    assert set(Q(count[e],len(trees)) for e in edges)=={Q(v-1,m*n)}
    T0=set(trees[0]);feedback=set(edges)-T0
    # Enumerate all connected 2-regular edge subsets (here, simple cycles).
    tested=0
    for k in range(4,2*min(m,n)+1,2):
        for s in combinations(edges,k):
            deg=Counter(x for e in s for x in e)
            if len(deg)!=k or set(deg.values())!={2} or not forest(v,s[1:]):continue
            assert set(s)&feedback
            for mark in set(s)&feedback:
                # Exact offsets in units of pi/3; correlation is cos(delta).
                angle={mark[0]:1,mark[1]:-1}
                corr={0:Q(1),1:Q(1,2),2:Q(-1,2)}
                val=sum((-1 if (i,j)==mark else 1)*corr[abs(angle.get(i,0)-angle.get(j,0))] for i,j in s)
                assert val==k-Q(3,2)>k-2
                # Actual optimal deterministic signed sum, rather than parity shortcut.
                bound=max(sum((-1 if (i,j)==mark else 1)*a[i]*a[j] for i,j in s) for a in (dict(zip(deg,b)) for b in product((1,-1),repeat=k)))
                assert bound==k-2
                tested+=1
    print(f'K_{m},{n}: {len(trees)} spanning trees; {tested} marked-cycle exact quantum/classical checks; tau*={Q(m*n,v-1)}')

for shp in [(2,2),(2,3),(3,3),(3,4)]:verify(*shp)
for r in range(2,31):
    k=2*r-2; mats=[[(i,k+(i+j)%k) for i in range(k)] for j in range(k)]
    paths=[];star=[]
    for j in range(0,k,2):
        edges=mats[j]+mats[j+1];star.append(edges[0]);paths.append(edges[1:]);assert forest(2*k,edges[1:]) and len(edges[1:])==2*k-1
    assert forest(2*k,star) and set(star).union(*paths)==set().union(*mats)
    assert (r-1)*(2*k-1)<k*k and r==1+len(paths)
print('Exact rank-r forest partitions checked for 2<=r<=30.')
# Two-copy four-context nonlocal cycle. A maximal rectangle excludes one label in each coordinate. Three rectangles with the same diagonal missing labels cover; no two rectangles can (the opposing omitted labels supply a hole).
W=set(product(range(4),repeat=2));rect=[{w for w in W if all(x!=y for x,y in zip(w,omit))} for omit in W]
assert all((u|v)!=W for u,v in combinations(rect,2));assert any(set.union(*t)==W for t in combinations(rect,3))
print('CHSH two-copy disjoint-variable RC=3 by exhaustive finite cover; limiting growth base 4/3 by the theorem.')
