#!/usr/bin/env python3
"""Separate integer replay: build the matching coordinates from the six-coordinate quadratic cap;
enumerate x and four outside sizes, not an ordered list of hyperplane section sizes."""
from itertools import product
from math import comb
from pathlib import Path
base=Path(__file__).resolve().parent
A=[]
tris={123,124,245,345,135,146,156,236,256,346}
for v in product(range(3),repeat=5):
 z=v+(1,); w=sum(t!=0 for t in z)
 code=int(''.join(str(i+1) for i,t in enumerate(z) if t))
 if (w==3 and code in tris) or (w==6 and z.count(1)%2==0):A.append(v)
F=list(product(range(3),repeat=5));M={}
for ln in (base/'matching.txt').read_text().splitlines():
 r,e,*edges=map(int,ln.split());key=(r,e);assert key not in M;M[key]=1
 pairs=[(j//1296,(j//36)%36,j%36) for j in edges]
 assert len(pairs)==23 and all(len(set(row))==23 for row in zip(*pairs))
 for i,j,k in pairs:
  v=A[i]+(1,0);w=A[j]+(0,1);t=tuple((a+e*b)%3 for a,b in zip(F[r],A[k]))+(1,1)
  assert all((a+b-c)%3==0 for a,b,c in zip(v,w,t))
assert set(M)=={(r,e) for r in range(243) for e in [-1,1]}
C=list(map(int,(base/'cert_basis.txt').read_text().split()));assert len(C)==45
def score(h,x,T):
 if h<=48:c=[sum(comb(h-24,i)*C[6*i+j] for i in range(5)) for j in range(6)]
 else:
  start=30+(h-55)*6;c=C[start:start+6]
 f=len(T);assert f==3
 h2=h*(h-1)//2;h3=h2*(h-2)//3; b=136-h; b2=b*(b-1)//2;b3=b2*(b-2)//3
 P=sum(t*(t-1)//2 for t in T);Q=sum(t*(t-1)*(t-2)//6 for t in T)
 X=(x,x*(x-1)//2,x*(x-1)*(x-2)//6,P,Q,x*P);Y=(121*h,40*h2,13*h3,121*b2,40*b3,40*h*b2)
 return 364*sum(i*j for i,j in zip(c,X))-sum(i*j for i,j in zip(c,Y))+C[-3]*(1093*h-364*136)+C[-2]*(1093*h2-121*9180)+C[-1]*(1093*h3-40*410040)
assert comb(136,3)==410040
A={h for h in range(24,57) if not 49<=h<=54};lo=None;hi=None;n=0
for x in range(21):
 for a in range(46):
  for b in range(a,46):
   for c in range(b,46):
    d=136-x-a-b-c;t=[a,b,c,d]
    if not c<=d<=45 or any(x+k not in A for k in t):continue
    z=sum(score(h+x,x,t[:i]+t[i+1:]) for i,h in enumerate(t))
    lo=z if lo==None else min(lo,z);hi=z if hi==None else max(hi,z);n+=1
print('Independent replay:',len(M),'matchings;',n,'pencils; extremal integer scores:',lo,hi)
assert (n,lo,hi)==(5841,89943589106,375561186455876)
