#!/usr/bin/env python3
"""Independent coordinate check of the moment identities on an actual projective 112-cap."""
from itertools import combinations
from verify import *
V,A,D,H=build()
S={norm(v+(t,)) for v in H for t in (1,2)}
assert len(S)==112 and all(norm(add(u,v)) not in S and norm(add(u,sm(2,v))) not in S for u,v in combinations(S,2))
P=projective(7);n=len(S);hs={a:sum(sum(t*z for t,z in zip(a,v))%3==0 for v in S) for a in P}
assert len(P)==1093 and all(sum(v)==0 for v in zip(*(outer(n,h) for h in hs.values())))
# One representative hyperplane of every section size. Enumerate K independently via actual point coordinates.
for h in sorted(set(hs.values())):
 u=next(a for a in P if hs[a]==h);p=next(i for i,x in enumerate(u) if x)
 Su=[v for v in S if sum(a*b for a,b in zip(u,v))%3==0];sumv=[0]*6
 for v in P:
  if v[p]:continue
  x=sum(sum(a*b for a,b in zip(v,s))%3==0 for s in Su)
  t=[hs[w]-x for w in (v,norm(add(v,u)),norm(add(v,sm(2,u))))]
  assert x+sum(t)+(h-x)==n
  sumv=[a+b for a,b in zip(sumv,mvec(x,t,n,h))]
 assert sumv==[0]*6
print('Positive control: all global moments and all six local identities on the doubled Hill 112-cap, for sections',sorted(set(hs.values())))
