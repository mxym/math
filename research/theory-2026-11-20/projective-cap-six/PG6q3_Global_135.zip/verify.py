#!/usr/bin/env python3
"""Exact proof checker. Stock Python only; execute inside this directory."""
from itertools import product, combinations, combinations_with_replacement
from math import comb
from pathlib import Path
DIR=Path(__file__).resolve().parent
def add(x,y):return tuple((a+b)%3 for a,b in zip(x,y))
def sm(k,x):return tuple(k*a%3 for a in x)
def norm(x):return sm(next(a for a in x if a),x)
def projective(n):return [x for x in product(range(3),repeat=n) if any(x) and x==norm(x)]
def build():
 V=list(product(range(3), repeat=5)); supp=lambda x:tuple(i+1 for i,y in enumerate(x) if y)
 T={(1,2,3),(1,2,4),(2,4,5),(3,4,5),(1,3,5),(1,4,6),(1,5,6),(2,3,6),(2,5,6),(3,4,6)}
 assert all(sum(set(ij)<=set(t) for t in T)==2 for ij in combinations(range(1,7),2))
 Delta=[v for v in projective(5) if supp(v) in T]
 A=[v for v in V if supp(v)+(6,) in T or (all(v) and (v.count(1)+1)%2==0)]
 assert (len(Delta),len(A))==(20,36)
 M=[[v[i]*v[j]%3 for i in range(5) for j in range(i,5)] for v in Delta]
 r=0
 for j in range(15):
  k=next((k for k in range(r,len(M)) if M[k][j]),None)
  if k is None:continue
  M[k],M[r]=M[r],M[k];M[r]=list(sm(M[r][j],M[r]))
  for k in range(len(M)):
   if k!=r:M[k]=list(add(M[k],sm(-M[k][j],M[r])))
  r+=1
 assert r==14 and all(sum(t*t for t in v)%3==0 for v in Delta)
 comps=[]
 for sig in [1,-1]:
  H={v+(0,) for v in Delta}|{norm(sm(sig,v)+(1,)) for v in A}
  comps.append(H);assert len(H)==56
  assert all(sum(a*a for a in h)%3==0 for h in H)
  for u,v in combinations(H,2):
   assert norm(add(u,v)) not in H and norm(add(u,sm(2,v))) not in H
 assert comps[0]!=comps[1]
 return V,A,Delta,H
def matches(V,A):
 seen=set()
 for row in (DIR/'matching.txt').read_text().splitlines():
  n,s,*c=map(int,row.split());assert n in range(243) and s in (1,-1) and len(c)==23 and (n,s) not in seen;seen.add((n,s))
  xs=[(t//1296,t%1296//36,t%36) for t in c]
  assert all(0<=v<36 for t in xs for v in t)
  assert all(len({t[j] for t in xs})==23 for j in range(3))
  for i,j,k in xs:assert add(A[i],A[j])==add(V[n],sm(s,A[k]))
 assert len(seen)==486
 print('Verified disjoint matchings: 486 placements x 23 triples.')
def profiles(N):
 # Every Table 3 bound n<=135 applies to N=136 by deletion OUTSIDE the two fixed sections.
 def table(x,y):
  return y>=48 and (x>=52 or x==51 and y>=49 or x==50 and y==50)
 left=[]
 for hs in combinations_with_replacement(range(20,57),4):
  if sum(hs)!=N+60:continue
  d,c,b,a=hs
  if table(a,b):continue
  if c>=48 and (168-(a+b+c)) < 23:continue
  left.append(hs)
 assert left==[(46,47,47,56),(47,47,47,55)]
 print('Surviving sorted Delta-pencil profiles:',left)
def mvec(x,a,N,h):
 b=N-h;p=sum(comb(s,2) for s in a);q=sum(comb(s,3) for s in a)
 return (364*x-121*h,364*comb(x,2)-40*comb(h,2),364*comb(x,3)-13*comb(h,3),364*p-121*comb(b,2),364*q-40*comb(b,3),364*x*p-40*h*comb(b,2))
def outer(N,h):return [1093*comb(h,k)-a*comb(N,k) for k,a in [(1,364),(2,121),(3,40)]]
def pen136():
 N=136; z=list(map(int,(DIR/'cert_eval.txt').read_text().split()))
 assert len(z)==6*33+3
 H=set(range(24,49))|{55,56};h6={h:z[(h-24)*6:(h-23)*6] for h in H}; out=z[-3:]
 ns=0; gap=None; top=None;where=None
 for hs in combinations_with_replacement(sorted(H),4):
  w=sum(hs)-N
  if w%3:continue
  x=w//3
  t=[h-x for h in hs]
  if not 0<=x<=20 or min(t)<0 or max(t)>45:continue
  # No restrictions on the type of a 20-point section.
  # In particular all Gamma_1 (tangent) possibilities are allowed.
  sc=0
  for i,h in enumerate(hs):
   v=mvec(x,t[:i]+t[i+1:],N,h)
   sc+=sum(a*b for a,b in zip(h6[h],v))+sum(a*b for a,b in zip(out,outer(N,h)))
  ns+=1
  if gap==None or sc<gap:gap=sc;where=x,hs
  top=sc if top==None else max(top,sc)
 print('N=136 pencil patterns / exact min / max / minimizer:',ns,gap,top,where)
 assert ns==5841 and gap>0
if __name__=='__main__':
 V,A,D,H=build();matches(V,A);profiles(136);pen136()
