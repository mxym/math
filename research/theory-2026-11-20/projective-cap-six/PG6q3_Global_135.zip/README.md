# A pencil obstruction to projective 136-caps
The proven bound is 112 ≤ m₂(6,3) ≤ 135. It does not establish the exact answer.

- Start with proof.pdf or proof.tex (two pages, references and precise outside dependencies).
- `python3 verify.py` checks the coordinates, quadratic-form uniqueness, all 486 explicit matchings, the two surviving Δ-pencil profiles, and the strict inequality on every one of 5,841 admissible pencils.
- `python3 replay.py` derives the coefficients independently from the 45 numbers in cert_basis.txt and enumerates outside slice sizes directly. It checks actual seven-coordinate collinearity for every matching edge.
- `python3 control.py` builds the known doubled-Hill projective 112-cap from scratch and tests all nine exact pencil/global identities for representatives of every occurring section size.
- No third-party dependencies; do not use python -O (which disables assertions).
- matching.txt: one row per (lexicographic translation index, sign), followed by 23 base-36 encoded triples in a matching. The three-coordinate indices are taken separately across the three different hyperplanes.
- cert_eval.txt: 33 consecutive 6-integer rows (section sizes 24 to 56), then a 3-integer global row. Only the justified section sizes 24–48, 55, and 56 occur.
- cert_basis.txt: for section size h≤48 the six coefficients are polynomials in the binomial basis C(h−24,k), k=0,...,4. Next are six each for h=55,56, then the global row. This gives the same score as the expanded table.

Historical baseline: Barát–Edel–Hill–Storme (2004), Corollary 7.6; the November 2026 Quantavane collection of seven projective improvements did not list this dimension/field. Public repos screened: mxym/math main 1caa2988f5ee03c5478919849040e223a69e8fa3 and the openai/math catalogue 4eaee87548250b2682affda7d05d947c05554bae. Absence of a matching search result is not a priority certificate. Nothing was published.
