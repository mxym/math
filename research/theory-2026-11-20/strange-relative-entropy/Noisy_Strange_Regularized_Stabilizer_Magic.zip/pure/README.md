# Exact stabilizer code overlap of qutrit Strange powers

Review strange.pdf (three pages, LaTeX source included). The result concerns normalized stabilizer projectors and squared overlaps, not exact rank or a stabilizer-circuit conversion rate.

Theorem: the maximum for an r-generator stabilizer code is 3^(-floor(r/2)) 2^(-(r mod 2)), independently of n≥r. As a consequence the Strange state's regularized relative entropy of magic over normalized stabilizer mixtures is (log2 3)/2. A prime-dimensional result on one-qudit inputs appears with proof; a second application is the exact qutrit T-state additive value. The finite arithmetic replay (python check.py; no dependencies) enumerates every stabilizer code and syndrome through n=3. It is not a premise of the general proof.

Source comparison, checked 2026-11-20:
- Veitch et al. (2014), doi:10.1088/1367-2630/16/1/013009, establishes nonadditivity from two Strange copies. 
- Bravyi et al. (2019), doi:10.22331/q-2019-09-02-181, give the qubit stabilizer alignment framework.
- Wang, Wilde, Su (2020), doi:10.1103/PhysRevLett.124.090505, Proposition 2 computes regularized thauma log2(5/3) of Strange and relative entropy of magic log2(3/2) of Norrell; it neither identifies Strange's normalized stabilizer R∞ with thauma, nor does so for the qutrit T state. Their Theorem 6 gives an upper bound on the ratio N→S in a larger operation class.
- Takagi, Regula, Wilde (2022), doi:10.1103/PRXQuantum.3.010348, Propositions 12,14 give equality between min and max relative entropies for tensor powers of injection and Strange states without the new all-n numerical values for Strange.
- Rubboli et al. (2024), Quantum 8, 1492, Proposition 12 explains Strange-state two-copy nonadditivity of divergences. arXiv:2507.05696 §III.D.3 treats larger Wigner-based free sets, not STAB. The 2026 papers arXiv:2605.22392 (qubit-relative-entropy emphasis) and arXiv:2605.28586 (stabilizer rank) do not supply this code/fidelity theorem. Targeted searches of primary literature and the indexed mxym/math and openai/math repositories did not surface the same all-copy result; this is not an exhaustive priority certification.
