"""Independent small-dimension arithmetic check; standard-library Python only.
Enumerate all isotropic exponent spaces in dimension 2n over F3 via RREF,
then *all* characters. S's symmetric Weyl characteristic is -1/2 off zero.
Returns unreduced integer scores divided by 3^r 2^(n+1) and checks maxima."""
from itertools import combinations, product
from fractions import Fraction as F
def spaces(d,r):
    for piv in combinations(range(d),r):
        fr=[(i,j) for i in range(r) for j in range(piv[i]+1,d) if j not in piv]
        for fill in product(range(3),repeat=len(fr)):
            a=[[0]*d for _ in piv]
            for i,j in enumerate(piv):a[i][j]=1
            for (i,j),v in zip(fr,fill):a[i][j]=v
            yield a
def go(n,r):
    d=2*n
    ls=list(product(range(3),repeat=r))
    coeff=[[2 if sum(i*j for i,j in zip(x,y))%3==0 else -1 for x in ls] for y in ls]
    best=-1;N=0
    for a in spaces(d,r):
        if any(sum(a[i][l]*a[j][n+l]-a[j][l]*a[i][n+l] for l in range(n))%3 for i in range(r) for j in range(i)):continue
        N+=1;scores=[]
        for x in ls:
            v=[sum(x[i]*a[i][l] for i in range(r))%3 for l in range(d)]
            w=sum(bool(v[i] or v[i+n]) for i in range(n))
            scores.append((-1)**w * 2**(n-w))
        best=max(best,max(sum(i*j for i,j in zip(scores,h)) for h in coeff))
    actual=F(best,3**r * 2**(n+1))
    assert actual==F(1,3**(r//2)*2**(r%2)),(n,r,actual)
    print('n=%d r=%d spaces=%d syndromes=%d max=%s PASS'%(n,r,N,N*3**r,actual))
for n in range(1,4):
    for r in range(n+1):go(n,r)
