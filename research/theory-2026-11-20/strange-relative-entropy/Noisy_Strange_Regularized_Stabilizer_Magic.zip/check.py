"""Exact standard-library replay for the noisy-Strange support function and integer rounding.
Run: python check.py. This finite check is not a premise of the proofs in noisy.pdf.
The real part of a symmetric qutrit Weyl syndrome phase, doubled, is 2 or -1.
Tr(X_z W_v) is z+2 for v=0 and (1-z)/2 otherwise, since the Strange
projector is (I-parity)/2 and Tr(parity W_v)=1 for every symmetric Weyl.
"""
from fractions import Fraction as F
from itertools import combinations,product
from math import floor

def rref(n,r):
    for piv in combinations(range(2*n),r):
        free=[(i,j) for i,p in enumerate(piv) for j in range(p+1,2*n) if j not in piv]
        for vals in product(range(3),repeat=len(free)):
            a=[[0]*(2*n) for i in piv]
            for i,p in enumerate(piv):a[i][p]=1
            for (i,j),v in zip(free,vals):a[i][j]=v
            if all(sum(u[i]*v[n+i]-v[i]*u[n+i] for i in range(n))%3==0
                   for u,v in combinations(a,2)):yield a

def polynomial_test(n):
    zs=(1,2,4,5,6,11); r=n
    coords=list(product(range(3),repeat=r))
    chars=[tuple(2 if sum(i*j for i,j in zip(x,y))%3==0 else -1 for x in coords) for y in coords]
    hists=set(); count=0
    for basis in rref(n,r):
        w=[]
        for x in coords:
            v=[sum(x[i]*basis[i][j] for i in range(r))%3 for j in range(2*n)]
            w.append(sum(bool(v[i] or v[n+i]) for i in range(n)))
        for row in chars:
            h=[0]*(n+1)
            for weight,phase in zip(w,row):h[weight]+=phase
            hists.add(tuple(h));count+=1
    maxes=[]
    for z in zs:
        m=F(z+1,2); h2=F(z*z+2,3)
        terms=[(z+2)**(n-w)*(1-z)**w*2**(n-w) for w in range(n+1)]
        best=F(max(sum(v*t for v,t in zip(h,terms)) for h in hists),3**r*2**(n+1))
        ex=max(h2**k*m**(n-2*k) for k in range(n//2+1))
        assert best==ex,(n,z,best,ex)
        maxes.append(str(best))
    print('n',n,'all stabilizers',count,'weight-syndrome polynomials',len(hists),
          'z',zs,'exact maxima',','.join(maxes),'PASS')

def rounding():
    L,H=F(5,6),F(25,27);cases=0
    for n in range(1,201):
        for k in range(n//2+1,n+1):
            x=F(k,n)
            if x<=L:theta,u,v=1,x,0
            elif x<H:theta,u,v=(H-x)/(H-L),L,H
            else:theta,u,v=0,0,x
            A=n*theta*u;B=n*theta*(1-u);C=F(n,2)*(1-theta)*v;E=F(n,2)*(1-theta)*(1-v)
            c,e=floor(C),floor(E)
            a,b=k-2*c,n-k-2*e
            assert min(a,b,c,e)>=0 and a+2*c==k and a+b+2*(c+e)==n
            assert all(abs(i-j)<2 for i,j in zip((a,b,c,e),(A,B,C,E)))
            cases+=1
    print('parity/exact target rounding, all nonfree types through n=200:',cases,'PASS')
if __name__=='__main__':
    for n in (1,2,3):polynomial_test(n)
    rounding()
