import itertools as I,collections,numpy as np,sympy as sp
def red(v):return tuple(x-v[-1] for x in v[:-1])
def mul(a,b):
 z=[0]*7
 for i,x in enumerate(a):
  for j,y in enumerate(b):z[(i+j)%7]+=x*y
 return red(z)
def co(a):return red((a[0],0)+a[:0:-1])
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
C=[];orig=[];M={}
for mask in range(128):
 a=tuple(1 if mask>>i&1 else -1 for i in range(7));r=red(a)
 if r not in C:C.append(r);orig.append(a)
 M.setdefault(r,[]).append(a)
D=[];ds=[]
for mask in range(8):
 a=[5]+[1 if mask>>i&1 else -1 for i in range(3)];a=tuple(a+a[:0:-1])
 if sum(a)>0:D.append(red(a));ds.append(a)
def blocks(data):
 ia,id,ib,*v=data;A=D[ia];E=D[id];B=C[ib];delta=sub(mul(A,E),mul(B,co(B)));P=[(v[i],v[i+1],v[i+2]) for i in range(0,len(v),3)]
 pols=[[None]*8 for _ in range(8)];pols[0][0]=[ds[ia]];pols[1][1]=[ds[id]];pols[0][1]=M[C[ib]];py={mul(delta,k):w for k,w in M.items()}
 for i,(ix,iy,d) in enumerate(P,2):
  X,Y=C[ix],C[iy];pols[i][i]=[ds[d]];pols[0][i]=M[X];pols[1][i]=M[Y]
  U=sub(mul(E,X),mul(B,Y));V=sub(mul(A,Y),mul(co(B),X))
  for j,(jx,jy,e) in enumerate(P[:i-2],2):
   val=add(mul(co(C[jx]),U),mul(co(C[jy]),V));pols[j][i]=py[val]
 return pols
def main():
 hist=collections.Counter();trip=0;rep=set()
 for line in open('p7rank2.log'):
  if line[:2]!='S ':continue
  data=list(map(int,line.split()[1:]));P=blocks(data);h=[sum(P[i][i][0])for i in range(8)];free=[(i,j) for i,j in I.combinations(range(8),2) if len(P[i][j])>1];hist[(tuple(sorted(h)),len(free))]+=1
 print(hist)
if __name__=='__main__':main()
def stage():
 hist=collections.Counter();w=[]
 for line in open('p7rank2.log'):
  if line[:2]!='S ':continue
  data=list(map(int,line.split()[1:]));P=blocks(data);pairs=list(I.combinations(range(8),2))
  for sel in I.product(*[list(map(sum,P[i][j])) for i,j in pairs]):
   T=sp.diag(*[sum(P[i][i][0]) for i in range(8)])
   for (i,j),v in zip(pairs,sel):T[i,j]=T[j,i]=v
   de=T.det(method='domain-ge');hist[de]+=1
   if de==0:
    r=T.rank()
    if r<=6:w.append((data,P,T,r))
 print('count',sum(hist.values()),'det0',hist[0],'low-rank',len(w),collections.Counter(r for a,b,c,r in w));return w
if __name__=='__main__':Ws=stage()
