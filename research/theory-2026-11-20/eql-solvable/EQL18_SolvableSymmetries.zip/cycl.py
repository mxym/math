import itertools as I, numpy as np,collections,sys,math
from functools import cache
def solve(p):
 signs=tuple(I.product((-1,1),repeat=p));diags=[]
 for a in I.product((-1,1),repeat=p//2):
  x=(5,)+a+a[::-1]
  if sum(x)>=0:diags.append(x)
 def quot(v):return tuple(int(x-v[-1]) for x in v[:-1])
 @cache
 def conv(a,b):return quot([sum(a[i]*b[(j-i)%p]for i in range(p))for j in range(p)])
 def inv(a):return a[:1]+a[:0:-1]
 def psd(a): # exact enough to skip only clearly impossible? no numerical filter required.
  return True
 def canon(v):return min(tuple(k*x for x in v[i:]+v[:i])for i in range(p)for k in (-1,1))
 neck=sorted({canon(v)for v in signs if min(v)!=max(v)});Pnorm=[(x,conv(inv(x),x))for x in neck]
 mul=lambda a,u:tuple(a[i*u%p]for i in range(p))
 base=[a for a in diags if a==min(mul(a,u) for u in range(1,p))]
 print('p',p,'bases',len(base),'necklaces',len(neck),flush=True)
 needed=58//p
 for A in base:
  norm={conv(A,D):D for D in diags};assert len(norm)==len(diags)
  S={conv(A,b):b for b in signs if max(b)!=min(b)};assert len(S)==len(signs)-2
  good=[(b,norm[n]) for b,n in Pnorm if n in norm]
  ne=[set()for t in good];Q={}
  for i,(b,d)in enumerate(good):
   for j,(c,e)in enumerate(good[:i+1]):
    z=S.get(conv(inv(b),c))
    if z is not None:
     if i==j:raise AssertionError(('duplicate',A,b,d,z))
     ne[i].add(j);ne[j].add(i);Q[i,j]=z;Q[j,i]=inv(z)
  solutions=[]
  def rec(R,V):
   if len(R)+len(V)<needed-1:return
   if len(R)==needed-1:
    blocks=[[() for j in range(needed)]for i in range(needed)];blocks[0][0]=A
    for i,x in enumerate(R,1):
     blocks[i][i]=good[x][1];blocks[0][i]=good[x][0];blocks[i][0]=inv(good[x][0])
     for j,y in enumerate(R[:i-1],1):blocks[i][j]=Q[x,y];blocks[j][i]=Q[y,x]
    solutions.append(blocks);return
   while V:
    i=V.pop();rec(R+[i],V&ne[i])
  rec([],set(range(len(good))))
  print('A',''.join('+'if x==1 else '-'for x in A[1:p//2+1]),'nodes',len(good),'edges',sum(map(len,ne))//2,'full orbit tuples',len(solutions),flush=True)
  for B in solutions:yield B
if __name__=='__main__':
 import json
 p=int(sys.argv[1]);n=0
 with open('blocks%d.jsonl'%p,'w')as f:
  for B in solve(p):print(json.dumps(B,separators=(',',':')),file=f);n+=1
 print('total tuples',n)
