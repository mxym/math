#include<bits/stdc++.h>
using namespace std;constexpr int p=5,F=p-1;using R=array<int,F>; using V=vector<int>;const R zero{}; 
R operator+(R a,const R&b){for(int i=0;i<F;i++)a[i]+=b[i];return a;}
R operator-(R a,const R&b){for(int i=0;i<F;i++)a[i]-=b[i];return a;}
R operator*(const R&a,const R&b){int c[p]={};for(int i=0;i<F;i++)for(int j=0;j<F;j++)c[(i+j)%p]+=a[i]*b[j];R z;for(int i=0;i<F;i++)z[i]=c[i]-c[F];return z;}
R conjg(const R&a){R z;for(int i=0;i<F;i++)z[i]=(i?(i==1?0:a[p-i]):a[0])-a[1];return z;}
R pol(const array<int,p>&a){R z;for(int i=0;i<F;i++)z[i]=a[i]-a[F];return z;}
int sm(const array<int,p>&a){return accumulate(a.begin(),a.end(),0);}
struct P{int x,y,d;R u,v;};long long bc=0,fc=0;unsigned long long solc=0;
#include "graminc.hpp"
int main(){vector<R> C;map<R,int> ind;vector<array<int,p>> orig;for(int mask=0;mask<1<<p;mask++){array<int,p>a;for(int i=0;i<p;i++)a[i]=mask>>i&1?1:-1;R r=pol(a);if(ind.insert({r,C.size()}).second){C.push_back(r);orig.push_back(a);}}assert(C.size()==(1<<p)-1);
 vector<R> D;vector<array<int,p>> ds;V first;for(int m=0;m<1<<(p/2);m++){array<int,p>a;a[0]=5;for(int i=1;i<=p/2;i++)a[i]=a[p-i]=(m>>(i-1)&1)?1:-1;if(sm(a)<0)continue;D.push_back(pol(a));ds.push_back(a);}
 for(int i=0;i<D.size();i++){bool good=true;for(int k=1;k<p;k++){array<int,p>a;for(int t=0;t<p;t++)a[t]=ds[i][(t*k)%p];good&=ds[i]<=a;}if(good)first.push_back(i);}
 vector<array<int,2*p>> gp(C.size());for(int i=0;i<C.size();i++)for(int j=0;j<2*p;j++){array<int,p>a;for(int t=0;t<p;t++)a[t]=(j>=p?-1:1)*orig[i][(t+j)%p];gp[i][j]=ind.at(pol(a));}
 vector<pair<int,int>> can;V can1;for(int i=0;i<C.size();i++){if(i==*min_element(gp[i].begin(),gp[i].end()))can1.push_back(i);
 for(int j=0;j<C.size();j++){bool a=true;for(int k=0;k<2*p;k++)a &= make_pair(i,j)<=make_pair(gp[i][k],gp[j][k]);if(a)can.push_back({i,j});}}
 cout<<"D "<<D.size()<<" first "<<first.size()<<" pair "<<can1.size()<<" triples "<<can.size()<<"\n";
 auto pos=[](const R&r){assert(r==conjg(r));int a=2*r[0]-r[2];return a>0&&a*a>5*r[2]*r[2];};
 struct Tr{int i,j,k;};vector<Tr>trip;for(auto[x,y]:can)for(int z=0;z<C.size();z++){bool lo=true;for(int g=0;g<2*p;g++)if(make_pair(gp[x][g],gp[y][g])==make_pair(x,y)&&gp[z][g]<z)lo=false;if(lo)trip.push_back({x,y,z});}
 cout<<" triple points "<<trip.size()<<endl;int posb=0,mx=0,tot=0;long long checks=0,graphs=0;long long solutions=0;V sizes(D.size());
 struct Pt{int t,i,j,k,l;R h;};
 for(int ia:first)for(int id=0;id<D.size();id++)for(int ib:can1){
 if(sm(ds[ia])<5||sm(ds[id])<5)continue; R A=D[ia],B=C[ib],E=D[id];R del=A*E-conjg(B)*B;if(!pos(A)||!pos(del))continue;++posb;
 vector<R> U(C.size()*C.size()),Vv(U),N(U);
 auto key=[&](int i,int j){return i*C.size()+j;};
 for(int i=0;i<C.size();i++)for(int j=0;j<C.size();j++){int k=key(i,j);U[k]=E*C[i]-B*C[j];Vv[k]=A*C[j]-conjg(B)*C[i];N[k]=conjg(C[i])*U[k]+conjg(C[j])*Vv[k];}
 for(auto[ix,iy]:can)for(int ie=0;ie<D.size();ie++){if(sm(ds[ie])<5)continue;int v=key(ix,iy);R H=del*D[ie]-N[v];if(!pos(H))continue;tot++;R denom=H*del;
 map<R,int> dshell,cshell;for(int i=0;i<D.size();i++)if(sm(ds[i])>=5)dshell.emplace(denom*D[i],i);for(int i=0;i<C.size();i++)cshell[denom*C[i]]=i;
 vector<R> a(U.size());for(auto[x,y]:can){int t=key(x,y);a[t]=conjg(C[ix])*U[t]+conjg(C[iy])*Vv[t];}
 vector<Pt> pts;for(int it=0;it<trip.size();it++){auto[x,y,z]=trip[it];int t=key(x,y);R h=del*C[z]-a[t];auto J=conjg(h)*h+H*N[t];auto f=dshell.find(J);if(f!=dshell.end())pts.push_back({t,x,y,z,f->second,h});}
 checks+=trip.size();mx=max(mx,(int)pts.size());if(pts.size()<8)continue;
 vector<vector<int>> ne(pts.size()),rows(pts.size(),vector<int>(pts.size()));for(int i=0;i<pts.size();i++)for(int j=0;j<=i;j++){auto&x=pts[i],&y=pts[j];
 R z= H*(conjg(C[x.i])*U[y.t]+conjg(C[x.j])*Vv[y.t])+conjg(x.h)*y.h;if(auto it=cshell.find(z);it!=cshell.end()){assert(i!=j);int g=it->second;rows[i][j]=rows[j][i]=C[g]==zero ? 0:sm(orig[g]);ne[i].push_back(j);ne[j].push_back(i);}}
 graphs++;V so;long long ct=0;
 function<void(V)> cl=[&](V v){if(so.size()==8){ct++;
 TBL T{};auto sumc=[&](int i){return C[i]==zero?0:sm(orig[i]);};
 T[0][0]=sm(ds[ia]);T[1][1]=sm(ds[id]);T[2][2]=sm(ds[ie]);
 T[0][1]=sumc(ib);T[0][2]=sumc(ix);T[1][2]=sumc(iy);
 for(int i=0;i<8;i++){auto&w=pts[so[i]];T[3+i][3+i]=sm(ds[w.l]);T[0][3+i]=sumc(w.i);T[1][3+i]=sumc(w.j);T[2][3+i]=sumc(w.k);for(int j=0;j<i;j++)T[3+j][3+i]=rows[so[i]][so[j]];}
 for(int i=11;i<14;i++)T[i][i]=25;for(int i=0;i<14;i++)for(int j=0;j<i;j++)T[i][j]=T[j][i];
 if(gram(T,0,State{})){cout<<"WITNESS ";for(int i=0;i<14;i++)for(int j=0;j<=i;j++)cout<<T[i][j]<<" ";cout<<endl;}
 if(false){cout<<"S "<<ia<<" "<<id<<" "<<ib<<" "<<ix<<" "<<iy<<" "<<ie;for(int k:so){auto&a=pts[k];cout<<" "<<a.i<<" "<<a.j<<" "<<a.k<<" "<<a.l;}cout<<"\n";}return;}
 if(so.size()+v.size()<8)return;
 // greedy proper coloring then reverse search
 V order,col;int ncol=0;while(!v.empty()){ncol++;V L,keep;for(int i:v){bool ok=true;for(int j:L)if(binary_search(ne[i].begin(),ne[i].end(),j)){ok=false;break;}if(ok){L.push_back(i);order.push_back(i);col.push_back(ncol);}else keep.push_back(i);}v.swap(keep);}
 for(int i=order.size()-1;i>=0&&so.size()+col[i]>=8;i--){V next;int b=order[i];for(int j=0;j<i;j++)if(binary_search(ne[b].begin(),ne[b].end(),order[j]))next.push_back(order[j]);so.push_back(b);cl(next);so.pop_back();}};
 V cand(pts.size());iota(cand.begin(),cand.end(),0);cl(cand);solutions+=ct;if(false&&ct)cout<<"FOUND "<<tot<<" pts "<<pts.size()<<" tuples "<<ct<<"\n";
 }
 cerr<<"base "<<ia<<" "<<id<<" "<<ib<<" triples "<<tot<<" max "<<mx<<" graphs "<<graphs<<" sols "<<solutions<<endl;
 }
 cout<<"TOTAL pos2 "<<posb<<" pos3 "<<tot<<" checks "<<checks<<" maxprofiles "<<mx<<" graphs "<<graphs<<" tuples "<<solutions<<" gramcalls "<<gramCalls<<" freepass "<<freepass<<" fullpass "<<fullpass<<endl;}
