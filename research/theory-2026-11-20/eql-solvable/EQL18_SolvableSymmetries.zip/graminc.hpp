constexpr int ND=14;using TBL=array<array<int,ND>,ND>;using LL=long long;
struct State{int r=0,b[6]={};LL det=1,adj[6][6]{};int vals[ND][6]={};};
long long gramCalls=0,freepass=0,fullpass=0;
bool gram(const TBL&T,int k,const State&s){
 gramCalls++;if(k==11)freepass++;if(k==14){fullpass++;return true;}
 int r=s.r,pos[6],m=0;LL q[6]={};
 for(int i=0;i<r;i++){q[i]=T[k][s.b[i]];if(!q[i]){if(k>=11&&i==0)q[i]=5;else pos[m++]=i;}}
 for(int mask=0;mask<1<<m;mask++){
 for(int j=0;j<m;j++)q[pos[j]]=mask>>j&1?5:-5; LL y[6]={},D=s.det,R=D*T[k][k];
 for(int i=0;i<r;i++){for(int j=0;j<r;j++)y[i]+=s.adj[i][j]*q[j];R-=q[i]*y[i];}
 if(R<0||(R&&r==6))continue;
 int vv[ND]={};bool ok=true;for(int j=0;j<k&&ok;j++){LL z=0;for(int i=0;i<r;i++)z+=s.vals[j][i]*y[i];if(T[j][k])ok=z==T[j][k]*D;else ok=abs(z)==5*D;if(ok)vv[j]=z/D;}
 if(!ok)continue;
 State t=s;for(int i=0;i<r;i++)t.vals[k][i]=q[i];
 if(R){t.b[r]=k;t.r++;t.det=R;for(int i=0;i<r;i++){for(int j=0;j<r;j++)t.adj[i][j]=(R*s.adj[i][j]+y[i]*y[j])/D;t.adj[i][r]=t.adj[r][i]=-y[i];}t.adj[r][r]=D;for(int i=0;i<k;i++)t.vals[i][r]=vv[i];t.vals[k][r]=T[k][k];}
 if(gram(T,k+1,t))return true;
 }return false;}
