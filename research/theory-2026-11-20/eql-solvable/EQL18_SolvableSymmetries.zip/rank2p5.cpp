#include<bits/stdc++.h>
using namespace std;constexpr int p=5,F=p-1;using R=array<int,F>; using V=vector<int>;const R zero{}; 
R operator+(R a,const R&b){for(int i=0;i<F;i++)a[i]+=b[i];return a;}
R operator-(R a,const R&b){for(int i=0;i<F;i++)a[i]-=b[i];return a;}
R operator*(const R&a,const R&b){int c[p]={};for(int i=0;i<F;i++)for(int j=0;j<F;j++)c[(i+j)%p]+=a[i]*b[j];R z;for(int i=0;i<F;i++)z[i]=c[i]-c[F];return z;}
R conjg(const R&a){R z;for(int i=0;i<F;i++)z[i]=(i?(i==1?0:a[p-i]):a[0])-a[1];return z;}
R pol(const array<int,p>&a){R z;for(int i=0;i<F;i++)z[i]=a[i]-a[F];return z;}
int sm(const array<int,p>&a){return accumulate(a.begin(),a.end(),0);}
struct P{int x,y,d;R u,v;};long long bc=0,fc=0;unsigned long long solc=0;
int main(){vector<R> C;map<R,int> ind;vector<array<int,p>> orig;for(int mask=0;mask<1<<p;mask++){array<int,p>a;for(int i=0;i<p;i++)a[i]=mask>>i&1?1:-1;R r=pol(a);if(ind.insert({r,C.size()}).second){C.push_back(r);orig.push_back(a);}}assert(C.size()==(1<<p)-1);
 vector<R> D;vector<array<int,p>> ds;V first;for(int m=0;m<1<<(p/2);m++){array<int,p>a;a[0]=5;for(int i=1;i<=p/2;i++)a[i]=a[p-i]=(m>>(i-1)&1)?1:-1;if(sm(a)<0)continue;D.push_back(pol(a));ds.push_back(a);}
 for(int i=0;i<D.size();i++){bool good=true;for(int k=1;k<p;k++){array<int,p>a;for(int t=0;t<p;t++)a[t]=ds[i][(t*k)%p];good&=ds[i]<=a;}if(good)first.push_back(i);}
 vector<array<int,2*p>> gp(C.size());for(int i=0;i<C.size();i++)for(int j=0;j<2*p;j++){array<int,p>a;for(int t=0;t<p;t++)a[t]=(j>=p?-1:1)*orig[i][(t+j)%p];gp[i][j]=ind.at(pol(a));}
 vector<pair<int,int>> can;V can1;for(int i=0;i<C.size();i++){if(i==*min_element(gp[i].begin(),gp[i].end()))can1.push_back(i);
 for(int j=0;j<C.size();j++){bool a=true;for(int k=0;k<2*p;k++)a &= make_pair(i,j)<=make_pair(gp[i][k],gp[j][k]);if(a)can.push_back({i,j});}}
 cout<<"D "<<D.size()<<" first "<<first.size()<<" pair "<<can1.size()<<" triples "<<can.size()<<"\n";
 int mx=0,mc=0;for(int ia:first)for(int id=0;id<D.size();id++)for(int ib:can1){
 R A=D[ia],B=C[ib],E=D[id];R del=A*E-conjg(B)*B;if(del==zero)continue;
 // Rank two implies del nonzero. Including indefinite base blocks can only enlarge the search.
 map<R,int> tg,py;for(int i=0;i<D.size();i++)assert(tg.emplace(del*D[i],i).second);for(int i=0;i<C.size();i++)assert(py.emplace(del*C[i],i).second);
 vector<P> pts;for(auto [ix,iy]:can){auto X=C[ix],Y=C[iy];auto U=E*X-B*Y,V=A*Y-conjg(B)*X;auto L=conjg(X)*U+conjg(Y)*V;
 auto i=tg.find(L);if(i!=tg.end())pts.push_back({ix,iy,i->second,U,V});}
 // Every orbit independently translated/oriented. Products transform accordingly; no omitted connections.
 vector<V> edges(pts.size());for(int i=0;i<pts.size();i++)for(int j=0;j<=i;j++){
 auto &x=pts[i], &y=pts[j];R z=conjg(C[x.x])*y.u+conjg(C[x.y])*y.v;
 if(py.count(z)){assert(i!=j);edges[i].push_back(j);edges[j].push_back(i);}}
 mx=max(mx,int(pts.size()));V so;int lmax=0;unsigned long long ct=0;
 function<void(V)> clique=[&](V v){lmax=max(lmax,int(so.size()));if(so.size()==7){ct++;
 if(ct<=500000){cout<<"S "<<ia<<" "<<id<<" "<<ib;for(int i:so){auto &a=pts[i];cout<<" "<<a.x<<" "<<a.y<<" "<<a.d;}cout<<"\n";}
 return;}while(v.size()+so.size()>=7){int i=v.back();v.pop_back();V next;set_intersection(v.begin(),v.end(),edges[i].begin(),edges[i].end(),back_inserter(next));so.push_back(i);clique(next);so.pop_back();}};
 V cand(pts.size());iota(cand.begin(),cand.end(),0);clique(cand);bc++;solc+=ct;mc=max(mc,lmax);
 cout<<"BASE "<<ia<<" "<<id<<" "<<ib<<" profiles "<<pts.size()<<" edges ";int ec=0;for(auto&t:edges)ec+=t.size();cout<<ec/2<<" tuples "<<ct<<"\n";}
 cout<<"TOTAL bases "<<bc<<" profilemax "<<mx<<" six-tuples "<<solc<<" max visited depth "<<mc<<"\n";
}
