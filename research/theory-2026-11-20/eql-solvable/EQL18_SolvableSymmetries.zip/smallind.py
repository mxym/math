"""Independent primitive-character screens for ranks one and two.
Finite-field evaluation, componentwise Gram products, different group normalization.
"""
from itertools import product,combinations
from collections import Counter
import numpy as np,sympy as sp,json
Q=4201 # prime, MW residue class 1 mod 35; for 11/13 use their own primes.
def bank(p):
 q=next(v for v in range(990,5000) if spi(v) and (v-1)%p==0);w=pow(int(sp.primitive_root(q)),(q-1)//p,q)
 c=np.array([[pow(w,(i*j)%p,q) for j in range(p)]for i in range(1,p)])
 E=lambda a:tuple(map(int,(c@np.array(a))%q))
 C={};D={}
 for a in product((-1,1),repeat=p):C.setdefault(E(a),[]).append(a)
 for x in product((-1,1),repeat=p//2):
  a=(5,)+x+x[::-1]
  if sum(a)>0:D[E(a)]=a
 assert len(C)==2**p-1
 def canon(d):
  v=D[d];return v==min(tuple(v[(i*j)%p]for i in range(p)) for j in range(1,p))
 return q,w,C,D,canon
def spi(v):return bool(sp.isprime(v))
def check(p,r):
 q,w,C,D,canon=bank(p);S=np.array(list(C));n=len(C);idx={c:i for i,c in enumerate(C)};gs=[]
 for g in range(p):
  for e in (-1,1):
   f=np.array([e*pow(w,g*j,q)%q for j in range(1,p)]);gs.append([idx[tuple(v)] for v in (S*f)%q])
 gs=np.array(gs).T;c1=[i for i in range(n) if min(gs[i])==i]
 c2=(np.array([(i,j) for i in range(n) for j in range(n) if min(zip(gs[i],gs[j]))==(i,j)]) if r==2 else None)
 P=np.array(list(D));Pmap={tuple(v):i for i,v in enumerate(P)};maxed=0;sol=0;full=0;zero=0;maxpts=0;maxedges=0;bases=0;control=None
 def inverse(a):
  assert all(a);return np.array([pow(int(x),-1,q)for x in a])
 for ia,A in enumerate(P):
  if not canon(tuple(A)):continue
  BB=[None] if r==1 else c1
  for bkey in BB:
   for dkey in (range(len(P)) if r==2 else [None]):
    if r==1:
     X=S[c1,None,:];U=X*inverse(A);h=(X[:,0,::-1]*U[:,0]).sum(axis=0) if False else (X[:,0,::-1]*U[:,0])%q
    else:
     B=S[bkey];F=P[dkey];det=(A*F-B*B[::-1])%q
     if not all(det):continue
     J=np.array([[F,-B],[-B[::-1],A]])*inverse(det)%q;X=S[c2];U=np.einsum('abk,nbk->nak',J,X)%q;h=(X[:,:,::-1]*U).sum(axis=1)%q
    bases+=1;idxs=[i for i,h1 in enumerate(h)if tuple(h1) in Pmap];maxpts=max(maxpts,len(idxs));N=[set() for _ in idxs];cross={}
    for j,v in enumerate(idxs):
     z=(X[idxs[:j+1],:,::-1]*U[v]).sum(axis=1)%q
     for i,z1 in enumerate(z):
      if tuple(z1) in idx:
       if i==j:raise AssertionError('repeated orbit')
       N[i].add(j);N[j].add(i);cross[i,j]=tuple(z1);cross[j,i]=tuple(z1[::-1])
    maxedges=max(maxedges,sum(map(len,N))//2)
    k={5:(6 if r==1 else 9),7:(6 if r==1 else 8),11:5,13:4}[p]
    def visit(T,L):
     nonlocal sol,full,zero,control
     if len(T)==k-r:
      sol+=1
      if p==7 and r==2:
       Z=[[None]*k for _ in range(k)];Z[0][0]=[D[tuple(A)]];Z[1][1]=[D[tuple(F)]];Z[0][1]=C[tuple(B)]
       for i,t in enumerate(T,2):
        v=idxs[t];Z[i][i]=[D[tuple(h[v])]]
        for j in range(2):Z[j][i]=C[tuple(X[v,j])]
        for j,u in enumerate(T[:i-2],2):Z[j][i]=C[cross[u,t]]
       pairs=list(combinations(range(k),2))
       for entries in product(*[Z[i][j] for i,j in pairs]):
        full+=1;A1=sp.diag(*[sum(Z[i][i][0]) for i in range(k)])
        for (i,j),z in zip(pairs,entries):A1[i,j]=A1[j,i]=sum(z)
        if A1.det(method='domain-ge')==0:zero+=1
        if control is None:
         for ix in combinations(range(8),6):
          B1=[]
          for a in ix:
           rr=[]
           for b in ix:
            z=Z[a][a][0] if a==b else entries[pairs.index(tuple(sorted((a,b))))]
            rr.append(list(z) if a<=b else [z[0],*z[:0:-1]])
           B1.append(rr)
          M=sp.Matrix([[B1[a][b][(j-i)%7] for b in range(6) for j in range(7)]for a in range(6)for i in range(7)])
          piv=M.rref()[1]
          if len(piv)==18 and M.extract(piv,piv).is_positive_definite:
           control=B1;break
      return
     while len(T)+len(L)>=k-r:
      u=L.pop();visit(T+[u],L&N[u])
    visit([],set(range(len(idxs))))
 print(p,r,'bases',bases,'maxprofiles',maxpts,'maxedges',maxedges,'orbit tuples',sol,'lifted',full,'det0',zero,flush=True)
 if control:
  with open('positive42.json','w')as f:json.dump(control,f,separators=(',',':'))
if __name__=='__main__':
 for p in (5,7,11,13):check(p,1)
 for p in (5,7):check(p,2)
