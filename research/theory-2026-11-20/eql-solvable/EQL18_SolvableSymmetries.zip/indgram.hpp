// Only a necessary condition is tested: one globally chosen 7-principal minor must vanish.
// Enumerate every sign in an ambiguous entry of that minor. If this test cannot exclude,
// try all 7-principal index choices. Exact mod 101; no positivity assumption.
using Board=std::array<std::array<int,11>,11>;
long long partCalls=0,partPass=0;int iv101[101];std::vector<std::array<int,7>>sets7;
void setup7(){for(int i=1;i<=100;i++)for(int j=1;j<=100;j++)if(i*j%101==1)iv101[i]=j;for(int mask=0;mask<2048;mask++)if(__builtin_popcount(mask)==7){std::array<int,7> u;int k=0;for(int i=0;i<11;i++)if(mask>>i&1)u[k++]=i;sets7.push_back(u);}}
bool singular(int (&A)[7][7],int n=7){int m[7][7];memcpy(m,A,sizeof m);for(int c=0;c<n;c++){int b=c;while(b<n&&m[b][c]%101==0)b++;if(b==n)return true;if(b!=c)for(int j=c;j<n;j++)std::swap(m[c][j],m[b][j]);int v=iv101[(m[c][c]%101+101)%101];for(int i=c+1;i<n;i++)if(m[i][c]){int f=(m[i][c]*v)%101;for(int j=c+1;j<n;j++)m[i][j]=(m[i][j]-f*m[c][j])%101;}}return false;}
bool obstruction(const Board&T,const std::array<int,7>&U){int a[7][7]{},n0=0,ii[21],jj[21];for(int i=0;i<7;i++)for(int j=0;j<=i;j++){int y=T[U[i]][U[j]];if(!y){ii[n0]=i;jj[n0++]=j;}a[i][j]=a[j][i]=y;}
 if(n0>7)return false;
 for(int s=0;s<1<<n0;s++){for(int j=0;j<n0;j++)a[ii[j]][jj[j]]=a[jj[j]][ii[j]]=s>>j&1?5:-5;if(singular(a))return false;}return true;}
bool rejected(const Board&T){partCalls++;
 for(auto&U:sets7)if(obstruction(T,U))return true;
 partPass++;return false;}
