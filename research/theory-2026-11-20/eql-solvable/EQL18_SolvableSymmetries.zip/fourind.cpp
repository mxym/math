#include<bits/stdc++.h>
using namespace std;
#include "indgram.hpp"
using W=array<int,4>;const W O{},ONE{1,1,1,1};constexpr int q=1000000891;
int mod(long long a){a%=q;return a<0?a+q:a;}
int power(int a,int n){int z=1;for(;n;n>>=1,a=mod(1LL*a*a))if(n%2)z=mod(1LL*z*a);return z;}
W operator+(W a,const W&b){for(int i=0;i<4;i++)a[i]=mod(a[i]+b[i]);return a;}
W operator-(W a,const W&b){for(int i=0;i<4;i++)a[i]=mod(a[i]-b[i]);return a;}
W operator*(W a,const W&b){for(int i=0;i<4;i++)a[i]=mod(1LL*a[i]*b[i]);return a;}
W conj(W a){reverse(a.begin(),a.end());return a;}
W recip(W a){for(int&i:a){assert(i);i=power(i,q-2);}return a;}
bool positive(W a){assert(a==conj(a));int tr=mod(a[0]+a[1]),N=mod(1LL*a[0]*a[1]);return tr>0&&tr<q/2&&N>0&&N<q/2;}
using Z=array<int,5>;W ev(const Z&z){static int rt=power(2,(q-1)/5);W w{};for(int j=1;j<=4;j++)for(int i=0;i<5;i++)w[j-1]=mod(w[j-1]+(long long)z[i]*power(rt,i*j));return w;}
int eval1(const Z&z){return accumulate(z.begin(),z.end(),0);}
int main(){setup7();int rt=power(2,(q-1)/5);assert(rt!=1&&power(rt,5)==1);
 vector<Z> ds,rep;vector<W>D,C;set<int>first;map<W,int>id;vector<int>val;
 for(int x:{-1,1})for(int y:{-1,1}){Z a={5,x,y,y,x};if(eval1(a)<5)continue;if(x<=y)first.insert(D.size());D.push_back(ev(a));ds.push_back(a);}
 for(int m=0;m<32;m++){Z a;for(int i=0;i<5;i++)a[i]=m>>i&1?1:-1;W w=ev(a);if(id.contains(w))continue;id[w]=C.size();C.push_back(w);rep.push_back(a);val.push_back(w==O?0:eval1(a));}
 vector<array<int,10>>g(C.size());for(int i=0;i<31;i++)for(int k=0;k<10;k++){Z a;for(int j=0;j<5;j++)a[j]=(k<5?1:-1)*rep[i][(j+k)%5];g[i][k]=id.at(ev(a));}
 vector<int>p1;vector<array<int,2>>p2;vector<array<int,3>>p3;
 for(int i=0;i<31;i++)for(int j=0;j<31;j++)for(int z=0;z<31;z++){array<int,3>u{i,j,z};bool ok=true;for(int k=0;k<10;k++)if(array<int,3>{g[i][k],g[j][k],g[z][k]}<u)ok=false;if(ok){p3.push_back(u);if(z==0){p2.push_back({i,j});if(j==0)p1.push_back(i);}}}
 assert(p1.size()==4&&p2.size()==97&&p3.size()==2980);long long B=0,ptsall=0,tups=0,gnum=0,fail=0;int mx=0;
 for(int ia:first)for(int ib:p1)for(int idd=0;idd<D.size();idd++){
 W A=D[ia],B0=C[ib],E=D[idd];if(!positive(A)||!positive(A*E-conj(B0)*B0))continue;
 for(auto [ix,iy]:p2)for(int ih=0;ih<D.size();ih++){W H[3][3]={{A,B0,C[ix]},{conj(B0),E,C[iy]},{conj(C[ix]),conj(C[iy]),D[ih]}},J[3][3];
 for(int i=0;i<3;i++)for(int j=0;j<3;j++){int r1=(j+1)%3,r2=(j+2)%3,c1=(i+1)%3,c2=(i+2)%3;J[i][j]=H[r1][c1]*H[r2][c2]-H[r1][c2]*H[r2][c1];}
 W det=O;for(int i=0;i<3;i++)det=det+H[0][i]*J[i][0];if(!positive(det))continue;B++;W inv=recip(det);for(auto&r:J)for(W&a:r)a=a*inv;
 struct Pt{array<int,3>x;array<W,3>u;int d;};vector<Pt>pt;map<W,int>lookup;for(int i=0;i<D.size();i++)lookup[D[i]]=i;
 for(auto x:p3){array<W,3>u{};W z{};for(int i=0;i<3;i++){for(int j=0;j<3;j++)u[i]=u[i]+J[i][j]*C[x[j]];z=z+conj(C[x[i]])*u[i];}if(lookup.contains(z))pt.push_back({x,u,lookup.at(z)});}
 int n=pt.size();ptsall+=n;mx=max(mx,n);if(n<8)continue;gnum++;vector<vector<int>>M(n,vector<int>(n,-9));vector<vector<int>>edge(n);for(int i=0;i<n;i++)for(int j=0;j<i;j++){W s{};for(int k=0;k<3;k++)s=s+conj(C[pt[i].x[k]])*pt[j].u[k];auto h=id.find(s);if(h!=id.end()){M[i][j]=M[j][i]=val[h->second];edge[i].push_back(j);edge[j].push_back(i);}}
 // Independent increasing-order neighbor-intersection recursion (no coloring).
 vector<int>basis;function<void(const vector<int>&)> dfs=[&](const vector<int>&v){if(basis.size()==8){tups++;Board T{};T[0][0]=eval1(ds[ia]);T[1][1]=eval1(ds[idd]);T[2][2]=eval1(ds[ih]);T[0][1]=val[ib];T[0][2]=val[ix];T[1][2]=val[iy];
 for(int i=0;i<8;i++){auto&a=pt[basis[i]];T[i+3][i+3]=eval1(ds[a.d]);for(int k=0;k<3;k++)T[k][i+3]=val[a.x[k]];for(int j=0;j<i;j++)T[j+3][i+3]=M[basis[j]][basis[i]];}for(int i=0;i<11;i++)for(int j=0;j<i;j++)T[i][j]=T[j][i];
 if(!rejected(T)){fail++;if(fail<10){cout<<"survived ";for(auto&r:T)for(auto v:r)cout<<v<<" ";cout<<endl;}}return;}
 for(int i=0;i<v.size()&&v.size()-i+basis.size()>=8;i++){int u=v[i];vector<int>r;for(int j=i+1;j<v.size();j++)if(M[u][v[j]]!=-9)r.push_back(v[j]);basis.push_back(u);dfs(r);basis.pop_back();}};
 vector<int>all(n);iota(all.begin(),all.end(),0);dfs(all);
 }cerr<<"ind progress "<<B<<" "<<tups<<" unresolved "<<fail<<endl;}
 cout<<"independent Fourier-modulus "<<q<<" bases "<<B<<" points "<<ptsall<<" max "<<mx<<" graphs "<<gnum<<" octuples "<<tups<<" modular-minor unresolved "<<fail<<endl;}
