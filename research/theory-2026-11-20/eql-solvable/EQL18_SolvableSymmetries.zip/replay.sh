#!/bin/sh
set -eu
export OPENBLAS_NUM_THREADS=1
for p in 5 7 11 13; do python3 cycl.py "$p" >"c$p.replayed"; cmp "c$p.log" "c$p.replayed"; done
for a in rank2 rank2p5 r3lift fourind; do c++ -std=c++20 -O3 "$a.cpp" -o "$a"; done
./rank2 >p7rank2.replayed; cmp p7rank2.replayed p7rank2.log
./rank2p5 >p5rank2.replayed; cmp p5rank2.replayed p5rank2.log
python3 lift7.py >lift7.replayed; cat lift7.replayed
python3 smallind.py >smallind.replayed; cmp smallind.replayed smallind.log
python3 positive.py
./r3lift >p5lift.replayed 2>p5lift-progress.replayed; cmp p5lift.replayed p5lift.log
./fourind >p5ind.replayed 2>p5ind-progress.replayed; cmp p5ind.replayed p5ind.log
python3 - <<'PY'
from sympy import isprime
assert isprime(1000000891) and isprime(101)
PY
tail -1 p5lift.replayed; tail -1 p5ind.replayed
