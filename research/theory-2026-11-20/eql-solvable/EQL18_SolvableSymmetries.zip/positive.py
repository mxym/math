from smallind import bank
import numpy as np,sympy as sp,itertools as I,json
def check(B):
 p=len(B[0][0]);n=len(B);assert all(len(r)==n for r in B)
 G=sp.Matrix([[B[a][b][(j-i)%p] for b in range(n) for j in range(p)] for a in range(n)for i in range(p)])
 assert G==G.T and all(G[i,i]==5 for i in range(G.rows)) and all(abs(G[i,j])==1 for i,j in I.combinations(range(G.rows),2))
 ix=G.rref()[1]
 if len(ix)<=18 and G.extract(ix,ix).is_positive_definite:
  return len(ix)
 return None
def generate():
 p=5;q,w,C,D,can=bank(p);F=np.array([[pow(w,(i*j)%5,q) for j in range(5)]for i in range(1,5)])
 d=[];c=[]
 for mask in range(4):
  a=[1 if mask>>i&1 else -1 for i in range(2)];d.append([5]+a+a[::-1])
 for m in range(31):c.append([1 if m>>i&1 else -1 for i in range(5)])
 E=lambda a:tuple(np.array(a)@F.T%q)
 for line in open('p5rank3.log'):
  if not line.startswith('S '):continue
  ia,id,ib,ix,iy,ie,*ds=map(int,line.split()[1:]);inds=ds[3::4]
  if min(sum(d[i]) for i in (ia,id,ie,*inds))<5:continue
  M=np.array([[E(d[ia]),E(c[ib]),E(c[ix])],[E(c[ib])[::-1],E(d[id]),E(c[iy])],[E(c[ix])[::-1],E(c[iy])[::-1],E(d[ie])]]);J=np.array([np.array(sp.Matrix(M[:,:,k]).inv_mod(q)).astype(int) for k in range(4)]).transpose(1,2,0)
  A=[[None]*11 for _ in range(11)]
  for i in range(3):
   for j in range(i,3):A[i][j]=([d[(ia,id,ie)[i]]] if i==j else C[tuple(M[i,j])])
  V=[]
  for i in range(8):
   x=[np.array(E(c[t]))for t in ds[4*i:4*i+3]];v=np.array(x);V.append(v);u=(J*v[None,:,:]).sum(axis=1)%q
   for j in range(3):A[j][i+3]=C[tuple(v[j])]
   for j in range(i):A[j+3][i+3]=C[tuple((V[j][:,::-1]*u).sum(axis=0)%q)]
   A[i+3][i+3]=[d[inds[i]]]
  for idx in I.combinations(range(11),6):
   pairs=list(I.combinations(range(6),2))
   for v in I.product(*[A[idx[i]][idx[j]] for i,j in pairs]):
    B=[[[] for _ in idx]for _ in idx]
    for i,a in enumerate(idx):B[i][i]=list(A[a][a][0])
    for (i,j),z in zip(pairs,v):B[i][j]=list(z);B[j][i]=[z[0],*z[:0:-1]]
    # Essential inexpensive prefilter: rank six at the trivial character is needed
    # for a rank-18 six-orbit control. The candidate's primitive rank is at most three.
    T=np.array([[sum(z) for z in row] for row in B],dtype=int)
    if sp.Matrix(T).det(method='domain-ge')<=0:continue
    r=check(B)
    if r==18:
     print('Positive rank',r);json.dump(B,open('positive30.json','w'),separators=(',',':'));return
if __name__=='__main__':
 import sys
 if len(sys.argv)>1:generate()
 for fn in ('positive30.json','positive42.json'):
  b=json.load(open(fn));r=check(b);assert r==18;print('Exact Gram control:',len(b)*len(b[0][0]),'lines, rank 18, automorphism order',len(b[0][0]))
