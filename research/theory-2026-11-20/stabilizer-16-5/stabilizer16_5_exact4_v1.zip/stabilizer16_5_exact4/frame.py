from itertools import combinations
from collections import Counter
from fractions import Fraction as F
from math import factorial
def rank(T):
 b={}
 for v in T:
  while v:
   j=v.bit_length()-1
   if j not in b:b[j]=v;break
   v^=b[j]
 return len(b)
def frame_counts(d=7,stop=13):
 base=[0]+[1<<j for j in range(d)];available=[i for i in range(1<<d)if i.bit_count()>=4];C=Counter()
 def walk(S,V):
  C[len(S)]+=1
  if len(S)==stop:return
  for i,x in enumerate(V):
   bad={x^a^b for a,b in combinations(S,2)}
   walk(S+[x],[v for v in V[i+1:]if v not in bad])
 walk(base,available);return C
