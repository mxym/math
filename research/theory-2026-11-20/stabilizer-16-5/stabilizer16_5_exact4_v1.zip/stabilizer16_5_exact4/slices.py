from pathlib import Path
from itertools import combinations
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import os,subprocess
assert __debug__
D=1024
A=[tuple(map(int,l.split()))for l in Path('d10.txt').read_text().splitlines()]
def canon(B):return min(tuple(sorted(y^x for y in B))for x in B)
def fourier(S):
 a=[0]*D
 for x in S:a[x]=1
 for i in range(10):
  h=1<<i
  for t in range(0,D,2*h):
   for j in range(t,t+h):a[j],a[j+h]=a[j]+a[j+h],a[j]-a[j+h]
 return a
def run(row):
 i,A=row;m=len(A);n=48-m;K=m-n;s=' '.join(map(str,A))
 get=lambda cmd:subprocess.check_output(cmd,input=s,text=True).splitlines()
 q1=get(['./high1',str(n),str(D),'1',str(K)]);C={canon(list(map(int,l.split())))for l in q1[:-1]};assert int(q1[-1])==n*len(C)
 q2=get(['./high2',str(n)]);assert q2[-1].startswith('hit 0 nodes ')
 U={canon(list(map(int,l.split())))for l in q2[:-1]};a=fourier(A)
 U={B for B in U if all(abs(x)+abs(y)<=K for x,y in zip(a[1:],fourier(B)[1:]))};assert U==C
 mx=0
 for B in C:
  S=A+tuple(1024+x for x in B);assert len(set(S))==48 and len({x^y for x,y in combinations(S,2)})==1128
  tr=Counter(x^y^z for x,y,z in combinations(S,3));mx=max(mx,max(tr.values()))
 return i,len(C),mx
with ThreadPoolExecutor(max_workers=int(os.environ.get('JOBS','2')))as pool:r=list(pool.map(run,enumerate(A)))
ans=[t for t in r if t[1]];assert ans==[(198,62,11),(199,124,11)],ans
print('PASS: 208 high-slice sources, 186 realizations up to opposite-layer translation, maximum triple multiplicity 11; two complete searches agree.')
