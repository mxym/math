from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import factorial
from collections import Counter
import subprocess,os,sys,time,re,hashlib,csv
from functools import lru_cache
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from frame import frame_counts,rank
if not __debug__:raise RuntimeError('the replay requires Python assertions')
os.chdir(Path(__file__).resolve().parent)
def count(A,b,d,sidon=True,mx=None):
 exe='./localcount' if d<=9 else './finalcount'
 return int(subprocess.check_output([exe,str(b),str(1<<d),str(int(sidon))]+([]if mx is None else [str(mx)]),input=' '.join(map(str,A)),text=True))
def moments(d,n):
 Q=1<<d;l=n%2;z2=Q*n-n*n;z4=Q*(3*n*n-2*n)-n**4
 return next(k for k in range((n+1)//2,n+1)if z4-(l+(2*k-n)**2)*z2+l*(2*k-n)**2*(Q-1)<=0)
def cfs(S,d):
 a=[0]*(1<<d)
 for x in S:a[x]=1
 for j in range(d):
  h=1<<j
  for q in range(0,len(a),2*h):
   for k in range(q,q+h):a[k],a[k+h]=a[k]+a[k+h],a[k]-a[k+h]
 return a
def read(d):
 f=Path('d%d.txt'%d).read_text();q=[tuple(map(int,l.split()))for l in f.splitlines()]
 for A in q:
  assert all(0<=x<1<<d for x in A) and len(A)==len(set(A)) and rank([x+(1<<d)for x in A])==d+1
  assert len({x^y for x,y in combinations(A,2)})==len(A)*(len(A)-1)//2
 g=list(map(int,subprocess.check_output(['./group',str(d)],input=f,text=True).split()))
 assert len(g)==len(q)
 return list(zip(q,g))
data={d:[tuple(map(int,l.split()))for l in Path('d%d.txt'%d).read_text().splitlines()]for d in (7,8,9,10)}
for d,hist in {7:{10:2,11:1,12:1},8:{14:5,15:5,16:3,17:1,18:1},9:{20:1681,21:738,22:127,23:8,24:1},10:{32:200,33:7,34:1}}.items():
 assert Counter(map(len,data[d]))==hist
jobs=int(os.environ.get('JOBS','2'));assert jobs>=1
mode=sys.argv[1]if len(sys.argv)>1 else 'all'
assert mode in ('all','classification','endpoint','endpoint1','endpoint2')
do_class=mode in ('all','classification')
caps={d:read(d)for d in (7,8,9,10)}if do_class else {}
if do_class:
 assert frame_counts(6,10)[10]==0 # a non-spanning 10-set cannot be Sidon in 5D: C(10,2)>31.
 cc=frame_counts()
 assert cc[13]==0
 for n in [10,11,12]:
  mass=sum(F(factorial(8)*sum(rank([v+128 for v in z])==8 for z in combinations(s,8)),g)for s,g in caps[7]if len(s)==n)
  assert mass==cc[n]
 print('normalized frame counts verified:',dict(sorted(cc.items())),flush=True)
def stage(d,n,pool,maximal=False):
 lo=moments(d,n);target=Counter();actual=Counter()
 for S,g in caps[d]:
  if len(S)!=n:continue
  w=cfs(S,d)[1:];largest=(n+max(map(abs,w)))//2
  for v in w:
   for m in [(n+v)//2,(n-v)//2]:
    if m>=lo and (not maximal or m==largest):actual[m]+=F(1,g)
 V=[(A,g) for A,g in caps[d-1]if len(A)>=lo]
 def calc(row):
  A,g=row;b=n-len(A);mx=len(A)-b if maximal else None
  if maximal and max(map(abs,cfs(A,d-1)[1:]))+b%2>mx:return len(A),F()
  return len(A),F(count(A,b,d-1,mx=mx),g*b)
 for a,x in pool.map(calc,V):target[a]+=x
 assert all(target[k]==actual[k] for k in set(target)|set(actual)),(d,n,actual,target)
 print('dimension',d,'size',n,'floor',lo,'mass',[(k,str(target[k])) for k in sorted(target)],flush=True)
if do_class:
 with ThreadPoolExecutor(max_workers=jobs)as pool:
  for d,ns in [(8,range(14,20)),(9,range(20,26)),(10,range(32,36))]:
   for n in ns:stage(d,n,pool,maximal=(d,n)==(10,32))
 print('PASS classification',flush=True)
