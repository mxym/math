#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 verify.py
python3 lower.py
CXX=${CXX:-c++}
CFLAGS=${CFLAGS:--O3 -march=native}
for s in group high2;do "$CXX" $CFLAGS -std=c++17 "$s.cpp" -o "$s";done
"$CXX" $CFLAGS -std=c++17 -DWIDTH=6 count.cpp -o localcount
"$CXX" $CFLAGS -std=c++17 -DWIDTH=9 count.cpp -o finalcount
"$CXX" $CFLAGS -std=c++17 -DWIDTH=9 high1.cpp -o high1
if [ "${1:-all}" != endpoint ];then python3 -u classify.py classification;fi
python3 -u slices.py
