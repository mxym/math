"""Exact Gaussian-integer replay for exterior-shuffle normalizations and pair CAR."""
from collections import defaultdict
from itertools import combinations
from math import comb
from random import Random
from fractions import Fraction as Q
rng=Random(621678)
z=(0,0)
def plus(a,b): return (a[0]+b[0],a[1]+b[1])
def times(a,b):return(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def star(a):return(a[0],-a[1])
def scale(c,a):return(c*a[0],c*a[1])
def sq(a):return a[0]**2+a[1]**2
def norm(v):return sum(map(sq,v.values()))
def require(b):
 if not b:raise ArithmeticError("exact identity failed")
def sg(I,J):return (-1)**sum(i>j for i in I for j in J)
def wedge(u,v):
 h=defaultdict(lambda:z)
 for I,a in u.items():
  for J,b in v.items():
   if set(I)&set(J):continue
   key=tuple(sorted(I+J));h[key]=plus(h[key],scale(sg(I,J),times(a,b)))
 return h
def adj(f,u):
 h=defaultdict(lambda:z)
 for I,a in f.items():
  for K,b in u.items():
   if not set(I)<=set(K):continue
   J=tuple(i for i in K if i not in I)
   h[J]=plus(h[J],scale(sg(I,J),times(star(a),b)))
 return h
def gram(v,k):
 C=defaultdict(dict)
 for K,a in v.items():
  for I in combinations(K,k):
   J=tuple(i for i in K if i not in I)
   C[J][I]=scale(sg(I,J),a)
 G=defaultdict(lambda:z)
 for col in C.values():
  for I,a in col.items():
   for J,b in col.items(): G[I,J]=plus(G[I,J],times(a,star(b)))
 return G
def inner(u,v):
 a=z
 for I,b in u.items():a=plus(a,times(star(b),v.get(I,z)))
 return a
def random_form(d,k):
 C=list(combinations(range(d),k))
 return {I:(rng.randrange(-3,4),rng.randrange(-3,4)) for I in rng.sample(C,min(13,len(C)))}
n=0
for d in range(8,16):
 for i in range(7):
  u=random_form(d,4);v=random_form(d,4) if i%2 else u
  val=sum((-1)**k*inner(gram(u,k),gram(v,k))[0] for k in range(5))
  require(val==norm(wedge(u,v)));n+=1
 f={(2*i,2*i+1):(i+1,0) for i in range(d//2)}
 h=random_form(d,4);AL=adj(f,wedge(f,h));LA=wedge(f,adj(f,h))
 for I in set(AL)|set(LA)|set(h):
  weight=sum((i//2+1)**2 for i in I if i<2*(d//2))
  require(plus(AL[I],scale(-1,LA[I]))==scale(norm(f)-weight,h.get(I,z)))
for m in range(4,14):
 u={tuple(j for i in s for j in (2*i,2*i+1)):(1,0) for s in combinations(range(m),2)}
 val=Q(norm(wedge(u,u)),norm(u)**2); target=Q(6*(m-2)*(m-3),m*(m-1))
 require(val==target)
# Exact coarsened constants in the transverse strict comparison.
delta=Q(1,10000);g=Q(1,100);D=3000000
req=Q(106,100);cross=Q(34,100)
require(2/(2-delta)<Q(1001,1000)**2 and Q(1001,1000)+2*Q(245,100)*g<req)
require(24*g+24*Q(71,10000)/(2-delta)<cross and Q(71,10000)**2>delta/2)
require(6-Q(60,D)-48*g>Q(11,2))
require(-(2-g*g)*Q(11,2)+4*req**2+2*cross+4*g*req*Q(245,100)+6*g*g<-5)
print(f"Passed {n} exact degree-(4,4) complex shuffle identities (including mixed arguments).")
print("Pair creation/annihilation commutator: 8 exact complex four-forms; 10 exact condensate ratios.")
print("Rational enclosures confirm the uniform transverse strict margin (>5).")
