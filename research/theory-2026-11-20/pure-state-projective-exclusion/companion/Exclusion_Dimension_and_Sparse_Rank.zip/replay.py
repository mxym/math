#!/usr/bin/env python3
"""Exact finite examples and incidence ranks; neither replaces analytic bounds."""
from itertools import combinations
import sympy as s
for n in range(4,11):
 for k in range(2,n-1):
  pairs=list(combinations(range(n),2));sets=list(combinations(range(n),k));m=len(pairs)
  A=s.Matrix([[int(i in S and j in S) for S in sets] for i,j in pairs])
  # exact row rank via the m x m integral symmetric Gram
  assert (A*A.T).det(method='domain-ge')!=0
  # every edge matrix diagonal follows from incidence edge coordinates
  for S in sets:
   assert all(sum((i in S and j in S) for j in range(n) if j!=i)==(k-1)*(i in S) for i in range(n))
 print("n =",n,": full integral incidence rank and diagonal recovery for all intermediate k.")
# Build r^2-1 independent null projectors for sample intrinsic ranks via
# orthogonal spatial vectors and pair superpositions with Gaussian rational data.
for r in range(3,8):
 p=r-1;std=[s.eye(p).col(j) for j in range(p)]
 aa=[phase*a for a in std for phase in [1,-1,s.I,-s.I]]
 for i,j in combinations(range(p),2):
  aa.extend([(3*std[i]+4*z*std[j])/5 for z in [1,s.I]])
 def vecH(M):return [M[i,i] for i in range(r)]+[f(M[i,j]) for i,j in combinations(range(r),2) for f in [s.re,s.im]]
 V=[a.col_join(s.ones(1,1)) for a in aa]
 Y=s.diag(*([1]*p+[-1]))
 assert all((v.H*Y*v)[0]==0 for v in V)
 rays=s.Matrix([vecH(v*v.H) for v in V]).T
 _,piv=rays.rref()
 assert len(piv)==r*r-1
 K=sum([V[j]*V[j].H for j in piv],s.zeros(r))
 assert K.det()!=0 and s.trace(Y*K)==0
 print("r =",r,": exact",len(piv),"independent null projectors, spanning covariance and zero dual trace.")
