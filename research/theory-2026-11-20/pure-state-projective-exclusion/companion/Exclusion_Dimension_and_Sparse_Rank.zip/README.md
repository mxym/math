# Sharp bounds on the dimension of projective dilations

Read **classification.pdf** (4 pages); the complete proof of the prior lemma it uses is included as basis_theorem/exclusion.pdf. Both corresponding TeX files are included. The original basis-theorem packet is unchanged.

* For a particular excludable n-state list of intrinsic span dimension r, its least total projective dilation dimension is max(r,s), with s the smallest size of an excludable subset. Equivalently this exactly computes the factor-width-(n−1) rank, even for singular inputs. A finite algorithm checks subset PSD feasibility; polynomial time is **not** claimed.
* Among all such lists with given n and r≥3 over C, the worst least dilation dimension is min(n,r²−1); for qubits it is min(n,4). Both the upper bound and the matching examples are mathematical, not numerical. Duplicate preparations are allowed, as for an indexed list.
* In square dimension the only universally projective list-size objectives are k=1 (identify), k=n−1 (exclude one), and k=n (do nothing). For each intermediate k we give a full-rank real Gram with precisely n(n−1)/2 outcomes and total projective dilation dimensions necessary and sufficient. The example uses integer entries before diagonal normalization. No general upper bound n(n−1)/2 for intermediate k is claimed.

* For all n≤d and any given POVM, one deterministic PVM simultaneously weakly improves every state’s conditional exclusion error. No random mixture of PVMs is necessary. With prior-weighted Gram G the Bayesian optimum is also the squared Bures–Wasserstein distance from G to the unnormalized factor-width-(n−1) cone.

These statements concern unassisted perfect one-copy tasks with arbitrary joint measurements. A dilation dimension is a total Hilbert dimension including the signal, not a number of ancilla qubits or multiplicative tensor-ancilla dimension.

## Source comparison, 20 Nov 2026

[Johnston, Moein & Plosker, §5.2](https://arxiv.org/abs/2405.11556) list unresolved dense 4×4 width-three cases. Their dense width-two n-choose-2 result is prior. Their general graph-covering lower bound does not give the n-choose-2 lower bound on our pencils of every intermediate width. The general real/complex ranks need not coincide; [Shitov, Thm. 7](https://doi.org/10.13140/RG.2.2.24873.15204) gives an order-20, width-15 example. Our equality is only for width n−1. No new claim about Hadamard powers is made.

[Johnston–Russo–Sikora](https://arxiv.org/abs/2311.17047) established the ordinary Gram feasibility criterion for POVMs; [The complexity of perfect quantum state classification](https://arxiv.org/abs/2510.20789) and [Johnston et al., Sept 2026](https://arxiv.org/abs/2609.17411) give k-learnability characterizations, bounds and applications. Our statements are about minimal projective implementation dimension / number of outcomes. [Molina](https://doi.org/10.22331/q-2019-01-25-117) studied the pure-exclusion projectivity question. Caves–Fuchs–Schack's qubit POVM criterion and trine separation already cover the elementary low-dimensional ingredients. The matrix inclusion rank, connected-set Carathéodory theorem and exposed-cone method are not claimed as new tools.

Targeted primary-literature and repository searches did not surface the exact all-rank threshold or intermediate-k outcome family before these proofs. [mxym/math](https://github.com/mxym/math)'s overlap cutoff and entanglement-assisted measurement exclusion are separate, as are [OpenAI's release papers](https://github.com/openai/math). Internal audit is not an external peer review or priority guarantee.

Optional replay: python3 replay.py (SymPy); expected stdout in replay.txt. It checks pair-incidence ranks in dimensions 4 through 10 and constructs exact bases of the Hermitian null-projector hyperplanes for r=3 through 7.
