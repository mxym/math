#!/usr/bin/env python3
"""Exact illustrative checks in the real and complex cases, using SymPy."""
from itertools import product
from sympy import Matrix,eye,zeros,I,Rational as R,simplify
def norm2(x):return (x.H*x)[0,0]
def basischeck(V,states):
 assert (V.H*V-eye(V.cols)).applyfunc(simplify)==zeros(V.cols)
 assert all(simplify((V.col(j).H*states.col(j))[0])==0 for j in range(V.cols))
for s in [1,-1,I,-I,(3+4*I)/5]:
 # L=span(e1,e2), zeta=e3. An exact fractional last effect.
 e1,e2,eta=[eye(3).col(j) for j in range(3)]
 q=R(7,25)*e1+s*R(24,25)*eta
 w=-R(3,5)*e1+s*R(7,40)*eta
 assert simplify(norm2(w)-R(25,64))==0 and (w.H*q).applyfunc(simplify)==zeros(1)
 En=w*w.H;E1=e2*e2.H;E2=eye(3)-En-E1
 assert E1*e1==zeros(3,1) and E2*e2==zeros(3,1)
 assert all(t>=0 for t in E2.eigenvals())
 # Lift from the residual Gram factor and compare the two endpoint signs.
 u=-R(3,5)*e1+s*R(4,5)*eta
 D=Matrix([[0,1],[R(4,5),0]])
 C=D.col_join(Matrix([[-R(3,5),0]]))
 assert C.H*C==eye(2) and D.H*D==eye(2)-C.row(2).H*C.row(2)
 def g(v):return simplify(abs((v.H*e1)[0])*R(7,25)-abs((v.H*eta)[0])*R(24,25))
 assert g(u)<0 and g(e1)>0
 # Connected interpolation has an explicit zero for this example.
 u2=-R(24,25)*e1+s*R(7,25)*eta
 v2=R(7,25)*e1+s*R(24,25)*eta
 assert g(u2)==0
 basischeck(Matrix.hstack(e2,v2,u2).applyfunc(simplify),Matrix.hstack(e1,e2,q))
print("5 phases, including non-real phases: fractional effect, Gram lift, both signs, exact orthonormal exclusion.")
# Test block positivity on the permitted faces after I-regularization.
for n in range(2,9):
 B=Matrix(n,n,lambda i,j:0 if i==j else (i+j*j+1)%5-2)
 G=B.H*B
 blocks=[]
 for j in range(n):
  v=B.row(j); ej=eye(n).col(j)
  X=v.H*v+(eye(n)-ej*ej.H)/(n-1)
  assert X*ej==zeros(n,1) and X.rank()==n-1
  blocks.append(X)
 assert sum(blocks,zeros(n))==G+eye(n)
print("7 dimensions: Gram regularization has the required sum and exactly one-dimensional block kernels.")
