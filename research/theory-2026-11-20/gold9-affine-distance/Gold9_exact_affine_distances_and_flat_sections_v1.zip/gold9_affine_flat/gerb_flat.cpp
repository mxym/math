// All nine-flats (not only maps) through affine triple-centers in Gold graphs of dimension nine.
#ifdef NDEBUG
#error keep assertion
#endif
#include<bits/stdc++.h>
using namespace std;using T=array<int,3>;constexpr int MOD=0x211;int F[512],d,goal;vector<T>ls;int permu[90];uint64_t raw,iso,hits;map<tuple<int,int,int>,uint64_t> dist;
int mul(int a,int b){int z=0;for(;b;b>>=1){if(b&1)z^=a;a*=2;if(a&512)a^=MOD;}return z;}
int pw(int a,int n){int r=1;for(;n;n>>=1){if(n&1)r=mul(a,r);a=mul(a,a);}return r;}
int dim(vector<int>vs){int b[18]={},r=0;for(int x:vs)for(int j=17;j>=0;j--)if(x>>j&1){if(!b[j]){r++;b[j]=x;break;}x^=b[j];}return r;}
void process(int a,int b,int c){
 T orig={a,b,c},y=orig;for(int k=0;k<9;k++){for(auto &x:y)x=permu[x];sort(y.begin(),y.end());if(y<orig)return;}iso++;
 int piv[18]={},bits[18]={};vector<int>basis;for(int z:orig)for(int t:{ls[z][0],ls[z][1]}){int v=t^((F[t]^1)<<9);basis.push_back(v);for(int j=17;j>=0;j--)if(v>>j&1){if(piv[j])v^=piv[j];else{piv[j]=v;break;}}}
 int freeCt=0;for(int j=0;j<18;j++)if(!piv[j])bits[j]=1<<freeCt++;assert(freeCt==12);
 int h[4096]={},lift[4096]={};vector<int>atleast[10];
 for(int x=0;x<512;x++){int z=x^((F[x]^1)<<9),u=z,mask=0;for(int j=17;j>=0;j--)if(u>>j&1){if(piv[j])u^=piv[j];else{u^=1<<j;mask^=bits[j];}}if(mask){lift[mask]=z;h[mask]++;assert(h[mask]<=3);atleast[h[mask]].push_back(mask);}else h[0]++;}
 assert(h[0]==9);int want=goal-h[0];
 for(int i:atleast[(want+6)/7]){int u=h[i];
  int minj=max(1,(want-u+5)/6);for(int j:atleast[minj]){
   int v=h[j];if(i==j||u<v||(u==v&&i>j))continue;int t=i^j,w=h[t];if(w>v||(w==v&&t<j))continue;
   int s=u+v+w, mink=max(1,(want-s+3)/4);if(mink>v)continue;for(int k:atleast[mink]){int p=h[k];if(k==i||k==j||k==t||p>v||(p==v&&k<j))continue;
   int l=i^k,m=j^k,n=t^k;int q=h[l],r=h[m],f=h[n];
   if(q>p||r>p||f>p||(q==p&&l<k)||(r==p&&m<k)||(f==p&&n<k))continue;
   int count=s+p+q+r+f;if(count<want)continue;
   vector<int>B=basis;for(int v:{i,j,k})B.push_back(lift[v]);vector<int>X,Y;for(int p:B){X.push_back(p&511);Y.push_back(p>>9);}int rx=dim(X),ry=dim(Y);
   if(dist[{count+9,rx,ry}]++==0){cout<<"exp "<<d<<" size "<<count+9<<" rx "<<rx<<" ry "<<ry<<" centered full-basis";for(int v:B)cout<<" "<<v;cout<<endl;}hits++;
 }}}
}
int main(int ac,char**av){assert(ac==3);d=atoi(av[1]);goal=atoi(av[2]);assert(goal>=19&&goal<=23);for(int i=0;i<512;i++)F[i]=pw(i,d);for(int a=1;a<512;a++)for(int b=a+1;b<512;b++)if((a^b)>b&&(F[a]^F[b]^F[a^b])==1)ls.push_back({a,b,a^b});assert(ls.size()==85);
 for(int i=0;i<85;i++){T b=ls[i];for(int &x:b)x=mul(x,x);sort(b.begin(),b.end());auto it=find(ls.begin(),ls.end(),b);assert(it!=ls.end());permu[i]=it-ls.begin();}
 for(int i=0;i<85;i++)for(int j=i+1;j<85;j++)for(int k=j+1;k<85;k++){raw++;process(i,j,k);}
 cerr<<"exp "<<d<<" goal "<<goal<<" raw "<<raw<<" iso "<<iso<<" hits "<<hits<<" table";for(auto [t,n]:dist){auto [s,a,b]=t;cerr<<" ("<<s<<","<<a<<","<<b<<"):"<<n;}cerr<<endl;}
