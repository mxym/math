// Independent exhaust: a quotient plane of Fano weight >=ceil(3s/7).
#ifdef NDEBUG
#error assertions integral to replay
#endif
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std; using T=array<int,3>;
int lg[512],ex[1022],f[512],degree,threshold;
uint64_t ranks,frames,good,has;
bool firstOnly;
struct Tab{int n[512]={},v[64]={},num=0;void take(int x){if(!n[x])v[num++]=x;n[x]++;}};
bool heavy(const array<Tab,8>& h,int s){
 int plane=(3*s+6)/7;
 for(int i=1;i<=7;i++)for(int j=1;j<=7;j++)if(j!=i){int l=i^j,k=1;while(k==i||k==j||k==l)k++;
  for(int aidx=0;aidx<h[i].num;aidx++){
   int a=h[i].v[aidx],u=h[i].n[a];if(3*u<plane)continue;
   auto check=[&](int b){int v=h[j].n[b],w=h[l].n[a^b];if(v>u||w>v)return false;int lhs=u+v+w;if(lhs<plane)return false;
     for(int c=0;c<512;c++)if(lhs+h[k].n[c]+h[i^k].n[a^c]+h[j^k].n[b^c]+h[l^k].n[a^b^c]>=s)return true;
     return false;
   };
   for(int bidx=0;bidx<h[j].num;bidx++)if(check(h[j].v[bidx]))return true;
   if(u>=plane)for(int b=0;b<512;b++)if(h[j].n[b]==0&&check(b))return true;
  }
 }return false;
}
void process(const T&a,const T&b,const T&c){
 array<int,9>p{},v{};int rank=0;
 auto insert=[&](int x,int y){for(int j=8;j>=0;j--)if(x>>j&1){if(p[j]){x^=p[j];y^=v[j];}else{p[j]=x;v[j]=y;rank++;return;}}};
 for(T t:{a,b,c})for(int j:{0,1})insert(t[j],f[t[j]]^1);
 if(rank!=6)return;ranks++;array<Tab,8>h;
 int freebits[9]={},q=0;for(int j=0;j<9;j++)if(!p[j])freebits[j]=1<<q++;assert(q==3);
 for(int x=0;x<512;x++){int t=x,w=f[x]^1,cos=0;for(int j=8;j>=0;j--)if(t>>j&1){if(p[j]){t^=p[j];w^=v[j];}else{cos^=freebits[j];t^=1<<j;}}assert(!t);h[cos].take(w);}
 frames++;int base=h[0].n[0];assert(base==9);
 if(heavy(h,threshold-base)){has++;if(firstOnly){cout<<"lower-control hit at frame "<<frames<<endl;exit(0);}}
}
int main(int ac,char**av){assert(ac>=3);degree=atoi(av[1]);threshold=atoi(av[2]);firstOnly=ac>3;
 vector<int> seen(512);int x=1;for(int i=0;i<511;i++){assert(!seen[x]++);lg[x]=i;ex[i]=ex[511+i]=x;x<<=1;if(x&512)x^=0x21b;}assert(x==1);
 for(int i=1;i<512;i++)f[i]=ex[(degree*lg[i])%511];
 vector<T>all;for(int i=1;i<512;i++)for(int j=i+1;j<512;j++)if(j<(i^j)&&(f[i]^f[j]^f[i^j])==1)all.push_back({i,j,i^j});assert(all.size()==85);
 for(int i=0;i<(int)all.size();i++)for(int j=0;j<i;j++)for(int k=0;k<j;k++)process(all[i],all[j],all[k]);
 cout<<"exponent "<<degree<<" threshold "<<threshold<<" all rank-six triples "<<ranks<<" frames "<<frames<<" hits "<<has<<endl;assert(ranks==93436&&frames==ranks&&!has&&!firstOnly);
}
