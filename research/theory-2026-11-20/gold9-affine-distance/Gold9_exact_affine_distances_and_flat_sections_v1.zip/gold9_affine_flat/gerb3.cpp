#ifdef NDEBUG
#error full checks required
#endif
#include<bits/stdc++.h>
using namespace std;
constexpr int Q=512,P=0x211;
using L=array<int,3>;
int d,target,F[512],xs[512],ys[512],where[512],sels[3],permute[120],rep[8],freq[8][512],mx[8],nvals[8],vals[8][512],qc[512];
uint64_t raw,canon,goodLeaf,tests,found,h0[30];
map<int,uint64_t> hbase; vector<L>leaves;
int mult(int a,int b){int r=0;for(;b;b>>=1){if(b&1)r^=a;a<<=1;if(a&Q)a^=P;}return r;}
int power(int a,int x){int r=1;for(;x;x>>=1){if(x&1)r=mult(a,r);a=mult(a,a);}return r;}
bool add(int x,int y,int n){if(where[x]>=0)return false;for(int i=0;i<n;i++){xs[n+i]=x^xs[i];ys[n+i]=y^ys[i];where[xs[n+i]]=n+i;}return true;}
void del(int n,int m){for(int i=n;i<m;i++)where[xs[i]]=-1;}
bool iscanon(){L p={sels[0],sels[1],sels[2]},q=p;for(int j=0;j<9;j++){for(auto &v:q)v=permute[v];sort(q.begin(),q.end());if(q<p)return false;}assert(q==p);return true;}
void witness(int i,int j,int k,int u,int v,int w){int t[8]={};t[i]=u;t[j]=v;t[k]=w;t[i^j]=u^v;t[j^k]=v^w;t[i^k]=u^w;t[i^j^k]=u^v^w;
 int count=0;array<int,9> cols;for(int b=0;b<9;b++){int x=1<<b,c=qc[x];cols[b]=ys[where[x^rep[c]]]^t[c];}vector<int>s;
 for(int x=0;x<512;x++){int a=1;for(int b=0;b<9;b++)if(x>>b&1)a^=cols[b];if(a==F[x])s.push_back(x);}assert((int)s.size()>=target);for(int c=0;c<8;c++)count+=freq[c][t[c]];assert(count==(int)s.size());
 if(!found++) {cout<<"WITNESS exp "<<d<<" target "<<target<<" size "<<s.size()<<" cols";for(auto v:cols)cout<<" "<<v;cout<<" roots";for(int v:s)cout<<" "<<v;cout<<endl;}
}
void finish(){
 int ext[3],h=0;for(int b=0;b<9;b++){int x=1<<b;if(where[x]>=0)continue;bool covered=false;for(int c=0;c<(1<<h);c++){int a=x;for(int j=0;j<h;j++)if(c>>j&1)a^=ext[j];if(where[a]>=0)covered=true;}if(!covered){assert(h<3);ext[h++]=x;}}assert(h==3);
 for(int c=0;c<8;c++){rep[c]=0;for(int j=0;j<3;j++)if(c>>j&1)rep[c]^=ext[j];memset(freq[c],0,sizeof(freq[c]));nvals[c]=0;mx[c]=0;for(int a=0;a<64;a++){int x=xs[a]^rep[c];qc[x]=c;int v=F[x]^ys[a]^1;if(!freq[c][v])vals[c][nvals[c]++]=v;mx[c]=max(mx[c],++freq[c][v]);}}
 int base=freq[0][0];hbase[base]++;assert(base==9);int need=target-base;
 for(int i=1;i<8;i++)for(int ii=0;ii<nvals[i];ii++){
   int u=vals[i][ii],a=freq[i][u]; if(7*a<need)continue;
   for(int j=1;j<8;j++)if(j!=i)for(int jj=0;jj<nvals[j];jj++){
     int v=vals[j][jj],b=freq[j][v],ij=i^j;
     if(b>a||a+6*b<need)continue;
     int g=freq[ij][u^v];if(g>b)continue;
     int sub=a+b+g;if(sub+4*b<need)continue;
     for(int k=1;k<8;k++)if(k!=i&&k!=j&&k!=ij){
       int lo=max(0,(need-sub+3)/4);if(lo>mx[k])continue;
       for(int kk=0;kk<(lo?nvals[k]:512);kk++){
        int w=lo?vals[k][kk]:kk,c=freq[k][w];if(c<lo||c>b)continue;
        int e=freq[k^i][u^w];if(e>c||sub+c+e+2*c<need)continue;
        int f=freq[k^j][v^w];if(f>c||sub+c+e+f+c<need)continue;
        int z=freq[k^ij][w^u^v];if(z>c)continue;
        if(sub+c+e+f+z>=need)witness(i,j,k,u,v,w);
       }
     }
   }
 }
}
void dfs(int n,int f,int sz){if(n==3){raw++;if(iscanon()){canon++;finish();}return;}for(int i=f;i+3-n<=(int)leaves.size();i++){auto[a,b,c]=leaves[i];sels[n]=i;if(!add(a,F[a]^1,sz))continue;if(add(b,F[b]^1,2*sz)){dfs(n+1,i+1,4*sz);del(2*sz,4*sz);}del(sz,sz*2);}}
int main(int ac,char**av){assert(ac>=3);d=atoi(av[1]);target=atoi(av[2]);for(int i=0;i<Q;i++){F[i]=power(i,d);assert(power(i,512)==i);}for(int a=1;a<Q;a++){int h[512]={};for(int x=0;x<Q;x++)++h[F[x]^F[a^x]];assert(*max_element(h,h+Q)==2);}
 for(int a=1;a<Q;a++)for(int b=a+1;b<Q;b++)if(b<(a^b)&&(F[a]^F[b]^F[a^b])==1)leaves.push_back({a,b,a^b});assert(leaves.size()==85);
 for(int i=0;i<85;i++){L q=leaves[i];for(int &x:q)x=mult(x,x);sort(q.begin(),q.end());auto it=find(leaves.begin(),leaves.end(),q);assert(it!=leaves.end());permute[i]=it-leaves.begin();}
 memset(where,-1,sizeof(where));where[0]=0;dfs(0,0,1);cerr<<"exp "<<d<<" target "<<target<<" raw-rank6 "<<raw<<" frob-orbits "<<canon<<" initial";for(auto [v,n]:hbase)cerr<<" "<<v<<":"<<n;cerr<<" hits ordered "<<found<<endl;
}
