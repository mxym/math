"""Affinely encoded maps in GF(512), low bit = constant power of t."""
from itertools import combinations
def need(b): 
 if not b:raise AssertionError('witness test failed')
def mul(a,b):
 r=0
 for j in range(9):
  if b>>j&1:r^=a<<j
 while r>=512:r ^= 0x211<<(r.bit_length()-10)
 return r
def power(a,n):
 r=1
 for _ in range(n):r=mul(r,a)
 return r
def lin(x,cols):
 y=0
 for i,c in enumerate(cols):
  if x>>i&1:y^=c
 return y
direct={
 3:[451,504,385,311,457,493,74,107,42],
 5:[19,33,207,369,182,239,175,218,155],
 17:[208,414,200,13,324,311,276,347,410]}
# Full-flat witness Y|X encoded as X+512Y, center (0,1).
flat={3:[(1<<j)+512*c for j,c in enumerate(direct[3])],
 5:[25603,123125,150090,56978,257612,181163,135564,21322,27568],
 17:[171011,91568,122894,211493,212538,86300,185117,173737,112923]}
def main():
 for d in (3,5,17):
  f=[power(x,d) for x in range(512)];need(len(set(f))==512)
  for a in range(1,512):need(len({f[x]^f[x^a] for x in range(512)})==256)
  target=19 if d==3 else 18
  yes=[x for x in range(512) if 1^lin(x,direct[d])==f[x]]
  need(len(yes)==target and len({a^b for a,b in combinations(yes,2)})==len(yes)*(len(yes)-1)//2)
  yToX={};P={lin(z,flat[d])^512 for z in range(512)};need(len(P)==512)
  need(len({p>>9 for p in P})==512)
  for p in P:yToX[p>>9]=p%512
  hit=[x for x,y in enumerate(f) if x+512*y in P];need(len(hit)==19)
  b=yToX[0];cols=[b^yToX[1<<j] for j in range(9)]
  need(all(yToX[x]==lin(x,cols)^b for x in range(512)))
  inv=pow(d,-1,511);need(sum((lin(y,cols)^b)==power(y,inv) for y in range(512))==19)
  coord=len({p%512 for p in P});need(coord==(512 if d==3 else 256))
  print('d',d,'direct offset 1 columns',direct[d],'agreements',len(yes))
  print('inverse exponent',inv,'offset',b,'columns',cols,'agreements',len(hit),'flat projection ranks',coord.bit_length()-1,9)
if __name__=='__main__':main()
