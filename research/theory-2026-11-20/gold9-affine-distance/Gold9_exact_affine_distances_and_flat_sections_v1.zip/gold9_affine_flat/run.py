"""Clean full replay. Requires C++17 compiler, no other dependencies."""
from pathlib import Path
import os,subprocess,tempfile,sys
from witness import main
root=Path(__file__).resolve().parent
def chk(z):
 if not z:raise AssertionError('upper replay mismatch')
def go(args):
 p=subprocess.run(args,capture_output=True,text=True,check=True);s=p.stdout+p.stderr;print(s,end='',flush=True);return s
with tempfile.TemporaryDirectory() as tmp:
 for name in ('gerb3','gerb_audit','gerb_flat','flat_audit'):
  bin=Path(tmp)/name
  subprocess.run([os.environ.get('CXX','g++'),'-O3','-std=c++17',str(root/(name+'.cpp')),'-o',str(bin)],check=True)
  for d in (3,5,17):
   n=20 if d==3 else 19;s=go([bin,str(d),str(n)])
   if name=='gerb3':chk(s.strip()==f'exp {d} target {n} raw-rank6 93436 frob-orbits 10388 initial 9:10388 hits ordered 0')
   elif name=='gerb_audit':
    chk(s.strip()==f'exponent {d} threshold {n} all rank-six triples 93436 frames 93436 hits 0')
    chk(go([bin,str(d),str(n-1),'control']).strip()==f'lower-control hit at frame '+str({3:1404,5:3,17:22}[d]))
   elif name=='gerb_flat':
    suffix={3:'0 table',5:'21 table (19,8,7):2 (19,8,8):16 (19,8,9):3',17:'18 table (19,8,7):2 (19,8,8):12 (19,8,9):4'}[d]
    chk(s.splitlines()[-1]==f'exp {d} goal {n} raw 98770 iso 10982 hits '+suffix)
   else:
    k={3:0,5:175,17:156}[d];chk(s.strip()==f'exp {d} threshold {n} raw triples 98770 with qualifying 9-flat {k} detected maximum '+str(19 if k else 0))
 main()
print('All four upper-bound searches and six direct witness checks passed.')
