#ifdef NDEBUG
#error keep checks enabled
#endif
#include <array>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cstdint>
#include <cassert>
#include <cstdlib>
using namespace std;using T=array<int,3>;
int lg[512],ex[1022],f[512],d,threshold;uint64_t frames,positive;
int verifyFlat(const T&a,const T&b,const T&c){
 vector<int>basis;for(T v:{a,b,c})for(int j:{0,1})basis.push_back(v[j]|((f[v[j]]^1)<<9));
 int pivot[18]={},map[18]={};for(int x:basis){while(x){int j=__builtin_ctz(x);if(pivot[j])x^=pivot[j];else{pivot[j]=x;break;}}}
 int bits=0;for(int j=0;j<18;j++)if(!pivot[j])map[j]=1<<bits++;assert(bits==12);
 int proj[18];for(int b=0;b<18;b++){int x=1<<b,v=0;for(int j=0;j<18;j++)if(x>>j&1){if(pivot[j])x^=pivot[j];else{x^=1<<j;v^=map[j];}}assert(!x);proj[b]=v;}
 int lo[512]={},hi[512]={};for(int x=1;x<512;x++){int j=__builtin_ctz(x);lo[x]=lo[x&(x-1)]^proj[j];hi[x]=hi[x&(x-1)]^proj[9+j];}
 uint8_t h[4096]={};int representative[4096]={};vector<int> v[4];
 for(int x=0;x<512;x++){int q=lo[x]^hi[f[x]^1];h[q]++;if(q){representative[q]=x|(512*(f[x]^1));assert(h[q]<=3);v[h[q]].push_back(q);}}assert(h[0]==9);
 int need=threshold-9,heavy=(3*need+6)/7;assert(heavy>=5);
 int best=0;
 for(int i:v[(heavy+2)/3])for(int j:v[1])if(i!=j){
  int p=h[i],q=h[j],l=i^j,r=h[l],w=p+q+r;if(w<heavy||q>p||r>q)continue; // some such choice inside every heavy plane
  int bound=(need-w+3)/4;assert(bound>=1);
  for(int k:v[bound])if(k!=i&&k!=j&&k!=l){int s=w+h[k]+h[k^i]+h[k^j]+h[k^l];best=max(best,s+9);if(s+9>=threshold){vector<int> rows=basis;for(int t:{i,j,k})rows.push_back(representative[t]);int bb[9]={},rank=0;for(int z:rows){z&=511;while(z){int bit=__builtin_ctz(z);if(bb[bit])z^=bb[bit];else{bb[bit]=z;rank++;break;}}}assert(s+9==19&&d!=3&&rank==8);}}
 }
 return best;
}
int main(int ac,char**av){assert(ac==3);d=atoi(av[1]);threshold=atoi(av[2]);assert(threshold==19||threshold==20);int x=1;vector<int>seen(512);for(int i=0;i<511;i++){assert(!seen[x]++);lg[x]=i;ex[i]=ex[i+511]=x;x<<=1;if(x&512)x^=0x21b;}assert(x==1);
 for(int i=1;i<512;i++)f[i]=ex[(lg[i]*d)%511];
 vector<T>all;for(int i=1;i<512;i++)for(int j=i+1;j<512;j++)if(j<(i^j)&&(f[i]^f[j]^f[i^j])==1)all.push_back({i,j,i^j});assert(all.size()==85);
 int bmax=0;for(int a=0;a<85;a++)for(int b=0;b<a;b++)for(int c=0;c<b;c++){frames++;int t=verifyFlat(all[a],all[b],all[c]);if(t>=threshold){positive++;bmax=max(t,bmax);}}
 cout<<"exp "<<d<<" threshold "<<threshold<<" raw triples "<<frames<<" with qualifying 9-flat "<<positive<<" detected maximum "<<bmax<<endl;assert(frames==98770&&((d==3&&threshold==20)?(!positive):positive>0)&&bmax<=19);
}
