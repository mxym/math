"""Exact finite-group controls. Python 3 standard library; no search solver or tolerance."""
from itertools import permutations, product
from collections import deque
from math import gcd,lcm
import random

def norm(d,m): return tuple((x-d[0])%m for x in d)
def rot(d,r=1): return tuple(d[(j-r)%3] for j in range(3))
def add(*xs): return tuple(map(sum,zip(*xs)))
def mul(g,h,m):
    r,d=g; s,e=h
    return ((r+s)%3,norm(add(d,rot(e,r)),m))
I=(0,(0,0,0))
def gen(generators,m):
    group={I}; todo=deque([I])
    while todo:
        u=todo.popleft()
        for v in generators:
            w=mul(u,v,m)
            if w not in group:
                group.add(w);todo.append(w)
    return group
def rowset(ts,m):
    return {(r,norm(add(t,(0,k*m//3,2*k*m//3)),m)) for r,t in enumerate(ts) for k in range(3)}
def orth(s,m):
    assert len(s)==9
    for r,d in s:
        for t,e in s:
            if r!=t or d==e: continue
            q=norm(tuple(a-b for a,b in zip(d,e)),m)
            assert set(q)=={0,m//3,2*m//3}
def canon_delta(ts,m):
    val=norm(add(*(rot(t,r) for r,t in enumerate(ts))),m)
    return min(norm(add(pv,(0,k*m//3,2*k*m//3)),m) for pv in permutations(val) for k in range(3))

m=3
extrema=[]
for c in (1,2):
    ts=((0,0,0),(0,0,0),(0,0,c))
    s=rowset(ts,m);orth(s,m)
    g=gen(s,m)
    assert len(g)==27 and (2,(0,0,0)) not in s
    extrema.append(canon_delta(ts,m))
assert extrema[0]!=extrema[1]
# Direct enumeration of every UEB contained in the canonical 27-group.
# Each shift row has three elements, necessarily a coset of <Z>.
allrows=list(product(range(3),repeat=3))
counts={}
for a,b,c in allrows:
    ts=[(0,0,j) for j in (a,b,c)]
    s=rowset(ts,3);orth(s,3)
    # Group of s times any chosen anchoring inverse.
    r,d=next(iter(s))
    inv=((-r)%3,norm(tuple(-v for v in rot(d,-r)),3))
    g=gen([mul(u,inv,3) for u in s],3)
    key=(len(g),canon_delta(ts,3))
    counts[key]=counts.get(key,0)+1
assert sorted(counts.values())==[9,9,9] and len(counts)==3
print("27-group: all 27 nine-element orthogonal sets in canonical coordinates:",counts)

# Use the source matrices literally as (shift, diagonal phases), in modulus lcm(n,3).
for n in range(1,41):
    m=lcm(n,3); h=m//n
    Y=(2,(0,0,h));V=(1,(0,0,-h));Z=(0,(0,m//3,2*m//3))
    assert mul(Y,V,m)==(0,norm((0,-h,h),m))
    g=gen([Y,V,Z],m)
    assert len(g)==9*(n//gcd(3,n))**2
print("SIC family: direct group closures agree for all phase orders n=1,...,40.")

# General monomial left/right gauges on finite phase grids. Permutations send
# index j to eps*j+shift; right permutation chosen with left*right = X^a.
rng=random.Random(7362)
for m in (3,6,9,15,21,24):
    def rand():return tuple(rng.randrange(m) for _ in range(3))
    for _ in range(100):
        ts=[rand() for _ in range(3)]
        orth(rowset(ts,m),m)
        for eps,shift,a in product((1,-1),range(3),range(3)):
            def perm(v):return tuple(v[eps*(j-shift)%3] for j in range(3))
            new=[None]*3;left=rand();right=rand()
            for r,t in enumerate(ts):
                s=(a+eps*r)%3
                new[s]=add(left,perm(t),rot(right,s))
            assert canon_delta(new,m)==canon_delta(ts,m)
print("Moduli: 10,800 exact equivalence transformations preserve the diagonal-orbit invariant.")
