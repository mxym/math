"""Python 3 stdlib. Exact local checks; these do not replace the analytic proof."""
from itertools import combinations, product
from collections import defaultdict
from math import comb
from fractions import Fraction

def ck(a,b,name):
    if a!=b:raise AssertionError((name,a,b))
def orient(edge):
    a,b=edge
    return ((a,b,1),(b,a,-1))
def canon(i,j):return ((i,j),1) if i<j else ((j,i),-1)
def sign(seq):return (-1)**sum(x>y for i,x in enumerate(seq) for y in seq[i+1:])
def tidy(a):return {k:v for k,v in a.items() if v}

def real_checks(d):
    es=list(combinations(range(d),2));r=len(es);tot=0
    for a,b in product(es,repeat=2):
        # Apply ordinary left swap to the ordered physical product (i,j,k,l),
        # then project back onto the normalized edge basis. The denominator is 4.
        true=defaultdict(int)
        for i,j,s in orient(a):
            for k,l,t in orient(b):
                if k==j or i==l:continue
                p,u=canon(k,j);q,v=canon(i,l);true[p,q]+=s*t*u*v
        # Independent proposed projector I+F - sum_S vec(J_S)vec(J_S)^T.
        target=defaultdict(int);target[a,b]+=1;target[b,a]+=1
        if len(set(a+b))==4:
            S=tuple(sorted(a+b));w=sign(a+b)
            for p in combinations(S,2):
                q=tuple(i for i in S if i not in p)
                target[p,q]-=w*sign(p+q)
        ck(tidy(true),tidy(target),('4M',d,a,b));tot+=1
    if d>=4:
        ck(Fraction(15*comb(d,4),comb(r,2)),Fraction(5*(d-3),d+1),('Haar scalar',d))
        # Exact count of unordered pairs of edges on each four-label support.
        count=sum(comb(d-len(set(a+b)),4-len(set(a+b))) for a,b in combinations(es,2))
        ck(count,15*comb(d,4),('count',d))
    return tot

def adj(D):return [list(i) for i in zip(*[[x.conjugate() for x in r] for r in D])]
def mul(A,B):return [[sum(x*y for x,y in zip(i,j)) for j in zip(*B)] for i in A]
def tr(A):return sum(A[i][i] for i in range(len(A)))
def contraction(d):
    # A nonreal rectangular 2 by 3 frame; all arithmetic is over small
    # Gaussian integers, exactly representable by the Python complex type.
    E=list(combinations(range(d),2));V={e:[[complex((s+2*a+b)%4-2,(s+a*b)%3-1) for b in range(3)] for a in range(2)] for s,e in enumerate(E)}
    A=[[[0j]*3 for _ in range(2)] for _ in range(d*d)]
    for e in E:
        for i,j,t in orient(e):
            A[i*d+j]=[[t*x for x in a] for a in V[e]]
    X=[[A[i*d+j][a][b] for j,b in product(range(d),range(3))] for i,a in product(range(d),range(2))]
    D=mul(X,adj(X));L=D and tr(mul(D,D))
    def sumarrays(arr):
        return [[sum(M[i][j] for M in arr) for j in range(len(arr[0][0]))] for i in range(len(arr[0]))]
    C=sumarrays([mul(v,adj(v)) for v in V.values()]);C1=tr(mul(C,C))
    C=sumarrays([mul(adj(v),v) for v in V.values()]);C2=tr(mul(C,C));cross=0
    for S in combinations(range(d),4):
        Q=[[0j]*6 for _ in range(6)]
        for a in combinations(S,2):
            b=tuple(i for i in S if i not in a);sg=sign(a+b)
            for i,j in product(range(6),repeat=2):
                Q[i][j]+=sg*V[a][i//3][i%3]*V[b][j//3][j%3]
        for a,b,c,f in product(range(2),range(3),range(2),range(3)):
            cross+=Q[3*a+b][3*c+f]*Q[3*c+b][3*a+f].conjugate()
    # X here uses unnormalized elementary wedges, so its fourth moment is four
    # times the normalized one (C1+C2-cross)/4.
    ck(L,C1+C2-cross,('rectangular contraction',d))

n=sum(real_checks(d) for d in range(2,11))
for d in range(2,8):contraction(d)
print(f'PASS: exact 4M projector checks on {n} ordered basis-pair columns for d=2,...,10;')
print('Haar dimension and support counts for d=4,...,10; complex rectangular contractions for d=2,...,7.')
