from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import factorial
from collections import Counter
import subprocess,os,sys,time,re,hashlib,csv
from functools import lru_cache
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from frame import frame_counts,rank
from apn import check as check_apn
from independent import search
if not __debug__:raise RuntimeError('the replay requires Python assertions')
os.chdir(Path(__file__).resolve().parent)
def count(A,b,d,sidon=True,mx=None):
 exe='./localcount' if d<=9 else './finalcount'
 return int(subprocess.check_output([exe,str(b),str(1<<d),str(int(sidon))]+([]if mx is None else [str(mx)]),input=' '.join(map(str,A)),text=True))
def moments(d,n):
 Q=1<<d;l=n%2;z2=Q*n-n*n;z4=Q*(3*n*n-2*n)-n**4
 return next(k for k in range((n+1)//2,n+1)if z4-(l+(2*k-n)**2)*z2+l*(2*k-n)**2*(Q-1)<=0)
def cfs(S,d):
 a=[0]*(1<<d)
 for x in S:a[x]=1
 for j in range(d):
  h=1<<j
  for q in range(0,len(a),2*h):
   for k in range(q,q+h):a[k],a[k+h]=a[k]+a[k+h],a[k]-a[k+h]
 return a
def read(d):
 f=Path('d%d.txt'%d).read_text();q=[tuple(map(int,l.split()))for l in f.splitlines()]
 for A in q:
  assert all(0<=x<1<<d for x in A) and len(A)==len(set(A)) and rank([x+(1<<d)for x in A])==d+1
  assert len({x^y for x,y in combinations(A,2)})==len(A)*(len(A)-1)//2
 g=list(map(int,subprocess.check_output(['./group',str(d)],input=f,text=True).split()))
 assert len(g)==len(q)
 return list(zip(q,g))
data={d:[tuple(map(int,l.split()))for l in Path('d%d.txt'%d).read_text().splitlines()]for d in (7,8,9,10)}
for d,hist in {7:{10:2,11:1,12:1},8:{14:5,15:5,16:3,17:1,18:1},9:{20:1681,21:738,22:127,23:8,24:1},10:{32:200,33:7,34:1}}.items():
 assert Counter(map(len,data[d]))==hist
jobs=int(os.environ.get('JOBS','2'));assert jobs>=1
mode=sys.argv[1]if len(sys.argv)>1 else 'all'
assert mode in ('all','classification','endpoint','endpoint1','endpoint2')
do_class=mode in ('all','classification')
caps={d:read(d)for d in (7,8,9,10)}if do_class else {}
if do_class:
 assert frame_counts(6,10)[10]==0 # a non-spanning 10-set cannot be Sidon in 5D: C(10,2)>31.
 cc=frame_counts()
 assert cc[13]==0
 for n in [10,11,12]:
  mass=sum(F(factorial(8)*sum(rank([v+128 for v in z])==8 for z in combinations(s,8)),g)for s,g in caps[7]if len(s)==n)
  assert mass==cc[n]
 print('normalized frame counts verified:',dict(sorted(cc.items())),flush=True)
def stage(d,n,pool,maximal=False):
 lo=moments(d,n);target=Counter();actual=Counter()
 for S,g in caps[d]:
  if len(S)!=n:continue
  w=cfs(S,d)[1:];largest=(n+max(map(abs,w)))//2
  for v in w:
   for m in [(n+v)//2,(n-v)//2]:
    if m>=lo and (not maximal or m==largest):actual[m]+=F(1,g)
 V=[(A,g) for A,g in caps[d-1]if len(A)>=lo]
 def calc(row):
  A,g=row;b=n-len(A);mx=len(A)-b if maximal else None
  if maximal and max(map(abs,cfs(A,d-1)[1:]))+b%2>mx:return len(A),F()
  return len(A),F(count(A,b,d-1,mx=mx),g*b)
 for a,x in pool.map(calc,V):target[a]+=x
 assert all(target[k]==actual[k] for k in set(target)|set(actual)),(d,n,actual,target)
 print('dimension',d,'size',n,'floor',lo,'mass',[(k,str(target[k])) for k in sorted(target)],flush=True)
if do_class:
 with ThreadPoolExecutor(max_workers=jobs)as pool:
  for d,ns in [(8,range(14,20)),(9,range(20,26)),(10,range(32,36))]:
   for n in ns:stage(d,n,pool,maximal=(d,n)==(10,32))
 print('PASS classification',flush=True)
if mode=='classification':sys.exit(0)
def sidon(S,d):
 assert len(S)==len(set(S)) and all(0<=x<1<<d for x in S) and len({x^y for x,y in combinations(S,2)})==len(S)*(len(S)-1)//2
def call(cmd,A):
 r=subprocess.run(cmd,input=' '.join(map(str,A))+'\n',text=True,capture_output=True,check=True)
 return r.stdout.splitlines(),r.stderr
assert len(check_apn())==64
print('PASS APN attainment: all 63 derivatives and 4032 correlations, linearity 32.',flush=True)
known=list(map(int,Path('known48.txt').read_text().split()));assert len(known)==48;sidon(known,11)
assert moments(11,49)==30 and moments(10,31)==20
assert 64*(1024*30-30**2)-28*(512*30-30**2)==1503600 < 1893360==1024*(3*30**2-2*30)-30**4
control=tuple(map(int,Path('control32.txt').read_text().split()));assert len(control)==32
assert count(control,16,10)==992
out,_=call(['./difference','16'],control);assert out[-1].startswith('hit 1 nodes ')
other=list(map(int,out[0].split()));assert len(other)==16;sidon(list(control)+[1024+x for x in other],11)
print('PASS 32+16 positive control: 992 labeled admissible opposite layers containing zero.',flush=True)
def top(A):
 n=49-len(A);assert n>=15
 assert count(A,n,10)==0
 out,_=call(['./difference',str(n)],A);assert len(out)==1 and out[0].startswith('hit 0 nodes '),out
with ThreadPoolExecutor(max_workers=jobs)as pool:list(pool.map(top,data[10]))
print('PASS: all 208 large hyperplane anchors excluded by both methods.',flush=True)
groups=[(22,9,9,9,13,13,31),(21,10,10,8,11,11,31),(21,10,9,9,11,12,31),(20,11,11,7,9,9,31),(20,11,10,8,9,12,31),(20,11,9,9,9,13,31),(20,10,10,9,10,10,30)]
engines=['./quarters','./quarter2']if mode in ('all','endpoint')else ['./quarters'if mode=='endpoint1'else './quarter2']
for exe in engines:
 out,_=call([exe,'48','32','12','10','6','8','12'],tuple(map(int,Path('control20.txt').read_text().split())))
 assert out[-1]=='hit 1';S=list(map(int,out[0].split()));assert len(S)==48;sidon(S,11)
print('PASS independently validated 48-point search control.',flush=True)
expected={
 (22,9,9,9):(124,1933634,8,11),
 (21,10,10,8):(695,336,0,6),
 (21,10,9,9):(695,901782,8,10),
 (20,11,11,7):(7,0,0,0),
 (20,11,10,8):(7,14884,308,11),
 (20,11,9,9):(7,1149200,21530,14),
}
tags={(22,9,9,9):'22',(21,10,10,8):'21a',(21,10,9,9):'21b',(20,11,11,7):'20a',(20,11,10,8):'20b',(20,11,9,9):'20c',(20,10,10,9):'30'}
with Path('checks.tsv').open()as f:
 ledger={(r['shape'],r['anchor_sha256']):tuple(int(r[k])for k in ('first_pairs','first_large_holes','first_max_holes','second_pairs','second_large_holes','second_max_holes'))for r in csv.DictReader(f,delimiter='\t')}
assert len(ledger)==124+2*695+3*7+846
def sweep(shape):
 a,b,c,d,ub,uc,m=shape
 sources=[s for s in data[9]if len(s)==a and max(map(abs,cfs(s,9)[1:]))+b%2<=ub]
 sums=defaultdict(int);largest=0
 def one(s):
  statuses=[]
  for exe in engines:
   out,log=call([exe,*map(str,(49,m,b,c,d,ub,uc))],s)
   assert out==['hit 0'],out
   x=tuple(int(z)if z is not None else 0 for z in [next(iter(re.findall(q+r'(\d+)',log)),None)for q in ('pairs','holes','maxhole')])
   statuses.append(x)
  key=hashlib.sha256(' '.join(map(str,s)).encode('ascii')).hexdigest();q=ledger[(tags[(a,b,c,d)],key)]
  for e,st in zip(engines,statuses):assert st==(q[:3] if e=='./quarters'else q[3:]),(e,shape,s,st,q)
  if m==31:assert len(set(statuses))==1,(shape,s,statuses)
  return statuses
 with ThreadPoolExecutor(max_workers=jobs)as pool:
  for z in pool.map(one,sources):
   for exe,(e,h,mx) in zip(engines,z):
    sums[exe,'pairs']+=e;sums[exe,'holes']+=h;sums[exe,'maxhole']=max(sums[exe,'maxhole'],mx)
 if (a,b,c,d) in expected:
  for e in engines:assert (len(sources),*(sums[e,k]for k in ('pairs','holes','maxhole')))==expected[(a,b,c,d)]
 if m==30:
  for e in engines:assert (len(sources),*(sums[e,k]for k in ('pairs','holes','maxhole')))==((846,0,0,0)if e=='./quarters'else(846,3210,279,12))
 print('quarters',shape,'eligible',len(sources),'(pairs,holes,maxhole) by checker',[(e,tuple(sums[e,k]for k in ('pairs','holes','maxhole')))for e in engines],flush=True)
for shape in groups:sweep(shape)
P=lambda x:-(x+11)*(x+3)*(x-1)*(x-9)
assert [P(x)for x in (-11,-7,-3,1,5,9)]==[0,2048,0,0,2048,0]
n=85;Q=4096
assert -Q*(3*n*n-2*n)+98*Q*n-297*Q-P(n)==-1249280 and 204-4*(3*n-2)<0
print('PASS corollary: dimension twelve admits at most 84 points.')
print('PASS: no size-49 binary Sidon set in dimension eleven. Known size 48 verified.',flush=True)
