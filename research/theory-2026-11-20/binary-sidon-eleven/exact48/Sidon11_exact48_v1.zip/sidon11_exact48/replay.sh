#!/bin/sh
set -eu
cd "$(dirname "$0")"
CXX=${CXX:-c++}
CFLAGS=${CFLAGS:--O3 -march=native}
for s in group quarters quarter2 difference;do "$CXX" $CFLAGS -std=c++17 "$s.cpp" -o "$s";done
"$CXX" $CFLAGS -std=c++17 -DWIDTH=6 count.cpp -o localcount
"$CXX" $CFLAGS -std=c++17 -DWIDTH=9 count.cpp -o finalcount
python3 -u replay.py "$@"
