#ifdef NDEBUG
#error assertions needed
#endif
#include<bits/stdc++.h>
using namespace std;
int n,tar;vector<vector<int>>subs;long long nodes[7];int basis[6];
void dfs(const vector<int>&V,int k){nodes[k]++;if(k==6){vector<int>F={0};for(int i=0;i<6;i++){int l=F.size();for(int j=0;j<l;j++)F.push_back(F[j]^basis[i]);}sort(F.begin(),F.end());subs.push_back(F);return;}
 int minv=(1<<(6-k))-1;if(V.size()<minv)return;bool in[4096]={};for(int v:V)in[v]=true;
 for(int h=0;h<V.size();h++){int x=V[h],p=31-__builtin_clz(x);if(p>=7+k)break;basis[k]=x;
 if(k==5){dfs({},k+1);continue;}vector<int>q;int b=1<<p;
 for(int j=h+1;j<V.size();j++){int y=V[j];if(y<2*b||(y&b)||!in[x^y])continue;q.push_back(y);}dfs(q,k+1);}}
int main(int ac,char**av){ifstream f(av[1]);vector<int>S;int x;while(f>>x)S.push_back(x);assert(S.size()==64);bool used[4096]={};for(int i=0;i<64;i++)for(int j=0;j<i;j++){int d=S[i]^S[j];assert(d&&!used[d]);used[d]=true;}
 vector<int>V;for(int i=1;i<4096;i++)if(!used[i])V.push_back(i);dfs(V,0);assert(set<vector<int>>(subs.begin(),subs.end()).size()==subs.size());map<int,long long>dim;for(int j=0;j<subs.size();j++){auto&a=subs[j];assert(a.size()==64);for(auto x:a)assert(!used[x]);for(int i=0;i<j;i++){auto&b=subs[i];int c=0;for(int v:a)if(binary_search(b.begin(),b.end(),v))c++;dim[c]++;}}
 cout<<av[1]<<" six-spaces "<<subs.size()<<" intersections";for(auto [k,v]:dim)cout<<" "<<k<<":"<<v;cout<<" nodes";for(auto n:nodes)cout<<" "<<n;cout<<endl;}
