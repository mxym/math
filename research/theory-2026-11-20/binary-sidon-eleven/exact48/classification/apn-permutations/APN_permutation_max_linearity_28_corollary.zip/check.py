from pathlib import Path
from tempfile import TemporaryDirectory
import os,subprocess,shutil,re
from zerosubdual import audit,ck
base=Path(__file__).resolve().parent;os.chdir(base)
expected={'apnD07.txt':(94,{4:180,8:1740,16:2145,32:306}),'apnD05.txt':(222,{1:256,2:2688,4:6636,8:10044,16:4179,32:728})}
# Table 1 of arXiv:2609.22394v2; binary field polynomial X^6+X^4+X^3+X+1.
def mul(x,y):
 v=0
 while y:
  if y&1:v^=x
  x=2*x
  if x&64:x^=91
  y//=2
 return v
def pow(x,n):
 a=1
 while n:
  if n&1:a=mul(a,x)
  x=mul(x,x);n//=2
 return a
from functools import reduce
from operator import xor
T=[[(0,3),(11,5),(13,9),(0,17),(11,33),(0,48)],[(0,3),(1,24),(0,10)]]
with TemporaryDirectory()as tmp:
 exe=Path(tmp)/'test';subprocess.run([os.environ.get('CXX','g++'),'-O3','-std=c++17','zerosub.cpp','-o',str(exe)],check=True)
 for (f,(n,c)),pol in zip(expected.items(),T):
  words=[x+64*reduce(xor,(mul(pow(2,k),pow(x,e))for k,e in pol),0)for x in range(64)]
  ck(words==list(map(int,Path(f).read_text().split())))
  ck(audit(f)==(n,c))
  z=subprocess.check_output([str(exe),f],text=True).split()
  ck(z[:3]==[f,'six-spaces',str(n)] and z[3]=='intersections')
  qq={int(v.split(':')[0]):int(v.split(':')[1])for v in z[4:z.index('nodes')]}
  ck(qq==c and sum(qq.values())==n*(n-1)//2)
print('PASS primal and dual independent censuses, D7 excluded, D5 positive control.')
