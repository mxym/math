"""Enumerate all six-dimensional zero-Walsh spaces by hyperplane intersection induction."""
from functools import cache
from collections import Counter
from itertools import combinations
from pathlib import Path
import sys
def ck(v):
 if not v:raise ValueError('arithmetic check failed')
def audit(p):
 A=tuple(map(int,Path(p).read_text().split()));ck(len(A)==len(set(A))==64 and len({a^b for a,b in combinations(A,2)})==2016);V=set(range(4096));zero={u for u in V if u==0 or sum((-1)**((u&x).bit_count()%2)for x in A)==0}
 @cache
 def enum(d,k):
  if k==0:return ((0,),)
  if k>d:return ()
  old=enum(d-1,k);new=list(old);H=1<<(d-1)
  for B in enum(d-1,k-1):
   unseen={x for x in range(H,2*H)if x in zero}
   # Every high coset of B is a possible opposite layer; try it once.
   while unseen:
    x=unseen.pop();C={x^y for y in B};unseen-=C
    if C<=zero:new.append(tuple(sorted((*B,*C))))
  return tuple(new)
 S=enum(12,6);ck(len(set(S))==len(S));Q=[]
 for space in S:
  q=frozenset(space);ck(len(q)==64 and q<=zero and all((x^y)in q for x in q for y in q));Q.append(q)
 c=Counter(len(a&b)for a,b in combinations(Q,2));print(p,len(S),dict(sorted(c.items())),flush=True)
 return len(S),dict(c)
if __name__=='__main__':
 for p in sys.argv[1:]:audit(p)
