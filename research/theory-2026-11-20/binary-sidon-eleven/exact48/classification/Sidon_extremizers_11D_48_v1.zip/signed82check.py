"""Independent integer checker for the 82-point, maximum 47 branch."""
import ast,json
from itertools import combinations,product
from math import prod
from functools import reduce
from operator import xor
from pathlib import Path
def req(ok): 
 if not ok:raise ValueError("check failed")
def evalfeat(k,w,n,b,M,marks):
 """Return (value on this profile, sum over all characters or upper bound, is an inequality)."""
 Q=1024
 if k=='count':return 1,Q,False
 if k=='mixed':return prod(w),0,False
 if isinstance(k[0],str) and k[0] not in ['ss']:
  if k[0]=='numtag':return int(k[1]==b),Q//M,False
  i=k[1]
  if k[0]=='square':return w[i]**2,Q*n[i],False
  if k[0]=='fourth':return w[i]**4,Q*(3*n[i]**2-2*n[i]),False
  if k[0]=='22':
   j=k[2];return (w[i]*w[j])**2,Q*n[i]*n[j],False
  if k[0]=='root':req(i in marks);return w[i],Q,False
  raise ValueError(k)
 f,h=k;req(0<=h<M);phase=(-1)**((b&h).bit_count()%2)
 if f=='ss':req(h!=0);return phase*sum(a*a for a in w),2*Q,True
 if f[0]=='pairtwo':
  j=f[1];req(j in (1,2,3));s,t=(i for i in (1,2,3)if i!=j)
  return phase*(w[0]*w[j]+w[s]*w[t]),Q,True
 op,side=f;req(side in ['hi','lo']);i=op[1]
 if op[0]=='square':req(h!=0);v=w[i]**2;cap=2*Q
 elif op[0]=='point':v=w[i];cap=Q
 elif op[0]=='pair':
  j=op[2];req(i<j);v=w[i]*w[j];cap=Q
 else:raise ValueError(op)
 return (phase*v if side=='hi' else -phase*v),(cap if side=='hi' else 0),True
def allprofs(n,m,g):
 even=[i for i in range(4)if n[i]%2==0];odd=[i for i in range(4)if n[i]%2];req(len(even)==len(g)==len(odd)==2)
 R=2*m-sum(n);M=1<<max(g).bit_length()
 for w in product(*(range(-R+(R-a)%2,R+1,2)for a in n)):
  if any((w[i]-n[i])%4 for i in odd):continue
  if max(abs(w[0]+w[1]+w[2]+w[3]),abs(w[0]+w[1]-w[2]-w[3]),abs(w[0]-w[1]+w[2]-w[3]),abs(w[0]-w[1]-w[2]+w[3]))>R:continue
  if any(abs(w[i])+abs(w[j])>2*n[0]-m for i,j in combinations(range(4),2) if n[i]+n[j]==m):continue
  for b in range(M):
   if all(((n[i]-w[i])//2)%2==((v&b).bit_count()%2)for v,i in zip(g,even)):yield w,b
def replay():
 data=json.loads(Path('signed_exact82m47.json').read_text());seen=set()
 for key,entry in data.items():
  m,n,g=ast.literal_eval(key);req(m==47 and n==[29,18,18,17]);M=1<<max(g).bit_length();marks=[1];seen.add(tuple(g));supp=entry['multipliers']
  zz=[(evalfeat(f,n,n,0,M,marks),v) for f,v in supp];req(all(type(v)is int and (not le or v>=0)for (_,_,le),v in zz))
  cost=sum((r-c)*v for (c,r,_),v in zz);cnt=0;req(cost==entry['cost']<0)
  for w,b in allprofs(n,m,g):
   req(sum(evalfeat(f,w,n,b,M,marks)[0]*v for f,v in supp)>=0);cnt+=1
  req(cnt==entry['rows']);print(tuple(g),cnt,cost)
 req(seen=={(0,0),(1,0),(0,1),(1,1),(1,2)})
def control():
 S=list(map(int,Path('control66.txt').read_text().split()));req(len(S)==66 and len({x^y for x,y in combinations(S,2)})==2145)
 S=S[2:];L=[{x>>2 for x in S if x%4==i}for i in range(4)];n=[len(x)for x in L];req(n==[17,11,20,16])
 # Normalize odd layers to XOR zero, one even layer to contain zero. These are 3 freely choosable quotient shears (incl. common translation).
 shifts=[reduce(xor,L[0]),reduce(xor,L[1]),min(L[2])];shifts.append(reduce(xor,shifts));L=[{a^t for a in A}for A,t in zip(L,shifts)]
 even=[2,3];G=[reduce(xor,L[i])for i in even];req(G[0] and G[1] and G[0]!=G[1])
 M=4;marks=[2];profiles=[]
 for u in range(1024):
  w=[sum((-1)**((x&u).bit_count()%2)for x in l)for l in L];tag=sum(((e&u).bit_count()%2)<<k for k,e in enumerate(G))
  req(all((n[i]-w[i])%4==0 for i in (0,1)));req(all((n[i]-w[i])//2%2==((tag>>k)&1)for k,i in enumerate(even)))
  profiles.append((w,tag))
 d=json.loads(Path('signed_exact82m47.json').read_text());fs={json.dumps(f)for x in d.values()for f,v in x['multipliers']};tags=[]
 for s in fs:
  f=json.loads(s)
  if isinstance(f,list)and f[0]=='root':f[1]=2
  for w,b in profiles[:1]:_,rhs,ub=evalfeat(f,w,n,b,M,marks)
  v=sum(evalfeat(f,w,n,b,M,marks)[0]for w,b in profiles);req(v<=rhs if ub else v==rhs)
 req({tag for w,tag in profiles}=={0,1,2,3});print('64-point sub-control all active Fourier families PASS')
if __name__=='__main__':replay();control()
