from math import comb,prod
from itertools import combinations,product
from pathlib import Path
from functools import reduce
from operator import xor
import json,ast
Q=1024
def chk(x):
 if not x:raise ValueError('certificate rejected')
def rows(n,g,M):
 ev=[i for i,a in enumerate(n)if a%2==0];marks=ev[:3-(4-len(ev))];ng=max(g).bit_length();G=1<<ng;j=n[0];R=2*M-sum(n)
 chk(len(g)==len(ev))
 for b in range(G):
  for w in product(*(range(-R+((R-a)%2),R+1,2)for a in n)):
   if any((w[i]-n[i])%4 for i in range(4)if i not in ev):continue
   if any(((n[i]-w[i])//2-(b&z).bit_count())%2 for i,z in zip(ev,g)):continue
   if any(abs(sum((-1 if (z&i)in (1,2)else 1)*w[i]for i in range(4)))>R for z in range(4)):continue
   if any(abs(w[i])+abs(w[k])>2*j-M for i,k in combinations(range(4),2)if n[i]+n[k]==M):continue
   yield w,b
def points(n,w,leading):
 sig={};t={}
 def add(k,z,sz):
  sig[k]=sz if leading else z;t[k]=sz
 for i in range(4):
  add('P'+str(i),w[i],n[i]);add('p'+str(i),-w[i],Q-n[i]);add('D'+str(i),(w[i]*w[i]-n[i])//2,comb(n[i],2))
 add('d',-sum(sig[f'D{i}']for i in range(4)),Q-sum(t[f'D{i}']for i in range(4)))
 for i in range(1,4):
  j,k=[v for v in range(1,4)if v!=i]
  add(f'C0{i}',w[0]*w[i],n[0]*n[i]);add(f'C{j}{k}',w[j]*w[k],n[j]*n[k]);add(f'c{i}',-w[0]*w[i]-w[j]*w[k],Q-n[0]*n[i]-n[j]*n[k])
 return sig,t
def E(f,n,g,w,b,lead,P,T):
 if f=='count':return 1,Q,False
 if f=='mixed':return prod(w),0,False
 if ':' not in f:
  if f.startswith('sq'):i=int(f[2:]);return w[i]**2,Q*n[i],False
  if f.startswith('four'):i=int(f[4:]);return w[i]**4,Q*(3*n[i]**2-2*n[i]),False
  if f.startswith('22'):i,j=map(int,f[2:]);chk(i<j);return (w[i]*w[j])**2,Q*n[i]*n[j],False
  if f.startswith('tag'):i=int(f[3:]);chk(0<=i<1<<max(g).bit_length());return int(b==i),Q//(1<<max(g).bit_length()),False
  if f.startswith('root'):i=int(f[4:]);ev=[h for h in range(4)if n[h]%2==0];chk(i in ev[:len(ev)-1]);return w[i],Q,False
  raise ValueError(f)
 h,key=f.split(':');h=int(h);chk(0<=h<1<<max(g).bit_length());side=key[-1];chk(side in '<>');ks=key[:-1].split('*');chk(len(ks)<=2)
 z=(-1)**((h&b).bit_count()%2)*prod(P[k]for k in ks)
 bound=1 if len(ks)==1 else min(T[k]for k in ks)
 return (z if side=='<'else-z),(Q*bound if side=='<'else 0),True
def check():
 raw=json.loads(Path('low79cert.json').read_text());seen=set()
 for k,val in raw.items():
  m,n,g=ast.literal_eval(k);G=1<<max(g).bit_length();seen.add((m,tuple(n),tuple(g)))
  p,t=points(n,n,True);v=val['v'];c=0
  for f,j in v.items():
   y,r,ub=E(f,n,g,n,0,True,p,t);chk(type(j)is int and (not ub or j>=0));c+=(r-y)*j
  chk(c==val['cost']<0);num=0
  for w,b in rows(n,g,m):
   p,t=points(n,w,False);chk(sum(E(f,n,g,w,b,False,p,t)[0]*j for f,j in v.items())>=0);num+=1
  chk(num==val['columns']);print(n,g,c,num,flush=True)
 modes={(0,0,0)}
 def seq(g,k,n):
  if len(g)==n:return {tuple(g)}
  return set.union(*(seq(g+[z],k+(z==1<<k),n)for z in range(1+(1<<k))))
 S=[(46,(28,18,17,16)),(46,(28,18,18,15))]
 chk(seen=={(m,n,g)for m,n in S for g in seq([],0,sum(x%2==0 for x in n))})
if __name__=='__main__':check()
