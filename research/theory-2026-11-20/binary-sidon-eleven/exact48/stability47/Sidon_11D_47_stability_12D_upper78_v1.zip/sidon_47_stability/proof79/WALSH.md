# Indicator-signal arithmetic for the two 79-point low-quarter shapes

The indicator signals on $U$ for the signed certificates are:
- $P_i=1_{S_i}$, and its complement $p_i$, with masses $n_i,Q-n_i$.
- $D_i=1_{\Delta S_i}$ for within-layer sums of distinct pairs, mass $\binom{n_i}{2}$. Its Walsh value is $(w_i^2-n_i)/2$. The four $D_i$ have disjoint supports; $d$ is the indicator of the complement of their union.
- $C_{ij}=1_{S_i+S_j}$, mass $n_i n_j$ and Walsh $w_iw_j$, because all these cross-sums are distinct. For each partition $0j|kl$, $C_{0j},C_{kl}$ have disjoint supports (no four-layer collision); $c_j$ is the complement of their union.


At $u\ne0$ the Fourier transform of a complement is the negative of the given signal or disjoint signal sum. **At zero instead use its full mass.** For any above indicator $T$ and any $h$ in the XOR span, $\sum_u(-1)^{u\cdot h}\widehat T(u)$ lies between 0 and $Q$ by Fourier inversion. For any two indicators $T,S$, the analogous Fourier sum with product $\widehat T\widehat S$ is $Q$ times their translate intersection cardinality, between 0 and $Q\min(|T|,|S|)$. These bounds also apply to a signal paired with itself.


Use the two profiles and rank-three tag normalizations specified in the main proof. Each of the 32 integer certificates has nonnegative coefficients on genuine upper bounds and on all possible nonprincipal profiles, but a strictly negative RHS.
