from pathlib import Path
from itertools import combinations
from concurrent.futures import ThreadPoolExecutor
from subprocess import run
from hashlib import sha256
from collections import Counter
from functools import reduce
from operator import xor
import re
ROOT=Path(__file__).resolve().parent
def ck(v,msg):
 if not v:raise ValueError(msg)
def lines(p):return [list(map(int,r.split()))for r in (ROOT/p).read_text().splitlines()]
def valid(s,d):return all(0<=x<1<<d for x in s)and len(s)==len(set(s))and len({x^y for x,y in combinations(s,2)})==len(s)*(len(s)-1)//2
def norm(B):return min(tuple(sorted(x^z for x in B))for z in B)
def fwt(S,N):
 V=[int(x in S)for x in range(N)];h=1
 while h<N:
  for i in range(0,N,2*h):
   for j in range(i,i+h):V[j],V[j+h]=V[j]+V[j+h],V[j]-V[j+h]
  h*=2
 return V
def rank(S):
 d={}
 for z in S:
  while z:
   j=z.bit_length()
   if j not in d:d[j]=z;break
   z^=d[j]
 return len(d)
def inputs():
 A,=lines('known48.txt');D=lines('d10.txt');M={(r[0],r[1]):r[2:]for r in lines('highmaps.txt')};H={(r[0],r[1]):r[2:]for r in lines('high48.txt')};ck(valid(A,11)and len(A)==48 and Counter(map(len,D))=={32:200,33:7,34:1},'bad extremal data')
 ck(len(H)==len(M)==186 and set(H)==set(M)and Counter(i for i,k in H)=={198:62,199:124},'incomplete positive maps')
 P=[set()for _ in D];seen=set()
 for (i,k),s in H.items():
  c=D[i];v=M[i,k];ck(len(v)==13 and rank(v[:11])==11 and s[:len(c)]==c and valid(s,11)and len(s)==48,'singular map or bad marked section')
  def ap(x):return v[12]^reduce(xor,(v[j]for j in range(11)if (x^v[11])>>j&1),0)
  ck({ap(x)for x in s}==set(A),'wrong Chen bijection')
  B=[x^1024 for x in s[len(c):]];key=(i,norm(B));ck(key not in seen,'duplicate marked 48');seen.add(key)
  for j in range(len(B)):P[i].add(norm(B[:j]+B[j+1:]))
 ck([len(x)for x in P]==[992 if i==198 else 1984 if i==199 else 0 for i in range(208)],'wrong high-deletion mass')
 ledger=(ROOT/'high47-ledger.txt').read_text().splitlines();ck(ledger==[f'anchor {i} size {len(c)} total {len(P[i])} punctures {len(P[i])} novel 0'for i,c in enumerate(D)],'bad per-source high ledger')
 return A,D,P
def high(exe,jobs):
 A,D,P=inputs()
 def one(i):
  c=D[i];k=47-len(c)
  def out(name,av):
   return run([str(exe/name),*map(str,av)],input=' '.join(map(str,c)),capture_output=True,text=True,check=True).stdout.splitlines()
  x=out('highpair',[k]);y=out('highroot47',[k,1024,1,999]);ck(re.fullmatch(r'hit 0 nodes [0-9]+',x[-1])and y[-1].isdigit()and int(y[-1])==k*(len(y)-1),'incomplete high endpoint')
  B=[list(map(int,l.split()))for l in x[:-1]];F=[list(map(int,l.split()))for l in y[:-1]];ck(all(len(s)==47 and s[:len(c)]==c and valid(s,11)for s in F),'false high full witness')
  ck(all(len(b)==k and valid(c+[1024+v for v in b],11)for b in B),'bad high opposite')
  s={norm(b)for b in B};z={norm([u-1024 for u in v[len(c):]])for v in F};ck(s==z==P[i]and len(s)==len(B)==len(F),f'missing/extra high 47-set at source {i}')
 with ThreadPoolExecutor(jobs)as p:list(p.map(one,range(208)))
 print('All 208 large-section sources, both independent searches, all exact 992+1984 puncture rows agreed.',flush=True)
def derived(exe,jobs,do_opp):
 A,D,P=inputs()
 raw=run([str(exe/'chenaut'),'11'],input=' '.join(map(str,A)),text=True,capture_output=True,check=True).stdout.splitlines();ck(raw[-1]=='80','group order')
 G=[list(map(int,r.split()))for r in raw[:-1]];ck(len({tuple(p)for p in G})==80 and all(sorted(p)==list(range(48))for p in G),'bad affine permutation');File=[r for r in lines('chenaut.raw')if len(r)==48];ck({tuple(p)for p in File}=={tuple(p)for p in G},'group replay changed')
 R=[];S=set(range(48))
 while S:
  i=min(S);R.append(i);O={g[i]for g in G};ck(len(O)==16 and O<=S,'bad point orbit');S-=O
 ck(len(R)==3,'puncture orbit split')
 for r in R:
  t=A[:r]+A[r+1:];H=set(range(2048))-set(t)-{x^y^z for x,y,z in combinations(t,3)}
  ck(H=={A[r]}and max(abs(w)for w in fwt(set(t),2048)[1:])==17,'nonunique completion or wrong maximum')
  if do_opp:
   for e,args in [('opp1',[17]),('opp2',[17,2048,1])]:
    L=run([str(exe/e),*map(str,args)],input=' '.join(map(str,t)),text=True,check=True,capture_output=True).stdout.strip()
    ck((re.fullmatch(r'hit 0 nodes [0-9]+',L)if e=='opp1'else L=='0'),'unexcluded 17 across a puncture')
 S={(i,j)for i in range(48)for j in range(48)if i!=j};mass=Counter()
 while S:
  i,j=min(S);O={(g[i],g[j])for g in G};ck(O<=S,'not a pair orbit');S-=O;mass[len(O)]+=1
  t=[v^A[j]for l,v in enumerate(A)if l not in(i,j)];ck(rank(t)==11 and valid([0]+t,11),'bad rooted puncture');pairs={x^y:(1<<a)|(1<<b)for(a,x),(b,y)in combinations(enumerate(t),2)};V=set()
  for(a,x),(b,y),(c,z)in combinations(enumerate(t),3):
   if (x^y^z)in pairs:V.add(pairs[x^y^z]|(1<<a)|(1<<b)|(1<<c))
  ck(len(V)==756 and all(z.bit_count()==5 for z in V)and rank(V)==35,'weight-5 generators')
 ck(mass=={80:27,16:6},'wrong code orbit mass')
 print('Three puncture classes, all unique extensions, 33 ordered classes, 756 weight-five generators of rank 35 on every representative; opposite17 checked:',do_opp,flush=True)
