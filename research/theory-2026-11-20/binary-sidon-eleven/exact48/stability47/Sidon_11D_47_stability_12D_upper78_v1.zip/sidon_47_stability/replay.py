#!/usr/bin/env python3
import argparse,gzip,sys,re,subprocess,os
from itertools import combinations
from collections import Counter,defaultdict
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
from check_high import ck,rank,inputs,high,derived,lines,valid,fwt,ROOT
def cases():
 R=lines('d9.txt');ck(sha256((ROOT/'d9.txt').read_bytes()).hexdigest()=='07437663dfc421d915982716164cdfaa407c5de02c6dc319fe6fd539b269c534'and sha256((ROOT/'d10.txt').read_bytes()).hexdigest()=='a12772fa637227ee3b017cbe35edfab700d14c935ae34daafc531cb56dbc7d98','bad catalogue hash');ck(all(valid(c,9)for c in R),'bad 9D anchor');src={q:[c for c in R if len(c)==q]for q in range(20,24)};res={}
 for q,L in src.items():
  for i,c in enumerate(L):
   peak=max(map(abs,fwt(set(c),512)[1:]));b=31-q;mu=2*q-31
   for k in range(8,b+1):
    mv=mu if q+k==31 else 15;rd=q,k,i;res[rd]=(c,[b,k,16-k,mu,mv],peak,peak>mu-b%2)
 ck(len(res)==9200 and sum(v[-1]for v in res.values())==6831,'incomplete mathematical branch coverage');return res
def trace(s,legal,second):
 if s.startswith('analytic no U:'):
  ck(legal and re.fullmatch(r'analytic no U: \d+ > \d+\n?',s),'unexpected analytic screen');return 0,0,0
 v=s.splitlines();ck(len(v)>=1 and v[0]=='hit 0'and s.count('hit')==1,'invalid exhaustion')
 pat=r'\bpairs\s*(\d+) holes\s*(\d+) maxhole(\d+)\s*$';m=re.search(pat,s)
 if m:return tuple(map(int,m.groups()))
 if second:ck(re.fullmatch(r'\s*(\d+:\d+\s*)*',s[len('hit 0'):])is not None and (legal or re.search(r' (\d+):0\s*$',s)),'incomplete second endpoint')
 else:ck(s.strip().endswith(('empty first','empty second')),'incomplete first endpoint')
 return 0,0,0
def runprog(e,args,c):
 return subprocess.run([str(e),*map(str,args)],input=' '.join(map(str,c)),text=True,capture_output=True,check=True)
def analytic():
 c,=lines('columns79_66.txt');ck(len(c)==79 and rank(c)==13 and valid([0]+c,13),'invalid [79,66,>=5] positive witness')
 ck(2048*(3*47*47-94)-47**4-(81+1)*(2048*47-47**2)+81*2047==953856,'47 largest half cannot be at most 28')
 ck(2048*(3*46*46-92)-46**4-64*(2048*46-46**2)==2440944,'46 largest half cannot be at most 27')
 # Short independent lower bound for a 29-set in V10: count degree-two truth support after XOR centering.
 for h,t in [(1,0)]+[(0,t)for t in range(10)]:
  M=[238,-21,540,84,182]if h else[386-12*t,32*t-229,724-24*t,4,138+4*t];W=[-7,-3,1,5,9]
  ck([sum(v*w**k for v,w in zip(M,W))for k in range(5)]==[1023,1024*h-29,1024*29-29**2,1024*(85*h+6*t)-29**3,1024*(3*29**2-58)-29**4],'small-section moments')
  if min(M)>=0:ck((h,t)in [(0,8),(0,9)]and 1+sum(v for v,w in zip(M,W)if(w-29)%8==0)in[32,64],'zero-centered quadratic')
 # 79-point slab. t is the number of disjoint zero-sum triples, h whether centered origin belongs.
 P=lambda w:-(w+9)*(w-3)*(w-7)*(w-11)
 ck(all(P(w)>=0 for w in [-9,-5,-1,3,7,11]),'bad signed quartic')
 for h,t in [(1,0)]+[(0,k)for k in range(27)]:
  n=79;D=4096;mom=[D-1,D*h-n,D*n-n*n,D*((3*n-2)*h+6*t)-n**3,D*(3*n*n-2*n)-n**4];V=sum(v*m for v,m in zip([2079,-948,58,12,-1],mom));ck(V==(-8346624 if h else -16014336+294912*t)and V<0,'large-section moment slab')
 for p in ['packed79lowcheck.py','control.py']:subprocess.run([sys.executable,'-O',p],cwd=ROOT/'proof79',check=True)
 print('All 32 signed low-79 mode certificates and rank-three real controls passed.',flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['audit','full','low','high','derived'],default='audit');p.add_argument('--jobs',type=int,default=2);p.add_argument('--work',type=Path,default=ROOT/'WORK');a=p.parse_args();W=a.work.resolve();W.mkdir(exist_ok=True,parents=True);N=cases();A,D,P=inputs()
 bins=['first','second','chenaut','opp1','opp2']+(['highroot47','highpair']if a.stage in ['high','full']else[])
 for b in bins:subprocess.run(['c++','-O3','-std=c++17',*(['-DWIDTH=16']if b in ['highroot47','opp2']else[]),str(ROOT/'src'/f'{b}.cpp'),'-o',str(W/b)],check=True)
 T=lines('m31-ledger.tsv');M={tuple(v[:3]):tuple(v[3:])for v in T};ck(len(M)==len(T)==9200 and set(M)==set(N),'incomplete per-source ledger')
 rows=gzip.decompress((ROOT/'m31-traces.tsv.gz').read_bytes()).decode().splitlines();seen=set()
 for z in rows:
  q,k,i,e,raw=z.split('\t');key=int(q),int(k),int(i);mode=int(e);ck(mode in [1,2]and(key,mode)not in seen,'bad trace identity');seen.add((key,mode));x=raw.replace('  WHOLE  ','\n');c,par,peak,ban=N[key]
  if ban:ck(x.strip()==f'analytic no U: {peak} > {par[-2]-par[0]%2}','false short-circuit')
  ck(trace(x,ban,mode==2)==M[key],'incorrect archived endpoint')
 ck(len(seen)==18400,'missing independent trace')
 for q in range(20,24):
  for k in range(8,32-q):
   V=[d for key,d in M.items()if key[:2]==(q,k)];print('shape',q,31-q,k,16-k,'sources',len(V),'pairs',sum(z[0]for z in V),'large',sum(z[1]for z in V),'maxhole',max(z[2]for z in V),flush=True)
 analytic();t,=lines('plant47m31.txt');c=[x for x in t if x<512];ck(len(c)==20 and valid(t,11)and max(map(abs,fwt(set(t),2048)[1:]))==17,'bad 47 control')
 for b in ['first','second']:
  for h in [31,32]:
   z=runprog(W/b,[47,h,11,10,6,9,15],c);ll=z.stdout.splitlines();ck(ll[-1]==f'hit {int(h==32)}','plant response')
   if h==32:
    y=list(map(int,ll[0].split()));ck(len(ll)==2 and len(y)==47 and valid(y,11)and max(map(abs,fwt(set(y),2048)[1:]))==17,'planted false positive')
   else:ck(len(ll)==1,'plant false negative control')
 derived(W,a.jobs,True)
 if a.stage in ['high','full']:high(W,a.jobs)
 if a.stage in ['low','full']:
  def job(key):
   c,args,peak,ban=N[key]
   if ban:return
   for be,b in enumerate(['first','second']):
    z=runprog(W/b,[47,31,*args],c);ck(trace(z.stdout+z.stderr,False,be==1)==M[key],f'raw negative discrepancy {key}/{b}')
  with ThreadPoolExecutor(a.jobs)as ex:
   for i,_ in enumerate(ex.map(job,sorted(N)),1):
    if i%500==0:print('low sources',i,'/9200',flush=True)
 print('PASS',a.stage,flush=True)
if __name__=='__main__':main()
