#ifdef NDEBUG
#error "The replay requires assertions to be enabled."
#endif
#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include <utility>
#include <cmath>
using namespace std;using W=unsigned long long;
constexpr int D=512,B=6;
void inc(long long &v){assert(v<LLONG_MAX);++v;}
struct Bits{W w[B]={};
 void add(int i){w[i/64]|=W(1)<<(i%64);}void rem(int i){w[i/64]&=~(W(1)<<(i%64));}
 int first(int s=0)const{for(int i=s/64;i<B;i++)if(w[i])return i*64+__builtin_ctzll(w[i]);return -1;}
 int size()const{int c=0;for(auto a:w)c+=__builtin_popcountll(a);return c;}};
int id[D],v[D],n,need,sel[64],M,capmax,goal,m0;bool forbid[D];int Awt[D];vector<int> C;Bits adj[D];
struct Layer{array<uint16_t,12> s{};array<W,8>d{};};vector<Layer> cur;
long long nodes=0,fin=0,fit=0;
array<array<W,8>,D> signs;array<W,8> exactp[21]; W QMon[1024];
void prepmon(){for(int x=0;x<1024;x++){int i=0;W z=0;for(int a=0;a<10;a++){if(x>>a&1)z|=1ull<<i;i++;}for(int a=0;a<10;a++)for(int b=a+1;b<10;b++){if((x>>a&1)&&(x>>b&1))z|=1ull<<i;i++;}assert(i==55);QMon[x]=z;}}
bool selectedQuad;
bool qokay(const vector<int>&s,int a,int b){ // Only used if the first full layer is a maximal global slice and its opposite odd.
 int w[1024]={};for(int x:C)w[x]=1;for(int x:s)w[512+x]=1;
 for(int h=1;h<1024;h*=2)for(int i=0;i<1024;i+=2*h)for(int j=i;j<i+h;j++){int x=w[j],y=w[j+h];w[j]=x+y;w[j+h]=x-y;}
 W rows[55]={};int t=a+b,r=goal-t,hi=2*m0-goal;assert(r%2);
 for(int u=1;u<1024;u++){int U=hi-abs(w[u]);int f=-1;bool fixed=true;
  for(int v=-U;v<=U;v++)if((r-v)%4==0){int g=((r-v)/4)&1;if(f<0)f=g;else if(f!=g){fixed=false;break;}}
  if(f<0)return false;if(!fixed)continue;W z=QMon[u]|(W(f)<<55);
  while(z){int i=__builtin_ctzll(z);if(i==55)return false;if(rows[i])z^=rows[i];else{rows[i]=z;break;}}
 }return true;}
void emit(int k){
 inc(fin);int d=v[sel[1]];vector<int>s,t;for(int j=0;j<k;j++){s.push_back(v[sel[j]]);t.push_back(v[sel[j]]^d);}sort(s.begin(),s.end());sort(t.begin(),t.end());if(t<s)return;
 if(selectedQuad&&!qokay(s,C.size(),k))return;inc(fit);Layer u;for(int j=0;j<k;j++){u.s[j]=s[j];for(int i=0;i<j;i++){int x=s[i]^s[j];u.d[x/64]|=W(1)<<(x%64);}}cur.push_back(u);}
using Reg=array<array<W,8>,4>;
bool advance(const Reg&r,int x,int k,Reg&z){
 if(k>=need-3){ // w(u)=k-2*p(u), and |w_final|<=M-|Awt|.
  for(int j=0;j<8;j++){W a=r[0][j],b=r[1][j],c=r[2][j],d=r[3][j],h=signs[x][j];
   W k1=a&h,k2=b&k1,k3=c&k2;z[0][j]=a^h;z[1][j]=b^k1;z[2][j]=c^k2;z[3][j]=d^k3;
   a=z[0][j];b=z[1][j];c=z[2][j];d=z[3][j];
   for(int p=0;p<=k;p++){int ab=abs(k-2*p)-(need-k);if(ab<=0)continue;W bad=exactp[ab][j];if(!bad)continue;
    if(bad&(p&1?a:~a)&(p&2?b:~b)&(p&4?c:~c)&(p&8?d:~d))return false;}
  }
 }else for(int j=0;j<8;j++){W a=r[0][j],b=r[1][j],c=r[2][j],d=r[3][j],h=signs[x][j],k1=a&h,k2=b&k1;z[0][j]=a^h;z[1][j]=b^k1;z[2][j]=c^k2;z[3][j]=d^(c&k2);}
 return true;}
void dfs(Bits P,int k,const Reg&r){
 inc(nodes);if(k==need){emit(k);return;}int t=need-k;if(P.size()<t)return;
 int ls[B*64],cs[B*64],z=0,c=0;Bits av=P;
 while(av.first()>=0){c++;Bits Q=av;for(int x=Q.first();x>=0;x=Q.first(x)){ls[z]=x;cs[z++]=c;av.rem(x);Q.rem(x);for(int w=x/64;w<B;w++)Q.w[w]&=~adj[x].w[w];}}
 while(z){--z;if(cs[z]<t)return;int x=ls[z];P.rem(x);Reg rr;if(!advance(r,v[x],k+1,rr))continue;Bits Q;
  for(int j=0;j<B;j++)Q.w[j]=P.w[j]&adj[x].w[j];
  for(int i=0;i<k;i++)for(int j=0;j<i;j++){int h=id[v[x]^v[sel[i]]^v[sel[j]]];if(h>=0)Q.rem(h);}
  sel[k]=x;dfs(Q,k+1,rr);
 }}
vector<Layer> gen(int k,int limit,bool quad){
 selectedQuad=quad;need=k;M=limit;cur.clear();nodes=fin=fit=0;vector<Layer> em;
 for(int u=1;u<D;u++)if(abs(Awt[u])>M-k%2)return em;
 for(auto &e:exactp)e.fill(0);
 for(int u=1;u<D;u++)for(int v=1;v<=k;v++)if(abs(Awt[u])+v>M)exactp[v][u/64]|=W(1)<<(u%64);
 for(int i=0;i<n;i++){adj[i]={};for(int j=1;j<n;j++)if(!forbid[v[i]]&&!forbid[v[j]]&&!forbid[v[i]^v[j]])adj[i].add(j);}
 for(int d=1;d<n;d++){
  Bits P=adj[d];for(int h=1;h<=d;h++)P.rem(h);Reg zero{},start;sel[0]=0;sel[1]=d;
  if(P.size()>=k-2 && advance(zero,v[d],2,start))dfs(P,2,start);
  for(int i=d+1;i<n;i++){int j=id[v[i]^v[d]];if(j>d)adj[i].rem(j);}
 }
 fprintf(stderr," k%d/M%d nodes%lld leaf%lld classes%zu;",k,limit,nodes,fin,cur.size());return move(cur);}
vector<int> fourth;long long edges=0,holes=0;int smallmax=0;
vector<int> bas48; // three retained layers; record fourth independently
bool candidate48(){int w[2048]={};for(int x:bas48){assert(!w[x]);w[x]=1;}for(int y:fourth){int x=y+1536;assert(!w[x]);w[x]=1;}
 for(int h=1;h<2048;h*=2)for(int i=0;i<2048;i+=2*h)for(int j=i;j<i+h;j++){int x=w[j],y=w[j+h];w[j]=x+y;w[j+h]=x-y;}assert(w[0]==goal);for(int i=1;i<2048;i++)if(abs(w[i])>2*m0-goal)return false;return true;}
void rootlayers(const Layer& u,const Layer& v,int b,int c){bas48=C;for(int i=0;i<b;i++)bas48.push_back(512+u.s[i]);for(int i=0;i<c;i++)bas48.push_back(1024+v.s[i]);}
bool choose(vector<int>v,int need,array<W,8> F){if(need==0)return candidate48();
 while((int)v.size()>=need){int x=v.back();v.pop_back();array<W,8> g=F;bool ok=true;for(int y:fourth){int z=x^y;if((F[z/64]>>(z%64))&1){ok=false;break;}g[z/64]|=W(1)<<(z%64);}
  if(!ok)continue;vector<int>w;for(int y:v){bool ok=true;for(int z:fourth){int r=y^z;if(g[r/64]>>(r%64)&1){ok=false;break;}}int r=y^x;if(ok&&!(g[r/64]>>(r%64)&1))w.push_back(y);}
  fourth.push_back(x);if(choose(w,need-1,g))return true;fourth.pop_back();
 }return false;}
bool combine(int b,int c,int d,int Mb,int Mc){
 auto U=gen(b,Mb,false);if(U.empty()){cerr<<" empty first\n";return false;}
 // For the large secondary search in the exceptional 20,11,9,9 shape, enumerate relative to each U directly.
 if((C.size()==20&&b==11&&c==9)||(C.size()==21&&b==10&&c==9&&U.size()<=32)){
  bool saved[D];copy(forbid,forbid+D,saved);
  for(int i=0;i<U.size();i++){
   copy(saved,saved+D,forbid);for(int k=0;k<8;k++)for(W q=U[i].d[k];q;q&=q-1)forbid[64*k+__builtin_ctzll(q)]=true;
   // Restrict both vertices and edges to the stronger allowed-difference set. Keep original priority/id order.
   auto V=gen(c,Mc,false); // gen() masks all now-forbidden vertices in its root, see below.
   bool base[D]={};for(int x:C)for(int j=0;j<b;j++)base[x^U[i].s[j]]=true;
   for(auto&v:V){inc(edges);vector<int>H;for(int x=0;x<D;x++){bool ok=true;for(int k=0;k<c;k++)if(base[x^v.s[k]]){ok=false;break;}if(ok)H.push_back(x);}
    int sz=H.size();smallmax=max(smallmax,sz);if(sz<d)continue;inc(holes);array<W,8> f=v.d;for(int x=0;x<D;x++)if(forbid[x])f[x/64]|=W(1)<<(x%64);
    rootlayers(U[i],v,b,c);fourth.clear();if(choose(H,d,f)){for(int x:C)cout<<x<<' ';for(int k=0;k<b;k++)cout<<512+U[i].s[k]<<' ';for(int k=0;k<c;k++)cout<<1024+v.s[k]<<' ';for(int x:fourth)cout<<1536+x<<' ';cout<<endl;return true;}
   }
  }
  copy(saved,saved+D,forbid);cerr<<" pairs"<<edges<<" holes"<<holes<<" maxhole"<<smallmax<<"\n";return false;
 }
 vector<Layer> Vsep;const bool same=b==c&&Mb==Mc;if(!same)Vsep=gen(c,Mc,false);auto&V=same?U:Vsep;if(V.empty()){cerr<<" empty second\n";return false;}
 int nw=(V.size()+63)/64;vector<vector<W>> bad(D,vector<W>(nw));for(int j=0;j<V.size();j++)for(int z=0;z<8;z++)for(W mask=V[j].d[z];mask;mask&=mask-1)bad[64*z+__builtin_ctzll(mask)][j/64]|=W(1)<<(j%64);
 array<W,8> F{};for(int x=0;x<D;x++)if(forbid[x])F[x/64]|=W(1)<<(x%64);
 for(int i=0;i<U.size();i++){
  vector<W>pot(nw,~W(0));if(V.size()%64)pot.back()=(W(1)<<(V.size()%64))-1;
  if(same){for(int j=0;j<i/64;j++)pot[j]=0;pot[i/64]&=~W(0)<<(i%64);}
  for(int z=0;z<8;z++)for(W m=U[i].d[z];m;m&=m-1){auto& y=bad[64*z+__builtin_ctzll(m)];for(int j=0;j<nw;j++)pot[j]&=~y[j];}
  array<array<W,8>,512> block;bool seen[D]={};for(int x:C)for(int k=0;k<b;k++)seen[x^U[i].s[k]]=true;
  array<W,8> base{};for(int x=0;x<D;x++)if(seen[x])base[x/64]|=W(1)<<(x%64);
  for(int j=0;j<D;j++)for(int k=0;k<8;k++){W w=base[k^(j/64)];int z=j&63;
   if(z&1)w=((w&0x5555555555555555ull)<<1)|((w>>1)&0x5555555555555555ull);
   if(z&2)w=((w&0x3333333333333333ull)<<2)|((w>>2)&0x3333333333333333ull);
   if(z&4)w=((w&0x0f0f0f0f0f0f0f0full)<<4)|((w>>4)&0x0f0f0f0f0f0f0f0full);
   if(z&8)w=((w&0x00ff00ff00ff00ffull)<<8)|((w>>8)&0x00ff00ff00ff00ffull);
   if(z&16)w=((w&0x0000ffff0000ffffull)<<16)|((w>>16)&0x0000ffff0000ffffull);
   if(z&32)w=(w<<32)|(w>>32);block[j][k]=w;}
  for(int j=0;j<nw;j++)for(W mask=pot[j];mask;mask&=mask-1){inc(edges);int l=64*j+__builtin_ctzll(mask);array<W,8> H;H.fill(~W(0));for(int k=0;k<c;k++)for(int z=0;z<8;z++)H[z]&=~block[V[l].s[k]][z];
   int nh=0;for(W v:H)nh+=__builtin_popcountll(v);smallmax=max(smallmax,nh);if(nh<d)continue;inc(holes);vector<int>vv;for(int k=0;k<8;k++)for(W m=H[k];m;m&=m-1)vv.push_back(64*k+__builtin_ctzll(m));
   array<W,8> f=F;for(int z=0;z<8;z++)f[z]|=U[i].d[z]|V[l].d[z];rootlayers(U[i],V[l],b,c);fourth.clear();
   if(choose(vv,d,f)){for(int x:C)cout<<x<<' ';for(int k=0;k<b;k++)cout<<512+U[i].s[k]<<' ';for(int k=0;k<c;k++)cout<<1024+V[l].s[k]<<' ';for(int x:fourth)cout<<1536+x<<' ';cout<<endl;return true;}
  }
 }cerr<<" pairs"<<edges<<" holes"<<holes<<" maxhole"<<smallmax<<"\n";return false;}
int main(int ac,char**av){assert(ac==8);goal=atoi(av[1]);m0=atoi(av[2]);int b=atoi(av[3]),c=atoi(av[4]),d=atoi(av[5]),Mb=atoi(av[6]),Mc=atoi(av[7]);prepmon();
 for(int x=0;x<D;x++)for(int u=1;u<D;u++)if(__builtin_parity(x&u))signs[x][u/64]|=W(1)<<(u%64);
 string l;while(getline(cin,l)){C.clear();int x;istringstream in(l);while(in>>x)C.push_back(x);assert(C.size()+b+c+d==goal);
 fill(begin(forbid),end(forbid),false);fill(begin(id),end(id),-1);
 for(int x:C)for(int y:C)forbid[x^y]=true;vector<pair<int,int>>V;
 for(int x=1;x<D;x++)if(!forbid[x]){int z=0;for(int y=1;y<D;y++)if(!forbid[y]&&!forbid[x^y])z++;V.emplace_back(-z,x);}
 sort(V.begin(),V.end());n=1;v[0]=0;id[0]=0;for(auto [dg,x]:V){v[n]=x;id[x]=n++;}assert(n<=B*64);
 for(int u=0;u<D;u++){int z=0;for(int x:C)z+=__builtin_parity(x&u)?-1:1;Awt[u]=z;}
 edges=holes=0;smallmax=0;bool res=combine(b,c,d,Mb,Mc);cout<<"hit "<<res<<endl;if(res)break;}}
