#include <vector>
#include <set>
#include <cstdlib>
#include <array>
#include <algorithm>
#include <iostream>
#include <cassert>
#include <sstream>
using namespace std;
using U=unsigned long long;
U mix(U x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
void wt(vector<U>&a){for(int h=1;h<a.size();h*=2)for(int i=0;i<a.size();i+=2*h)for(int j=i;j<i+h;j++){U x=a[j],y=a[j+h];a[j]=x+y;a[j+h]=x-y;}}
int E;
struct Root{
 vector<int>S;vector<U>c;vector<bool>in;
 Root(const vector<int>&v,int p):in(E){
  for(int x:v){in[x^p]=true;S.push_back(x^p);}
  vector<U>r(E),l(S.size(),1),a(E);
  for(int tt=0;tt<3;tt++){
   fill(a.begin(),a.end(),0);for(int i=0;i<S.size();i++)a[S[i]]=mix(l[i]);wt(a);
   for(int u=0;u<E;u++)r[u]=mix(r[u])*a[u]+mix(r[u])+mix(a[u]);
   for(int u=0;u<E;u++)a[u]=mix(r[u]);wt(a);
   for(int i=0;i<S.size();i++){U b=a[S[i]];l[i]=mix(l[i])*b+mix(b)+mix(l[i]);}
  }
  c=a;
 }
};
struct Hom{
 vector<int>P,Q;vector<bool>usedP,usedQ;Root&A,&B;
 Hom(Root&a,Root&b):P(E),Q(E),usedP(E),usedQ(E),A(a),B(b){usedP[0]=usedQ[0]=true;}
 long long solve(int r){
  if(r==E)return 1;
  int bx=-1;vector<int>opt;
  for(int x:A.S)if(!usedP[x]){vector<int>vy;for(int y:B.S)if(!usedQ[y]&&A.c[x]==B.c[y]){
    bool ok=true;for(int j=0;j<r;j++)if(A.in[x^P[j]]!=B.in[y^Q[j]]||A.c[x^P[j]]!=B.c[y^Q[j]]){ok=false;break;}
    if(ok)vy.push_back(y);}
   if(vy.empty())return 0;if(bx<0||vy.size()<opt.size()){bx=x;opt=vy;if(opt.size()==1)break;}}
  assert(bx>=0);
  for(int i=0;i<r;i++){P[r+i]=P[i]^bx;usedP[P[r+i]]=true;}
  long long out=0;for(int y:opt){for(int i=0;i<r;i++){Q[r+i]=Q[i]^y;usedQ[Q[r+i]]=true;}out+=solve(2*r);
    for(int i=r;i<2*r;i++)usedQ[Q[i]]=false;}
  for(int i=r;i<2*r;i++)usedP[P[i]]=false;return out;
 }
};
int main(int ac,char**av){assert(ac==2);E=1<<atoi(av[1]);set<vector<U>>seen;string line;
 while(getline(cin,line)){vector<int>s;istringstream ist(line);int x;while(ist>>x)s.push_back(x);assert(!s.empty());
 Root a(s,s[0]);long long g=0;vector<U>certificate;
 for(int y:s){Root b(s,y);if(a.c[0]==b.c[0]){Hom h(a,b);g+=h.solve(1);}
  auto co=b.c;sort(co.begin(),co.end());vector<U>loc;for(int t:b.S)loc.push_back(b.c[t]);sort(loc.begin(),loc.end());
  U z=0xf123456789ULL;for(U v:co)z=z*199+mix(v);loc.push_back(z);U k=0xabbaabbaULL;for(U v:loc)k=191*k+mix(v);certificate.push_back(k);}
 sort(certificate.begin(),certificate.end());assert(seen.insert(certificate).second&&"affine inequivalence not certified");
 assert(g>0);cout<<g<<endl;}
}