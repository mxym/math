from itertools import combinations
from functools import reduce
def search(A,need,sidon=True):
 # A subset of F2^10. Begin B with 0, by translation in B's layer.
 F={a^b for a,b in combinations(A,2)}|{0}
 U=[x for x in range(1,1024) if x not in F]
 # indexing directly by group element ensures no relabeling ambiguity.
 N=[0]*1024
 for x in U:
  N[x]=sum(1<<y for y in U if x^y not in F)
 nodes=0
 def rec(P,B):
  nonlocal nodes
  nodes+=1;t=need-len(B)
  if t<=0:return B
  if P.bit_count()<t:return
  # Extract t-1 independent sets; their union cannot contain a t-clique. Branch on every remaining vertex.
  free=P
  for _ in range(t-1):
   if not free:return
   stable=free
   while stable:
    bit=stable&-stable; v=bit.bit_length()-1;free^=bit;stable^=bit;stable&=~N[v]
  while free:
   bit=1<<(free.bit_length()-1);x=bit.bit_length()-1;free^=bit;P^=bit
   Q=P&N[x]
   if sidon:
    for a,b in combinations(B,2): Q&=~(1<<(a^b^x))
   hit=rec(Q,B+(x,))
   if hit:return hit
  return
 r=rec(sum(1<<v for v in U),(0,));return r,nodes
