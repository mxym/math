#!/bin/sh
set -eu
cd "$(dirname "$0")"
export LC_ALL=C
CXX=${CXX:-c++}
"$CXX" -O3 -std=c++17 group.cpp -o group
"$CXX" -O3 -std=c++17 -DWIDTH=6 count.cpp -o localcount
"$CXX" -O3 -std=c++17 -DWIDTH=9 count.cpp -o finalcount
python3 -u replay.py
