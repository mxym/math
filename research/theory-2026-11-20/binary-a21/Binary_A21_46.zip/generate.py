"""Enumerate each isometry class of up to four even binary words of length 21, min dist 10.
Encoding: the first word is translated to zero; columns with equal bit pattern are permutable.
No non-standard packages or auxiliary data.
"""
from itertools import combinations,permutations
from hashlib import sha256
n=21
R=[(0,)]+[(0,2**a-1) for a in range(10,21,2)]
for a in range(10,21,2):
 for b in range(a,21,2):
  for c in range(b,21,2):
   if a+b+c>2*n:continue
   j=(a+b-c)//2
   R.append((0,2**a-1,2**j-1|((2**(b-j)-1)<<a)))
perms=[]
for p in permutations(range(4)):
 def go(i):
  t=(0,i//4,i//2%2,i%2)
  return (4*(t[p[1]]^t[p[0]])+2*(t[p[2]]^t[p[0]])+(t[p[3]]^t[p[0]]))
 perms.append(tuple(go(i) for i in range(8)))
quads=set()
for a0,a1,a2,a3,a4,a5,a6 in combinations(range(n+7),7):
 v=(a0,a1-a0-1,a2-a1-1,a3-a2-1,a4-a3-1,a5-a4-1,a6-a5-1,n+6-a6)
 a,b,c,e,f,g,h,j=v
 dist=(f+g+h+j,c+e+h+j,b+e+g+j,c+e+f+g,b+e+f+h,b+c+g+h)
 if min(dist)<10 or any(u%2 for u in dist):continue
 quads.add(min(tuple(v[i] for i in p) for p in perms))
assert len(quads)==455
for profile in sorted(quads):
 w=[0]*4;s=0
 for i,a in enumerate(profile):
  block=(2**a-1)<<s;s+=a
  for k in range(3):
   if (i>>k)&1:w[k+1]|=block
 R.append(w)
assert len(R)==484
for W in R:
 assert len(W)==len(set(W)) and all((a^b).bit_count()>=10 and (a^b).bit_count()%2==0 for a,b in combinations(W,2))
with open('orbits.txt','w') as f:
 for W in R:print(len(W),*W,file=f)
print('orbit sizes by cardinality:',[sum(len(W)==k for W in R) for k in range(1,5)])
