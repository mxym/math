#!/bin/sh
set -eu
python3 positive.py
python3 generate.py
out=$(mktemp -d); trap 'rm -f "$out/verify"; rmdir "$out"' EXIT
c++ -std=c++17 -O2 verify.cpp -lgmpxx -lgmp -o "$out/verify"
"$out/verify"
python3 independent.py
