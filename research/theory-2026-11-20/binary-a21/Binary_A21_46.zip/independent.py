"""Independent pure-Python audit. Different orbit enumeration, kernel recurrence and
Fourier sum, no external packages/compiler. Run with assertions enabled.
"""
from math import comb,lcm
from itertools import permutations,product,combinations,combinations_with_replacement
from functools import cache
from collections import defaultdict,Counter
import json
n=21;M=47;D=tuple(range(10,21,2));Mask=(1<<n)-1
ct=json.load(open('certificate.json'));U=1<<ct['ep'];V=1<<ct['wp'];L=lcm(*(comb(n,r) for r in range(n+1)));Q=U*U*L;mu=list(map(int,ct['eq']));assert all(int(c['weight'])>=0 for c in ct['cuts'])
def dist(w):
 return tuple(sorted((a^b).bit_count() for a,b in combinations(w,2)))
def signature(w): # six labelled pair distances up to all permutations, plus xor weight; complete binary four-row isometry invariant
 ds=tuple(sorted([]))
 def tw(p):return tuple((p[i]^p[j]).bit_count() for i,j in combinations(range(4),2))
 return (min(map(tw,permutations(w))), (w[0]^w[1]^w[2]^w[3]).bit_count())
def orbits():
 R=[(0,)]+[(0,(1<<d)-1) for d in D]
 for a,b,c in combinations_with_replacement(D,3):
  if a+b+c<=2*n:
   q=(a+b-c)//2;R.append((0,(1<<a)-1,((1<<q)-1)|(((1<<(b-q))-1)<<a)))
 W={}
 for ra,rb,rc,ab,ac,bc in product(D,repeat=6):
  # exploit a necessary ordering under permutations of the last three labels
  if not ra<=rb<=rc:continue
  p=(ra+rb-ab)//2;q=(ra+rc-ac)//2;r=(rb+rc-bc)//2
  for t in range(max(0,p+q-ra,p+r-rb,q+r-rc),min(p,q,r,n-ra-rb-rc+p+q+r)+1):
   atoms=(n-ra-rb-rc+p+q+r-t,rc-q-r+t,rb-p-r+t,r-t,ra-p-q+t,q-t,p-t,t)
   assert min(atoms)>=0 and sum(atoms)==n
   s=0;x=y=z=0
   for i,v in enumerate(atoms):
    mask=((1<<v)-1)<<s;s+=v
    x|=mask*bool(i&4);y|=mask*bool(i&2);z|=mask*bool(i&1)
   a=(0,x,y,z);W.setdefault(signature(a),a)
 assert len(W)==455;return R+list(W.values())
B=defaultdict(lambda:defaultdict(int));ki=[];lc=0
for c in ct['cuts']:
 lam=int(c['weight'])
 if c['tag']=='lin':assert c['r']==1;lc+=lam
 elif c['tag']=='int':ki.append((c['r'],tuple(c['typ']),c['a'],lam))
 else:
  a={tuple(v[:2]):int(v[2]) for v in c['w']}
  b=B[c['kind'],c['r'],c['h'],c['g']]
  for t,wt in a.items():
   for v,wv in a.items():b[t,v]+=lam*wt*wv
def blockvalid():
 for (kind,r,h,g),b in B.items():
  for a,y in b:
   for i,j in (a,y):
    assert (i,j)==(-1,-1) and h==g==0 and kind=='P' or h<=i<=r-h and g<=j<=n-r-g
blockvalid()
@cache
def hkernel(deg,n00,n01,n10,n11):
 if deg==0:return 1
 val=0
 if n00*n11:val+=n00*n11*hkernel(deg-1,n00-1,n01,n10,n11-1)
 if n01*n10:val-=n01*n10*hkernel(deg-1,n00,n01-1,n10-1,n11)
 return val
@cache
def kpair(kind,r,s,u,atoms):
 v=0;w=atoms
 for (family,m,h,g),tt in B.items():
  if (family,m)!=(kind,r) or (s,u) not in tt:continue
  v+=tt[s,u]*hkernel(h,*w[:4])*hkernel(g,*w[4:])
 return v
def pflags(W):
 allsum=0
 for a,b in permutations(W,2):
  mask=a^b;r=mask.bit_count();other=[t for t in W if t not in (a,b)]
  for (sr,typ,theta,lam) in ki:
   if r!=sr:continue
   # Inclusion-exclusion over the outside-support set extracts the polynomial coefficient for this orbit.
   for k in range(len(other)+1):
    for sel in combinations(other,k):
     N=sum((((t^a)&mask).bit_count(),((t^a)&~mask).bit_count())==typ for t in sel)
     allsum-=lam*Q*(-1)**(len(other)-k)*(N-theta)*(N-theta-1)
  for u,v in product([None]+other,repeat=2):
   if set(z for z in (u,v) if z is not None)!=set(other):continue
   def S(z):return (-1,-1) if z is None else (((z^a)&mask).bit_count(),((z^a)&~mask).bit_count())
   x=0 if u is None else u^a;y=0 if v is None else v^a
   bins=tuple((region&f&g).bit_count() for region in (mask,Mask^mask) for f in (Mask^x,x) for g in (Mask^y,y))
   allsum-=L*kpair('P',r,S(u),S(v),bins)
 return allsum
@cache
def fourier_pattern(quad):
 # Coefficient extraction of product over coordinates (1+sign*t_ij), not Krawtchouk transform.
 shift=tuple(1<<(5*j) for j in range(4)); F={0:1}
 for label,num in enumerate(quad):
  for _ in range(num):
   ofs=shift[label//2];sgn=1-2*(label%2);G=F.copy()
   for t,c in F.items():G[t+ofs]=G.get(t+ofs,0)+sgn*c
   F=G
 tots=[quad[2*j]+quad[2*j+1] for j in range(4)];sm=0
 for code,c in F.items():
  if not c:continue
  S=tuple((code>>(5*j))&31 for j in range(4));r=sum(S)
  if r>10:continue
  s=(S[2]+S[3],tots[2]+tots[3]-S[2]-S[3]);u=(S[1]+S[3],tots[1]+tots[3]-S[1]-S[3])
  if s[0]%2 or u[0]%2:continue
  other=tuple(x-y for x,y in zip(tots,S))
  sm+=c*(L//comb(n,r))*kpair('E',r,s,u,S+other)
 return sm
def eflags(W):
 h=Counter()
 for A,B,C,D in product(W,repeat=4):
  if len({A,B,C,D})!=len(W):continue
  a,b,c=A^B,C^D,A^C
  bins=tuple((u&v&w).bit_count() for u in (Mask^a,a) for v in (Mask^b,b) for w in (Mask^c,c));h[bins]+=1
 return -sum(m*fourier_pattern(k) for k,m in h.items())
def main():
 R=orbits();lv={dist(W):j+1 for j,W in enumerate(R[:29])};tot=[];rhs=(lc*23+mu[0]*M)*Q
 for W in R:
  t=dist(W);k=len(W);scalar=eflags(W)+pflags(W)
  if k==1:scalar+=mu[0]*Q
  if k==2:scalar-=lc*(n-2*t[0])*(Q//n)
  if k<4:scalar+=(k-M)*mu[lv[t]]*Q
  if k>1:
   for V0 in combinations(W,k-1):scalar+=mu[lv[dist(V0)]]*Q
  tot.append((k,scalar))
 floor=0
 for k in range(1,5):
  a=min(v for t,v in tot if t==k);floor+=comb(M,k)*a;print(k,a,flush=True)
 print('gap',floor-rhs,'denominator',V*Q);assert floor>rhs
if __name__=='__main__':main()
