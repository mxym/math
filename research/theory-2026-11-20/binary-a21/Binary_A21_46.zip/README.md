# An exact four-point certificate for A₂(21,10) ≤ 46

**Claim.** An unrestricted binary length-21 code of minimum distance 10 has at most 46 words. Equivalently A₂(20,9)≤46. The known lower bound is 42, with an explicit independently checkable witness in this archive. Existence at each of sizes 43 through 46 is not settled here. Private research memorandum, 20 November 2026. See note.pdf (editable source: note.tex) for mathematical definitions and primary references.

## Verify

Unpack the archive into a writable directory and run `sh replay.sh` there. Requires Python 3 (tested with 3.12), a C++17 compiler named c++, and GMP C/C++ development headers and libraries. No numerical or SDP software is needed. To use only the standard library, run `python3 positive.py` and `python3 independent.py`: that path implements the full bound, not merely a reduced instance.

* positive.py: constructs and directly checks a 42-word code.
* generate.py: enumerates all orbit representatives using coordinate patterns; outputs orbits.txt.
* verify.cpp + coeffs.txt: evaluates the entire certificate using exact GMP integers.
* independent.py + certificate.json: separate orbit enumeration from pair distances and parity, separate evaluations of the harmonic and Fourier kernels, and Python big-integer arithmetic.
* expected.log: expected integer output for the two main checkers; there are four orbit-size minima, each agreeing exactly.
* SHA256SUMS: checksums of the numerical certificates, both verifiers, the memorandum and the support files. Run `sha256sum -c SHA256SUMS` before replay.

The two verifiers independently derive the same strictly positive integer numerator (approximately 3.4568×10⁻⁶ after dividing by the common positive denominator). This is a certificate of impossibility of 47 (and hence all larger sizes), not a decimal optimization estimate.
