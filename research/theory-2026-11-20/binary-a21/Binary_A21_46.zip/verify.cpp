// Integer-only verifier for the 47-word exclusion. Build with g++ -std=c++17 -O2 verify.cpp -lgmpxx -lgmp.
// Coordinates and orbits are developed in generate.py. No optimization software is used.
#include <bits/stdc++.h>
#include <gmpxx.h>
using namespace std;using Z=mpz_class;using V=vector<int>;using W4=array<int,4>;using Key=array<int,4>;using Cell=pair<int,int>;
constexpr int N=21,M=47; constexpr int full=(1<<N)-1;
int cb[22][22];long fact[22][11];Z L=1,dy,Wden;int ncut;
int bc(int x){return __builtin_popcount((unsigned)x);}
long K(int n,int x,int a){long v=0;for(int j=0;j<=a;j++)v+=(j%2?-1:1)*cb[x][j]*cb[n-x][a-j];return v;}
// Signed pair-of-coordinates harmonic inner product, divided by the positive factor 2^h.
long ker(int n,int h,int i,int j,int d){
 if(i<0 || j<0)return h==0?1:0;
 int t=(i+j-d)/2;assert((i+j-d)%2==0 && min({t,i-t,j-t,n-i-j+t})>=0);
 static_assert(sizeof(long)>=8); __int128 v=0;
 for(int l=0;l<=h;l++) v+=( (__int128)((h-l)%2?-1:1))*cb[h][l]*fact[t][l]*fact[n-i-j+t][l]*fact[i-t][h-l]*fact[j-t][h-l]; assert(v>=LONG_MIN&&v<=LONG_MAX);return (long)v;
}
struct Block{int h,g;map<pair<Cell,Cell>,Z> U;};
map<Key,Block> B;map<pair<int,int>,vector<Block*>> by;map<array<int,5>,Z> Ic;
Z single;vector<Z> mu;vector<V> R;
int id(int i,int j){return i<0?255:(i<<5)+j;}
map<array<int,8>,Z> cache;
Z qform(int kind,int r,int i,int j,int x,int y,int di,int dj){
 array<int,8> key={kind,r,i,j,x,y,di,dj};auto it=cache.find(key);if(it!=cache.end())return it->second;
 Z s=0;for(auto b:by[{kind,r}]){
  auto u=b->U.find({{i,j},{x,y}});if(u==b->U.end())continue;
  long a=ker(r,b->h,i,x,di),c=ker(N-r,b->g,j,y,dj);
  if(a&&c)s+=u->second*a*c;
 }
 return cache[key]=s;
}
void readin(){
 ifstream in("coeffs.txt");assert(in);int e,p,q;in>>e>>p>>q>>ncut;assert(e==80&&p==95&&q==30&&ncut>0);dy=Z(1)<<(2*e);Wden=Z(1)<<p;
 for(int i=0;i<q;i++){Z a;in>>a;mu.push_back(a);}
 int pos=0;
 for(int z=0;z<ncut;z++){
  char c;in>>c;int r,h,g;Z wt;in>>r;assert(r>=0&&r<=N);
  if(c=='L'){in>>wt;assert(r==1&&wt>=0);single+=wt;continue;}
  if(c=='I'){int i,j,t;in>>i>>j>>t>>wt;assert(wt>=0);Ic[{r,i,j,t,0}]+=wt;continue;}
  int nw;in>>h>>g>>wt>>nw;assert(wt>=0&&(c=='E'||c=='P'));int kind=c=='E'?0:1;
  map<Cell,Z>a;
  for(int z=0;z<nw;z++){
   int i,j;Z w;in>>i>>j>>w;assert((kind==1&&h==0&&g==0&&i==-1&&j==-1)||(i>=h&&j>=g&&r-i>=h&&N-r-j>=g));a[{i,j}]=w;
  }
  auto &b=B[{kind,r,h,g}];b.h=h;b.g=g;for(auto &s:a)for(auto&t:a)b.U[{s.first,t.first}]+=wt*s.second*t.second;
 }
 string rest;assert(!(in>>rest));for(auto &[k,b]:B)by[{k[0],k[1]}].push_back(&b);
 ifstream o("orbits.txt");int n;while(o>>n){V s(n);for(int&v:s)o>>v;R.push_back(s);}assert(R.size()==484);
}
V key(const V&w){V a;for(int i=0;i<(int)w.size();i++)for(int j=0;j<i;j++)a.push_back(bc(w[i]^w[j]));sort(a.begin(),a.end());return a;}
Z local(const V&w){
 Z sum=0;for(int a:w)for(int b:w)if(a!=b){
  int D=a^b,r=bc(D);V ext;for(int z:w)if(z!=a&&z!=b)ext.push_back(z^a);
  vector<pair<int,int>>pairs;
  if(ext.empty())pairs={{-1,-1}};
  if(ext.size()==1)pairs={{-1,ext[0]},{ext[0],-1},{ext[0],ext[0]}};
  if(ext.size()==2)pairs={{ext[0],ext[1]},{ext[1],ext[0]}};
  for(auto [u,v]:pairs){
   int i=-1,j=-1,x=-1,y=-1,di=0,dj=0;
   if(u>=0){i=bc(u&D);j=bc(u&~D);}if(v>=0){x=bc(v&D);y=bc(v&~D);}
   if(u>=0&&v>=0){di=bc((u^v)&D);dj=bc((u^v)&~D);}
   sum-=qform(1,r,i,j,x,y,di,dj)*L;
  }
  for(auto &[k,wt]:Ic)if(k[0]==r){
   int t=k[3],c=0;for(int v:ext)if(bc(v&D)==k[1]&&bc(v&~D)==k[2])c++;
   int coeff=ext.empty() ? -t*(t+1) : ext.size()==1 ? ((c==1)?2*t:0) : ((c==2)?-2:0);
   sum+=wt*coeff*dy*L;
  }
 }
 return sum;
}
Z freeq(const V&w){
 int sz=w.size();map<array<int,8>,int> hist;
 for(int a=0;a<sz;a++)for(int b=0;b<sz;b++)for(int c=0;c<sz;c++)for(int d=0;d<sz;d++){
  if(((1<<a)|(1<<b)|(1<<c)|(1<<d))!=(1<<sz)-1)continue;
  int U=w[a]^w[b],V=w[c]^w[d],F=w[a]^w[c];array<int,8> v{};
  for(int j=0;j<N;j++)v[4*((U>>j)&1)+2*((V>>j)&1)+((F>>j)&1)]++;
  hist[v]++;
 }
 Z sum=0;for(auto &[v,occ]:hist){
  int p[4],coef[4][22];
  for(int i=0;i<4;i++){p[i]=v[2*i]+v[2*i+1];for(int j=0;j<=p[i];j++)coef[i][j]=K(p[i],v[2*i+1],j);}
  int d1=p[2]+p[3],d2=p[1]+p[3],dist=p[1]+p[2];
  for(int a=0;a<=p[0];a++)for(int b=0;b<=p[1];b++)for(int c=0;c<=p[2];c++)for(int d=0;d<=p[3];d++){
   int r=a+b+c+d,di=b+c,i=c+d,x=b+d;if(!by.count({0,r}) || ((i|x)&1))continue;
   long m=1LL*coef[0][a]*coef[1][b]*coef[2][c]*coef[3][d];if(!m)continue;
   sum-=(L/cb[N][r])*occ*m*qform(0,r,i,d1-i,x,d2-x,di,dist-di);
  }
 }
 return sum;
}
int main(){
 for(int n=0;n<=N;n++){cb[n][0]=1;fact[n][0]=1;for(int j=1;j<=n;j++){cb[n][j]=(n==j)?1:cb[n-1][j-1]+cb[n-1][j];if(j<=10)fact[n][j]=fact[n][j-1]*(n-j+1);}}
 for(int r=0;r<=N;r++)L=L*cb[N][r]/gcd(L,Z(cb[N][r]));
 readin();vector<Z> Q;Z rhs=(23*single+M*mu[0])*dy*L;
 for(auto&w:R){
  int l=w.size();Z v=freeq(w)+local(w);
  if(l==1)v+=mu[0]*dy*L;
  if(l==2)v-=single*K(N,bc(w[0]^w[1]),1)*(L/N)*dy;
  for(int i=0;i<29;i++){
   auto &U=R[i];int k=U.size(),cnt=0;
   if(l==k && key(w)==key(U))cnt=k-M;
   if(l==k+1){for(int j=0;j<l;j++){auto W=w;W.erase(W.begin()+j);if(key(W)==key(U))cnt++;}}
   v+=mu[i+1]*cnt*dy*L;
  }
  Q.push_back(v);
 }
 Z lb=0;int c=1;for(int k=1;k<=4;k++){
  c=c*(M-k+1)/k;bool init=false;Z lo=0;for(int i=0;i<(int)R.size();i++)if((int)R[i].size()==k&&(!init||Q[i]<lo)){lo=Q[i];init=true;}
  lb+=c*lo;cout<<"k="<<k<<" number="<<c<<" min-num="<<lo<<"\n";
 }
 Z gap=lb-rhs;cout<<"RHS numerator: "<<rhs<<"\nlower-bound numerator: "<<lb<<"\nstrict gap numerator: "<<gap<<"\ncommon denominator: "<<Wden*dy*L<<endl;
 if(gap<=0){cerr<<"NOT CERTIFIED\n";return 1;}cout<<"PROVED: no even (21,47,10) code.\n";
}
