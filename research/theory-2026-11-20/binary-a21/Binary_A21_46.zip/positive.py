"""A 42-word positive control, given by a quasi-cyclic construction in 20 bits."""
from itertools import combinations
def code():
 mask=(1<<20)-1;words=[0,349525]
 for seed in [90703,81831,43483,38459]:
  a=seed
  for k in range(10):
   words.append(a);a=((a<<2)&mask)|(a>>18)
  assert a==seed
 assert len(words)==len(set(words))==42
 assert min((u^v).bit_count() for u,v in combinations(words,2))==9
 extended=[u|((u.bit_count()%2)<<20) for u in words]
 assert min((u^v).bit_count() for u,v in combinations(extended,2))==10
 return extended
if __name__=='__main__':print('42 distinct words, all even in 21 bits; minimum distance',min((i^j).bit_count() for i,j in combinations(code(),2)))
