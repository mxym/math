from fractions import Fraction as F
from math import lcm
from itertools import combinations
from collections import Counter
import sys
def basis(G,keep):
 B=[];M=[]
 for k in keep:
  a=list(map(F,G[k]))
  for j,r in M:
   x=a[j];a=[s-x*v for s,v in zip(a,r)]
  if any(a):
   j=next(i for i,x in enumerate(a) if x);x=a[j];a=[y/x for y in a];M.append((j,a));B.append(k)
 return B
def inv(A):
 n=len(A);A=[[F(x) for x in r]+[int(i==j) for j in range(n)] for i,r in enumerate(A)]
 for i in range(n):
  k=next(k for k in range(i,n) if A[k][i]);A[k],A[i]=A[i],A[k];x=A[i][i];A[i]=[y/x for y in A[i]]
  for j in range(n):
   if j!=i:
    x=A[j][i];A[j]=[a-x*b for a,b in zip(A[j],A[i])]
 return [r[n:] for r in A]
def prof(L,U=()):
 n=36;role=[(i//6,i%6,z) for i,z in enumerate(L)];G=[[2*sum(x==y for x,y in zip(u,v))-1 for u in role]for v in role]
 keep=[i for i in range(n) if i not in U];B=basis(G,keep);assert len(B)==15;A=inv([[G[i][j] for j in B]for i in B]);J=[[(sum(G[i][r]*A[j][k] for j,r in enumerate(B))) for k in range(15)]for i in range(n)]
 m=lcm(*(v.denominator for r in J for v in r));C=[[int(m*v) for v in r]for r in zip(*J)];v=[sum(v) for v in zip(*C)];s=0;P=set()
 for j in range(1<<14):
  if j:
   x=(j&-j).bit_length();a=2 if s>>x&1 else -2;s^=1<<x;v=[y+a*z for y,z in zip(v,C[x])]
  if all(abs(v[i])==m for i in keep) and sum(a*a for a in v)<=60*m*m:
   sig=-1 if v[keep[0]]<0 else 1;P.add(tuple(F(v[i]*sig,m) for i in range(n)))
 return G,sorted(P)
def sqsup(A,B,z):
 return sum(x*sum(y*v for y,v in zip(row,z))for x,row in zip(B,A))
def witness(c,fn):
 L=list(map(int,open('latin6.txt').read().splitlines()[c]));X=[[int(v) for v in r.split()]for r in open('prof%d.txt'%c)]
 G,P=prof(L);assert set(P)==set(map(tuple,X));a=open(fn).read().splitlines();b=list(map(int,a[0].split()));K=[list(map(int,x.split()))for x in a[1:4]];Y=[(u,tuple(col))for u,col in zip(b,zip(*K))]+[(k,tuple(ys)) for k,*ys in (list(map(int,row.split())) for row in a[4:])];I=inv(K)
 for i,x in Y:
  assert sqsup(I,x,x)==6
 for (i,x),(j,y) in combinations(Y,2):
  t=F(sum(a*b for a,b in zip(X[i],X[j])),12)+sqsup(I,x,y)/3;assert abs(t)==1
 print('verified exact Gram of',36+len(Y),'lines; Gram rank=15+3=18')
if __name__=='__main__':
 for c,ss in enumerate(open('latin6.txt')):
  G,P=prof(list(map(int,ss.strip())));ref={tuple(map(int,x.split())) for x in open('prof%d.txt'%c)};assert set(P)==ref and len(P)==(84 if c in (0,1) else 30);
  axes=set()
  for role in range(3):
   for plus in combinations(range(6),3):
    sv=tuple(1 if (j//6,j%6,int(ss[j]))[role] in plus else -1 for j in range(36));axes.add(tuple(a*sv[0] for a in sv))
  assert len(axes)==30 and axes<=set(P) and ((set(P)==axes)==(c>=2));print(c,len(P),flush=True)
 witness(2,'witness18.txt')
