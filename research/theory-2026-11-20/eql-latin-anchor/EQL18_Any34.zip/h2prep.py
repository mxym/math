from independent import prof
from aututil import aut
import numpy as np
from itertools import combinations
from collections import Counter
def go():
 src=open('latin6.txt').read().splitlines()
 for c,ss in enumerate(src):
  L=list(map(int,ss.strip()));A=list(aut(L));todo=set(combinations(range(36),2));case=0;ready=0
  while todo:
   U=min(todo);todo-=set(tuple(sorted([p[i] for i in U])) for p in A);case+=1
   P0=prof(L,U)[1]
   for v in P0:assert all(a.denominator==1 for a in v)
   P=np.array([[int(x) for x in v] for v in P0 if all(abs(v[i])!=5 for i in U)]);mixed=[j for j,v in enumerate(P) if any(abs(v[i])!=1 for i in U)]
   if not mixed:continue
   ready+=1
   i,j=U;first=next(v for v in range(36)if v not in U);K={tuple(x):j+1 for j,x in enumerate(P)};V=[]
   for p in A:
    if set([p[i],p[j]])!=set(U):continue
    R=P[:,p];t=R[:,first];V.append(tuple(a*K[tuple(x)]for a,x in zip(t,(R*t[:,None]))))
   V=sorted(set(V));tag='d%02d_%02d_%02d'%(c,i,j);out=open('h2/'+tag+'.aut','w');print(len(V),file=out)
   for g in V:print(*g,file=out)
   print(*mixed,file=out);np.savetxt('h2/'+tag+'.prof',P,fmt='%d')
  print(c,case,ready,flush=True)
go()
