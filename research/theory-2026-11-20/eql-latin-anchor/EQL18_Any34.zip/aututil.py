import itertools as I,numpy as np
def aut(L):
 T=[(i//6,i%6,z) for i,z in enumerate(L)]
 for a,b,c in I.permutations(range(3)):
  S=[[0]*6 for i in range(6)]
  for v in T:S[v[a]][v[b]]=v[c]
  for r in range(6):
   for s in range(6):
    o=S[r][s];V=[i for i in range(6) if i!=o]
    for u in I.permutations(range(1,6)):
     f=[0]*6
     for i,v in zip(V,u):f[i]=v
     rr=[f[S[t][s]] for t in range(6)];cc=[f[q] for q in S[r]]
     P=[6*rr[v[a]]+cc[v[b]] for v in T]
     if all(L[p]==f[v[c]] for p,v in zip(P,T)):yield P
def go(c):
 L=list(map(int,open('latin6.txt').read().splitlines()[c]));A=np.loadtxt('prof%d.txt'%c,dtype=int)
 keys={tuple(x):j+1 for j,x in enumerate(A)};sig=[]
 for p in aut(L):
  t=A[:,p];s=t[:,0];u=t*s[:,None];sig.append(tuple(int(s[i])*keys[tuple(a)] for i,a in enumerate(u)))
 sig=sorted(set(sig));G=open('aut%d.txt'%c,'w');print(len(sig),file=G)
 for v in sig:print(*v,file=G)
 # pure row/col/symbol classification
 mixed=[]
 for i,v in enumerate(A):
  D=[set()for _ in range(18)]
  for k,z in enumerate(L):
   for b in (k//6,6+k%6,12+z):D[b].add(v[k])
  if all(any(len(D[j])>1 for j in range(t,t+6)) for t in (0,6,12)):mixed.append(i)
 print('c',c,'aut',len(sig),'mixed',len(mixed),'orbits',sorted(set(min(abs(g[v])-1 for g in sig) for v in mixed)))
 print(*mixed,file=G)
