#!/bin/sh
set -eu
export OPENBLAS_NUM_THREADS=1
python3 latin.py
python3 profiles.py
python3 independent.py
python3 aut.py
python3 holeprep.py
mkdir -p h2
python3 h2prep.py
for a in twobit holebit doublebit; do c++ -O3 -march=native -std=c++17 "$a.cpp" -o "$a"; done
for c in 0 1; do ./twobit 58 aut$c.txt <prof$c.txt >"full$c.replayed" 2>/dev/null; grep '^No completion' "full$c.replayed"; done
for x in h?_?.prof; do a=${x%.prof}; ./holebit 58 "$a.aut" <"$x" >"$a.replayed" 2>/dev/null; grep -q '^No completion' "$a.replayed"; done
for x in h2/*.prof; do a=${x%.prof}; ./doublebit 58 "$a.aut" <"$x" >"$a.replayed" 2>/dev/null; grep -q '^No completion' "$a.replayed"; done
c++ -O3 -march=native -std=c++17 threereplay.cpp -o threereplay
for c in 0 1; do ./threereplay 58 aut$c.txt <prof$c.txt; done
python3 control.py
