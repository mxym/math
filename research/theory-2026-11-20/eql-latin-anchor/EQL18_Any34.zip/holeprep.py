from independent import prof
from aututil import aut
import numpy as np
active=[]
for c in range(12):
 L=list(map(int,open('latin6.txt').read().splitlines()[c]));A=list(aut(L));orb={min(p[i] for p in A) for i in range(36)}
 print(c,orb)
 for i in sorted(orb):
  P0=prof(L,[i])[1];assert all(all(x.denominator==1 for x in v) for v in P0);P=np.array([[int(x) for x in v] for v in P0 if abs(v[i])!=5]);first=int(i==0);
  mx=[j for j,v in enumerate(P) if abs(v[i])!=1]
  if not mx:continue
  active.append((c,i));assert all(abs(P[j,i])==3 for j in mx) and len(mx)==2;K={tuple(x):j+1 for j,x in enumerate(P)}
  V=[]
  for p in A:
   if p[i]!=i:continue
   R=P[:,p];v=R[:,first];V.append(tuple(t*K[tuple(x)]for t,x in zip(v,(R*v[:,None]))))
  V=sorted(set(V));out=open('h%d_%d.aut'%(c,i),'w');print(len(V),file=out)
  for s in V:print(*s,file=out)
  print(*mx,file=out);np.savetxt('h%d_%d.prof'%(c,i),P,fmt='%d')

assert active==[(0,0),(1,0),(1,2)],active
