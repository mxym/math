#include<bits/stdc++.h>
using namespace std;using V=vector<int>;using U=uint64_t;struct P{int id;array<int,3>t;};int z[100][100],prof[100][36],n,A[3][3],h=0;
vector<P>pt;vector<vector<bool>>g;int best=0;V sol,stackp;long long br=0,ba=0,ptmax=0,large=0,cl=0;int goal;int T[3][3];int bp,bq,br0;
int prod(const array<int,3>&x,const array<int,3>&y){int v=0;for(int i=0;i<3;i++)for(int j=0;j<3;j++)v+=x[i]*A[i][j]*y[j];return v;}
void output(){ofstream f("witness"+to_string(goal)+".txt");f<<bp<<" "<<bq<<" "<<br0<<"\n";for(auto&r:T)f<<r[0]<<" "<<r[1]<<" "<<r[2]<<"\n";for(int j:stackp){f<<pt[j].id;for(int v:pt[j].t)f<<" "<<v;f<<"\n";}f.flush();}
bool ck(V cand){cl++;if((int)cand.size()+(int)stackp.size()<goal)return false;
 V q,ord,col;for(int c=1;!cand.empty();c++){q.clear();V rem;for(int x:cand){bool b=true;for(int y:q)if(g[x][y]){b=false;break;}if(b){q.push_back(x);ord.push_back(x);col.push_back(c);}else rem.push_back(x);}cand=move(rem);}
 for(int i=ord.size()-1;i>=0;i--){if(col[i]+(int)stackp.size()<goal)return false;int x=ord[i];stackp.push_back(x);if((int)stackp.size()>best)best=stackp.size();if((int)stackp.size()==goal){output();return true;}
  V w;for(int j=0;j<i;j++)if(g[x][ord[j]])w.push_back(ord[j]);if(ck(w))return true;stackp.pop_back();}return false;}
struct Bits{U a[12]={}; void set(int i){a[i/64]|=1ULL<<(i%64);} void del(int i){a[i/64]&=~(1ULL<<(i%64));}};
int NW;vector<Bits>ne;V orderback;
int countb(const Bits&a){int r=0;for(int i=0;i<NW;i++)r+=__builtin_popcountll(a.a[i]);return r;}
Bits meet(const Bits&a,const Bits&b){Bits c;for(int i=0;i<NW;i++)c.a[i]=a.a[i]&b.a[i];return c;}
bool bbc(Bits all){cl++;const int need=goal-stackp.size();int count=countb(all);if(count<need)return false;Bits left=all;
 unsigned short ids[768],lev[768];int nr=0,k=0,s=0;while(nr<count){s=nr;k++;Bits avail=left;
 for(int j=0;j<NW;j++)while(avail.a[j]){int i=64*j+__builtin_ctzll(avail.a[j]);ids[nr]=i;lev[nr++]=k;left.del(i);avail.del(i);for(int h=j;h<NW;h++)avail.a[h]&=~ne[i].a[h];}}
 for(int j=nr-1;j>=0&&lev[j]>=need;j--){int i=ids[j];stackp.push_back(orderback[i]);if((int)stackp.size()>=goal){output();return true;}
 if(bbc(meet(all,ne[i])))return true;stackp.pop_back();all.del(i);}return false;}
bool bwrap(V v){int n=v.size();NW=(n+63)/64;assert(NW<=12);V ord;ord.reserve(n);
 // Degeneracy ordering, then reverse so greedy coloring treats the dense core first.
 V deg(n);for(int i=0;i<n;i++)for(int j=0;j<n;j++)deg[i]+=g[v[i]][v[j]];
 V live(n,1);for(int k=0;k<n;k++){int j=-1;for(int i=0;i<n;i++)if(live[i]&&(j<0||deg[i]<deg[j]))j=i;ord.push_back(v[j]);live[j]=0;for(int i=0;i<n;i++)deg[i]-=g[v[i]][v[j]];}
 reverse(ord.begin(),ord.end());orderback=ord;ne.assign(n,{});Bits all;for(int i=0;i<n;i++){all.set(i);for(int j=0;j<n;j++)if(g[ord[i]][ord[j]])ne[i].set(j);}
 return bbc(all);}
bool go(int p,int q,int r,int x,int y,int t){
 T[0][0]=T[1][1]=T[2][2]=6;T[0][1]=T[1][0]=x;T[0][2]=T[2][0]=y;T[1][2]=T[2][1]=t;
 h=216-6*(x*x+y*y+t*t)+2*x*y*t;if(h<=0||abs(x)>=6||abs(y)>=6||abs(t)>=6)return false;ba++;
 for(int i=0;i<3;i++)for(int j=0;j<3;j++)A[i][j]=T[(j+1)%3][(i+1)%3]*T[(j+2)%3][(i+2)%3]-T[(j+1)%3][(i+2)%3]*T[(j+2)%3][(i+1)%3];
 pt.clear();for(int a=0;a<n;a++)for(int b:{3-z[a][p],-3-z[a][p]})if(abs(b)<=6&&(a>=q||abs(b)==6))
 for(int c:{3-z[a][q],-3-z[a][q]})if(abs(c)<=6&&(a>=r||6*(36-x*x)==6*(b*b+c*c)-2*x*b*c))
 for(int d:{3-z[a][r],-3-z[a][r]})if(abs(d)<=6){array<int,3>v={b,c,d};if(prod(v,v)==6*h)pt.push_back({a,v});}
 ptmax=max(ptmax,(long long)pt.size());if((int)pt.size()<goal)return false;large++;
 vector<V>adj(pt.size());g.assign(pt.size(),vector<bool>(pt.size()));for(int i=0;i<(int)pt.size();i++)for(int j=0;j<i;j++){int a=z[pt[i].id][pt[j].id],s=prod(pt[i].t,pt[j].t);if(abs(a*h+s)==3*h){g[i][j]=g[j][i]=true;adj[i].push_back(j);adj[j].push_back(i);}}
 V live(pt.size());iota(live.begin(),live.end(),0);for(bool ch=true;ch;){ch=false;V newl;for(int i:live){int k=0;for(int j:live)k+=g[i][j];if(k>=goal-1)newl.push_back(i);else ch=true;}live.swap(newl);}if((int)live.size()<goal)return false;
 sort(live.begin(),live.end(),[&](int i,int j){return adj[i].size()>adj[j].size();});bp=p;bq=q;br0=r;return bwrap(live);
}
int main(int argc,char**argv){goal=stoi(argv[1])-39;while(cin>>prof[n][0]){for(int i=1;i<36;i++)cin>>prof[n][i];n++;}for(int i=0;i<n;i++)for(int j=0;j<n;j++){int s=inner_product(prof[i],prof[i]+36,prof[j],0);assert(s%4==0);z[i][j]=s/4;}
 ifstream f(argv[2]);int m;f>>m;vector<V>Aut(m,V(n));for(V&v:Aut)for(int&x:v)f>>x;V mixed;int z0;while(f>>z0)mixed.push_back(z0);set<int> chosen; for(int i:mixed){int k=i;for(const V&v:Aut)k=min(k,abs(v[i])-1);chosen.insert(k);}
 for(int p:chosen){for(int q=0;q<n;q++)if(q!=p)for(int r=q+1;r<n;r++)if(r!=p)for(int x:{3-z[p][q],-3-z[p][q]})for(int y:{3-z[p][r],-3-z[p][r]})for(int t:{3-z[q][r],-3-z[q][r]}){br++;if(go(p,q,r,x,y,t)){cout<<"FOUND "<<goal+39<<" lines "<<p<<" "<<q<<" "<<r<<"\n";return 0;}}}
 cout<<"No completion "<<39+goal<<". triples "<<br<<" positive "<<ba<<" max candidates "<<ptmax<<" target-size lists "<<large<<" clique nodes "<<cl<<"\n";}
