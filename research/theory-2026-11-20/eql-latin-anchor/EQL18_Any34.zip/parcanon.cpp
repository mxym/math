#include<bits/stdc++.h>
using namespace std;
string canon(const string&L){string best(36,'9');int a[3]={0,1,2};do{
 int S[6][6];memset(S,-1,sizeof S);for(int i=0;i<36;i++)if(L[i]!='6'){int x[3]={i/6,i%6,L[i]-'0'};S[x[a[0]]][x[a[1]]]=x[a[2]];}vector<pair<int,int>>h;
 for(int i=0;i<6;i++)for(int j=0;j<6;j++)if(S[i][j]<0)h.push_back({i,j});assert(h.size()==2);
 for(int b=0;b<2;b++){
 int r0=h[b].first,r1=h[b^1].first,c0=h[b].second,c1=h[b^1].second,u=0,v=0;assert(r0!=r1&&c0!=c1);
 for(int i=0;i<6;i++){if(S[r0][i]>=0)u|=1<<S[r0][i];if(S[r1][i]>=0)v|=1<<S[r1][i];}
 u=__builtin_ctz(63^u);v=__builtin_ctz(63^v);assert(u!=v);int f[6];int others[4],t=0;for(int i=0;i<6;i++)if(i!=u&&i!=v)others[t++]=i;assert(t==4);
 do{f[u]=0;f[v]=1;for(int i=0;i<4;i++)f[others[i]]=i+2;int R[6]={r0,r1},C[6]={c0,c1};int y=2,z=2;for(int i=0;i<6;i++){if(i!=r0&&i!=r1)R[y++]=i;if(i!=c0&&i!=c1)C[z++]=i;}
 sort(R+2,R+6,[&](int i,int j){return f[S[i][c0]]<f[S[j][c0]];});sort(C+2,C+6,[&](int i,int j){return f[S[r0][i]]<f[S[r0][j]];});
 string s;for(int i:R)for(int j:C)s+=S[i][j]<0?'6':'0'+f[S[i][j]];best=min(best,s);
 }while(next_permutation(others,others+4));}
 }while(next_permutation(a,a+3));return best;}
int main(){string l;map<string,int> a;while(cin>>l)a[canon(l)]++;for(auto&[x,num]:a)cout<<x<<" "<<num<<"\n";cerr<<a.size()<<" canonical partial frames\n";}
