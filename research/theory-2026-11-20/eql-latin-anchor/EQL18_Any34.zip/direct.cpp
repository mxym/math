#include<bits/stdc++.h>
using namespace std;int a[6][6],rows[6],cols[6];long ct=0;
void rec(int j){if(j==36){ct++;for(auto&r:a)for(int x:r)cout<<x;cout<<"\n";return;}int r=j/6,c=j%6;if(j==0||j==7){rec(j+1);return;}int ok=63&~(rows[r]|cols[c]); // canonical lossless normalization of complete nondeficient columns/rows by the first defective row/column
 if(r==0&&c>=3)ok&=~((1<<(a[0][c-1]+1))-1);
 if(c==0&&r>=3)ok&=~((1<<(a[r-1][0]+1))-1);
 for(int t=0;t<6;t++)if(ok>>t&1){a[r][c]=t;rows[r]|=1<<t;cols[c]|=1<<t;rec(j+1);rows[r]^=1<<t;cols[c]^=1<<t;}}
int main(){a[0][0]=a[1][1]=6;rows[0]=1;rows[1]=2;cols[0]=2;cols[1]=1;rec(0);cerr<<ct<<" direct normalized arrays\n";}
