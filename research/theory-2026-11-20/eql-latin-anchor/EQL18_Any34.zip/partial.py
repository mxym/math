from itertools import combinations
from collections import Counter
def generated(L):
 X=[(i//6,i%6,s)for i,s in enumerate(L)]
 for turn in range(3):
  # Choose each original role as distinguished symbol; other two roles can be interchanged.
  T=[tuple(v[(i+turn)%3]for i in range(3)) for v in X]
  for a,b in combinations(range(6),2):
   H=[t for t in T if t[2] in (a,b)];other=[t for t in T if t[2] not in (a,b)]
   for i,j in combinations(range(12),2):
    u,v=H[i],H[j]
    if u[0]==v[0] or u[1]==v[1]:continue
    F=[t for k,t in enumerate(H)if k not in (i,j)];rest=set(range(10));comps=[]
    for z in [u[0],v[0],u[1]+6,v[1]+6]:
     E={z};C=[]
     for unused in range(12):
      new=[k for k in rest if F[k][0] in E or F[k][1]+6 in E]
      if not new:break
      for k in new:E.update((F[k][0],F[k][1]+6));C.append(k);rest.remove(k)
     if C:comps.append(C)
    for B in comps:
     W=other+[(r,c,a+b-s if k in B else s) for k,(r,c,s) in enumerate(F)]
     sa=set(range(6))-{s for r,c,s in W if r==u[0]};sb=set(range(6))-{s for r,c,s in W if c==u[1]}
     if sa==sb:continue
     p=['6']*36
     for r,c,s in W:p[6*r+c]=str(s)
     yield ''.join(p)
def run():
 D=set()
 for L in open('latin6.txt'):
  E=set(generated(list(map(int,L.strip()))));D.update(E);print(len(E),len(D),flush=True)
 open('partial_raw.txt','w').write('\n'.join(sorted(D))+'\n')
if __name__=='__main__':run()
