import itertools as I,numpy as np,sympy as sp,sys,math
from collections import Counter
from hashlib import sha256
import os
def parent(p):
 holes=[i for i,s in enumerate(p) if s==6];r,c=divmod(holes[0],6);r1,c1=divmod(holes[1],6)
 a=next(j for j in range(6)if j not in p[6*r:6*r+6]);b=next(j for j in range(6)if j not in p[6*r1:6*r1+6]);assert a!=b
 H={i for i,s in enumerate(p) if s in (a,b)};can=[]
 while H:
  k=min(H);U={k}
  for _ in range(12):U|={t for t in H if any(t//6==j//6 or t%6==j%6 for j in U)}
  H-=U;q=p[:]
  for j in U:q[j]=a+b-q[j]
  for j in holes:
   r=j//6;q[j]=next(v for v in range(6)if v not in q[r*6:r*6+6])
  if all(len(set(q[j::6]))==6 for j in range(6)):can.append((len(U),q))
 assert can;return min(can)
def rows(p):return np.array([(j//6,j%6,s)for j,s in enumerate(p) if s!=6])
def gram(P,Q):return 2*(P[:,None,:]==Q[None,:,:]).sum(2)-1
def ready():
 X=np.ones((15,1<<14),int)
 for i in range(14):X[i+1]=1-2*((np.arange(1<<14)>>i)&1)
 return X
X=ready()
def digest(Z,h):
 import fractions
 return sha256(('\n'.join(sorted(','.join(str(fractions.Fraction(int(v),int(h))) for v in z) for z in Z))+'\n').encode()).hexdigest()
def do(p,n,folder):
 dist,q=parent(p);P=rows(p);Q=rows(q);G=gram(P,P);T=gram(Q,P)
 _,b=sp.Matrix(G).rref();assert len(b)==15
 W=sp.Matrix(G[:,b][list(b),:]).inv();D=sp.Matrix(G[:,b])*W;d=sp.ilcm(*(v.q for v in D));M=np.array(D*d,dtype=int)
 B=X[:,(abs(M@X)==d).all(axis=0)];N=sp.Matrix(T[:,b])*W;h=sp.ilcm(*(v.q for v in N));Z=(np.array(h*N,dtype=int)@B).T
 Z=Z[(Z*Z).sum(1)<=60*h*h].astype(np.int64);sf=int(4*h*h);D=(Z@Z.T);div=math.gcd(sf,*[int(x) for x in D.ravel()]);scale=sf//div;D=D//div
 M=[i for i,s in enumerate(Z) if (abs(s)!=h).any()];norm=15*scale-D.diagonal()
 # if zero norm we need to handle it specially, cannot use as independent first vector.
 assert scale==1 and all(3<=int(e)/3<=5 for e in D.diagonal()) and min(norm)>0
 assert all(int(x) in (4,6) for x in norm)
 if M:
  with open(folder+'/%03d.dat'%n,'w') as O:
   print(len(Z),scale,len(M),file=O);print(*M,file=O);np.savetxt(O,D,fmt='%d')
 return dist,len(Z),scale,len(M),int(norm.min()),int(max(abs(D.ravel()))),digest(Z,h)
if __name__=='__main__':
 os.makedirs('non',exist_ok=True)
 for n,row in enumerate(open('noncomplete.txt')):
  p=list(map(int,row.split()[0]));print(n,*do(p,n,'non'),flush=True)
