from pathlib import Path
from collections import Counter
import itertools,json
# Check analytic pillar fact: all feasible size-four profile groups have pairwise-overlapping projective supports.
V=list(itertools.combinations(range(6),3));S=set()
for four in itertools.combinations(V,4):
 if all(len(set(a)&set(b))==1 for a,b in itertools.combinations(four,2)):
  S.add(tuple(sorted(min(tuple(t),tuple(i for i in range(6)if i not in t)) for t in four)))
assert len(S)==15 and all(set(a)&set(b) for a,b in itertools.combinations(S,2))
from independent import prof
from aututil import aut
F=list(map(str.strip,open('latin6.txt')));sums=[];active=[];single=[]
for c,L in enumerate(F):
 L=list(map(int,L));perm=list(aut(L));todo=set(itertools.combinations(range(36),2));z=[];files=[]
 while todo:
  e=min(todo);orb={tuple(sorted(p[x]for x in e))for p in perm};assert orb<=todo;todo-=orb;z.append(len(orb))
  fn=Path('h2/d%02d_%02d_%02d.prof'%(c,*e))
  if fn.exists():files.append(fn)
 assert sum(z)==630;sums.append(len(z));active.append(len(files));single.append(len({min(p[i] for p in perm)for i in range(36)}))
assert sum(sums)==358 and sum(active)==177
ll=[q for q in Path('h2').glob('*.out')];assert len(ll)==177 and all(q.read_text().startswith('No completion') for q in ll)
for fn in ('bt0.log','bt1.log','h0_0.out','h1_0.out','h1_2.out'):assert Path(fn).read_text().startswith('No completion')
print('all 15 four-profile groups intersect, and all 12·630 hole pairs recovered; orbit counts',sums,'active',active)
