import itertools as I
def gen():
 n=6;rows=[tuple(range(n))];used=[1<<i for i in range(n)];per=[[p for p in I.permutations(range(n)) if p[0]==i]for i in range(n)]
 def rec(i):
  if i==n:yield sum(rows,());return
  for p in per[i]:
   if any(b>>j&1 for b,j in zip(used,p)):continue
   for k,j in enumerate(p):used[k]^=1<<j
   rows.append(p);yield from rec(i+1);rows.pop()
   for k,j in enumerate(p):used[k]^=1<<j
 yield from rec(1)
def equiv(L):
 A=[(i//6,i%6,v) for i,v in enumerate(L)]
 for a,b,c in I.permutations(range(3)):
  S=[[0]*6 for _ in range(6)]
  for t in A:S[t[a]][t[b]]=t[c]
  for r in range(6):
   for s in range(6):
    v=S[r][s];W=[i for i in range(6) if i!=v];cc=S[r];rr=[t[s] for t in S]
    for p in I.permutations(range(1,6)):
     f=[0]*6
     for i,t in zip(W,p):f[i]=t
     R=sorted(range(6),key=lambda k:f[rr[k]]);C=sorted(range(6),key=lambda k:f[cc[k]])
     yield tuple(f[S[i][j]] for i in R for j in C)
def reps():
 L=set(gen());assert len(L)==9408;out=[]
 while L:
  o=min(L);pairs=set(equiv(o));out.append(o);L-=pairs;print('class',len(out),len(pairs),flush=True)
 assert len(out)==12;return out
if __name__=='__main__':open('latin6.txt','w').writelines(''.join(map(str,r))+'\n' for r in reps())
