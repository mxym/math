#include<bits/stdc++.h>
using namespace std;using V=vector<int>;using U=uint64_t;int n,d[100][100],ss[100][36],needed;struct W{int i,a,b,z;};vector<W> P;vector<vector<bool>> g;V answer,sol;long long nodes=0,cores=0,bs=0,raw=0;int capP=0;int pp,qq,tp,squarefree;
void save(){ofstream f("holeWitness"+to_string(needed)+".txt");f<<pp<<" "<<qq<<" "<<tp<<" "<<squarefree<<"\n";for(int i:sol){auto w=P[i];f<<w.i<<" "<<w.a<<" "<<w.b<<" "<<w.z<<"\n";}}
bool clique(V v){nodes++;if(sol.size()+v.size()<(unsigned)needed)return false;
 V order,col;int k=0;while(!v.empty()){k++;V c,rem;for(int i:v){bool ok=true;for(int j:c)if(g[i][j]){ok=false;break;}if(ok){c.push_back(i);col.push_back(k);order.push_back(i);}else rem.push_back(i);}swap(rem,v);}
 for(int i=order.size()-1;i>=0;i--){if((int)sol.size()+col[i]<needed)return false;int a=order[i];sol.push_back(a);if((int)sol.size()==needed){save();return true;}V r;for(int k=0;k<i;k++)if(g[a][order[k]])r.push_back(order[k]);if(clique(r))return true;sol.pop_back();}return false;}
struct Bits{U a[12]={}; void set(int i){a[i/64]|=1ULL<<(i%64);} void del(int i){a[i/64]&=~(1ULL<<(i%64));}};
int NW;vector<Bits>ne;V orderback;
int countb(const Bits&a){int r=0;for(int i=0;i<NW;i++)r+=__builtin_popcountll(a.a[i]);return r;}
Bits meet(const Bits&a,const Bits&b){Bits c;for(int i=0;i<NW;i++)c.a[i]=a.a[i]&b.a[i];return c;}
bool bbc(Bits all){nodes++;const int need=needed-sol.size();int count=countb(all);if(count<need)return false;Bits left=all;
 unsigned short ids[768],lev[768];int nr=0,k=0,s=0;while(nr<count){s=nr;k++;Bits avail=left;
 for(int j=0;j<NW;j++)while(avail.a[j]){int i=64*j+__builtin_ctzll(avail.a[j]);ids[nr]=i;lev[nr++]=k;left.del(i);avail.del(i);for(int h=j;h<NW;h++)avail.a[h]&=~ne[i].a[h];}}
 for(int j=nr-1;j>=0&&lev[j]>=need;j--){int i=ids[j];sol.push_back(orderback[i]);if((int)sol.size()>=needed){save();return true;}
 if(bbc(meet(all,ne[i])))return true;sol.pop_back();all.del(i);}return false;}
bool bwrap(V v){int n=v.size();NW=(n+63)/64;assert(NW<=12);V ord;ord.reserve(n);
 // Degeneracy ordering, then reverse so greedy coloring treats the dense core first.
 V deg(n);for(int i=0;i<n;i++)for(int j=0;j<n;j++)deg[i]+=g[v[i]][v[j]];
 V live(n,1);for(int k=0;k<n;k++){int j=-1;for(int i=0;i<n;i++)if(live[i]&&(j<0||deg[i]<deg[j]))j=i;ord.push_back(v[j]);live[j]=0;for(int i=0;i<n;i++)deg[i]-=g[v[i]][v[j]];}
 reverse(ord.begin(),ord.end());orderback=ord;ne.assign(n,{});Bits all;for(int i=0;i<n;i++){all.set(i);for(int j=0;j<n;j++)if(g[ord[i]][ord[j]])ne[i].set(j);}
 return bbc(all);}
bool solve(int p,int q,int t){
 pp=p;qq=q;tp=t;int PP=15-d[p][p],QQ=15-d[q][q],D=PP*QQ-t*t;map<int,vector<W>>pv;for(int i=0;i<n;i++)for(int a:{3-d[i][p],-3-d[i][p]})if(a*a<=(15-d[i][i])*PP)for(int b:{3-d[i][q],-3-d[i][q]})if(b*b<=(15-d[i][i])*QQ){int l=(15-d[i][i])*D-QQ*a*a-PP*b*b+2*t*a*b;if(l<0)continue;int sf=l,z=1;if(!sf)z=0;else for(int x=2;x*x<=sf;x++)while(sf%(x*x)==0){sf/=x*x;z*=x;}pv[sf].push_back({i,a,b,z});if(z)pv[sf].push_back({i,a,b,-z});}
 for(const auto&[sf,vs]:pv)if(sf){bs++;squarefree=sf;P=vs;if(pv.count(0))P.insert(P.end(),pv.at(0).begin(),pv.at(0).end());int m=P.size();capP=max(capP,m);if(m<needed)continue;g.assign(m,vector<bool>(m));
  for(int i=0;i<m;i++)for(int j=0;j<i;j++){auto x=P[i],y=P[j];int u=QQ*x.a*y.a+PP*x.b*y.b-t*(x.a*y.b+x.b*y.a)+sf*x.z*y.z;g[i][j]=g[j][i]=abs(d[x.i][y.i]*D+u)==3*D;}
  V v(m);iota(v.begin(),v.end(),0);for(;;){V r;for(int i:v){int deg=0;for(int j:v)deg+=g[i][j];if(deg+1>=needed)r.push_back(i);}if(r.size()==v.size())break;swap(r,v);}if((int)v.size()<needed)continue;
  cores++;sort(v.begin(),v.end(),[&](int a,int b){return count(g[a].begin(),g[a].end(),true)>count(g[b].begin(),g[b].end(),true);});cerr<<"START "<<pp<<" "<<qq<<" "<<tp<<" sf "<<sf<<" g "<<v.size()<<" nodes "<<nodes<<endl;if(bwrap(v))return true;cerr<<"END "<<nodes<<endl;}
 return false;
}
int main(int argc,char**argv){needed=atoi(argv[1])-37;while(cin>>ss[n][0]){for(int i=1;i<36;i++)cin>>ss[n][i];n++;}for(int i=0;i<n;i++)for(int j=0;j<n;j++){int tot=inner_product(ss[i],ss[i]+36,ss[j],0);assert(tot%4==0);d[i][j]=tot/4;}
 ifstream f(argv[2]);int m;f>>m;vector<V>A(m,V(n));for(auto&x:A)for(int&v:x)f>>v;V mixed;int id;while(f>>id){assert(15-d[id][id]>0);mixed.push_back(id);}
 set<tuple<int,int,int>> seen;for(int p:mixed)for(int q=0;q<n;q++)if(q!=p)for(int t:{3-d[p][q],-3-d[p][q]})if(t*t<(15-d[p][p])*(15-d[q][q])){raw++;if(seen.count({p,q,t}))continue;
  for(auto&x:A){int i=x[p],j=x[q];seen.insert({abs(i)-1,abs(j)-1,((i<0)^(j<0))?-t:t});}if(solve(p,q,t)){cout<<"WITNESS "<<needed+37<<" "<<p<<" "<<q<<" "<<t<<endl;return 0;}}
 cout<<"No completion of size "<<needed+37<<" using mixed line. Raw oriented two-bases "<<raw<<" squarefree cases "<<bs<<" graph supports "<<cores<<" max possible "<<capP<<" clique nodes "<<nodes<<endl;}
