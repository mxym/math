"""Independent enumeration in row/column/symbol potential coordinates, not the anchor Gram."""
from independent import basis,inv
from nonprep import parent,digest
from fractions import Fraction as F
from math import lcm
import numpy as np
def design(q):
 return [[int(x==j)-int(x==5) for x in (k//6,k%6,v) for j in range(5)] for k,v in enumerate(q) if v!=6]
def check(p):
 L=design(p);S=design(parent(p)[1]);B=basis(L,range(34));assert len(B)==15 and B[0]==0
 A=inv([L[i] for i in B]);d=lcm(*(t.denominator for r in A for t in r));A=np.array([[int(t*d) for t in r] for r in A],dtype='int64')
 # pattern order differs from nonprep, and enumerates columns - to +.
 signs=np.ones((15,2**14),dtype=np.int64);t=np.arange(2**14)
 for k in range(1,15):signs[k]=((t>>(14-k))%2)*2-1
 vals=A@signs;ok=(abs(L@vals)==d).all(axis=0);vals=vals[:,ok]
 # Squared projection norm is half sum of squares of all 18 potential values. Recover three omitted potentials from zero sums.
 sq=(vals**2).sum(axis=0)+sum(vals[k:k+5,:].sum(axis=0)**2 for k in (0,5,10));vals=vals[:,sq<=10*d*d]
 z=S@vals;assert len(z)==36 and max(abs(z.ravel()))<10**9
 return digest(z.T,d)
if __name__=='__main__':
 rows=[r.split() for r in open('nonprof.log')];assert len(rows)==282
 for i,(r,line) in enumerate(zip(rows,open('noncomplete.txt'))):
  p=list(map(int,line.split()[0]));assert len(p)==36;h=check(p);assert h==r[-1],(i,h,r[-1])
 print('Potential-coordinate verifier matched all 282 exact profile sets.')
