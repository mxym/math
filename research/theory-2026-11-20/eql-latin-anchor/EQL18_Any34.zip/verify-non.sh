#!/bin/sh
set -eu
export OPENBLAS_NUM_THREADS=1
for src in parcanon direct nonbit; do c++ -O3 -std=c++17 "$src.cpp" -o "$src"; done
python3 partial.py >switch.replayed
./parcanon <partial_raw.txt >switch-canonical.replayed
cmp switch-canonical.replayed noncomplete.txt
./direct >direct.raw.replayed; ./parcanon <direct.raw.replayed >direct-canonical.replayed
cmp direct-canonical.replayed dcanon.txt
cut -d' ' -f1 direct-canonical.replayed >direct-keys.replayed
cut -d' ' -f1 switch-canonical.replayed >switch-keys.replayed
cmp direct-keys.replayed switch-keys.replayed
test "$(wc -l <direct-keys.replayed)" -eq 282
test "$(wc -l <partial_raw.txt)" -eq 31322
awk '{n+=$2}END{exit n!=53184}' dcanon.txt
python3 nonprep.py >nonprof.replayed; cmp nonprof.replayed nonprof.log
python3 nonind.py
test "$(find non -name '*.dat' | wc -l)" -eq 2
for f in non/*.dat; do ./nonbit 58 <"$f" >"${f%.dat}.replayed" 2>/dev/null; cmp "${f%.dat}.out" "${f%.dat}.replayed"; grep '^No completion' "${f%.dat}.replayed"; done

for f in non/*.dat; do ./nonbit 58 slow <"$f" >"${f%.dat}.slow.replayed" 2>/dev/null; cmp "${f%.dat}.slow" "${f%.dat}.slow.replayed"; grep '^No completion' "${f%.dat}.slow.replayed"; done
python3 control.py
