import numpy as np,sympy as sp
from collections import Counter
from itertools import combinations
def profile(S):
 x=np.array([(i//6,i%6,j) for i,j in enumerate(S)],dtype=int);G=2*((x[:,None,:]==x[None,:,:]).sum(axis=2))-1
 assert np.array_equal(G@G,12*G)
 _,B=sp.Matrix(G).rref();assert len(B)==15
 M=sp.Matrix(G[:,B][list(B),:]).inv();D=sp.Matrix(G[:,B])*M
 l=sp.ilcm(*(int(x.q) for x in D));H=np.array(l*D,dtype=np.int64)
 v=np.arange(2**14);Xs=1-2*((v[None,:]>>(np.arange(15)[:,None]-1).clip(0,20))%2);Xs[0]=1
 Z=(H@Xs).T;P=Z[(abs(Z)==l).all(axis=1)]//l;assert (G@P.T==12*P.T).all() and len(B)==15
 return G,P
if __name__=='__main__':
 for c,ss in enumerate(open('latin6.txt')):
  S=list(map(int,ss.strip()));g,p=profile(S);d=p@p.T;dist=Counter(d[i,j] for i,j in combinations(range(len(p)),2));print(c,len(p), sorted(dist.items()),flush=True)
  np.savetxt('prof%d.txt'%c,p,fmt='%d')
