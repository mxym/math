# Infinitely many genuine qutrit QR codes distill the Strange state

Private proof for independent review, 20 November 2026. Read qr.pdf (3 pages, LaTeX source included).

For every prime p ≡ 11 modulo 12, the [[p,1]] qutrit CSS quadratic-residue code distills the Strange state with at least cubic suppression and nonzero success. The near-pure threshold lower bound on p.3 is per length. It does not improve the 11-qutrit Golay record, prove a uniform positive threshold, or solve contextuality sufficiency. The distance grows by the known QR distance bound. The pass to infinitely many p is Dirichlet’s theorem.

The proof uses two transversal symmetries of the Euclidean-self-dual extended ternary QR code, then a separate mod-p orbit count of its signed fullweight words. Those words certify that the ideal post-selection probability does not vanish. The exact success/conditional-error distinction, and the correspondence between input error δ and depolarization ε, appear in the note.

Verification: run `python check.py` with no external dependency (or `python check.py 11 23` for a quick subset). The standalone replay builds the code via the Paley residue incidence matrix, without imported weight tables. Its rows are cyclic shifts of (1_R,1); in the ternary Fourier transform the two nonzero-frequency Gaussian periods have sum −1 and product (p+1)/4=0 modulo 3, so one of the two quadratic classes is its zero set. Thus it generates an equivalent augmented QR code with the same appended parity. The script also checks half rank and full self-orthogonality independently. For the two-even amplitude test: all codeword weights are multiples of three, so if all unmarked coordinates are ±1 and at most two coordinates are marked, the marked coordinates must be ±1 as well. Only the |+,+> component can survive; its unnormalized coefficient at each pair is the signed fullweight count with both marked signs removed. All pairs vanish in the exact independent calculation.

Primary comparison:
- Zurel, Jana & de Silva, *Quantum Sci. Technol.* 11, 045052 (2026), DOI 10.1088/2058-9565/aea362, arXiv:2603.18560v2, Theorem 3 & Corollary 5 identify these codes; §4.3/Table 3 gives finite qutrit examples, and §5 explicitly proposes the infinite-qutrit analogue of its qubit Theorem 4 as further work. Its proof of qubit nonvanishing also uses a cyclic congruence.
- Prakash & Singhal, *PRA* 113, 042404 (2026), DOI 10.1103/61q5-f754 reports finite cubic examples through 23 CSS sites, not the infinite QR result.
- Prakash, *Proc. R. Soc. A* 476, 20200187 (2020), DOI 10.1098/rspa.2020.0187 proves the 11-qutrit Golay result.
- Targeted primary-literature searches through 20 Nov 2026 and file-index queries for qutrit distillation, Zurel and Strange + quadratic residue in mxym/math and openai/math returned no duplicate proof. arXiv:2611.17823 concerns 11-qutrit decoder comparisons and is not the asymptotic result. This comparison is not exhaustive priority certification.
