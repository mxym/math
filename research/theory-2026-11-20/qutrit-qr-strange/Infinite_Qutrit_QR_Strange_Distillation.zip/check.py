"""Exact QR replay. Enumerate only fullweight candidates in a systematic information set
(2^K, not 3^K); bit-parallel ternary update on parity coordinates, no dependencies.
Typical few seconds even at length 47; default all three published CSS examples.
"""
from fractions import Fraction as F
from itertools import combinations
import sys
def replay(p):
 n=p+1;k=n//2
 R={j*j%p for j in range(1,p)}
 rows=[[int((j-i)%p in R) for j in range(p)]+[1] for i in range(p)]
 assert all(sum(u*v for u,v in zip(a,b))%3==0 for a in rows for b in rows)
 piv=[];j=0
 while j<n:
  m=len(piv); i=next((i for i in range(m,len(rows)) if rows[i][j]),None)
  if i is None:j+=1;continue
  rows[m],rows[i]=rows[i],rows[m]; c=rows[m][j];rows[m]=[(a*c)%3 for a in rows[m]]
  for i in range(len(rows)):
   c=rows[i][j]
   if i!=m and c:rows[i]=[(a-c*b)%3 for a,b in zip(rows[i],rows[m])]
  piv.append(j);j+=1
 assert len(piv)==k
 G=[r for r in rows if any(r)]; free=[j for j in range(n) if j not in piv]
 H=[[r[j] for j in free] for r in G]
 def masks(a):
  return tuple(sum(1<<i for i,v in enumerate(a) if v==j) for j in range(3))
 add=list(map(masks,H)); mask=(1<<k)-1
 _,v1,v2=masks([sum(r[j] for r in H)%3 for j in range(k)])
 # Start all information symbols +1.
 g=0; words=[]
 for i in range(1<<k):
  if i:
   bit=i&-i; g^=bit; z,o,t=add[bit.bit_length()-1]
   if not(g&bit):o,t=t,o
   v0=mask^v1^v2;v1,v2=(v1&z)|(v0&o)|(v2&t),(v2&z)|(v0&t)|(v1&o)
  if (v1|v2)==mask:words.append(g|(v2<<k))
 # Words have been reordered into information set then complement; all pairs unaffected.
 signed=[((-1)**(w.bit_count()%2),w) for w in words]
 N=sum(s for s,w in signed); assert N%p==2 and N!=0
 for i,j in combinations(range(n),2):
  assert sum(s if ((w>>i)^(w>>j))&1==0 else -s for s,w in signed)==0
 acc=F(3*N*N,3**k*2**n)
 print('p=%d n_ext=%d dim=%d full=%d signed=%d (=2 mod p), all %d two-even amplitudes zero, pure acceptance=%s PASS'%(p,n,k,len(words),N,n*(n-1)//2,acc),flush=True)
for p in ([int(x) for x in sys.argv[1:]] or [11,23,47]):replay(p)
