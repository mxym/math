#!/usr/bin/env python3
"""Fraction-only matrix construction and elementary checks. The all-compressions
claim is proved in the paper, not tested by numerical sampling here."""
from fractions import Fraction as R
from math import factorial
from argparse import ArgumentParser
from pathlib import Path
import json
def construct(k):
    assert isinstance(k, int) and k>=1
    d=2*k+1; s=2**d; t=s*s; n=d*d
    def idx(i,j):return d*i+j
    def new():return [[R(0) for _ in range(n)] for _ in range(n)]
    def addouter(X,vec):
        for a,v in vec.items():
            for b,w in vec.items():X[a][b]+=v*w
    def pair(X,Y):return sum(X[i][j]*Y[j][i] for i in range(n) for j in range(n))
    def gamma(X,a,b): return X[d*(a//d)+b%d][d*(b//d)+a%d]
    K=new(); rho=new(); W=new()
    addouter(rho,{idx(i,i):R(1) for i in range(d)})
    for i in range(d):
        for j in range(i+1,d):
            addouter(rho,{idx(i,j):R(s),idx(j,i):R(1,s)})
            for e in (1,-1):
                addouter(K,{idx(i,i):R(1),idx(j,j):-R(1),
                            idx(i,j):-R(e,s),idx(j,i):R(e*s)})
    assert pair(K,rho)==0
    F=[1 if i<=j else s**4 for i in range(d) for j in range(d)]
    delta=R(d,2*sum(F[a]*rho[a][a] for a in range(n)))
    e0=(R(t-1,4*d*(t+1))*delta)**(2*d)/factorial(d)**2
    for a in range(n):
        for b in range(n):
            W[a][b]=K[a][b]/e0
        W[a][a]+=delta*F[a]-int(a//d==a%d)
    assert pair(W,rho)==-R(d,2)
    h=[R(4)**(j-i) for i in range(d) for j in range(d)]
    scale=sum(h[idx(0,j)]**2*W[idx(0,j)][idx(0,j)] for j in range(d))
    for a in range(n):
        for b in range(n):
            W[a][b]*=h[a]*h[b]/scale
            rho[a][b]/=h[a]*h[b]
    assert pair(W,rho)==-R(d,2)/scale
    assert all(W[a][b]==gamma(W,a,b) and rho[a][b]==gamma(rho,a,b) for a in range(n) for b in range(n))
    assert all(sum(W[idx(i,j)][idx(l,j)] for j in range(d))==int(i==l)
               and sum(W[idx(j,i)][idx(j,l)] for j in range(d))==int(i==l)
               for i in range(d) for l in range(d))
    return d,W,rho,delta,e0,scale
if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('k',type=int,nargs='?',default=2);p.add_argument('--json',type=Path); a=p.parse_args()
    d,W,r,delta,e0,h=construct(a.k)
    print('PASS: M_'+str(d)+', exact PPT witness pairing = -d/(2*scale), both marginals identity.')
    print('delta =',delta,'; e0 denominator decimal digits:',len(str(e0.denominator)))
    if a.json:
        def sparse(X):
            return [[i,j,str(v)] for i,row in enumerate(X) for j,v in enumerate(row) if v]
        a.json.write_text(json.dumps({'k':a.k,'local_dimension':d,'basis':'zero-based |i,j> indexed d*i+j, input first','normalized_choi_sparse':sparse(W),'ppt_witness_sparse':sparse(r),'delta':str(delta),'epsilon0':str(e0),'normalizing_scale':str(h)},indent=1)+'\n')
