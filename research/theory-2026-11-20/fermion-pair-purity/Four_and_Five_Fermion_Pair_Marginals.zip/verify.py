"""Exact Gaussian-integer sanity replay; not a substitute for the general proof."""
from itertools import combinations
from math import comb
from random import Random
from collections import defaultdict
from functools import lru_cache
R=Random(641854)
Z=(0,0)
def add(x,y):return (x[0]+y[0],x[1]+y[1])
def scale(k,x):return(k*x[0],k*x[1])
def star(x):return(x[0],-x[1])
def m(x,y):return(x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def sq(x):return x[0]**2+x[1]**2
def norm(x):return sum(map(sq,x.values()))
def inner(x,y):
 t=Z
 for k,a in x.items():t=add(t,m(star(a),y.get(k,Z)))
 return t
def insist(x): 
 if not x:raise ArithmeticError("identity failed")
@lru_cache(None)
def sets(d,k):return tuple(combinations(range(d),k))
def sgn(A,B):return (-1)**sum(a>b for a in A for b in B)
def rand(d,k):return {I:(R.randrange(-4,5),R.randrange(-4,5)) for I in R.sample(sets(d,k),min(15,len(sets(d,k))))}
def wedge(p,q):
 w=defaultdict(lambda:Z)
 for I,x in p.items():
  for J,y in q.items():
   if set(I)&set(J):continue
   K=tuple(sorted(I+J));w[K]=add(w[K],scale(sgn(I,J),m(x,y)))
 return w
def gam(p,k):
 cols=defaultdict(dict)
 for S,x in p.items():
  for I in combinations(S,k):
   J=tuple(i for i in S if i not in I)
   cols[J][I]=scale(sgn(I,J),x)
 M=defaultdict(lambda:Z)
 for col in cols.values():
  for I,x in col.items():
   for J,y in col.items():M[I,J]=add(M[I,J],m(x,star(y)))
 return M
def holes(p,d):
 q={}
 for I,x in p.items():
  J=tuple(j for j in range(d) if j not in I)
  q[J]=scale(sgn(I,J),x)
 return q
for d in range(4,15):
 for _ in range(8):
  p=rand(d,2);q=rand(d,2);a,b=gam(p,1),gam(q,1)
  h=inner(a,b);insist(h[1]==0 and h[0]>=0)
  insist(norm(wedge(p,q))==norm(p)*norm(q)-h[0]+sq(inner(p,q)))
 sl={tuple(range(4)):(1,0)};g=gam(sl,2)
 insist(norm(g)==6 and sum(x[0] for (I,J),x in g.items() if I==J)==6)
for d in range(6,12):
 for N in range(2,d-1):
  for _ in range(3):
   p=rand(d,N);q=holes(p,d);t=norm(p)
   gp,gh=gam(p,2),gam(q,2);g1=gam(p,1)
   Dp=comb(N,2)*t*t-norm(gp);Dh=comb(d-N,2)*t*t-norm(gh)
   insist(Dh-Dp==(d-2*N)*(N*t*t-norm(g1)))
   if N==4:insist(norm(gp)<=6*t*t)
print("Exact exterior identity: 88 complex pairs, d=4..14.")
print("Exact Slater normalization: 11 mode spaces; pair trace=purity=6.")
print("Particle-hole purity transfer: 99 random complex occupation tensors, d=6..11.")
# Independent finite cubature with exact Gaussian fourth moments is possible,
# but simpler here is a deterministic phase-orbit cubature: uniform 4th roots
# give the two Wick pairings except double counting all diagonal cases.
# A sparse single-axis correction restores those. Integer identity:
# E_G F(z) = average_{phase} F(z) + sum_i F(e_i)
# equivalently E_G F = E_phase F + sum_i F(e_i), for (2,2) homogeneous F.
from itertools import product
def annih(p,i):
 return {tuple(j for j in A if j!=i):scale((-1)**A.index(i),x) for A,x in p.items() if i in A}
def plus_scaled(vs,z):
 q=defaultdict(lambda:Z)
 for vi,ci in zip(vs,z):
  for A,x in vi.items():q[A]=add(q[A],m(ci,x))
 return q
def wf(k,q):return norm(gam(q,k))
# To avoid 4**d cost, use direct basis polarization to calculate the phase mean:
# full phase average = sum_i F_i + sum_{i<j}( E_t F(e_i+t e_j)-F_i-F_j ).
phase=[(1,0),(-1,0),(0,1),(0,-1)]
for d,N in [(5,4),(6,5),(7,5),(8,6)]:
 p=rand(d,N); vs=[annih(p,i) for i in range(d)]; t=norm(p)
 for k in range(0,min(N-1,3)+1):
  fi=[wf(k,v) for v in vs]; direct4=8*sum(fi)
  for i,j in combinations(range(d),2):
   direct4+=sum(wf(k,plus_scaled([vs[i],vs[j]],[(1,0),s])) for s in phase)-4*(fi[i]+fi[j])
  rhs4=4*((N-k)**2*wf(k,p)+(k+1)**2*wf(k+1,p))
  insist(direct4==rhs4)
print("Gaussian removal identity: 16 exact fourth-moment cubatures, j=0..3, N=4,5,6.")
