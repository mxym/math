#!/usr/bin/env python3
"""Integer replays of the source-index reordering, partial transpose and signed
minor identity. The symbolic all-k proof is supplied in grid_minors.pdf."""
from itertools import combinations
from random import Random
from collections import defaultdict
import argparse

def det(m):
    a=[list(r) for r in m];n=len(a);p=1;s=1
    for i in range(n-1):
        if not a[i][i]:
            r=next((r for r in range(i+1,n) if a[r][i]),None)
            if r is None:return 0
            a[i],a[r]=a[r],a[i];s=-s
        v=a[i][i]
        for j in range(i+1,n):
            for l in range(i+1,n):
                z=a[j][l]*v-a[j][i]*a[i][l];assert z%p==0;a[j][l]=z//p
        p=v
    return s*a[-1][-1] if n else 1
def run(k):
    n=2*k-1;I=range(k);rng=Random(k);gen=[]
    def add(v,w=1):gen.append((v,w))
    add([(i,k-1-i) for i in I])
    for i in I:
        for j in I:
            if i+j>=k:add([(i,j),(n-j,n-i)])
            if i+j<k-1:add([(i,j)])
    for a in range(1,n):add([(a,n-a)],min(a,n-a))
    def perm(i,j):
        return (i,k-1-j if j<k else k+n-j)
    alpha=rng.randrange(1,12);coef=[alpha]+[rng.randrange(-6,7) for _ in gen[1:]]
    M=[[0]*(2*k) for _ in range(2*k)]
    pt=defaultdict(int); gram=defaultdict(int)
    for c,(vs,w) in zip(coef,gen):
        vs=[perm(i,j) for i,j in vs]
        for i,j in vs:
            M[i][j]+=c
            for a,b in vs:pt[i,b,a,j]+=w
    def g(vs):
        for i,j in vs:
            for a,b in vs:gram[i,j,a,b]+=1
    for i in I:
        g([(i,i)])
        for j in range(i):
            g([(i,j),(j,i)]);g([(i,k+i),(k+j,j)]);g([(k+j,k+i)])
    assert pt==gram
    A=[r[:k] for r in M[:k]]
    for i in I:
        assert A[i][i]==alpha
        for j in I:
            assert M[k+j][k+i]==(A[i][j] if i>j else 0)
            if i!=j:assert M[i][k+j]==M[k+i][j]==0
    lhs=0
    for r in range(k+1):
        for Y in combinations(I,r):
            Yc=tuple(i for i in I if i not in Y)
            for Z in combinations(I,r):
                Zc=tuple(i for i in I if i not in Z)
                rows=Y+tuple(k+j for j in Zc);cols=Z+tuple(k+i for i in Yc)
                lhs+=(-1)**(sum(Y)+sum(Z)+k-r)*det([[M[i][j] for j in cols] for i in rows])
    assert lhs==alpha**k
    print('k=%d: exact indexing, PPT Gram identity, signed minor sum = %d = alpha^k'%(k,lhs))
if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('k',type=int,nargs='*',default=[2,3,4,5,6]);p=a.parse_args()
    for k in p.k:run(k)
