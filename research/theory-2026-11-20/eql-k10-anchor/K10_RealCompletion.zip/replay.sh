#!/bin/sh
set -eu
export OPENBLAS_NUM_THREADS=1
python3 vectors.py >vectors.replayed
python3 run.py >run.replayed
cmp run.log run.replayed
python3 direct.py >direct.replayed
cmp direct.log direct.replayed
cat run.replayed direct.replayed
