"""Independent exact sign enumeration directly on the 45-line frame; no modular assumption about its outsiders."""
import itertools as I
from collections import Counter
from math import lcm
import sympy as sp,numpy as np
from run import colorings,S
def candidates(f):
 # 18 independent potentials after suppressing the last member of each zero-sum role.
 H=np.array([[int(c==j)-int(c==9) for j in range(9)]+[int(a==j)+int(b==j)-int(a==9)-int(b==9) for j in range(9)] for (a,b),c in zip(S,f)],dtype=np.int64)
 Q=sp.Matrix(H);B=Q.T.rref()[1];assert len(B)==18;E=Q[list(B),:].inv();den=lcm(*(v.q for v in E));I=np.array(E*den,dtype='int64');L=H@I;out=[]
 for s in range(8):
  N=np.arange(2**14,dtype=np.int64)+s*2**14;X=np.ones((18,len(N)),dtype=np.int64)
  for i in range(17):X[i+1]=1-2*((N>>i)&1)
  T=I@X[:,(abs(L@X)==den).all(axis=0)];A=T[:9];U=T[9:];Z=np.vstack([A,-A.sum(axis=0),U,-U.sum(axis=0)]).T
  out.extend(Z[(Z*Z).sum(1)==10*den**2].tolist())
 return np.array(out),den
def analyze(P,d):
 pure=(P[:,10:]==0).all(axis=1);assert sum(pure)==126
 ne=abs(P@P.T)==2*d*d
 G=[frozenset(i for i,y in enumerate(r) if y)for r in ne]
 # Exhaustive Bron--Kerbosch maximum clique with greedy independent-set cover upper bounds.
 calls=0
 def clique(X,k):
  nonlocal calls;calls+=1
  if k<1:return True
  if len(X)<k:return False
  colors=[];left=set(X)
  while left:
   t=set(left);C=[]
   while t:
    i=min(t);t.discard(i);C.append(i);t-=G[i];left.discard(i)
   colors.append(C)
  for idx in range(len(colors)-1,k-2,-1):
   for i in colors[idx]:
    X=X-{i}
    if clique(X&G[i],k-1):return True
  return False
 mixed=[i for i,y in enumerate(pure) if not y];X=set(range(len(P)))
 for i in mixed:
  X.discard(i);assert not clique(X&G[i],12)
 return len(P),len(mixed),calls
def reps():
 C=list(colorings());ind={c:i for i,c in enumerate(C)};assert len(C)==len(ind)==1024;remain=set(ind);rep=[]
 while remain:
  f=min(remain);orb=set()
  for u,v in I.product((1,2,3,4),range(5)):
   for fl in range(32):
    z=[2*((u*(i//2)+v)%5)+((i%2)^((fl>>(i//2))%2)) for i in range(10)]
    g={tuple(sorted([z[a],z[b]])):2*((u*(c//2)+2*v)%5)+(c%2) for (a,b),c in zip(S,f)}
    h=tuple(g[p]for p in S);assert h in ind;orb.add(h)
  assert orb<=remain;remain-=orb;rep.append((f,len(orb)))
 assert sum(s for f,s in rep)==1024
 return rep
if __name__=='__main__':
 from itertools import combinations
 # Directly select a universal 12-line pure completion, without relying on any printed list.
 blocks=[set((0,)+v) for v in I.combinations(range(1,10),4)]
 def sel(P,A):
  if len(A)==12:return A
  while len(P)+len(A)>=12:
   z=P[-1];P=P[:-1];W=sel([w for w in P if len(z&w) in (2,3)],A+[z])
   if W:return W
  return None
 split=sel(blocks,[]);assert len(split)==12 and all(len(x&y) in (2,3) for x,y in combinations(split,2))
 print('universal positive subsets:',','.join(''.join(map(str,sorted(x))) for x in split))
 print('Every anchor has a pure 12-line completion.')
 rep=reps();print('orbit count',len(rep),Counter(s for f,s in rep),flush=True)
 for j,(f,s) in enumerate(rep):
  P,d=candidates(f);print(j,s,d,*analyze(P,d),flush=True)
