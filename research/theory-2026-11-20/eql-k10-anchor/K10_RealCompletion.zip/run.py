from vectors import vectors
from itertools import product,combinations
import numpy as np
from collections import Counter
from functools import reduce
S=list(combinations(range(10),2))
def colorings():
 # colour pairs (2s,2s+1) assigned edge pairs with block indices summing to s.
 D=[]
 for s in range(5):
  fixed=3*s%5 # 2 inverse mod 5
  blocks=[(a,(s-a)%5) for a in range(5) if a<(s-a)%5];assert len(blocks)==2
  p=[]
  for flips in product((0,1), repeat=2):
   f={(2*fixed,2*fixed+1):2*s}
   for (a,b),d in zip(blocks,flips):
    for x,y in product(range(2),repeat=2):
     f[(2*a+x,2*b+y)]=2*s+(x^y^d)
   assert len(f)==9;p.append(f)
  D.append(p)
 for W in product(*D):
  f={k:v for t in W for k,v in t.items()};yield tuple(f[k] for k in S)
def classify(P):
 core=[];mixed=[]
 for z in P:
  if len(set(i%10 for i in z[10:]))>1:mixed.append(z)
  elif z[10:]==(0,)*10:core.append(z)
 assert len(core)==126 and len(mixed)==460
 return core,mixed
def main():
 core,mixed=classify(vectors()[0]);P=np.array(core+mixed,dtype=int);G=abs(P@P.T)==50;A=np.array(mixed,dtype=int)
 ne=[sum(1<<int(j) for j in np.where(row)[0]) for row in G]
 groups={};count=Counter()
 for j,f in enumerate(colorings()):
  E=np.array([A[:,c]+A[:,10+a]+A[:,10+b] for (a,b),c in zip(S,f)])
  keep=np.where((abs(E)==5).all(0))[0];m=int(sum(1<<(126+int(i)) for i in keep));groups.setdefault(m,[]).append(j);count[len(keep)]+=1
 print('groups',len(groups),'distribution',count,flush=True);rank=Counter();nn=0
 def clique(V,n):
  nonlocal nn
  nn+=1
  if n==0:return []
  if V.bit_count()<n:return None
  left=V;order=[];colors=[];d=0
  while left:
   d+=1;x=left
   while x:
    a=x&-x;i=a.bit_length()-1;order.append(i);colors.append(d);left^=a;x^=a;x&=~ne[i]
  for i,c in zip(order[::-1],colors[::-1]):
   if c<n:return None
   q=clique(V&ne[i],n-1)
   if q is not None:return [i]+q
   V^=1<<i
  return None
 for m,ls in groups.items():
  orig=(1<<126)-1;v=m
  while v:
   a=v&-v;v^=a;i=a.bit_length()-1;q=clique(ne[i]&(orig|v),12)
   if q is not None:
    print('WITNESS',ls[0],i,q,flush=True);np.savetxt('found.txt',P[[i]+q],fmt='%d');open('color.txt','w').write(str(ls[0]));return
  rank[m.bit_count()]+=len(ls)
 print('No 58; nodes',nn,'counts',rank,flush=True)
if __name__=='__main__':main()
