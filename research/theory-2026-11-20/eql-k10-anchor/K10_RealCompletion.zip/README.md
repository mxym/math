# An exact unrestricted completion theorem for every K10 edge-coloring frame
Run `sh replay.sh` with Python 3.10+, NumPy, SymPy. No network or graph library. The proof is in proof.pdf and proof.tex. No code uses numerical linear algebra.

* `vectors.py` enumerates an exact integer norm shell.
* `run.py` constructs all 1024 normalized Z5-compatible colorings, tests each shell vector, builds the exact compatibility graph, and tests for a 13-clique involving a nonuniform outsider.
* `direct.py` checks the same branch independently: quotient by explicitly generated vertex isometries; on each of the 10 actual orbits, directly enumerate all 131072 signed basis assignments, with no shell or partition hypothesis imposed on the remaining lines. An alternative clique search is then run on those directly recovered profiles. It also produces a 12-line completion by direct inspection of 5-subsets; the same 12 work on every proper 10-coloring, giving exact maximum 57 for each anchor.
