from itertools import product,combinations
from collections import Counter
from functools import lru_cache
@lru_cache(None)
def shell(r,bound):
 q=[sorted((x for x in range(-15,16) if (x-i)%10==0),key=abs) for i in r];ls=[]
 def rec(v,cost,s):
  if len(v)==10:
   if s==0:ls.append((tuple(v),cost))
  else:
   for x in q[len(v)]:
    if cost+x*x>bound:break
    rec(v+[x],cost+x*x,s+x)
 rec([],0,0);return ls
def vectors():
 pts=set(); ct=Counter()
 for h in range(5):
  for n in range(10):
   r=tuple((n+2*h*(i//2))%10 for i in range(10));s=tuple((5-2*n-2*h*(i//2))%10 for i in range(10))
   for U,e in shell(r,250):
    for T,f in shell(s,250-e):
     if e+f!=250:continue
     z=T+U
     if z>tuple(-x for x in z):continue
     ct[h,n]+=1;pts.add(z)
 return sorted(pts),ct
if __name__=='__main__':
 p,c=vectors();print(len(p),c);print(Counter(sum(x*x for x in t[:10]) for t in p));open('vectors.txt','w').writelines(' '.join(map(str,z))+'\n' for z in p)
