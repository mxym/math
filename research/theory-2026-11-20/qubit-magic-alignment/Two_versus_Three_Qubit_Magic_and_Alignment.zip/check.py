"""Two independent exact checks: full third projective moment and formal factorization.
Requires Python 3 and SymPy. No SDP, floating point, or numerical input.
"""
from itertools import combinations, permutations, product
from collections import defaultdict
from sympy import Matrix, I, eye, kronecker_product as kron, symbols, factor, Rational as Q
# Construct every rank-one four-dimensional stabilizer projector P.
O=eye(2); X=Matrix([[0,1],[1,0]]); Y=Matrix([[0,-I],[I,0]]); Z=Matrix.diag(1,-1)
pauli=[kron(a,b) for a,b in product((O,X,Y,Z),repeat=2)][1:]
projectors={}
for a,b in combinations(pauli,2):
 if a*b!=b*a: continue
 for e,f in product((-1,1),repeat=2):
  P4=(eye(4)+e*a)*(eye(4)+f*b)
  assert P4*P4==4*P4 and P4.trace()==4
  projectors[tuple(P4)]=P4
assert len(projectors)==60
# Work with integer pairs for Gaussian arithmetic in the 4096-entry moment.
def gm(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]
M=defaultdict(lambda:[0,0])
for P4 in projectors.values():
 t=[(i,j,tuple(map(int,P4[i,j].as_real_imag()))) for i,j in product(range(4),repeat=2) if P4[i,j]]
 for (i,j,x),(k,l,y),(r,s,z) in product(t,repeat=3):
  v=gm(gm(x,y),z); e=M[(i,k,r,j,l,s)]; e[0]+=v[0]; e[1]+=v[1]
# For j=3 the Haar moment is (1/120) sum_S3 U_pi. 60*(4^3)/120=32.
for row in product(range(4),repeat=3):
 for col in product(range(4),repeat=3):
  assert M[row+col]==[32*sum(u==col for u in permutations(row)),0]
print('All 60 rank-one two-qubit stabilizers, all 4096 Gaussian-integer tensor moment entries: PASS')
# Independent symbolic computation of both exact identities.
s,U=symbols('s U')
D=Matrix([[s/2-Q(1,4),s/8-(1+s**2)/20],
          [s/8-(1+s**2)/20,s*(1+s**2)/40-(1+3*s**2+2*U)/120]]).det()
g=factor(4800*D)
assert (g-(2*s-1)*(-20*U+24*s**3-3*s**2-6*s+2)).expand()==0
h=factor(4800*D.subs(U,s**4))
assert (h+(2*s-1)**2*(2*s+1)*(5*s*s-6*s+2)).expand()==0
assert (5*(s-Q(3,5))**2+Q(1,5)-(5*s*s-6*s+2)).expand()==0
print('4800 det M =',g)
print('4800 det M at U=s^4 =',h)
print('all polynomial identities and quadratic positivity: PASS')
# Three-qubit companion: exact gamma algebra, paired marginals, and A7 invariant algebra.
from sympy import sqrt, Rational
G=[kron(kron(Z if i>0 else g, Z if i>1 else (g if i==1 else O)),g if i==2 else O)
   for i in range(3) for g in (X,Y)]+[kron(kron(Z,Z),Z)]
assert len(G)==7 and all(a*a==eye(8) for a in G)
assert all(a*b==-b*a for a,b in combinations(G,2))
S=sum(G,eye(8)*0);assert (S*S).applyfunc(lambda x:x.expand())==7*eye(8)
ls=list(range(7))
digits=lambda v:sum(i>j for i,j in combinations(v,2))%2
perms=[p for p in permutations(ls) if not digits(p)];assert len(perms)==2520
for k in (0,1,2,3):
  basis=list(combinations(ls,k))
  tr=0
  for p in perms:
    for u in basis:
      v=[p[i] for i in u]
      if sorted(v)==list(u):tr+=(-1)**digits(v)
  assert tr==len(perms)*(k<2)
print('A7 invariant dimensions of Clifford gamma monomial grades 0,1,2,3: 1,1,0,0 (2520 even permutations): PASS')
# Direct matrix replay of one Clifford U mapping S to conjugate S.
T=(eye(8)+G[0]*G[1])/sqrt(2) # swaps coordinates 0,1 with one sign
R=(T*S*T.H).applyfunc(lambda x:x.expand())
for i,j in combinations(ls,2):
  V=G[i]*G[j]
  if V*R*V.H==S.conjugate():break
else:raise AssertionError('single correcting pair unavailable')
assert ((V*T)*S*(V*T).H).applyfunc(lambda x:x.expand())==S.conjugate()
print('explicit conjugate Clifford: gamma pair',i+1,j+1,'after quarter-turn (1,2): PASS')
P=(eye(8)+S/sqrt(7))/2;Q=eye(8)-P;f=(1+1/sqrt(7))/2
assert (P*P-P).applyfunc(lambda x:x.expand())==eye(8)*0 and P.trace()==4 and (P*Q).trace().expand()==0
assert ((eye(8)+S/7)/8 - (f*P+(1-f)*Q)/4).applyfunc(lambda x:x.expand())==eye(8)*0
print('rank-four sector, one-copy free majorant and Bell flag weights: PASS')
# Verify the parity-rank accounting in the normal form and the odd/even optimal counts.
for l,q,a,b in product(range(7),repeat=4):
 assert ((l+q+a)+(q+b)-(l+a+b))==2*q
# Multiplication of squared weights in Q(sqrt(7)); h²=1/2 > f² exactly.
assert (Rational(1,2)-f*f).expand().is_positive
for n in range(1,19):
 max_odd=max(j for j in range(n+1) if j%2==0) # number of odd-exponent factors
 assert max_odd==2*(n//2) and n-max_odd==n%2
print('graded-compression rank exponents and parity optimizer: PASS')
