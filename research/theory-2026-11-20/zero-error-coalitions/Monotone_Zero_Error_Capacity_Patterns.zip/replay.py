#!/usr/bin/env python3
"""Finite, exact checks of the ingredients of coalitions.tex (standard library)."""
from itertools import combinations, permutations, product
from collections import Counter
A=(0,1,2,4)
F=[[(a,b) for a,b in product(A,repeat=2) if (a-b)%7==ell] for ell in range(7)]
assert list(map(len,F))==[4]+[2]*6
h={t:int(i>=len(f)//2) for f in F for i,t in enumerate(f)}
assert all(len({a for a,b in f})==len({b for a,b in f})==len(f) for f in F)
assert all(sum((-1)**h[x] for x in f)==0 for f in F)
assert all(sum(a==z for a,b in h)==4==sum(b==z for a,b in h) for z in A)
print('Seven balanced partial matchings; each input and output degree is four.')
# Cyclotomic integer vectors evaluated at zeta_7: p(zeta)=0 iff its seven
# integer coefficients are all equal, modulo x^7-1 and degree at most 6.
def det(cols,rows=A):
 v=[0]*7
 for perm in permutations(range(4)):
  parity=sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2
  v[sum(rows[i]*cols[perm[i]] for i in range(4))%7]+=(-1)**parity
 return v
for cols in combinations(range(7),4):
 a=det(cols);b=det(cols,(0,1,2,3));w=[sum(b[(i-s)%7] for s in cols) for i in range(7)]
 assert len(set(a))>1 and a==w
print('All 35 Fourier determinants are nonzero, and match Vandermonde times the four-root sum exactly.')
# The GHZ amplitude in each Kraus word at length m is an algebraic
# polynomial in z=exp(i*pi/m). Only exponents 0,m can survive; z^m=-1.
for m in (1,2,3,4,5):
 count=0
 for ls in product(range(7),repeat=m):
  cells=set.intersection(*(set(F[l]) for l in ls)); counts=Counter(sum(h[x] for _ in ls) for x in cells)
  assert set(counts)<={0,m} and counts[0]==counts[m];count+=1
 print(f'Length {m}: all {count} GHZ amplitudes cancel exactly.')
# Exhaustive combinatorial audit of the maximum-distance isolation argument.
for num_sym,n in ((2,1),(2,2),(2,3),(3,1)):
 words=list(product(range(num_sym),repeat=n)); dist={(s,t):sum(a!=b for a,b in zip(s,t)) for s in words for t in words}
 subsets=[[w for i,w in enumerate(words) if mask>>i&1] for mask in range(1,2**len(words))]
 for U,V in product(subsets,repeat=2):
  s,t=max(product(U,V),key=dist.get);J=[i for i in range(n) if s[i]!=t[i]]
  assert [a for a in U if all(a[i]==s[i] for i in J)]==[s]
  assert [b for b in V if all(b[i]==t[i] for i in J)]==[t]
 print(f'Flags d={num_sym}, j={n}: {len(subsets)**2} support pairs passed maximum-distance isolation.')
# All antichains on four vertices, excluding those containing the empty set.
from fractions import Fraction
V=range(4)
def rank(cols):
 basis={}
 for c in cols:
  c=list(map(Fraction,c))
  for j in sorted(basis):
   a=c[j];c=[x-a*y for x,y in zip(c,basis[j])]
  inds=[j for j,x in enumerate(c) if x]
  if inds:
   j=inds[0];a=c[j];basis[j]=[x/a for x in c]
 return len(basis)
def parts(F,n):
 if n==16:yield F
 else:
  yield from parts(F,n+1)
  if all((x&n) not in (x,n) for x in F):yield from parts(F+[n],n+1)
total=0
for F in parts([],1):
 m=sum(x.bit_count()-1 for x in F);off=0;vectors=[]
 for f in F:
  sites=[v for v in V if f>>v&1];s=len(sites)
  for i,v in enumerate(sites):
   e=[0]*m
   if i<s-1:e[off+i]=1
   else:
    for j in range(s-1):e[off+j]=-1
   vectors.append((v,e))
  off+=s-1
 assert off==m
 for U in range(16):
  cols=[e for v,e in vectors if (U>>v)&1];win=any(U&f==f for f in F)
  assert (rank(cols)<len(cols))==win
  total+=1
print(f'All {total//16} antichains of nonempty subsets of 4 vertices: {total} exact rank/coalition tests passed.')
