"""Construct the circle from its field, cover all directions, and exhaust both 26-layer searches."""
from pathlib import Path
from itertools import combinations
from collections import Counter
from tempfile import TemporaryDirectory
import subprocess,os,sys
root=Path(__file__).resolve().parent
def insist(condition, reason):
    if not condition:raise ValueError(reason)
def base(x,y):
    result=0
    while y:
        if y&1:result^=x
        x<<=1
        if x&64:x^=67
        y>>=1
    return result
def pw(x,n,times):
    v=1
    while n:
        if n&1:v=times(v,x)
        n>>=1;x=times(x,x)
    return v
insist(all(pw(x,63,base)==1 for x in range(1,64)),"base field")
def tr(x):
    a=x;o=0
    for i in range(6):o^=a;a=base(a,a)
    return o
delta=next(x for x in range(64)if tr(x)==1)
def mul(x,y):
    a,b=x%64,x//64;c,d=y%64,y//64
    bd=base(b,d)
    return (base(a,c)^base(delta,bd))+64*(base(a,d)^base(b,c)^bd)
def sidon(a):
    return len(a)==len(set(a)) and len({x^y for x,y in combinations(a,2)})==len(a)*(len(a)-1)//2
def canonical(B):
    return min(sorted(x^t for x in B)for t in B)
S=[0]+[x for x in range(1,4096)if pw(x,65,mul)==1]
insist(len(S)==66 and sidon(S),"norm circle + nucleus")
alpha=next(x for x in S[1:]if pw(x,13,mul)!=1 and pw(x,5,mul)!=1)
def dot(x,y):return (x&y).bit_count()&1
def value(mat,x):
    v=0
    for i in range(12):
        if x>>i&1:v^=mat[i]
    return v
def transpose(mat,u):
    return sum(dot(c,u)<<i for i,c in enumerate(mat))
mats=[]
for op in [lambda x:mul(alpha,x),lambda x:mul(x,x)]:
    mat=[op(1<<i)for i in range(12)]
    insist(len({op(x)for x in range(4096)})==4096 and {op(x)for x in S}==set(S) and all(op(x)==value(mat,x)for x in range(4096)),"generator")
    mats.append(mat)
print("GF(64) delta",delta,"norm-one generator",alpha,"linear columns",mats,flush=True)
V=set(range(1,4096));sections=[];mass=Counter()
while V:
    u=min(V);Q=[u];V.remove(u)
    for v in Q:
        for mat in mats:
            z=transpose(mat,v)
            if z in V:Q.append(z);V.remove(z)
    ws={sum(1-2*dot(t,x)for x in S)for t in Q}
    insist(len(ws)==1,"constant signed character in orbit");w=ws.pop();mass[w]+=len(Q)
    if abs(w) in (14,10):
        j=(u&-u).bit_length()-1
        def fold(x):return (x&((1<<j)-1))|((x>>(j+1))<<j)
        a=[fold(x)for x in S if dot(u,x)==int(w<0)]
        b=[fold(x)for x in S if dot(u,x)!=int(w<0)]
        insist(len(a)==(66+abs(w))//2 and len(b)==66-len(a) and sidon(a+[x+2048 for x in b]),"plant")
        insist(len(set(a)|{x^y^z for x,y,z in combinations(a,3)})==2048,"maximality")
        span={0}
        for x in a:span|={v^x^a[0]for v in span}
        insist(len(span)==2048,"affine span")
        sections.append((u,w,len(Q),a,b))
insist(dict(mass)=={2:780,6:780,-6:585,-10:520,10:455,-2:390,14:390,-14:195},"all 4095 directions")

secs40=[s for s in sections if len(s[3])==40]
secs38=[s for s in sections if len(s[3])==38]
insist([(u,w,n)for u,w,n,a,b in secs40]==[(6,14,390),(17,-14,195)],"two maximum orbits")
insist(sorted(n for u,w,n,a,b in secs38)==[65,130,390,390],"four second-largest orbits")
wit=list(map(int,(root/'sharp19.txt').read_text().split()))
u,w,n,a,b=secs40[1]
insist(len(wit)==19 and sidon(a+[2048+x for x in wit]),"explicit size-59 example")
hits=[sum((x^t) in b for x in wit)for t in range(2048)]
insist(max(hits)==17,"no planted 26 translate contains the 19")
print("Walsh distribution",sorted(mass.items()),"sections",[(u,w,len(a),n)for u,w,n,a,b in sections],"sharp19 maximum overlap",max(hits),flush=True)
if '--quick' in sys.argv:
    print("Geometry and exact size-59 controls PASS; searches not run",flush=True);sys.exit(0)
with TemporaryDirectory() as wd:
    for label,sec in [('exotic',secs40),('full',secs38)]:
        for eng in ('degree','numeric'):
            exe=Path(wd)/(label+eng)
            subprocess.run([os.environ.get('CXX','g++'),'-O3','-march=native','-std=c++17',str(root/(label+'_'+eng+'.cpp')),'-o',str(exe)],check=True)
            for u,w,n,a,b in sec:
                exotic=(label=='exotic'); t=20 if exotic else 28
                inp=Path(wd)/'plant';inp.write_text(' '.join(map(str,b))+'\n')
                args=[str(exe),str(t)]+([str(inp)] if exotic else [])
                run=subprocess.run(args,input=' '.join(map(str,a))+'\n',text=True,capture_output=True,check=True)
                out=run.stdout.splitlines(); ks=[s for s in out if s.startswith('k ')]
                insist([int(s.split()[1]) for s in ks]==list(range((t+1)//2,t+1)),"complete larger-side range")
                if exotic and eng=='degree':
                    insist(out==ks and all(s.endswith(' hit0')for s in out),"no exotic opposite 20")
                elif exotic:
                    insist(out==ks+['TOTAL 0'] and all(s.endswith(' classes 0')for s in ks),"no exotic class")
                else:
                    insist(len(out)==len(ks)+2 and out[-2].startswith('B ') and list(map(int,out[-2].split()[1:]))==canonical(b) and out[-1]=='TOTAL 1',"exact opposite 28 class equals planting")
                print(label,eng,u,run.stderr.strip(),flush=True);print(run.stdout.strip(),flush=True)
print("PASS. Every circle40 section has threshold at most 60, sharp on the second orbit; every circle38 fixes the size-66 completion.",flush=True)
