#ifdef NDEBUG
#error requires assertions
#endif
#include<bits/stdc++.h>
using namespace std;using V=array<int,16>;int k;
V norm(V a){if(k%2){int y=0;for(int i=0;i<k;i++)y^=a[i];for(int i=0;i<k;i++)a[i]^=y;sort(a.begin(),a.begin()+k);return a;}V t=a,b;fill(b.begin(),b.end(),1024);for(int i=0;i<k;i++){for(int j=0;j<k;j++)t[j]=a[j]^a[i];sort(t.begin(),t.begin()+k);if(t<b)b=t;}return b;}
int main(int ac,char**av){assert(ac==3);int id=atoi(av[1]);k=atoi(av[2]);assert(198<=id&&id<=199&&k<=16);
 string line;ifstream ff("core67gold.txt");for(int i=198;i<=id;i++)getline(ff,line);vector<int>A;istringstream f(line);int x;while(f>>x)A.push_back(x);assert(A.size()==32);set<int>sa(A.begin(),A.end());
 ifstream g("maps"+to_string(id)+".txt");vector<array<int,10>> gl;while(getline(g,line)){istringstream in(line);array<int,10>r;for(int&v:r)assert(in>>v);int extra;assert(!(in>>extra));gl.push_back(r);}assert(gl.size()==12);vector<array<int,1024>>gen;
 for(auto&r:gl){array<int,1024>v{};for(int i=1;i<1024;i++)v[i]=v[i&(i-1)]^r[__builtin_ctz(i)];assert(set<int>(v.begin(),v.end()).size()==1024);bool ok=false;for(int y:A){int b=v[A[0]]^y;set<int>im;for(int a:A)im.insert(v[a]^b);if(im==sa){ok=true;break;}}assert(ok);gen.push_back(v);}
 ifstream ur("core67layers/32_"+to_string(id)+"_"+to_string(k)+".txt");vector<V>S;map<V,int> pos;
 bool ending=false;while(getline(ur,line)){if(line.rfind("hit 0 nodes ",0)==0){ending=true;break;}V a{};istringstream in(line);for(int i=0;i<k;i++)assert(in>>a[i]);int z;assert(!(in>>z));a=norm(a);assert(!pos.count(a));pos[a]=S.size();S.push_back(a);}assert(ending);
 vector<int>seen(S.size(),-1);int nc=0;for(int i=0;i<S.size();i++)if(seen[i]<0){vector<int>Q={i};seen[i]=nc++;for(int j=0;j<Q.size();j++)for(auto &t:gen){V u{};for(int h=0;h<k;h++)u[h]=t[S[Q[j]][h]];u=norm(u);auto it=pos.find(u);assert(it!=pos.end());int h=it->second;if(seen[h]==-1){seen[h]=seen[i];Q.push_back(h);}else assert(seen[h]==seen[i]);}cout<<Q.size();for(int j=0;j<k;j++)cout<<" "<<S[i][j];cout<<'\n';}cerr<<id<<" k"<<k<<" n "<<S.size()<<" reps "<<nc<<endl;}
