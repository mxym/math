"""Fresh independent executable verification. Pass --raw for the slower one-root cross-check as well."""
import json,os,sys,subprocess,tempfile,hashlib
from pathlib import Path as P
from itertools import combinations
from collections import Counter
src=P(__file__).resolve().parent
def require(v,what):
 if not v:raise ValueError(what)
def strings(a):return ' '.join(map(str,a))
def nums(s):return list(map(int,s.split()))
def sha(b):return hashlib.sha256(b).hexdigest()
def delta(a):return {x^y for x,y in combinations(a,2)}
def rawcount(lines):
 require(len(lines)>=1 and lines[-1].startswith('hit 0 nodes ') and len(lines[-1].split())==4, 'endpoint trailer')
 return lines[:-1],int(lines[-1].split()[-1])
def runner(args,input='',**kw):return subprocess.run(args,input=input,text=True,capture_output=True,check=True,**kw).stdout
def main():
 rows=(src/'d10.txt').read_bytes();require(sha(rows)=='a12772fa637227ee3b017cbe35edfab700d14c935ae34daafc531cb56dbc7d98','pinned V10 file')
 by={k:[nums(l)for l in rows.decode().splitlines()if len(l.split())==k]for k in (32,33,34)}
 require([len(by[k])for k in by]==[200,7,1],'certified V10 source counts');require(all(len(delta(a))==len(a)*(len(a)-1)//2 for c in by.values()for a in c),'source Sidon')
 layers=json.loads((src/'layer_manifest.json').read_text());checks={(i,k):(n,h)for i,k,n,h in layers};require(len(checks)==len(layers)==600,'all raw layer inputs')
 ep=json.loads((src/'endpoints.json').read_text());require(len(ep)==312,'opposite endpoints');expect={(i,k,j):(m,u,h,nn)for i,k,j,m,u,h,nn in ep};seen=set()
 with tempfile.TemporaryDirectory()as tmp:
  wd=P(tmp);args=[os.environ.get('CXX','g++'),'-std=c++17','-march=native','-O3']
  for n in (10,11):subprocess.run([*args,f'-DDIM={n}',str(src/'rootpairs.cpp'),'-o',str(wd/f'pair{n}')],check=True)
  subprocess.run([*args,str(src/'orbits.cpp'),'-o',str(wd/'orbits')],check=True)
  subprocess.run([*args,str(src/'split.cpp'),'-o',str(wd/'split')],check=True)
  raw='--raw' in sys.argv
  if raw:subprocess.run([*args,'-DWIDTH=18',str(src/'raw.cpp'),'-o',str(wd/'raw')],check=True)
  def pair(a,k,dim):return runner([str(wd/f'pair{dim}'),str(k)],strings(a)+'\n')
  for x in by[33]+by[34]:
   assertx,_=rawcount(pair(x,12,10).splitlines());require(not assertx,'12-mate to 33/34')
  def mates(a,k):
   v,_=rawcount(pair(a,k,10).splitlines());v=[nums(l)for l in v]
   require(all(len(t)==k and len(set(t))==k and len(delta(t))==k*(k-1)//2 and not(delta(t)&delta(a))for t in v),'explicit mate')
   return [delta(t)for t in v]
  for i,a in enumerate(by[33]):
   ds=mates(a,11);require(len(ds)==[2,2,2,2,0,0,54][i],('33 mate count',i))
   require(not any(x.isdisjoint(y)and x.isdisjoint(z)and y.isdisjoint(z)for x,y,z in combinations(ds,3)),('33 triple disjoint impossible',i))
  X=by[34][0];U=mates(X,11);Y=mates(X,10);require(len(U)==2 and len(Y)==22,'34 positive counts')
  require(not any(U[0].isdisjoint(U[1])and not(z&U[0]or z&U[1]) for z in Y),'34 triple compatibility')
  print('All 33 and 34 branches passed, including normalized 11/11/11 and 11/11/10 families.',flush=True)
  A,B=[nums(l)for l in (src/'positive.txt').read_text().splitlines()];canon=lambda t:min(sorted(x^z for x in t)for z in t)
  require(len(A)==46 and len(B)==16 and len(delta(A+[x+2048 for x in B]))==1891,'62-point positive control')
  result=runner([str(wd/'split'),'16'],strings(A)+'\n').splitlines();require(result[-1]=='TOTAL 1'and nums(result[-2][2:])==canon(B),'positive split recovers planted 16-mate')
  r,_=rawcount(pair(A,16,11).splitlines());require(len(r)==1 and canon(nums(r[0]))==canon(B),'positive whole-space search recovers same mate')
  print('Positive 46+16 control: the independent solvers both recovered the planted class.',flush=True)
  (wd/'core67layers').mkdir();(wd/'core67gold.txt').write_text(''.join(strings(a)+'\n'for a in by[32][-2:]))
  for i in [198,199]:(wd/f'maps{i}.txt').write_bytes((src/f'maps{i}.txt').read_bytes())
  S2=json.loads((src/'split_ledger.json').read_text());s2={tuple(d['key']):d for d in S2};require(len(S2)==len(s2)==312 and set(s2)==set(expect),'split keys')
  totals=Counter();nchecks=Counter()
  for i,a in enumerate(by[32]):
   for k in (12,13,14):
    text=pair(a,k,10);body,nn=rawcount(text.splitlines())
    require(checks[i,k]==(len(body),sha(text.encode())),('raw translated arrays',i,k,nn))
    totals[k]+=len(body)
    if i<198:reps=[(1,nums(l))for l in body]
    else:
     (wd/'core67layers'/f'32_{i}_{k}.txt').write_text(text)
     s=runner([str(wd/'orbits'),str(i),str(k)],cwd=wd);zz=[nums(l)for l in s.splitlines()];reps=[(row[0],row[1:])for row in zz]
    require(sum(m for m,u in reps)==len(body),'orbit coverage')
    for j,(m,u)in enumerate(reps):
     key=i,k,j;seen.add(key);ms,U,h,N=expect[key];nchecks[k]+=1
     H=a+[1024+y for y in u];require(ms==m and U==u and sha(strings(H).encode())==h and len(u)==k and len(delta(H))==len(H)*(len(H)-1)//2,('anchor',key))
     t=18 if k==14 else 66-len(H);out,nn=rawcount(pair(H,t,11).splitlines());require(not out and nn==N,('terminal',key))
     out=runner([str(wd/'split'),str(t)],strings(H)+'\n').splitlines()
     require(s2[key]['hash']==h and s2[key]['t']==t and s2[key]['stdout'].splitlines()==out,('independent transcript',key))
     require(out[-1]=='TOTAL 0' and [int(s.split()[1])for s in out[:-1]]==list(range((t+1)//2,t+1)) and all(s.startswith('k ')and s.endswith(' labelled 0 classes 0')for s in out[:-1]),('independent split',key))
     if raw:require(runner([str(wd/'raw'),str(t),'2048','1'],strings(H)+'\n').strip()=='0',('independent raw origin root',key))
   if i%20==19 or i>=197:print('Completed V10 source',i+1,'/200; terminal count',sum(nchecks.values()),flush=True)
  require(seen==set(expect) and dict(totals)=={12:785014,13:114080,14:22320}and dict(nchecks)=={12:280,13:23,14:9},'global ledger')
  print('PASS',dict(totals),dict(nchecks),'raw=',raw,flush=True)
if __name__=='__main__':main()
