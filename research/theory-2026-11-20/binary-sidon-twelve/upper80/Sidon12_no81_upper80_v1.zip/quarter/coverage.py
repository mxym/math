from itertools import combinations,product
from math import prod
def ck(x):
 if not x:raise ValueError('certificate failed')
def gap(d,n,m):
 Q=1<<d;P2=Q*n-n*n;P4=Q*(3*n*n-2*n)-n**4;h=(2*m-n)**2;l=n%2
 return P4-(l+h)*P2+l*h*(Q-1)
def shapes():
 S=set()
 for m in range(41,48):
  if gap(12,81,m)>0:continue
  for a in range((m+1)//2,35):
   if gap(11,m,a)>0:continue
   b=m-a
   for c in range((82-m)//2,82-m):
    d=81-m-c
    if min(a,b,c,d)<0 or max(u+v for u,v in combinations((a,b,c,d),2))>m:continue
    S.add((m,a,b,c,d))
 ck(S=={(46,28,18,18,17),(47,29,18,17,17),(47,29,18,18,16),(47,30,17,17,17)})
 print('shapes',sorted(S),'global m<=45 contradiction',gap(12,81,45),'inner forbidden gaps',gap(11,46,27),gap(11,47,28),flush=True)
def plain():
 n=(28,18,18,17);m=46;Q=1024;R=11
 v=[961,93,100,100,39,-1,-1,-1,0,-7,-7,-3,-7,-4,-4,-21]
 def col(w):return [1,*[x*x for x in w],*[x**4 for x in w],*[(x*y)**2 for x,y in combinations(w,2)],prod(w)]
 b=[Q,*[Q*x for x in n],*[Q*(3*x*x-2*x)for x in n],*[Q*x*y for x,y in combinations(n,2)],0]
 cost=sum(z*(x-y)for z,x,y in zip(v,b,col(n)));ck(cost<0);N=0
 for w in product(*(range(-R+(R-x)%2,R+1,2)for x in n)):
  if any(abs(sum((-1)**((q&i).bit_count()%2)*x for i,x in enumerate(w)))>R for q in range(4)):continue
  if any(abs(w[i])+abs(w[j])>2*n[0]-m for i,j in combinations(range(4),2)if n[i]+n[j]==m):continue
  ck(sum(x*y for x,y in zip(col(w),v))>=0);N+=1
 print('m46 signed profiles',N,'RHS',cost,flush=True)
if __name__=='__main__':shapes();plain()
