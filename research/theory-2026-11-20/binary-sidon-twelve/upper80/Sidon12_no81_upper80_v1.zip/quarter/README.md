# 81-point Sidon sets in twelve binary dimensions: reduction to one quarter shape

**Scoped result.** A hypothetical 81-point Sidon set in $\mathbb F_2^{12}$ must have a largest hyperplane section of size 47 and admit a codimension-two decomposition of sizes $(30,17,17,17)$. **That remaining branch is not excluded in this packet.** This packet alone does not improve the published upper 81 or assert existence/nonexistence of 81.

The prerequisite [classification of the 48-point extremizers](https://github.com/mxym/math/commit/a78febb46b89666125b6fc483fd14322b5f593bc) and its opposite-layer corollary imply that a 12-dimensional Sidon set of size at least 65 has no 48-point section and that no section can be larger; thus our maximal section $m$ is at most 47.

For $n$ points in binary dimension $d$ let $P_2=2^dn-n^2$ and $P_4=2^d(3n^2-2n)-n^4$ be the off-zero second and fourth Walsh moments. These follow by character orthogonality, counting diagonal pairs and ordered zero-sum quadruples. If the maximal half is at most $m$, all nontrivial $W$ obey $l\le W^2\le H$ for $l=n\bmod2,H=(2m-n)^2$. Hence $P_4-(l+H)P_2+lH(2^d-1)\le0$. At $n=81,d=12,m=45$ the left side is **10,575,360**, so $m\ge46$. Among maximum $m$-sections choose one with its own maximum half $a$ greatest. Applying the same slab to this $m$-set in dimension 11 excludes $\max a\le27$ when $m=46$ (gap 2,440,944), and $\max a\le28$ for $m=47$ (953,856). Writing the quarter sizes $n_i$ as $(a,m-a,c,81-m-c)$, with $c$ the larger side, every pair has sum at most $m$. These constraints and the previously established $s(10)=34$ give exactly four shapes: $(28,18,18,17)$ for 46; $(29,18,17,17),(29,18,18,16),(30,17,17,17)$ for 47. The small coverage checker regenerates all four.

For four quarter layers in $U=\mathbb F_2^{10}$ let $w_i(u)$ be their Walsh coefficients. At $u\ne0$ all four quotient-signed sums have magnitude at most $2m-81$. Moreover $|w_i|+|w_j|\le2a-m$ when $n_i+n_j=m$, by the chosen maximum internal section across **all** maximum halves. With $Q=1024$ the exact total rows are
- $\sum w_i^2=Q n_i$ and $\sum w_i^4=Q(3n_i^2-2n_i)$ by Sidon;
- $\sum w_i^2w_j^2=Qn_i n_j$ because same-layer distinct pair differences never recur in another layer;
- $\sum\prod_i w_i=0$ since four distinct layers cannot supply a zero-sum quadruple.

For the single $m=46$ shape, an explicit 16-entry integer combination in coverage.py has nonnegative value on all 1,296 signed, parity-admissible nonzero profiles and residual RHS $-135720$. (Its count row is included.) This rules the shape out.

For each of the two remaining nonhard $m=47$ shapes, independently translate any three quotient layers in $U$ by an affine shear plus common translation; the fourth translation is their XOR. Center every odd layer's XOR at zero, then force the first $e-1$ of the $e$ even layers to contain zero. Exactly three translations are specified. Even-layer XORs $g_i$ are translation-invariant. Up to changes of basis in their span there are 2 configurations for one even layer and 16 for three (introduce a new independent vector as the next basis element, otherwise take any previous span element). For a frequency $u$, the tag $b$ is its restriction to this span. Odd layers have $w_i\equiv n_i\bmod4$; even layers have $w_i\equiv n_i-2\langle b,g_i\rangle\bmod4$. The sum of each tag count is $Q/|\langle g_i\rangle|$; a rooted layer has $\sum_u w_i(u)=Q$.

The indicator signals on $U$ for the signed certificates are:
- $P_i=1_{S_i}$, and its complement $p_i$, with masses $n_i,Q-n_i$.
- $D_i=1_{\Delta S_i}$ for within-layer sums of distinct pairs, mass $\binom{n_i}{2}$. Its Walsh value is $(w_i^2-n_i)/2$. The four $D_i$ have disjoint supports; $d$ is the indicator of the complement of their union.
- $C_{ij}=1_{S_i+S_j}$, mass $n_i n_j$ and Walsh $w_iw_j$, because all these cross-sums are distinct. For each partition $0j|kl$, $C_{0j},C_{kl}$ have disjoint supports (no four-layer collision); $c_j$ is the complement of their union.

At $u\ne0$ the Fourier transform of a complement is the negative of the given signal or disjoint signal sum. **At zero instead use its full mass.** For any above indicator $T$ and any $h$ in the XOR span, $\sum_u(-1)^{u\cdot h}\widehat T(u)$ lies between 0 and $Q$ by Fourier inversion. For any two indicators $T,S$, the analogous Fourier sum with product $\widehat T\widehat S$ is $Q$ times their translate intersection cardinality, between 0 and $Q\min(|T|,|S|)$. These bounds also apply to a signal paired with itself.

Subtract the $u=0$ profile from all RHSs. Each stored certificate is an integer linear combination of equality and upper-bound rows, with nonnegative multipliers on inequalities, nonnegative value on every admissible tagged column and strictly negative residual RHS. The checker independently enumerates every required label configuration and every tagged column. A positive indicator/control replay on two rank-full subsamples of the explicit 66-Sidon example checks every active bound or equality; this also exercises nonconstant character signs and both the one-even-layer and three-even-layers normalizations. No floating-point output is used.

**Replay (Python 3.10+, standard library only):**

    python3 -O coverage.py
    python3 -O packed81check.py
    python3 -O control.py

The signed JSON file has 18 certificates. The $m=46$ plain certificate is embedded in coverage.py, so there are 19 finite separators in total. The residual shape $30,17,17,17$ requires a distinct argument not supplied here.
