#!/usr/bin/env python3
"""Rerun, not a compressed hash-only proof. WORK contains expendable generated files."""
import argparse,os,sys,subprocess as sp,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations
from collections import Counter
from functools import reduce
from operator import xor
ROOT=Path(__file__).resolve().parent
def ck(test,msg):
 if not test:raise ValueError(msg)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,**kw):return sp.run(args,check=True,**kw)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['audit','full','generators','q20','q21'],default='audit');ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--work',type=Path,default=ROOT/'WORK');a=ap.parse_args();work=a.work.resolve();work.mkdir(exist_ok=True,parents=True);os.chdir(work)
 def exe(s):return str(work/s)
 def build(s,f,more=()):run(['c++','-O3','-std=c++17',*more,str(ROOT/'src'/f),'-o',exe(s)])
 ss={'first':'gen81A.cpp','second':'gen81B.cpp','verify':'verifybases81.cpp','maps':'checkmaps81.cpp','mark1':'param_markB17oct.cpp','mark2':'param_markB17oct2.cpp','raw1':'join81batch.cpp','raw2':'join81batch2.cpp'}
 with ThreadPoolExecutor(max(1,a.jobs))as ex:list(ex.map(lambda k:build(k,ss[k]),ss))
 def checkcontrol():
  for k in [1,2]:build(f'plant{k}',ss[f'mark{k}'],['-DFINAL_CAP=17'])
  A=list(map(int,(ROOT/'plant47A.txt').read_text().split()));B=list(map(int,(ROOT/'plant47B.txt').read_text().split()));ck(reduce(xor,B)==0,'known centered B');z=A+[1024+x for x in B];ck(len({x^y for x,y in combinations(z,2)})==1081,'47 control is not Sidon')
  R=[]
  for e in ['plant1','plant2','mark1','mark2']:
   s=run([exe(e)],input=' '.join(map(str,A)),capture_output=True,text=True).stdout.splitlines();res={tuple(map(int,l.split()))for l in s[:-1]};ck(len(res)==int(s[-1].split()[1])==len(s)-1,'control endpoint stop');R.append(res)
  ck(R[0]==R[1] and len(R[0])==18 and tuple(B)in R[0] and tuple(B)not in R[2] and R[2]==R[3],'47 control replay');print('q20 positive 47: both recover all 18 relaxed-cap=17 opposite layers; target cap=13 rejects displayed layer.')
 raw=(ROOT/'d9.txt').read_text().splitlines();ck(digest(ROOT/'d9.txt')=='07437663dfc421d915982716164cdfaa407c5de02c6dc319fe6fd539b269c534','pinned source changed');S={q:[l for l in raw if len(l.split())==q]for q in [20,21]};ck([len(S[q])for q in [20,21]]==[1681,738],'incomplete anchor inputs')
 counts={q:[list(map(int,x.split()))for x in (ROOT/f'ledger/generated{q}.txt').read_text().splitlines()]for q in S};lt=(ROOT/'ledger/q21_batch.txt').read_text().splitlines();c20=(ROOT/'ledger/q20_end.txt').read_text().splitlines()
 for q,ct in counts.items():ck([v[0]for v in ct]==list(range(len(S[q])))and all(0<=z<=y for i,y,z in ct),'incomplete generator ledger')
 ck([sum(t[j]for t in counts[q])for q in S for j in (1,2)]==[60338,60338,34115749,787461],'bad raw input totals')
 def parts(s):return list(map(int,s.split()[1:]))
 xyz=[parts(s)for s in lt];ck(len(lt)==738 and [sum(z[i]for z in xyz)for i in (0,1,2,4,5)]==[787461,10369060,48820,126,0] and max(z[3]for z in xyz)==14,'bad raw join ledger')
 pts=(ROOT/'ledger/positive47.txt').read_text().splitlines();ck(len(pts)==126,'positive joins missing');freq=Counter()
 for l in pts:
  i,j,k,m,*v=map(int,l.split());ck(len(v)==47 and len({x^y for x,y in combinations(v,2)})==1081,'not a true 47-join');h=max(max(r,47-r)for t in range(1,2048) for r in [sum((t&x).bit_count()%2 for x in v)]);ck(h==m>30,'spurious hyperplane rejection');freq[h]+=1
 print('Maximum sections among 126 marked positive 47 controls:',freq)
 ck(len(c20)==475 and all(x.split()[:2]==['metrics','0']for x in c20)and [sum(parts(z)[j]for z in c20)for j in (1,2)]==[7345317,13891],'bad q20 ledger')
 for s in ('coverage.py','packed81check.py','control.py'):run([sys.executable,'-O',s],cwd=ROOT/'quarter')
 checkcontrol()
 if a.stage=='audit':print('Frozen ledgers, exact Walsh certificates and positive controls passed. Use --stage full to recompute negative searches.');return
 if a.stage in ('full','generators','q20','q21'):
  Q=[20]if a.stage=='q20'else [21]if a.stage=='q21'else [20,21]
  def generate(qi):
   q,i=qi;l=S[q][i];b=30-q;k=2*q-30;d=48-q-2*b;pa=work/f'a{q}_{i}';pb=work/f'b{q}_{i}';c=work/f's{q}_{i}';c.write_text(l+'\n');args=['48','30',str(b),str(b),str(d),str(k),str(k)]
   for e,ls,f in [('first',args,pa),('second',[],pb)]:
    with f.open('w')as out:r=run([exe(e),*ls],input=l,text=True,stdout=out,stderr=-1)
    v=r.stderr.split();ck([int(v[-3]),int(v[-1])]==counts[q][i][1:],f'generator counts {q},{i},{e}')
   r=run([exe('verify'),str(q),str(pa),str(pb)],capture_output=True,text=True);ck(r.stdout.strip()=='equal '+str(counts[q][i][-1]),'normalized basis-set disagreement')
   if q==21 and a.stage!='generators':
    ys=[list(map(int,l.split()[1:]))for l in pts_for[i]];exp=sorted(ys)
    for e,f in [('raw1',pa),('raw2',pb)]:
     with f.open()as inp:r=run([exe(e),str(c)],stdin=inp,capture_output=True,text=True).stdout.splitlines()
     ck(r[-1]==lt[i],f'incomplete/wrong q21 {i} {e}');obs=sorted(list(map(int,s.split()[1:]))for s in r[:-1]);ck(obs==([]if e=='raw1'else exp),f'positive control q21 {i} {e}')
   return qi
  pts_for={i:[]for i in range(738)}
  for l in pts:
   sp0=l.split(maxsplit=1);pts_for[int(sp0[0])].append('w '+sp0[1])
  cases=[(q,i)for q in Q for i in range(len(S[q]))]
  with ThreadPoolExecutor(max(1,a.jobs))as ex:
   for k,_ in enumerate(ex.map(generate,cases),1):
    if k%200==0:print(k,'/',len(cases),'independently replayed sources',flush=True)
  if 20 in Q and a.stage!='generators':
   all20=work/'all20'
   with all20.open('wb')as out:
    for i in range(1681):out.write((work/f'a20_{i}').read_bytes())
   run([exe('maps'),str(all20),str(ROOT/'representatives20.txt'),str(ROOT/'maps20.bin'),'20'])
   def endpoint(x):
    i,l=x
    for e in ['mark1','mark2']:
     r=run([exe(e)],input=l,text=True,capture_output=True).stdout.splitlines();ck(len(r)==1,'unexpected q20 candidate');v=r[-1].split();ck(v[::2]==['candidates','prefixes','large']and list(map(int,v[1::2]))==parts(c20[i]),f'wrong endpoint {i} {e}')
   reps=(ROOT/'representatives20.txt').read_text().splitlines();ck(len(reps)==475,'wrong q20 representatives')
   with ThreadPoolExecutor(max(1,a.jobs))as ex:list(ex.map(endpoint,enumerate(reps)))
  print('Replay complete:',a.stage)
if __name__=='__main__':main()
