#ifdef NDEBUG
#error assertions on
#endif
#include<bits/stdc++.h>
using namespace std;using U=uint64_t;struct R{array<int,30>s;int shade[30];unsigned char ix[1024];array<U,30>v;};
U mix(U z){z+=0x9e3779b97f4a7c15ULL;z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
U sig(R&s){int hits[1024]={};for(int i=0;i<30;i++)for(int j=0;j<i;j++)for(int k=0;k<j;k++)hits[s.s[i]^s.s[j]^s.s[k]]++;
 U edge[30][30]={};for(int i=0;i<30;i++)for(int j=0;j<i;j++){U v=0;for(int a:s.s)v+=mix(hits[s.s[i]^s.s[j]^a]);edge[i][j]=edge[j][i]=mix(v);}
 U color[30]={};for(int r=0;r<2;r++){U nw[30]={};for(int i=0;i<30;i++){for(int j=0;j<30;j++)nw[i]+=mix(color[j]^edge[i][j]);nw[i]=mix(nw[i]);}copy(nw,nw+30,color);}
 copy(color,color+30,s.v.begin());U h=0;for(auto z:s.v)h+=mix(z);return h;}
int Y[1024],P[1024],Q[1024];bool usedP[1024],usedQ[1024];int sp,tp;R *A,*B;
bool rec(int r){if(r==1024)return true;int pick=-1;vector<int>cand;
 for(int i=0;i<30;i++){int a=A->s[i]^sp;if(usedP[a])continue;vector<int>vv;for(int j=0;j<30;j++){int b=B->s[j]^tp;if(usedQ[b]||A->v[i]!=B->v[j])continue;bool ok=true;for(int k=0;k<r;k++){
  int ai=A->ix[a^P[k]^sp],bi=B->ix[b^Q[k]^tp];if((ai==255)!=(bi==255)||(ai!=255&&A->v[ai]!=B->v[bi])){ok=false;break;}}if(ok)vv.push_back(b);}
 if(vv.empty())return false;if(pick<0||vv.size()<cand.size()){pick=a;cand=vv;if(cand.size()==1)break;}}
 assert(pick>=0);for(int i=0;i<r;i++){P[r+i]=P[i]^pick;usedP[P[r+i]]=true;}
 for(int b:cand){for(int i=0;i<r;i++){Q[r+i]=Q[i]^b;usedQ[Q[r+i]]=true;}if(rec(r*2))return true;for(int i=r;i<2*r;i++)usedQ[Q[i]]=false;}
 for(int i=r;i<2*r;i++)usedP[P[i]]=false;return false;}
bool iso(R &a,R&b){A=&a;B=&b;sp=a.s[0];for(int j=0;j<30;j++)if(a.v[0]==b.v[j]){tp=b.s[j];memset(usedP,0,sizeof(usedP));memset(usedQ,0,sizeof(usedQ));P[0]=Q[0]=0;usedP[0]=usedQ[0]=true;if(rec(1)){for(int k=0;k<1024;k++)Y[P[k]]=Q[k];for(int x:a.s)assert(b.ix[Y[x^sp]^tp]!=255);return true;}}return false;}
int main(int ac,char**av){assert(ac==3);ofstream out(av[1]),maps(av[2],ios::binary);assert(out&&maps);unordered_map<U,vector<int>>by;vector<R>reps;map<int,int>ct;int rows=0;string l;while(getline(cin,l)){R a{};istringstream in(l);memset(a.ix,255,1024);for(int j=0;j<30;j++){assert(in>>a.s[j]);int x=a.s[j];assert(0<=x&&x<1024&&a.ix[x]==255);a.ix[x]=j;}int w;assert(!(in>>w));U key=sig(a);int cl=-1;bool fresh=false;for(auto i:by[key])if(iso(a,reps[i])){cl=i;break;}
 if(cl<0){fresh=true;cl=reps.size();reps.push_back(a);by[key].push_back(cl);for(auto x:a.s)out<<x<<' ';out<<endl;}if(fresh){sp=tp=0;for(int i=0;i<1024;i++)Y[i]=i;}
 uint32_t idx=cl;assert(idx==cl);maps.write((char*)&idx,4);uint16_t eq[11];for(int k=0;k<10;k++)eq[k]=Y[1<<k];eq[10]=Y[sp]^tp;
 for(int x:a.s){int w=eq[10];for(int k=0;k<10;k++)if(x>>k&1)w^=eq[k];assert(reps[cl].ix[w]!=255);}
 maps.write((char*)eq,22);assert(maps);ct[cl]++;rows++;}
 cout<<"rows "<<rows<<" classes "<<reps.size()<<" multiplicities";for(auto z:ct)cout<<" "<<z.second;cout<<endl;}
