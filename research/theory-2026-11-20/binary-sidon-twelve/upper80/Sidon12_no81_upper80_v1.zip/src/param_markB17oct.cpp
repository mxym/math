#ifndef FINAL_CAP
#define FINAL_CAP 13
#endif
#include <set>
#ifdef NDEBUG
#error "The replay requires assertions to be enabled."
#endif
#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include <utility>
#include <cmath>
using namespace std;using W=unsigned long long;
constexpr int D=512,B=6;
void inc(long long &v){assert(v<LLONG_MAX);++v;}
struct Bits{W w[B]={};
 void add(int i){w[i/64]|=W(1)<<(i%64);}void rem(int i){w[i/64]&=~(W(1)<<(i%64));}
 int first(int s=0)const{for(int i=s/64;i<B;i++)if(w[i])return i*64+__builtin_ctzll(w[i]);return -1;}
 int size()const{int c=0;for(auto a:w)c+=__builtin_popcountll(a);return c;}};
int id[D],v[D],n,need,sel[64],M,capmax,goal,m0;bool forbid[D];int Awt[D];vector<int> C;Bits adj[D];
struct Layer{array<uint16_t,12> s{};array<W,8>d{};};vector<Layer> cur;
long long nodes=0,fin=0,fit=0;
array<array<W,8>,D> signs;array<W,8> exactp[21]; W QMon[1024];
void prepmon(){for(int x=0;x<1024;x++){int i=0;W z=0;for(int a=0;a<10;a++){if(x>>a&1)z|=1ull<<i;i++;}for(int a=0;a<10;a++)for(int b=a+1;b<10;b++){if((x>>a&1)&&(x>>b&1))z|=1ull<<i;i++;}assert(i==55);QMon[x]=z;}}
bool selectedQuad;
bool qokay(const vector<int>&s,int a,int b){ // Only used if the first full layer is a maximal global slice and its opposite odd.
 int w[1024]={};for(int x:C)w[x]=1;for(int x:s)w[512+x]=1;
 for(int h=1;h<1024;h*=2)for(int i=0;i<1024;i+=2*h)for(int j=i;j<i+h;j++){int x=w[j],y=w[j+h];w[j]=x+y;w[j+h]=x-y;}
 W rows[55]={};int t=a+b,r=goal-t,hi=2*m0-goal;assert(r%2);
 for(int u=1;u<1024;u++){int U=hi-abs(w[u]);int f=-1;bool fixed=true;
  for(int v=-U;v<=U;v++)if((r-v)%4==0){int g=((r-v)/4)&1;if(f<0)f=g;else if(f!=g){fixed=false;break;}}
  if(f<0)return false;if(!fixed)continue;W z=QMon[u]|(W(f)<<55);
  while(z){int i=__builtin_ctzll(z);if(i==55)return false;if(rows[i])z^=rows[i];else{rows[i]=z;break;}}
 }return true;}
void emit(int k){
 inc(fin);int d=v[sel[1]];vector<int>s,t;for(int j=0;j<k;j++){s.push_back(v[sel[j]]);t.push_back(v[sel[j]]^d);}sort(s.begin(),s.end());sort(t.begin(),t.end());if(t<s)return;
 if(selectedQuad&&!qokay(s,C.size(),k))return;inc(fit);Layer u;for(int j=0;j<k;j++){u.s[j]=s[j];for(int i=0;i<j;i++){int x=s[i]^s[j];u.d[x/64]|=W(1)<<(x%64);}}cur.push_back(u);}
using Reg=array<array<W,8>,4>;
bool advance(const Reg&r,int x,int k,Reg&z){
 if(k>=need-3){ // w(u)=k-2*p(u), and |w_final|<=M-|Awt|.
  for(int j=0;j<8;j++){W a=r[0][j],b=r[1][j],c=r[2][j],d=r[3][j],h=signs[x][j];
   W k1=a&h,k2=b&k1,k3=c&k2;z[0][j]=a^h;z[1][j]=b^k1;z[2][j]=c^k2;z[3][j]=d^k3;
   a=z[0][j];b=z[1][j];c=z[2][j];d=z[3][j];
   for(int p=0;p<=k;p++){int ab=abs(k-2*p)-(need-k);if(ab<=0)continue;W bad=exactp[ab][j];if(!bad)continue;
    if(bad&(p&1?a:~a)&(p&2?b:~b)&(p&4?c:~c)&(p&8?d:~d))return false;}
  }
 }else for(int j=0;j<8;j++){W a=r[0][j],b=r[1][j],c=r[2][j],d=r[3][j],h=signs[x][j],k1=a&h,k2=b&k1;z[0][j]=a^h;z[1][j]=b^k1;z[2][j]=c^k2;z[3][j]=d^(c&k2);}
 return true;}
void dfs(Bits P,int k,const Reg&r){
 inc(nodes);if(k==need){emit(k);return;}int t=need-k;if(P.size()<t)return;
 int ls[B*64],cs[B*64],z=0,c=0;Bits av=P;
 while(av.first()>=0){c++;Bits Q=av;for(int x=Q.first();x>=0;x=Q.first(x)){ls[z]=x;cs[z++]=c;av.rem(x);Q.rem(x);for(int w=x/64;w<B;w++)Q.w[w]&=~adj[x].w[w];}}
 while(z){--z;if(cs[z]<t)return;int x=ls[z];P.rem(x);Reg rr;if(!advance(r,v[x],k+1,rr))continue;Bits Q;
  for(int j=0;j<B;j++)Q.w[j]=P.w[j]&adj[x].w[j];
  for(int i=0;i<k;i++)for(int j=0;j<i;j++){int h=id[v[x]^v[sel[i]]^v[sel[j]]];if(h>=0)Q.rem(h);}
  sel[k]=x;dfs(Q,k+1,rr);
 }}
vector<Layer> gen(int k,int limit,bool quad){
 selectedQuad=quad;need=k;M=limit;cur.clear();nodes=fin=fit=0;vector<Layer> em;
 for(int u=1;u<D;u++)if(abs(Awt[u])>M-k%2)return em;
 for(auto &e:exactp)e.fill(0);
 for(int u=1;u<D;u++)for(int v=1;v<=k;v++)if(abs(Awt[u])+v>M)exactp[v][u/64]|=W(1)<<(u%64);
 for(int i=0;i<n;i++){adj[i]={};for(int j=1;j<n;j++)if(!forbid[v[i]]&&!forbid[v[j]]&&!forbid[v[i]^v[j]])adj[i].add(j);}
 for(int d=1;d<n;d++){
  Bits P=adj[d];for(int h=1;h<=d;h++)P.rem(h);Reg zero{},start;sel[0]=0;sel[1]=d;
  if(P.size()>=k-2 && advance(zero,v[d],2,start))dfs(P,2,start);
  for(int i=d+1;i<n;i++){int j=id[v[i]^v[d]];if(j>d)adj[i].rem(j);}
 }
 fprintf(stderr," k%d/M%d nodes%lld leaf%lld classes%zu;",k,limit,nodes,fin,cur.size());return move(cur);}

vector<int>AO,U0;int histo[1024];set<vector<int>>results;long long large=0,pairs0=0;
void fwt(int *w,int n){for(int h=1;h<n;h*=2)for(int i=0;i<n;i+=2*h)for(int j=i;j<i+h;j++){int p=w[j],q=w[j+h];w[j]=p+q;w[j+h]=p-q;}}
void tailpick(const vector<int>&H,int pos,int need,W *used,vector<int>&top,vector<int>&bottom){
 if(!need){int arr[1024]={};for(int x:top)arr[x]=1;for(int x:bottom)arr[512+x]=1;fwt(arr,1024);for(int u=1;u<1024;u++)if(abs(arr[u])+abs(histo[u])>FINAL_CAP)return;
  vector<int>R=top;for(int x:bottom)R.push_back(512+x);int t=0;for(int x:R)t^=x;for(auto&x:R)x^=t;sort(R.begin(),R.end());results.insert(R);return;}
 for(int j=pos;j+need<=H.size();j++){int x=H[j];W f[8];copy(used,used+8,f);bool good=true;for(int y:bottom){int z=x^y;if(f[z/64]>>(z%64)&1){good=false;break;}f[z/64]|=W(1)<<(z%64);}if(!good)continue;bottom.push_back(x);tailpick(H,j+1,need-1,f,top,bottom);bottom.pop_back();}
}
int main(){prepmon();for(int x=0;x<D;x++)for(int u=1;u<D;u++)if(__builtin_parity(x&u))signs[x][u/64]|=W(1)<<(u%64);string line;
 while(getline(cin,line)){istringstream in(line);C.clear();U0.clear();AO.clear();results.clear();int x;while(in>>x){AO.push_back(x);if(x<512)C.push_back(x);else U0.push_back(x^512);}assert(AO.size()==30);int a=C.size();assert(a==20||a==21);fill(begin(histo),end(histo),0);for(int x:AO)histo[x]=1;fwt(histo,1024);
 fill(begin(forbid),end(forbid),false);fill(begin(id),end(id),-1);for(auto& A:{C,U0})for(int x:A)for(int y:A)forbid[x^y]=true;
 vector<pair<int,int>>V;for(int x=1;x<D;x++)if(!forbid[x]){int z=0;for(int y=1;y<D;y++)if(!forbid[y]&&!forbid[x^y])z++;V.emplace_back(-z,x);}sort(V.begin(),V.end());n=1;v[0]=0;id[0]=0;for(auto [q,x]:V){v[n]=x;id[x]=n++;}assert(n<=B*64);
 for(int u=0;u<D;u++){int z=0;for(int x:C)z+=__builtin_parity(u&x)?-1:1;Awt[u]=z;}
 bool AA[512]={};for(int x:C)for(int y:U0)AA[x^y]=true;array<array<W,8>,512>mask;for(int t=0;t<512;t++){mask[t].fill(0);for(int u=0;u<512;u++)if(!AA[u^t])mask[t][u/64]|=W(1)<<(u%64);}
 large=0;pairs0=0;for(int k=9;k<=30-a;k++){int cap=(a+k==30)?2*a-30:13;auto L=gen(k,cap,false);for(auto&l:L){vector<int>H;W F[8]={};for(int x=0;x<512;x++)if(forbid[x])F[x/64]|=W(1)<<(x%64);
  vector<int>top(l.s.begin(),l.s.begin()+k),bot;for(int h=0;h<8;h++){F[h]|=l.d[h];W w=~W(0);for(int t:top)w&=mask[t][h];while(w){H.push_back(64*h+__builtin_ctzll(w));w&=w-1;}}pairs0++;if(H.size()>=17-k){large++;tailpick(H,0,17-k,F,top,bot);}
 }}
 for(auto&S:results){for(int x:S)cout<<x<<" ";cout<<endl;}cout<<"candidates "<<results.size()<<" prefixes "<<pairs0<<" large "<<large<<endl;
 }}
