#ifdef NDEBUG
#error keep assertions
#endif
#include<bits/stdc++.h>
using namespace std;using P=array<int,9>;using W=uint64_t;struct T{P x;W mask[8]{};};vector<T> R;vector<int>C;int U[8],aa[9],bb[9];W fixedD[8];long long paths,h8,good,finals;int peak;
void complete(vector<int> v,int k,const array<W,8>&D,int i,int j){if(k==8){++good;vector<int> pts=C;for(int a:aa)pts.push_back(512+a);for(int b:bb)pts.push_back(1024+b);for(int x:U)pts.push_back(1536+x);bool used[2048]={};for(int r=0;r<47;r++)for(int h=0;h<r;h++){int z=pts[r]^pts[h];assert(z&&!used[z]);used[z]=true;}
 int maxh=0;for(int t=1;t<2048;t++){int c=0;for(int a:pts)c+=__builtin_parity(t&a);maxh=max({maxh,c,47-c});}
 cout<<"w "<<i<<" "<<j<<" "<<maxh;for(int a:pts)cout<<" "<<a;cout<<"\n";if(maxh<=30)finals++;return;}
 while(int(v.size())>=8-k){int y=v.back();v.pop_back();auto D0=D;bool ok=true;for(int t=0;t<k;t++){int z=U[t]^y;if(D0[z>>6]>>(z&63)&1){ok=false;break;}D0[z>>6]|=1ull<<(z&63);}if(!ok)continue;U[k]=y;vector<int>n;for(int w:v){int t=0;for(;t<=k;t++){int z=w^U[t];if(D0[z>>6]>>(z&63)&1)break;}if(t==k+1)n.push_back(w);}complete(n,k+1,D0,i,j);}}
int main(int argc,char**argv){assert(argc==2);ifstream f(argv[1]);int t;while(f>>t)C.push_back(t);assert(C.size()==21);for(int x:C)for(int y:C)fixedD[(x^y)>>6]|=1ull<<((x^y)&63);string line;while(getline(cin,line)){istringstream in(line);int x;for(int a:C){assert(in>>x);assert(x==a);}T z;for(auto&v:z.x){assert(in>>v);v-=512;assert(0<=v&&v<512);}assert(!(in>>x));P best;best.fill(999);for(int u:z.x){auto r=z.x;for(auto&b:r)b^=u;sort(r.begin(),r.end());best=min(best,r);}z.x=best;
 for(int a:best)for(int b:best)if(a<b){x=a^b;assert(!(fixedD[x>>6]>>(x&63)&1)&&!(z.mask[x>>6]>>(x&63)&1));z.mask[x>>6]|=1ull<<(x&63);}R.push_back(z);}
 sort(R.begin(),R.end(),[](auto&a,auto&b){return a.x<b.x;});for(int i=1;i<R.size();i++)assert(R[i].x!=R[i-1].x);unsigned char lut[8][256]={};for(int s=0;s<8;s++)for(int v=0;v<256;v++)for(int b=0;b<8;b++)if(v&(1<<b))lut[s][v]|=1<<(b^s);
 for(int i=0;i<R.size();i++){unsigned char hole[64];memset(hole,255,64);for(int x:C)for(int a:R[i].x){int z=x^a;hole[z>>3]&=~(1<<(z&7));}W tbl[512][8];for(int a=0;a<512;a++)for(int b=0;b<8;b++){W w=0;for(int h=0;h<8;h++)w|=W(lut[a&7][hole[(b*8+h)^(a>>3)]])<<(h*8);tbl[a][b]=w;}
 for(int j=0;j<R.size();j++){int k=0;for(;k<8;k++)if(R[i].mask[k]&R[j].mask[k])break;if(k<8)continue;++paths;W mask[8];int cnt=0;for(int z=0;z<8;z++){W m=~W(0);for(int a:R[j].x)m&=tbl[a][z];mask[z]=m;cnt+=__builtin_popcountll(m);}peak=max(peak,cnt);if(cnt<8)continue;h8++;
 vector<int>v;array<W,8>D;for(int h=0;h<8;h++){D[h]=R[i].mask[h]|R[j].mask[h]|fixedD[h];for(int b=0;b<64;b++)if(mask[h]>>b&1)v.push_back(64*h+b);}copy(R[i].x.begin(),R[i].x.end(),aa);copy(R[j].x.begin(),R[j].x.end(),bb);complete(v,0,D,i,j);}}
 cout<<"complete "<<R.size()<<" "<<paths<<" "<<h8<<" "<<peak<<" "<<good<<" "<<finals<<"\n";}
