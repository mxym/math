#ifdef NDEBUG
#error assertions required
#endif
#include<bits/stdc++.h>
using namespace std;using Row=array<int,30>;
Row readrow(string l){istringstream s(l);Row a;bitset<1024>seen;for(int&x:a){assert(s>>x);assert(x>=0&&x<1024&&!seen[x]);seen[x]=1;}int x;assert(!(s>>x));sort(a.begin(),a.end());return a;}
int main(int ac,char**av){assert(ac==5);ifstream inp(av[1]),reps(av[2]),matrix(av[3],ios::binary);assert(inp&&reps&&matrix);int q=stoi(av[4]);vector<Row>R;string l;while(getline(reps,l)){auto a=readrow(l);assert(count_if(a.begin(),a.end(),[](int x){return x<512;})==q);R.push_back(a);}
 vector<long long>mult(R.size());int rows=0;while(getline(inp,l)){auto a=readrow(l);assert(count_if(a.begin(),a.end(),[](int x){return x<512;})==q);uint32_t id=0;uint16_t Y[11];assert(matrix.read((char*)&id,4));assert(matrix.read((char*)Y,22));assert(id<R.size());mult[id]++;for(int i=0;i<=10;i++)assert(Y[i]<1024);
 int lin[10]={};for(int i=0;i<10;i++){int z=Y[i];while(z){int b=31-__builtin_clz(z);if(lin[b])z^=lin[b];else{lin[b]=z;break;}}assert(z);}
 for(int &x:a){int y=Y[10];for(int j=0;j<10;j++)if(x&(1<<j))y^=Y[j];x=y;}sort(a.begin(),a.end());assert(a==R[id]);rows++;}
 assert(matrix.get()==EOF);for(auto n:mult)assert(n>0);cout<<"verified "<<rows<<" affine bijections onto "<<R.size()<<" representatives\n";}
