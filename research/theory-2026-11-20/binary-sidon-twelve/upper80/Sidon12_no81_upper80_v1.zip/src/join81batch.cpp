#ifdef NDEBUG
#error assertions required
#endif
#include<bits/stdc++.h>
using namespace std;using W=uint64_t;using M=array<W,8>;
struct S{array<int,9>x;M D{};};vector<int>C;vector<S>L;M Delta{};long long pairs=0,large=0,legal=0,walsh=0;int maxhole=0;array<array<W,8>,512> shiftH;
int cross[512],wA[1024],depth[8];void fwt(int *a,int n){for(int h=1;h<n;h*=2)for(int i=0;i<n;i+=h*2)for(int j=i;j<i+h;j++){int l=a[j],r=a[j+h];a[j]=l+r;a[j+h]=l-r;}}
array<int,9> canon(array<int,9> a){auto b=a;for(int t:a){auto c=a;for(auto&x:c)x^=t;sort(c.begin(),c.end());b=min(b,c);}return b;}
void pick(int i,int j,const vector<int>&H,int start,int k,const M&D){if(k==8){legal++;int u[1024]={};for(int x:L[j].x)u[x]=1;for(int x:depth)u[x+512]=1;fwt(u,1024);for(int t=1;t<1024;t++)if(abs(u[t])+abs(wA[t])>13)return;walsh++;cout<<"hit "<<i<<" "<<j;for(int x:depth)cout<<" "<<x;cout<<"\n";return;}
 for(int a=start;a+8-k<=int(H.size());a++){int x=H[a];M T=D;bool ok=true;for(int t=0;t<k;t++){int z=x^depth[t];if((T[z>>6]>>(z&63))&1){ok=false;break;}T[z>>6]|=W(1)<<(z&63);}if(ok){depth[k]=x;pick(i,j,H,a+1,k+1,T);}}}
int main(int ac,char**av){assert(ac==2);ifstream src(av[1]);assert(src);int x;for(int i=0;i<21;i++){assert(src>>x);C.push_back(x);}int y;assert(!(src>>y));for(int u:C)for(int v:C)Delta[(u^v)/64]|=W(1)<<((u^v)%64);
 string l;while(getline(cin,l)){istringstream in(l);for(int a:C){assert(in>>x);assert(x==a);}S r;for(auto&v:r.x){assert(in>>v);v-=512;assert(v>=0&&v<512);}assert(!(in>>y));r.x=canon(r.x);for(int j=0;j<9;j++)for(int i=0;i<j;i++){int z=r.x[i]^r.x[j];assert(!(r.D[z>>6]>>(z&63)&1)&&!(Delta[z>>6]>>(z&63)&1));r.D[z>>6]|=W(1)<<(z&63);}L.push_back(r);}
 sort(L.begin(),L.end(),[](auto&a,auto&b){return a.x<b.x;});for(int i=1;i<L.size();i++)assert(L[i-1].x!=L[i].x);int n=L.size(),w=(n+63)/64;
 vector<vector<W>>conf(512,vector<W>(w));for(int i=0;i<n;i++)for(int a:L[i].x)for(int b:L[i].x)if(a<b)conf[a^b][i>>6]|=W(1)<<(i&63);
 for(int i=0;i<n;i++){M base; base.fill(~W(0));for(int y:C)for(int z:L[i].x)base[(y^z)>>6]&=~(W(1)<<((y^z)&63));
 memset(wA,0,sizeof(wA));for(int a:C)wA[a]=1;for(int a:L[i].x)wA[512+a]=1;fwt(wA,1024);
 for(int z=0;z<512;z++)for(int j=0;j<8;j++){W a=base[j^(z>>6)];for(auto [t,m]:{pair<int,W>{1,0x5555555555555555ull},{2,0x3333333333333333ull},{4,0x0f0f0f0f0f0f0f0full},{8,0x00ff00ff00ff00ffull},{16,0x0000ffff0000ffffull},{32,0x00000000ffffffffull}})if(z&t)a=((a&m)<<t)|((a>>t)&m);shiftH[z][j]=a;}
 vector<W> cand(w,~W(0));if(n%64)cand[w-1]=(W(1)<<(n%64))-1;for(int a:L[i].x)for(int b:L[i].x)if(a<b){auto&g=conf[a^b];for(int j=0;j<w;j++)cand[j]&=~g[j];}
 for(int z=0;z<w;z++)for(W mask=cand[z];mask;mask&=mask-1){int j=z*64+__builtin_ctzll(mask);assert(i!=j);pairs++;M h;h.fill(~W(0));for(int b:L[j].x)for(int t=0;t<8;t++)h[t]&=shiftH[b][t];int s=0;for(W f:h)s+=__builtin_popcountll(f);maxhole=max(maxhole,s);if(s<8)continue;large++;vector<int> H;M used=Delta;for(int t=0;t<8;t++){used[t]|=L[i].D[t]|L[j].D[t];for(W v=h[t];v;v&=v-1)H.push_back(t*64+__builtin_ctzll(v));}pick(i,j,H,0,0,used);}
 }
 cout<<"complete "<<n<<" "<<pairs<<" "<<large<<" "<<maxhole<<" "<<legal<<" "<<walsh<<"\n";
}
