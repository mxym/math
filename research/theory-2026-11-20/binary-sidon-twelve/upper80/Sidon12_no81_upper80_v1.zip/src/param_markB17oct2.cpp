#ifndef FINAL_CAP
#define FINAL_CAP 13
#endif
#include <set>
#ifdef NDEBUG
#error "The replay requires assertions to be enabled."
#endif
#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include <utility>
#include <cmath>
using namespace std;using R=uint64_t;
void inc(long long &v){assert(v<LLONG_MAX);++v;}
constexpr int N=512,K=8;
using Words=array<R,K>;
void on(Words&a,int i){a[i>>6]|=R(1)<<(i&63);}void off(Words&a,int i){a[i>>6]&=~(R(1)<<(i&63));}
int first(const Words&a){for(int j=0;j<K;j++)if(a[j])return 64*j+__builtin_ctzll(a[j]);return -1;}
int pop(const Words&a){int n=0;for(R x:a)n+=__builtin_popcountll(x);return n;}
bool disjoint(const Words&a,const Words&b){for(int j=0;j<K;j++)if(a[j]&b[j])return false;return true;}
struct Layer{array<uint16_t,12>x{};Words dif{};};vector<int>C;
bool bad[N];int want,lim,half,tot;int s[20];Words nb[N];vector<Layer> found;uint64_t nodes=0;
alignas(64) int8_t sign2[N][N],vsum[20][N],allow[20][N];int coeff[N];
bool extend(int x,int k){int good=0;
 for(int u=0;u<N;u++){int a=vsum[k-1][u]+sign2[x][u];vsum[k][u]=a;good|=abs(a)>allow[k][u];}
 return !good;}
void accept(int k){
 int d=s[1];array<int,12>a{},b{};for(int i=0;i<k;i++){a[i]=s[i];b[i]=s[i]^d;}sort(a.begin(),a.begin()+k);sort(b.begin(),b.begin()+k);
 if(a>b)return;Layer l;for(int i=0;i<k;i++){l.x[i]=a[i];for(int j=0;j<i;j++)on(l.dif,a[i]^a[j]);}found.push_back(l);}
void visit(Words P,int k){
 ++nodes;if(k==want){accept(k);return;}int t=want-k;
 int nv=pop(P);if(nv<t)return;
 // Keep t-1 stable color classes; every t-clique intersects the uncolored residual set.
 Words rem=P;for(int col=1;col<t;col++){if(first(rem)<0)return;Words st=rem;
  for(int u=first(st);u>=0;u=first(st)){off(st,u);off(rem,u);for(int w=0;w<8;w++)st[w]&=~nb[u][w];}}
 for(int u=first(rem);u>=0;u=first(rem)){off(rem,u);off(P,u);if(!extend(u,k+1))continue;Words Q;for(int j=0;j<K;j++)Q[j]=P[j]&nb[u][j];
  for(int i=0;i<k;i++)for(int j=0;j<i;j++)off(Q,u^s[i]^s[j]);s[k]=u;visit(Q,k+1);}
}
vector<Layer> listing(int k,int bound){
 want=k;lim=bound;nodes=0;found.clear();
 for(int u=1;u<N;u++)if(abs(coeff[u])+k%2>lim)return {};
 for(int l=0;l<=k;l++){allow[l][0]=100;for(int u=1;u<N;u++)allow[l][u]=lim-abs(coeff[u])+k-l;}
 for(int u=0;u<N;u++)vsum[1][u]=1;
 // d is least (plain numerical value) nonzero difference. Translate its endpoints to 0,d;
 // all other point differences strictly exceed d. The two translations are distinguished at the leaf.
 for(int d=1;d<N;d++)if(!bad[d]){Words V{};
  for(int x=d+1;x<N;x++)if(!bad[x]&&!bad[x^d]&&(x^d)>d)on(V,x);if(pop(V)<k-2)continue;
  for(Words T=V;;){int x=first(T);if(x<0)break;off(T,x);nb[x]={};
   for(Words it=V;;){int y=first(it);if(y<0)break;off(it,y);if((x^y)>d&&!bad[x^y])on(nb[x],y);}}
  s[0]=0;s[1]=d;if(extend(d,2))visit(V,2);
 }
 fprintf(stderr," %d:%zu",k,found.size());return move(found);}

vector<int>A,U,C0;int whole[1024];set<vector<int>> ans;
void search(const vector<int>&pref,const vector<int>&P,int goal,vector<int>&Q,Words mask){
 if(goal==0){vector<int>S=pref;for(int q:Q)S.push_back(q+512);assert(S.size()==17);int t=0;for(int x:S)t^=x;
  for(int h=1;h<1024;h++){int w=0;for(int x:S)w+=__builtin_parity(h&x)?-1:1;if(abs(w)+abs(whole[h])>FINAL_CAP)return;}
  for(auto&v:S)v^=t;sort(S.begin(),S.end());ans.insert(S);return;}
 for(int p=0;p+goal<=P.size();p++){int x=P[p];Words f=mask;bool ok=true;for(int y:Q){int a=x^y;if(f[a/64]>>(a%64)&1){ok=false;break;}on(f,a);}if(!ok)continue;
  vector<int>r;for(int i=p+1;i<P.size();i++){int a=P[i]^x;if(f[a/64]>>(a%64)&1)continue;bool good=true;for(int y:Q){int v=P[i]^y;if(f[v/64]>>(v%64)&1){good=false;break;}}if(good)r.push_back(P[i]);}Q.push_back(x);search(pref,r,goal-1,Q,f);Q.pop_back();}
}
int main(){for(int x=0;x<N;x++)for(int h=0;h<N;h++)sign2[x][h]=__builtin_parity(x&h)?-1:1;string l;
 while(getline(cin,l)){istringstream in(l);int x;A.clear();U.clear();C.clear();ans.clear();while(in>>x){A.push_back(x);if(x<512)C.push_back(x);else U.push_back(x-512);}assert(A.size()==30);int a=C.size();assert(a==20||a==21);
  Words init{};fill(bad,bad+N,false);for(const auto&v:{C,U})for(int x:v)for(int y:v){on(init,x^y);bad[x^y]=true;}
 for(int h=0;h<1024;h++){whole[h]=0;for(int x:A)whole[h]+=__builtin_parity(h&x)?-1:1;}
 for(int h=0;h<512;h++){coeff[h]=0;for(int x:C)coeff[h]+=sign2[x][h];}
 bool cross[512]={};for(int x:C)for(int y:U)cross[x^y]=true;long long n0=0,n1=0;
 for(int k=9;k<=30-a;k++){auto f=listing(k,(k+a==30)?2*a-30:13);for(auto&v:f){inc(n0);vector<int>top;for(int i=0;i<k;i++)top.push_back(v.x[i]);vector<int>P,Q;
 for(int x=0;x<512;x++){bool ok=true;for(int y:top)if(cross[x^y]){ok=false;break;}if(ok)P.push_back(x);}if(P.size()<17-k)continue;inc(n1);Words mask=init;for(int i=0;i<8;i++)mask[i]|=v.dif[i];search(top,P,17-k,Q,mask);}}
 for(const auto&s:ans){for(auto x:s)cout<<x<<" ";cout<<endl;}cout<<"candidates "<<ans.size()<<" prefixes "<<n0<<" large "<<n1<<endl;
 }}
