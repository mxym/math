#ifdef NDEBUG
#error assertions must remain enabled
#endif
#include<bits/stdc++.h>
using namespace std;
vector<vector<int>> rows(const string &f,int q){ifstream in(f);assert(in);string s;vector<vector<int>>all;while(getline(in,s)){istringstream l(s);vector<int>a;int x;for(int j=0;j<30;j++){assert(l>>x);if(j>=q){assert(512<=x&&x<1024);a.push_back(x-512);}}assert(!(l>>x));vector<int> best;for(int t:a){auto r=a;for(auto&z:r)z^=t;sort(r.begin(),r.end());if(best.empty()||r<best)best=r;}all.push_back(best);}sort(all.begin(),all.end());assert(adjacent_find(all.begin(),all.end())==all.end());return all;}
int main(int ac,char**av){assert(ac==4);int q=stoi(av[1]);auto p=rows(av[2],q),r=rows(av[3],q);assert(p==r);cout<<"equal "<<p.size()<<endl;}
