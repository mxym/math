#ifdef NDEBUG
#error "The replay requires assertions to be enabled."
#endif
#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include <utility>
#include <cmath>
using namespace std;using R=uint64_t;
void inc(long long &v){assert(v<LLONG_MAX);++v;}
constexpr int N=512,K=8;
using Words=array<R,K>;
void on(Words&a,int i){a[i>>6]|=R(1)<<(i&63);}void off(Words&a,int i){a[i>>6]&=~(R(1)<<(i&63));}
int first(const Words&a){for(int j=0;j<K;j++)if(a[j])return 64*j+__builtin_ctzll(a[j]);return -1;}
int pop(const Words&a){int n=0;for(R x:a)n+=__builtin_popcountll(x);return n;}
bool disjoint(const Words&a,const Words&b){for(int j=0;j<K;j++)if(a[j]&b[j])return false;return true;}
struct Layer{array<uint16_t,12>x{};Words dif{};};vector<int>C;
bool bad[N];int want,lim,half,tot;int s[20];Words nb[N];vector<Layer> found;uint64_t nodes=0;
alignas(64) int8_t sign2[N][N],vsum[20][N],allow[20][N];int coeff[N];
bool extend(int x,int k){int good=0;
 for(int u=0;u<N;u++){int a=vsum[k-1][u]+sign2[x][u];vsum[k][u]=a;good|=abs(a)>allow[k][u];}
 return !good;}
long long raw=0,valid=0;array<array<uint64_t,16>,1024> pos{};
bool okpeak(int k){if(k==10)return true;array<uint64_t,16>mask;mask.fill(~uint64_t(0));
for(int u=1;u<1024;u++){int w=coeff[u%512]+(u<512?1:-1)*vsum[k][u%512];if(abs(w)!=12)continue;
 uint64_t any=0;for(int j=0;j<16;j++){mask[j]&=(w<0?pos[u][j]:~pos[u][j]);any|=mask[j];}if(!any)return false;}return true;}
void accept(int k){
 int d=s[1];array<int,12>a{},b{};for(int i=0;i<k;i++){a[i]=s[i];b[i]=s[i]^d;}sort(a.begin(),a.begin()+k);sort(b.begin(),b.begin()+k);
 if(a>b)return;inc(raw);if(!okpeak(k))return;inc(valid);Layer l;for(int i=0;i<k;i++){l.x[i]=a[i];for(int j=0;j<i;j++)on(l.dif,a[i]^a[j]);}found.push_back(l);}
void visit(Words P,int k){
 ++nodes;if(k==want){accept(k);return;}int t=want-k;
 int nv=pop(P);if(nv<t)return;
 // Keep t-1 stable color classes; every t-clique intersects the uncolored residual set.
 Words rem=P;for(int col=1;col<t;col++){if(first(rem)<0)return;Words st=rem;
  for(int u=first(st);u>=0;u=first(st)){off(st,u);off(rem,u);for(int w=0;w<8;w++)st[w]&=~nb[u][w];}}
 for(int u=first(rem);u>=0;u=first(rem)){off(rem,u);off(P,u);if(!extend(u,k+1))continue;Words Q;for(int j=0;j<K;j++)Q[j]=P[j]&nb[u][j];
  for(int i=0;i<k;i++)for(int j=0;j<i;j++)off(Q,u^s[i]^s[j]);s[k]=u;visit(Q,k+1);}
}
vector<Layer> listing(int k,int bound){
 want=k;lim=bound;nodes=0;found.clear();
 for(int u=1;u<N;u++)if(abs(coeff[u])+k%2>lim)return {};
 for(int l=0;l<=k;l++){allow[l][0]=100;for(int u=1;u<N;u++)allow[l][u]=lim-abs(coeff[u])+k-l;}
 for(int u=0;u<N;u++)vsum[1][u]=1;
 // d is least (plain numerical value) nonzero difference. Translate its endpoints to 0,d;
 // all other point differences strictly exceed d. The two translations are distinguished at the leaf.
 for(int d=1;d<N;d++)if(!bad[d]){Words V{};
  for(int x=d+1;x<N;x++)if(!bad[x]&&!bad[x^d]&&(x^d)>d)on(V,x);if(pop(V)<k-2)continue;
  for(Words T=V;;){int x=first(T);if(x<0)break;off(T,x);nb[x]={};
   for(Words it=V;;){int y=first(it);if(y<0)break;off(it,y);if((x^y)>d&&!bad[x^y])on(nb[x],y);}}
  s[0]=0;s[1]=d;if(extend(d,2))visit(V,2);
 }
 fprintf(stderr," %d:%zu",k,found.size());return move(found);}
int main(){for(int x=0;x<N;x++)for(int u=0;u<N;u++)sign2[x][u]=__builtin_parity(u&x)?-1:1;
for(int u=0;u<1024;u++)for(int x=0;x<1024;x++)if(!__builtin_parity(x&u))pos[u][x>>6]|=uint64_t(1)<<(x&63);
int x;while(cin>>x)C.push_back(x);assert(C.size()==20||C.size()==21);for(int x:C)for(int y:C)bad[x^y]=true;
for(int u=0;u<N;u++){coeff[u]=0;for(int x:C)coeff[u]+=sign2[x][u];}
int q=C.size();auto R=listing(30-q,2*q-30);for(auto &r:R){for(int x:C)cout<<x<<" ";for(int i=0;i<30-q;i++)cout<<512+r.x[i]<<" ";cout<<"\n";}cerr<<" raw "<<raw<<" eligible "<<valid<<"\n";}
