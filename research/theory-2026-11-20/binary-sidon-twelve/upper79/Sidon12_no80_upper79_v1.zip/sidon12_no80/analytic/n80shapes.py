from itertools import combinations
def gap(d,n,m):
 q=1<<d;t=(2*m-n)**2;lo=n%2;return q*(3*n*n-2*n)-n**4-(lo+t)*(q*n-n*n)+lo*t*(q-1)
def ck(a): 
 if not a:raise ValueError('incomplete coverage')
S={(m,a,m-a,c,80-m-c) for m in range(40,48)if gap(12,80,m)<=0 for a in range((m+1)//2,35)if gap(11,m,a)<=0 for c in range((81-m)//2,35)if max(x+y for x,y in combinations((a,m-a,c,80-m-c),2))<=m}
ck(S=={(46,28,18,17,17),(46,28,18,18,16),(46,29,17,17,17),(47,29,18,17,16),(47,29,18,18,15),(47,30,17,17,16)})
print(sorted(S),'gap m<=45',gap(12,80,45))
