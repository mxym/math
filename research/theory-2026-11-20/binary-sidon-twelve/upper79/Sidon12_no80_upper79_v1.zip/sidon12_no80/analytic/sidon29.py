#!/usr/bin/env python3
"""No 29-point Sidon set in F2^10 has every affine half at most 19; stdlib only."""
from math import comb
def ck(v):
 if not v:raise ArithmeticError('29-point moment check failed')
n=29;D=1024;ws=[-7,-3,1,5,9]
# Distinct ws make the five moment equations nonsingular (Vandermonde).
for at,t in [(1,0)]+[(0,i)for i in range(10)]:
 f=[238,-21,540,84,182]if at else[386-12*t,32*t-229,724-24*t,4,138+4*t]
 rhs=[D-1,D*at-n,D*n-n*n,D*((3*n-2)*at+6*t)-n**3,D*(3*n*n-2*n)-n**4]
 ck([sum(v*w**j for v,w in zip(f,ws))for j in range(5)]==rhs);ck((min(f)>=0)==(at==0 and t in [8,9]))
# t=9 leaves two distinct representatives of XOR zero, so t=8.
terms={(0,3):-25,(1,3):25,(2,0):18,(2,2):-18,(3,0):-50,(3,1):30,(4,0):-40}
prof=[(z,l)for z in range(9)for l in [0,2,4]if -7<=4*z-3-2*l<=9]
coeff=[sum(v*comb(z,k)*comb(l,j)for(k,j),v in terms.items())for z,l in prof]
ck(len(prof)==14 and min(coeff)==0)
rhs={}
for k,j in terms:
 a=D*comb(8,k)*comb(5,j);b=4**k*2**j;ck(a%b==0);rhs[k,j]=a//b-(comb(8,k)if j==0 else 0)
ck(sum(terms[k]*rhs[k]for k in terms)==-88)
print('29-point moment certificate:', list(zip(prof,coeff)),'with total -88')
