from packed80check import E,points,chk
from itertools import combinations
from functools import reduce
from operator import xor
from pathlib import Path
import ast,json
def control():
 W=list(map(int,Path('control66.txt').read_text().split()));chk(len(W)==66 and len({x^y for x,y in combinations(W,2)})==2145)
 raw=json.loads(Path('packed80modes.json').read_text())
 for t in [(0,0,1,1),(0,0,0,0),(1,0,1,0),(1,0,0,1)]:
  e=t.count(0)
  feats=set().union(*(val['v']for k,val in raw.items()if tuple(i%2 for i in ast.literal_eval(k)[1])==t))
  # Find a small real sub-control with full rank on the e XORs of the even layers.
  found=False
  for j in combinations(range(16),4):
   S=[x for i,x in enumerate(W)if i not in j];L=[{x>>2 for x in S if x%4==i}for i in range(4)]
   # Match the order of parities used by the certificate.
   od=[l for l in L if len(l)%2];ed=[l for l in L if not len(l)%2]
   if len(ed)!=e:continue
   L=[od.pop()if j else ed.pop()for j in t]
   n=list(map(len,L));ev=[i for i in range(4)if n[i]%2==0];odd=[i for i in range(4)if n[i]%2]
   if len(ev)!=e:continue
   gg=[reduce(xor,L[i])for i in ev];gs=[reduce(xor,[x for j,x in enumerate(gg)if t>>j&1],0)for t in range(1<<e)]
   if len(set(gs))<1<<e:continue
   eq={i:reduce(xor,L[i])for i in odd}
   for i in ev[:len(ev)-1]:eq[i]=min(L[i])
   other,=set(range(4))-eq.keys();eq[other]=reduce(xor,eq.values(),0);L=[{x^eq[i]for x in l}for i,l in enumerate(L)]
   chk(all(reduce(xor,L[i])==0 for i in odd)and all(0 in L[i]for i in ev[:-1]));g=[1<<j for j in range(e)]
   sums={f:0 for f in feats};upper={};rhs={}
   for u in range(1024):
    b=sum(((x&u).bit_count()%2)<<j for j,x in enumerate(gg));w=[sum((-1)**((u&x).bit_count()%2)for x in l)for l in L];p,t=points(n,w,u==0)
    for f in feats:
     y,r,ub=E(f,n,g,w,b,u==0,p,t);sums[f]+=y;rhs[f]=r;upper[f]=ub
   chk(all(z<=rhs[f]if upper[f]else z==rhs[f] for f,z in sums.items()));found=True;print('control',n,'rank',e,'active arithmetic rows',len(feats));break
  chk(found)
if __name__=='__main__':control()
