#!/usr/bin/env python3
"""All timings depend on the available CPU. --stage full redoes actual enumeration."""
from pathlib import Path
from itertools import combinations
from concurrent.futures import ThreadPoolExecutor
from subprocess import run
import argparse,sys,re,hashlib,os,gzip
from types import SimpleNamespace
root=Path(__file__).resolve().parent
def ck(v,msg):
 if not v: raise ValueError(msg)
def gap(r,n,m):
 t=(2*m-n)**2;e=n%2;D=2**r;return D*(3*n**2-2*n)-n**4-(e+t)*(D*n-n*n)+e*t*(D-1)
def solve_parse(s,expected_hit,empty_by_walsh=False):
 out=s.stdout.splitlines();ck(out and out[-1]==f'hit {expected_hit}',f'search hit/termination {out}')
 if expected_hit:
  ck(len(out)==2,'plant returned unexpected number');return list(map(int,out[0].split()))
 ck(len(out)==1,'unexpected witness line');v=re.search(r'\bpairs\s*(\d+) holes\s*(\d+) maxhole(\d+)\s*$',s.stderr)
 if v is None:
  ck((not s.stderr.strip() and empty_by_walsh) or s.stderr.strip().endswith(('empty first','empty second','empty')) or re.fullmatch(r'\s*\d+:0\s*',s.stderr),'unrecognized empty completion: '+s.stderr);return 0,0,0
 return tuple(map(int,v.groups()))
def empty_by_walsh(lim,line):
 c=list(map(int,line.split()));w=[0]*512
 for x in c:w[x]=1
 h=1
 while h<512:
  for i in range(0,512,2*h):
   for j in range(i,i+h):w[j],w[j+h]=w[j]+w[j+h],w[j]-w[j+h]
  h*=2
 return max(abs(x)for x in w[1:])>lim
def test_sid(a,goal,maximum):
 ck(len(a)==goal==len(set(a))and all(0<=x<2048 for x in a),'invalid positive control')
 ck(len({v^u for v,u in combinations(a,2)})==goal*(goal-1)//2,'false Sidon control')
 z=[]
 for t in range(1,2048):
  s=sum((t&x).bit_count()%2 for x in a);z.append(max(s,goal-s))
 ck(max(z)<=maximum,'false maximum on control');return max(z)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['audit','full','46','47'],default='audit');ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--work',type=Path,default=root/'WORK');u=ap.parse_args();work=u.work.resolve();work.mkdir(exist_ok=True,parents=True)
 ck(gap(12,80,45)==4899840 and gap(12,79,44)==11401728,'wrong moment baseline')
 c=list(map(int,(root/'columns80_67.txt').read_text().split()));base={}
 for x in c:
  while x:
   j=x.bit_length()-1
   if j in base:x^=base[j]
   else:base[j]=x;break
 ck(len(c)==80 and len(set(c))==80 and min(c)>0 and max(c)<8192 and len(base)==13 and len({x^y for x,y in combinations([0]+c,2)})==3240,'bad explicit [80,67,>=5] check columns')
 f=root/'d9.txt';ck(hashlib.sha256(f.read_bytes()).hexdigest()=='07437663dfc421d915982716164cdfaa407c5de02c6dc319fe6fd539b269c534','wrong complete 9D census')
 raw=f.read_text().splitlines();S={n:[l for l in raw if len(l.split())==n-26]for n in[46,47]};ck(list(map(len,S.values()))==[1681,738],'incomplete source cover')
 for e in ['first','second']:run(['c++','-O3','-std=c++17',str(root/'src'/f'{e}.cpp'),'-o',str(work/e)],check=True)
 def search(e,n,limit,l):return run([str(work/e),str(n),str(limit),'9','9','8',str(n-35),str(n-35)],text=True,input=l,capture_output=True,check=True)
 for n in S:
  a=list(map(int,(root/f'positive{n}.txt').read_text().split()));m=test_sid(a,n,32);ck(m>n-17,'planted genuine set must be rejected at target')
  h=' '.join(str(x)for x in a if x<512);ck(len(h.split())==n-26,'plant has wrong anchor size');ck([sum(x//512==i for x in a)for i in range(4)]==[n-26,9,9,8],'plant has wrong layer profile')
  for e in ['first','second']:
   t=solve_parse(search(e,n,32,h),1);test_sid(t,n,32)
  print('Positive control',n,'has actual largest half',m,'and both engines recover genuine controls at relaxed bound 32.',flush=True)
 for p in ['sidon29.py','n80shapes.py','packed80check.py','control.py']:
  run([sys.executable,'-O',p],cwd=root/'analytic',check=True)
 ledger={}
 for n in S:
  v=[list(map(int,l.split()))for l in (root/f'ledger{n}.tsv').read_text().splitlines()]
  ck(len(v)==len(S[n])and all(len(q)==4 and 0<=q[2]<=q[1]and 0<=q[3]<=512 and q[0]==i for i,q in enumerate(v)),f'bad ledger {n}')
  ledger[n]=v;rr=gzip.decompress((root/f'raw{n}.tsv.gz').read_bytes()).decode().splitlines();ck(len(rr)==2*len(v),'incomplete per-key traces');eng=('near46j','near46second')if n==46 else ('near47j','near47second')
  for i,row in enumerate(v):
   ew=empty_by_walsh(n-36,S[n][i])
   for j,e in enumerate(eng):
    nn,ii,gg,std,stat=rr[2*i+j].split('\t');ck((int(nn),int(ii),gg)==(n,i,e),'incorrect raw trace key')
    ck(solve_parse(SimpleNamespace(stdout=std,stderr=stat),0,ew)==tuple(row[1:]),'inconsistent raw trace')
  print(n,'anchors',len(v),'pairs',sum(q[1]for q in v),'large',sum(q[2]for q in v),'maxhole',max(q[3]for q in v),flush=True)
 if u.stage=='audit':return
 cases=[(n,i)for n in S if u.stage=='full'or str(n)==u.stage for i in range(len(S[n]))]
 def one(k):
  n,i=k;exp=tuple(ledger[n][i][1:]);empty_w=empty_by_walsh(n-36,S[n][i])
  for e in ['first','second']:
   ck(solve_parse(search(e,n,n-17,S[n][i]),0,empty_w)==exp,f'disagreement {n}/{i}/{e}')
 with ThreadPoolExecutor(max(1,u.jobs))as ex:
  for i,_ in enumerate(ex.map(one,cases),1):
   if i%100==0:print(i,'of',len(cases),'both exact checks complete',flush=True)
 print('All requested source keys matched.',flush=True)
if __name__=='__main__':main()
