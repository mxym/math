#ifdef NDEBUG
#error "The replay requires assertions to be enabled."
#endif
#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include <utility>
#include <cmath>
using namespace std;using R=uint64_t;
void inc(long long &v){assert(v<LLONG_MAX);++v;}
constexpr int N=512,K=8;
using Words=array<R,K>;
void on(Words&a,int i){a[i>>6]|=R(1)<<(i&63);}void off(Words&a,int i){a[i>>6]&=~(R(1)<<(i&63));}
int first(const Words&a){for(int j=0;j<K;j++)if(a[j])return 64*j+__builtin_ctzll(a[j]);return -1;}
int pop(const Words&a){int n=0;for(R x:a)n+=__builtin_popcountll(x);return n;}
bool disjoint(const Words&a,const Words&b){for(int j=0;j<K;j++)if(a[j]&b[j])return false;return true;}
struct Layer{array<uint16_t,12>x{};Words dif{};};vector<int>C;
bool bad[N];int want,lim,half,tot;int s[20];Words nb[N];vector<Layer> found;uint64_t nodes=0;
alignas(64) int8_t sign2[N][N],vsum[20][N],allow[20][N];int coeff[N];
bool extend(int x,int k){int good=0;
 for(int u=0;u<N;u++){int a=vsum[k-1][u]+sign2[x][u];vsum[k][u]=a;good|=abs(a)>allow[k][u];}
 return !good;}
void accept(int k){
 int d=s[1];array<int,12>a{},b{};for(int i=0;i<k;i++){a[i]=s[i];b[i]=s[i]^d;}sort(a.begin(),a.begin()+k);sort(b.begin(),b.begin()+k);
 if(a>b)return;Layer l;for(int i=0;i<k;i++){l.x[i]=a[i];for(int j=0;j<i;j++)on(l.dif,a[i]^a[j]);}found.push_back(l);}
void visit(Words P,int k){
 ++nodes;if(k==want){accept(k);return;}int t=want-k;
 int nv=pop(P);if(nv<t)return;
 // Keep t-1 stable color classes; every t-clique intersects the uncolored residual set.
 Words rem=P;for(int col=1;col<t;col++){if(first(rem)<0)return;Words st=rem;
  for(int u=first(st);u>=0;u=first(st)){off(st,u);off(rem,u);for(int w=0;w<8;w++)st[w]&=~nb[u][w];}}
 for(int u=first(rem);u>=0;u=first(rem)){off(rem,u);off(P,u);if(!extend(u,k+1))continue;Words Q;for(int j=0;j<K;j++)Q[j]=P[j]&nb[u][j];
  for(int i=0;i<k;i++)for(int j=0;j<i;j++)off(Q,u^s[i]^s[j]);s[k]=u;visit(Q,k+1);}
}
vector<Layer> listing(int k,int bound){
 want=k;lim=bound;nodes=0;found.clear();
 for(int u=1;u<N;u++)if(abs(coeff[u])+k%2>lim)return {};
 for(int l=0;l<=k;l++){allow[l][0]=100;for(int u=1;u<N;u++)allow[l][u]=lim-abs(coeff[u])+k-l;}
 for(int u=0;u<N;u++)vsum[1][u]=1;
 // d is least (plain numerical value) nonzero difference. Translate its endpoints to 0,d;
 // all other point differences strictly exceed d. The two translations are distinguished at the leaf.
 for(int d=1;d<N;d++)if(!bad[d]){Words V{};
  for(int x=d+1;x<N;x++)if(!bad[x]&&!bad[x^d]&&(x^d)>d)on(V,x);if(pop(V)<k-2)continue;
  for(Words T=V;;){int x=first(T);if(x<0)break;off(T,x);nb[x]={};
   for(Words it=V;;){int y=first(it);if(y<0)break;off(it,y);if((x^y)>d&&!bad[x^y])on(nb[x],y);}}
  s[0]=0;s[1]=d;if(extend(d,2))visit(V,2);
 }
 fprintf(stderr," %d:%zu",k,found.size());return move(found);}
vector<int>last,first3;
void root3(const Layer&u,int b,const Layer&v,int c){first3=C;for(int k=0;k<b;k++)first3.push_back(512+u.x[k]);for(int k=0;k<c;k++)first3.push_back(1024+v.x[k]);}
bool fourthOK(){vector<int> s=first3;for(int x:last)s.push_back(1536+x);assert(s.size()==tot);for(int u=1;u<2048;u++){int count=0;for(int x:s)count+=__builtin_parity(x&u);if(max(count,tot-count)>half)return false;}return true;}

bool pick(const vector<int>&H,int pos,int need,Words used){if(!need)return fourthOK();
 for(int i=pos;i+need<=H.size();i++){int x=H[i];Words nw=used;bool ok=true;for(int y:last){int z=x^y;if((used[z/64]>>(z%64))&1){ok=false;break;}on(nw,z);}
 if(ok){last.push_back(x);if(pick(H,i+1,need-1,nw))return true;last.pop_back();}}
 return false;}
bool join(int b,int c,int d,int ub,int uc){
 auto U=listing(b,ub);if(U.empty())return false;
 if((C.size()==20&&b==11&&c==9)||(C.size()==21&&b==10&&c==9&&U.size()<=32)){
  bool init[N];copy(bad,bad+N,init);long long pairs=0,holes=0;int mx=0;
  for(auto &v:U){copy(init,init+N,bad);for(int j=0;j<b;j++)for(int k=0;k<j;k++)bad[v.x[j]^v.x[k]]=true;
   auto Z=listing(c,uc); // All are pair-difference disjoint from both C and the fixed v.
   for(auto &z:Z){inc(pairs);bool used[N]={};for(int x:C)for(int j=0;j<b;j++)for(int k=0;k<c;k++)used[x^v.x[j]^z.x[k]]=true;vector<int> H;for(int x=0;x<N;x++)if(!used[x])H.push_back(x);
    mx=max(mx,int(H.size()));if(H.size()<d)continue;inc(holes);Words f=z.dif;for(int x=0;x<N;x++)if(bad[x])on(f,x);root3(v,b,z,c);last.clear();
    if(pick(H,0,d,f)){for(int x:C)cout<<x<<' ';for(int j=0;j<b;j++)cout<<512+v.x[j]<<' ';for(int k=0;k<c;k++)cout<<1024+z.x[k]<<' ';for(int x:last)cout<<1536+x<<' ';cout<<endl;return true;}
   }
  }
  copy(init,init+N,bad);cerr<<" pairs"<<pairs<<" holes"<<holes<<" maxhole"<<mx;return false;
 }
  vector<Layer>V0;bool same=b==c&&ub==uc;if(!same)V0=listing(c,uc);auto&V=same?U:V0;
 long long pairs=0,holes=0;int mx=0;
 // Indexed sparse forbidden-difference joins, independently implemented on consecutive chunks of 64 V-entries.
 const int nb=(V.size()+63)/64;
 vector<array<R,512>>blocks(nb);
 for(int j=0;j<V.size();j++)for(int k=0;k<c;k++)for(int l=0;l<k;l++)blocks[j/64][V[j].x[k]^V[j].x[l]]|=R(1)<<(j%64);
 static unsigned char perm[8][256];for(int k=0;k<8;k++)for(int x=0;x<256;x++)for(int t=0;t<8;t++)if(x>>t&1)perm[k][x]|=1<<(t^k);
 for(int i=0;i<U.size();i++){int difs[70],nf=0;for(int j=0;j<b;j++)for(int k=0;k<j;k++)difs[nf++]=U[i].x[j]^U[i].x[k];
 unsigned char empty[64];fill(empty,empty+64,255);
 for(int x:C)for(int j=0;j<b;j++){int w=x^U[i].x[j];empty[w>>3]&=~(1u<<(w&7));}
 // tg[t] lists holes in C+U+t. Compute by permuting eight-bit chunks, not reversing bit pairs on words.
 array<Words,512>tg;for(int t=0;t<512;t++)for(int w=0;w<8;w++){R v=0;for(int k=0;k<8;k++)v|=R(perm[t&7][empty[(w*8+k)^(t>>3)]])<<(8*k);tg[t][w]=v;}
 for(int jj=(same?i/64:0);jj<nb;jj++){int start=64*jj;R forbidden=0;for(int p=0;p<nf;p++)forbidden|=blocks[jj][difs[p]];
 R cand=~forbidden;if(start+64>V.size())cand&=(R(1)<<(V.size()-start))-1;
 if(same && i>=start){int nskip=i-start+1;cand=nskip>=64?0:cand&(~R(0)<<nskip);}
 while(cand){int j=start+__builtin_ctzll(cand);cand&=cand-1;inc(pairs);Words hmask=tg[0];for(int k=1;k<c;k++)for(int w=0;w<8;w++)hmask[w]&=tg[V[j].x[k]][w];
 int nh=pop(hmask);mx=max(mx,nh);if(nh<d)continue;inc(holes);vector<int>H;for(int h=first(hmask);h>=0;h=first(hmask)){H.push_back(h);off(hmask,h);}
 Words F{};for(int k=0;k<N;k++)if(bad[k])on(F,k);for(int k=0;k<K;k++)F[k]|=U[i].dif[k]|V[j].dif[k];root3(U[i],b,V[j],c);last.clear();
 if(pick(H,0,d,F)){for(int x:first3)cout<<x<<' ';for(int x:last)cout<<1536+x<<' ';cout<<endl;return true;}
 } }
 }fprintf(stderr," pairs%lld holes%lld maxhole%d",pairs,holes,mx);return false;}
int main(int ac,char**av){assert(ac==8);tot=atoi(av[1]);half=atoi(av[2]);int b=atoi(av[3]),c=atoi(av[4]),d=atoi(av[5]),ub=atoi(av[6]),uc=atoi(av[7]);
 for(int x=0;x<N;x++)for(int u=0;u<N;u++)sign2[x][u]=__builtin_parity(u&x)?-1:1;
 string ln;while(getline(cin,ln)){C.clear();int x;istringstream st(ln);while(st>>x)C.push_back(x);assert(C.size()+b+c+d==tot);
 fill(begin(bad),end(bad),false);for(int x:C)for(int y:C)bad[x^y]=true;
 for(int u=0;u<N;u++){coeff[u]=0;for(int x:C)coeff[u]+=sign2[x][u];}
 bool got=join(b,c,d,ub,uc);cerr<<'\n';cout<<"hit "<<got<<endl;if(got)break;}}
