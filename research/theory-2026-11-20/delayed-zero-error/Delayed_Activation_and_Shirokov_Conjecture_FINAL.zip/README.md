# Delayed activation in quantum channels

Private proof snapshot, 20 November 2026. Start with the five-page `late.pdf` (including references). `late.tex` is the entire source. This is a proof draft, not a statement of external review or exhaustive priority.

## Main theorem
For each finite horizon k and every target asymptotic rate R, some finite-dimensional channel carries **no unassisted perfectly distinguishable classical bit** in any of its first k identical parallel uses, but supports **exact quantum transmission** at rate at least R. This proves S_*(k)=infinity as conjectured in Shirokov (2015), Eqs. (16)–(19) and the discussion after Eq. (21). For fixed k the synchronization length N is independent of the late quantum code dimension d. Taking d arbitrarily large also increases the channel dimensions; the result is not an infinite rate on a fixed finite channel.

## Two fixed-size consequences
* For each k a single explicit 5→4 channel is minimum-output Rényi-entropy additive through k uses and fails by N, for all sufficiently small p>0 (depending on k). Zhang's September 2026 three-copy example is prior. We do not prescribe the exact first failing length m in dimensions 5→4 or a uniform positive Rényi order. Blocking does realize every prescribed first length r≥2 when dimensions may grow.
* An explicit 8→6 channel can have arbitrarily long delay before the **first nontrivial finite classical zero-error code**, with positive asymptotic capacity all along. There is no prior entanglement, feedback, or side channel.

`replay.py` requires only Python's standard library. It checks all 35 relevant Fourier determinants exactly in cyclotomic coordinates, the seven balanced partial matchings, finite GHZ cancellations including complex-phase conventions, and maximum-distance isolation on every pair of support sets of short words. `replay.txt` is the saved output. No computational checks are premises of any theorem.

## Scope and sources
* [Shirokov, 2015](https://arxiv.org/abs/1407.8524): distinguished an unbounded delay (proved there for quantum codes) from unbounded delayed **rates** (explicit conjecture). Its multidimensional perturbation bound deteriorates with code dimension; ours uses a dimension-independent local transitivity bound and then separates label supports.
* [Ruskai, Problem 19](https://arxiv.org/abs/0708.1902); [Cubitt–Harrow–Leung–Montanaro–Winter](https://arxiv.org/abs/0712.3628), prior two-channel output-rank and small-order mechanism; [Zhang, September 2026](https://yuxuanzhang1995.github.io/agentic-research/delayed-onset-additivity/), prior explicit m=3 and constant branch. The new entropy assertion is **unbounded** delayed onset in fixed dimensions.
* [Duan](https://arxiv.org/abs/0906.2527) proved two copies can transmit a classical bit when one cannot; [Cubitt–Chen–Harrow](https://arxiv.org/abs/0906.2547) proved superactivation of two different channels with zero asymptotic capacity. These are not the delayed classical statement here.
* A 20 November search for the exact Shirokov statement, delayed-onset entropy, finite-block zero-error classical activation, and entries in mxym/math and the OpenAI public math corpus located no prior proof of these strengthened results. This is a comparison, not a priority guarantee.
