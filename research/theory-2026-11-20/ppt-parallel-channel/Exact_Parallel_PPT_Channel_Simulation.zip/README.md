# Exact parallel PPT simulation of a point-to-point quantum channel

Read **parallel_channel_cost.pdf** for the four-page proof. Theorem 1 derives a single-use operational characterization and strong additivity for different channels from the corrected Wang–Wilde regularization and the published Lami–Mele–Regula state hierarchies. Theorem 2 uses the independent state theorem in **companion/** to obtain a single finite semidefinite program with explicit level h = (d_in d_out)^2 + 2 d_in d_out.

Scope: finite-dimensional point-to-point channels, exact/zero-error parallel simulation with completely PPT-preserving assistance. This is not an adaptive, sequential, vanishing-error, LOCC, or bidirectional simulation theorem. In particular, the result does not reinstate the retracted unregularized channel kappa_1 equality.

Both PDFs are accompanied by their editable LaTeX files. No numerical result, third-party code, postselection assumption, or certificate corpus is needed. This is private review material and not a peer-reviewed or formally verified publication.

Primary reference: [Wang–Wilde correction v2, revised Theorem 17](https://doi.org/10.5281/zenodo.11061607), not the original additivity statement. The historical one-way specialization of Gour–Scandolo max-logarithmic negativity is the unregularized kappa_1, not the corrected asymptotic formula. The [LMR state paper](https://arxiv.org/html/2405.09613v2) supplies the converging state hierarchies and the trace-based tensor-sum idea explicitly credited here.
