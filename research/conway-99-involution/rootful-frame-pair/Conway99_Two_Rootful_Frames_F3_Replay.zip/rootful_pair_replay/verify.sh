#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
if [ -f MANIFEST.sha256 ];then sha256sum -c MANIFEST.sha256 >/dev/null;fi
for x in markweak shellaxis setsweak ocquot cucap compmark compcert;do g++ -O3 -std=c++17 -march=native "$x.cpp" -o "$x";done
for d in weak_12x15_12x15 weak_7x7_7x7_10x10;do
 python validate.py "$d"
 ./markweak "$d" emit > "$d/markpool.dat" 2>"$d/markscan.log"
 ./shellaxis "$d" > "$d/shellfiltered" 2>"$d/shell.log"
 mv "$d/markpool.dat" "$d/initial_markpool.dat";mv "$d/shellfiltered" "$d/markpool.dat"
 python stabs.py "$d"
 (while read -r h _;do ./setsweak "$d" "$h" emit 2>"$d/set$h.log" | ./ocquot "$d" "$h" >"$d/ureps$h.dat";done <"$d/pairgens.dat") 2>"$d/ureps.log"
 ./cucap "$d" 6 >"$d/cap6.out" 2>"$d/cap6.log"
 ./compmark "$d" 2>"$d/cm.log" | ./compcert "$d" >"$d/residue.out" 2>"$d/cc.log"
 test ! -s "$d/residue.out";cat "$d/cc.log"
 if [[ "$d" == weak_12* ]]; then start=6149; pool=2324; pairs=15; target=13378; else start=11303; pool=1524; pairs=18; target=829539; fi
 test "$(( $(wc -l < "$d/initial_markpool.dat") - 1 ))" -eq "$start"
 test "$(( $(wc -l < "$d/markpool.dat") - 1 ))" -eq "$pool"
 test "$(wc -l < "$d/pairgens.dat")" -eq "$pairs"
 grep -Fx "TOTAL $target residue survivors 0" "$d/cc.log" >/dev/null
done
echo ALL VERIFIED
