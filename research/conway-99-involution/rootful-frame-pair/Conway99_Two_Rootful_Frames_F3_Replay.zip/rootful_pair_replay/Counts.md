# Reproducibility and scope

This calculation excludes **two ambient isometry types**, not every lattice or involution, and not a Conway graph without an involution. It assumes the named positive integral odd unimodular rank-24 extension U with perpendicular norm-seven marks, as specified in Proof.md. Apart from the external classification that the two displayed root systems identify individual classes, the search and its necessary conditions are checked from the two given codes. No eigenfunction E=8 or E=9 computational exclusion is used.

| Stage (some rows deliberately count equivalent charts) | 4D6 | 2A7 + 2D5 |
|---|---:|---:|
| mark-support pair representatives before root tests | 62 | 178 |
| orthogonal relative mark choices before root tests | 44,775 | 124,960 |
| relative marks after elementary norm-16 tests | 6,149 | 11,303 |
| relative marks after elementary E=8,9 structural inequalities | 2,324 | 1,524 |
| distinct remaining ordered pairs of exceptional supports | 15 | 18 |
| signed orthogonal charts processed after binary coset sieve | 834,674 | 4,703,480 |
| absolute mark/sign-chart incidences | 24,106,748 | 20,869,777 |
| charts with **all 42 exterior labels nonempty** | **13,378** | **829,539** |
| certificates of inconsistency independently checked against the original columns | 13,378 | 829,539 |
| remaining charts | 0 | 0 |

Run `bash verify.sh` in an extracted copy. Generated executables and logs intentionally stay in that working directory. The inputs are just the two explicitly listed codes and generators of their coordinate permutation subgroups. Validation does not require that either supplied subgroup be the full automorphism group. The shell driver exits nonzero on a failed command, unexpected count, nonempty survivor file, or a rejected modular witness.
