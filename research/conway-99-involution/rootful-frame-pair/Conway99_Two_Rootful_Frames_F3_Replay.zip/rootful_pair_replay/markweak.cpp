#include<bits/stdc++.h>
using namespace std;using U=uint32_t;using W=uint64_t;int pc(U x){return __builtin_popcount(x);}using four=array<int,4>;int ext(U x,U t){int s=0,h=0;for(;t;t&=t-1){if(x&(t&-t))s|=1<<h;h++;}return s;}
uint8_t good4[16][16][16],allow8[256][256][256];void initok(){for(int x=0;x<16;x++)for(int y=0;y<16;y++)for(int v=0;v<16;v++)if(!(x&y)&&pc(v)%2==0){bool ok=1;for(int e=0;e<16;e++){int a=0,b=0;for(int j=0;j<4;j++){int s=e>>j&1?-1:1;a+=s*(x>>j&1?-3:1);b+=s*(v>>j&1?-1:1)*(y>>j&1?-3:1);}if(pc(e)&1){if(a*a+b*b>56)ok=false;}else if(a*a+b*b>112)ok=false;}good4[x][y][v]=ok;}
 for(int x=0;x<256;x++)for(int y=0;y<256;y++)if(!(x&y)&&pc(x)<=4&&pc(y)<=4&&(pc(x)>=3||pc(y)>=3)&&min(pc(x),pc(y))>=2){
  vector<int> ax,ay;for(int e=0;e<256;e++)if(pc(e)%2){int a=8-2*pc(e)-4*(pc(x)-2*pc(e&x)),b=8-2*pc(e)-4*(pc(y)-2*pc(e&y));if(abs(a)>=14)ax.push_back(e);if(abs(b)>=14)ay.push_back(e);}
  for(int v=0;v<256;v++)if(pc(v)%2==0){bool ok=1;for(int e:ax){int z=v^e;int b=8-2*pc(z)-4*(pc(y)-2*pc(z&y));if(abs(b)>=10)ok=0;}for(int e:ay){int z=v^e;int a=8-2*pc(z)-4*(pc(x)-2*pc(z&x));if(abs(a)>=10)ok=0;}allow8[x][y][v]=ok;}
 }}
struct Tetra{U t;vector<int>a3,hi;vector<uint8_t>a2,p4,p8;vector<U>chi5,chi7;};
int main(int ac,char**av){initok();ifstream code(string(av[1])+"/code.dat"),gen(string(av[1])+"/group.dat");U A[4096];for(auto&v:A)code>>v;vector<U>G(A,A+2048),R,O;for(auto v:A){if(pc(v)==4)R.push_back(v);if(pc(v)==8)O.push_back(v);}vector<vector<uint8_t>>qu4,qu8;for(U w:R){vector<uint8_t>x;for(U g:G)x.push_back(ext(g,w));qu4.push_back(x);}for(U w:O){vector<uint8_t>x;for(U g:G)x.push_back(ext(g,w));qu8.push_back(x);}
 vector<Tetra>ts;map<U,int>di;for(int i=0;i<24;i++)for(int j=0;j<i;j++)for(int k=0;k<j;k++)for(int l=0;l<k;l++){U t=1u<<i|1u<<j|1u<<k|1u<<l;bool ok=1;for(auto w:R)if(pc(w&t)>=3)ok=0;if(!ok)continue;
 Tetra x;x.t=t;for(U w:R)x.p4.push_back(ext(t,w));for(U w:O)x.p8.push_back(ext(t,w));for(int q=0;q<2048;q++){U z=G[q];int n=1-(pc(z)-4*pc(z&t))/4;assert(abs(n)<=3);if(abs(n)==3)x.a3.push_back(q);x.a2.push_back(abs(n)>=3);U c5=0,c7=0;for(int p=0;p<24;p++){int h=abs(2*n-(z>>p&1?-1:1)*(t>>p&1?-3:1));assert(h<=7);if(h>=5)c5|=1u<<p;if(h>=7)c7|=1u<<p;}x.chi5.push_back(c5);x.chi7.push_back(c7);if(c7)x.hi.push_back(q);}
 di[t]=ts.size();ts.push_back(x);}
 int N=ts.size(),ng;gen>>ng;vector<vector<int>>pr(ng,vector<int>(N));for(auto &p:pr){int v[24];for(int&i:v)gen>>i;for(int j=0;j<N;j++){U u=0;for(U x=ts[j].t;x;x&=x-1)u|=1u<<v[__builtin_ctz(x)];p[j]=di.at(u);}}
 vector<uint8_t>seen((N*N+7)/8);auto mark=[&](int a,int b){if(a>b)swap(a,b);int z=a*N+b,m=1u<<(z%8);if(seen[z/8]&m)return false;seen[z/8]|=m;return true;};
 int pairs=0;long long orth=0,r0=0,n3=0,x8=0,x16=0;cout<<"T "<<N<<" roots "<<R.size()<<" oct "<<O.size()<<endl;
 for(int i=0;i<N;i++)for(int j=i+1;j<N;j++){auto &a=ts[i],&b=ts[j];if((a.t&b.t)||!mark(i,j))continue;pairs++;vector<pair<int,int>>s={{i,j}};for(int h=0;h<(int)s.size();h++)for(auto&p:pr){auto [u,v]=s[h];if(mark(p[u],p[v]))s.emplace_back(p[u],p[v]);}
 vector<int>ti,oi;for(int k=0;k<R.size();k++)if(a.p4[k]||b.p4[k])ti.push_back(k);for(int k=0;k<O.size();k++){int f=pc(O[k]&a.t),g=pc(O[k]&b.t);if(max(f,g)>=3&&min(f,g)>=2)oi.push_back(k);}
 int alive=0;for(int v=0;v<2048;v++){if(pc(G[v])-4*pc(G[v]&(a.t|b.t))!=-4)continue;orth++;bool ok=1;for(int k:ti)if(!good4[a.p4[k]][b.p4[k]][qu4[k][v]]){ok=0;break;}if(!ok)continue;r0++;
 for(int q:a.a3)if(b.a2[v^q]){ok=0;break;}if(ok)for(int q:b.a3)if(a.a2[v^q]){ok=0;break;}if(!ok)continue;n3++;
 for(int k:oi)if(!allow8[a.p8[k]][b.p8[k]][qu8[k][v]]){ok=false;break;}if(!ok)continue;x8++;
 for(int q:a.hi)if(a.chi7[q]&b.chi5[q^v]){ok=false;break;}if(ok)for(int q:b.hi)if(a.chi5[q^v]&b.chi7[q]){ok=false;break;}if(!ok)continue;x16++;alive++;if(ac>2)cout<<a.t<<' '<<b.t<<' '<<G[v]<<'\n';} }
 cerr<<"support pairs "<<pairs<<" orth "<<orth<<" root/short char "<<r0<<" E3 "<<n3<<" oct char "<<x8<<" sign char "<<x16<<endl;
}
