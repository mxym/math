# No antisymmetric integer −4 eigenfunction of paired energy at most nine

For an involution of a strongly regular (99,14,1,2) graph with unique fixed vertex, let f be any nonzero antisymmetric integer −4 adjacency eigenfunction. Its squared norm on one representative of each of the 49 twin pairs is **at least 10** (equivalently, its full squared norm is at least 20). If Λ is the integral Gram lattice of 3I−S on those 49 coordinates, every nonzero vector in its metric dual has squared norm at least **10/7** by 7-tightness. The bound is a necessary local condition, not an attained minimum for an actual graph. No Schur-rank or rootlessness hypothesis is used. For a minimal norm-2 root r of a rank-24 completion with orthogonal norm-7 marks c,d, it implies (r,c)²+(r,d)²≤4, hence |(r,c)|+|(r,d)|≤2.

Run `bash verify_all.sh` to replay the earlier E≤8 theorem and this E=9 theorem. To replay just E=9 run `bash verify.sh`. Python (NumPy/SciPy), g++ and unzip are required; no discovery solver is needed. Integer negative certificates and final checked pure RUP proofs are included in the archive. The earlier E=8 treatment includes its own support-subcase argument; the unrestricted induced-Q4 theorem is not an additional assumption.

Rows of the table count complete chart decisions. LP means an explicit strict integer separating certificate, RUP is a reconstructed Boolean refutation, and negative capacity is tested directly.

| symmetric support family | signed-axis core orbits | negative capacity | integer separation | final RUP |
|---|---:|---:|---:|---:|
|0|12,355|0|11,244|1,111|
|1|8,556|0|8,108|448|
|2|2,099|66|1,780|253|
|All|23,010|66|21,132|1,812|
