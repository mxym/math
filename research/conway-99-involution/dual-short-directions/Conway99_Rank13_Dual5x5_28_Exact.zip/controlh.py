from pathlib import Path
from math import gcd
from functools import reduce
import itertools as it, numpy as np, sympy as sy
t1=np.array([1,1,-1,-2]);t2=np.array([1,-1,-2,1]);q=np.array([5,3,1,0]);r=np.array([-3,5,0,1]);assert q@q==r@r==35 and q@r==0
W=np.zeros((12,15),int);W[:11,:11]=np.eye(11,dtype=int);W[0,11:]=t1;W[1,11:]=t2;W[11]=-W[:11].sum(0)
P=np.column_stack([q,r]);ga=W[:,11:]@P//7;assert np.all(ga*7==W[:,11:]@P)
J=np.diag([7,7]+[1]*13);F=W@J@W.T;U=sy.Matrix(F+1);det=U.det();I=U.inv()*det;gg=reduce(gcd,[int(det)]+[int(q)for q in I]);D=int(det)//gg;I=np.array(I/gg,dtype=np.int64);detF=int(sy.Matrix(F[:11,:11]).det())
Y=[]
for t in (t1,-t1,t2,-t2):
 for i in range(8):
  y=np.zeros(15,int);y[[2+(i+j)%9 for j in range(3)]]=[1,1,1 if i%2 else -1];y[11:]=t;Y.append(y)
y=np.array([1,0,1,1,1]+10*[0]);Y.append(y);Y=np.array(Y);assert np.all(np.diag(Y@J@Y.T)==10)
h=Y[:,11:]@P//7;v=Y@J@W.T
WW=np.vstack([W[:11],np.hstack([np.zeros((2,11),int),P.T])])
rr=np.vstack([WW,Y[0],Y[16]]);d=int(sy.Matrix(rr).det());assert d and np.all(rr@rr.T==rr@rr.T)
with open('controlh.in','w')as f:
 print(D,detF,len(Y),file=f); print(*[sy.Matrix(F[:i,:i]).det() for i in range(1,12)],file=f);np.savetxt(f,I,fmt='%d');np.savetxt(f,ga.T,fmt='%d');np.savetxt(f,np.hstack([v,h]),fmt='%d');np.savetxt(f,Y@J@Y.T,fmt='%d')
print('explicit integral 15-coordinate control, one full-rank basis determinant',d,'(Gram determinant',49*d*d,')')
