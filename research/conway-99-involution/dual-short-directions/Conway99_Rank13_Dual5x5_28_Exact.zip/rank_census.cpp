#include <bits/stdc++.h>
#include <gmpxx.h>
using namespace std;using i128=__int128_t;using ll=long long;typedef mpz_class Big; Big cv(i128 x){bool neg=x<0;unsigned __int128 w=neg?-x:x;Big r=(unsigned long)(w>>64);r<<=64;r+=(unsigned long)w;return neg?-r:r;}using V=array<ll,12>;
void demand(bool x){if(!x)throw runtime_error("exact bounds/indices violated");}
ll dot(V const&a,V const&b){i128 w=0;for(int i=0;i<12;i++)w+=(i128)a[i]*b[i];demand(w<LLONG_MAX&&w>LLONG_MIN);return ll(w);}
struct Meta{int d;V v,av;ll nu;};
struct X{int j;ll x,y;i128 nu;};
const vector<int> pr={17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193};
int qr[40][200];ll D,detF;int z[42][7],zd[30][30];V I[12];vector<Meta> md;
using Sig=array<int,24>;using Row=array<int,84>;
ll smod(i128 x,int p){ll w=x%p;return w<0?w+p:w;}
struct Run{
 V g{},h{},ag{},ah{};ll a,b,c;i128 det;int sc[40];vector<X>pool[270];map<pair<int,int>,bool> memo;ll products=0, perfect=0;
 Run(Sig const&s){for(int j=0;j<12;j++){g[j]=s[j];h[j]=s[j+12];}
  for(int j=0;j<12;j++){ag[j]=dot(I[j],g);ah[j]=dot(I[j],h);}a=5*D-7*dot(g,ag);b=-7*dot(g,ah);c=5*D-7*dot(h,ah);det=(i128)a*c-(i128)b*b;demand(a>0&&det>0);
  for(int i=0;i<(int)pr.size();i++)sc[i]=smod(detF,pr[i])*smod(det,pr[i])%pr[i];
  for(int j=0;j<(int)md.size();j++){auto&M=md[j];ll vx=dot(ag,M.v),vy=dot(ah,M.v);
   for(int sx=-1;sx<=1;sx++)for(int sy=-1;sy<=1;sy++){ll x=sx*D-vx,y=sy*D-vy;
    i128 n=(i128)M.nu*det-7*((i128)c*x*x-2*(i128)b*x*y+(i128)a*y*y);
    if(n>=0)pool[9*M.d+(sx+1)*3+sy+1].push_back({j,x,y,n});
   }
  }
 }
 bool vals(X const&x,X const&y,int z){products++;
  ll v=dot(md[x.j].av,md[y.j].v);i128 u=(-(i128)D*z-v)*det-7*((i128)c*x.x*y.x-(i128)b*((i128)x.x*y.y+(i128)x.y*y.x)+(i128)a*x.y*y.y);
   for(int l=-1;l<=1;l++){i128 cr=u-(i128)4*l*D*det;bool ok=1;
    for(int k=0;k<(int)pr.size();k++){int p=pr[k];ll w=smod(cr,p);ll rhs=(smod(x.nu,p)*smod(y.nu,p)-w*w+p*p)%p;
      if(!qr[k][rhs*sc[k]%p]){ok=0;break;}}
    if(ok){Big val=cv(detF)*cv(det)*(cv(x.nu)*cv(y.nu)-cv(cr)*cv(cr));if(val>=0){if(mpz_perfect_square_p(val.get_mpz_t())){perfect++;return true;}}}
   }
  return false;
 }
 map<pair<int,int>,vector<vector<int>>> tab;
 vector<int> const&neighbors(int i,int xi,int j){
  auto k=make_pair(i,j);auto&rows=tab[k];if(rows.empty())rows.resize(pool[i].size());
  auto&v=rows[xi];if(!v.empty())return v;
  for(int a=0;a<pool[j].size();a++)if(vals(pool[i][xi],pool[j][a],zd[i/9][j/9]))v.push_back(a);
  v.push_back(-1);return v;
 }
 bool any(int i,int j){
  if(i>j)swap(i,j);auto k=make_pair(i,j);auto it=memo.find(k);if(it!=memo.end())return it->second;
  for(auto&x:pool[i])for(auto&y:pool[j])if(vals(x,y,zd[i/9][j/9]))return memo[k]=true;
  return memo[k]=false;
 }
 bool extend(vector<int>const&keys,vector<vector<int>> const&dom,int n, int lim){
  if(n==lim)return true;
  for(int x:dom[n]){
   auto next=dom;bool ok=1;
   for(int j=n+1;j<lim;j++){
    next[j].clear();auto&nb=neighbors(keys[n],x,keys[j]);set_intersection(dom[j].begin(),dom[j].end(),nb.begin(),nb.end()-1,back_inserter(next[j]));
    if(next[j].empty()){ok=0;break;}
   }
   if(ok&&extend(keys,next,n+1,lim))return true;
  }
  return false;
 }
 int tryeq(Row const&r){vector<int>k;for(int i=0;i<30;i++){k.push_back(9*i+3*(1+r[i+12])+1+r[i+54]);if(pool[k.back()].empty())return 0;}
  stable_sort(k.begin(),k.end(),[&](int i,int j){return pool[i].size()<pool[j].size();});
  if(!any(k[0],k[1]))return 1;
  int lim=8;vector<vector<int>> dom(lim);for(int t=0;t<lim;t++){dom[t].resize(pool[k[t]].size());iota(dom[t].begin(),dom[t].end(),0);}
  if(!extend(k,dom,0,lim))return 3;
  for(int w=1;w<30;w++)for(int j=0;j<w;j++)if(!any(k[j],k[w]))return 1;
  return 2;
 }
};

namespace old {
#include "legacy/real.hpp"
}
using Root=array<int,42>;
vector<Root> Gs;ll depPairs=0;
void readG(){
 ifstream q("cuts5.tsv");Root r{};while(q>>r[0]){for(int i=1;i<42;i++)q>>r[i];Gs.push_back(r);}demand(Gs.size()==7476);
 int k=0;for(int a=0;a<7;a++)for(int b=a+1;b<7;b++)for(int sign:{1,-1}){z[k][a]=1;z[k][b]=sign;k++;}
 for(int i=0;i<30;i++)for(int j=0;j<30;j++)for(int a=0;a<7;a++)zd[i][j]+=z[i+12][a]*z[j+12][a];
 for(int i=0;i<(int)pr.size();i++)for(int j=0;j<pr[i];j++)qr[i][j*j%pr[i]]=1;
}
map<Sig,vector<Row>> configs(){
 struct Part{V s,is;int wt;ll val;vector<int> full;};vector<Part>parts;map<V,vector<int>>by;
 for(int j=0;j<(int)Gs.size();j++){V s{};for(int i=0;i<12;i++)s[i]=Gs[j][i];by[s].push_back(j);}
 for(auto&[s,fs]:by){V is;for(int i=0;i<12;i++)is[i]=dot(I[i],s);ll v=5*D-7*dot(is,s);if(v<0)continue;parts.push_back({s,is,(int)dot(s,s),v,fs});}
 map<Sig,vector<Row>>out;depPairs=0;
 for(auto&x:parts)if(x.wt==10)for(auto&y:parts){
  ll v=7*dot(x.is,y.s);i128 det=(i128)x.val*y.val-(i128)v*v;if(det<0)continue;Sig sig;
  for(int j=0;j<12;j++){sig[j]=x.s[j];sig[j+12]=y.s[j];}
  for(int a:x.full)for(int b:y.full){int d=0;for(int j=0;j<42;j++)d+=Gs[a][j]*Gs[b][j];if(d!=0)continue;
   if(!det){depPairs++;continue;}Row r;copy(Gs[a].begin(),Gs[a].end(),r.begin());copy(Gs[b].begin(),Gs[b].end(),r.begin()+42);out[sig].push_back(r);
  }
 }
 return out;
}
int main(int argc,char**argv){
 readG();ifstream f("forms.txt"),p("layouts.tsv");int id,r,lo=argc>1?atoi(argv[1]):0,hi=argc>2?atoi(argv[2]):3580,step=argc>3?atoi(argv[3]):1;ll total=0;
 for(;;){if(!(f>>id>>D>>detF))break;demand(D>0&&D<1000000000&&detF>0);for(auto&v:I)for(auto&w:v)f>>w;
  int P[12],N[12];p>>r;for(int&a:P)p>>a;for(int&a:N)p>>a;if(id<lo||id>=hi||(id-lo)%step)continue;
  clock_t tm=clock();old::Shell sh(P,N);if(!sh.admissible){cout<<id<<" bad-shell\n"<<flush;continue;}
  auto by=configs();ll total=0;for(auto&[k,v]:by)total+=v.size();cout<<id<<" "<<r<<" "<<by.size()<<" "<<total<<" "<<depPairs<<"\n"<<flush;continue;if(by.empty()){cout<<id<<" no-positive-pair degenerate="<<depPairs<<"\n"<<flush;continue;}
  old::Form F(P,N);old::RForm sg(F,P,N,1),un(F,P,N,0);demand(sg.det==D);
  for(int a=0;a<12;a++)for(int b=0;b<12;b++)demand(I[a][b]==sg.D[a][b]);
  sh.gen();md.clear();for(int k=0;k<30;k++)for(auto q:sh.domain[k]){
   int f[12],u[12];ll pf[12],pu[12],nf,nu;bool bad=false;
   for(int j=0;j<12;j++){int a=(q.a>>j)&1,b=(q.b>>j)&1;if(a&&b&&P[j]==N[j])bad=true;f[j]=-4*(a-b)-sh.z[k][j];u[j]=1-abs(sh.z[k][j])-2*(a+b);}
   if(bad||!sg.project(f,pf,nf,10)||!un.project(u,pu,nu,5))continue;
   Meta m;m.d=k;for(int i=0;i<12;i++){m.v[i]=f[i];m.av[i]=pf[i];}m.nu=nf;md.push_back(m);
  }
  ll ct[4]={},pairs=0,accepted=0;for(auto&[s,G]:by){Run c(s);for(auto&r:G)ct[c.tryeq(r)]++;pairs+=c.products;accepted+=c.perfect;}
  cout<<id<<" r"<<r<<" raw "<<md.size()<<" groups "<<by.size()<<" totals "<<ct[0]<<" "<<ct[1]<<" "<<ct[3]<<" "<<ct[2]<<" degenerate "<<depPairs<<" pairs "<<pairs<<" ok "<<accepted<<" cpu "<<(double(clock()-tm)/CLOCKS_PER_SEC)<<"\n"<<flush;
 }
}
