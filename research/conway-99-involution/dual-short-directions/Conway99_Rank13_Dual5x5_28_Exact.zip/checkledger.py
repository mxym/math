from pathlib import Path
import sys
def must(b):
 if not b:raise ValueError('ledger mismatch')
def data(fn):
 L={};
 for l in Path(fn).read_text().splitlines():
  k,*w=l.split();j=int(k);must(j not in L)
  L[j]=w[:w.index('cpu')] if 'cpu' in w else w
 return L
if len(sys.argv)>2:must(data(sys.argv[1])==data(sys.argv[2]));print('PASS exact ledger',sys.argv[1]);raise SystemExit
R=data('expected/ranks.tsv');N=data('expected/positive.tsv');S=data('expected/singular.tsv')
m=p=z=q=bp=bc=0
for k,v in R.items():
 w=N[k]
 if v==['bad-shell']:must(w==v and S[k]==v);bp+=1;continue
 r,gs,n,s=map(int,v);m+=1
 if not gs:must(w==['no-positive-pair','degenerate='+str(s)])
 else:
  must(w[:1]==['r'+str(r)] and int(w[4])==gs and w[5]=='totals' and sum(map(int,w[6:10]))==n and int(w[9])==0 and int(w[11])==s)
 if s:
  t=S[k];must(int(t[11])==s and sum(map(int,t[6:10]))==s and int(t[9])==0);bc+=1
 else:must(k not in S)
 p+=n;z+=s
must((len(R),len(N),m,bp,bc,z)==(3580,3580,3308,272,40,62132))
print('PASS full coverage',m,'admissible charts,',p,'positive assignments,',z,'degenerate assignments; no open choices')
