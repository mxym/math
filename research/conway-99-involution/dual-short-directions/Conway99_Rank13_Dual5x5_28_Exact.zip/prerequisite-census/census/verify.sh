#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
python pre.py
for exe in comp short char; do g++ -O3 -std=c++17 "$exe.cpp" -o "$exe"; done
for f in *.form; do
 q=${f%.form}
 ./comp < "$f" > "$q.pair"
 ./short 3 < "$f" > "$q.short"
 ./short 4 < "$f" > "$q.s4"
 ./char < "$f" > "$q.chi"
done
python join.py; python sieve.py; python shadow.py; python reduce.py; python twist.py; python chart.py; sha256sum -c EXPECTED.sha256
