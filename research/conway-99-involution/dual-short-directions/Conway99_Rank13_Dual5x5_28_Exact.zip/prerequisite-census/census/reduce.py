from join import *
from pre import shape
@lru_cache(None)
def simple(q):
 g=np.array(shape(q),dtype=int)
 return [[int(2*x//g[j,j]) for x in g[j]] for j in range(len(g))]
@lru_cache(None)
def can(q,u,v):
 u=list(u);v=list(v);g=simple(q)
 while True:
  j=next((i for i,x in enumerate(u) if x<0),None)
  if j is None:break
  t=u[j];s=v[j]; u=[a-t*b for a,b in zip(u,g[j])];v=[a-s*b for a,b in zip(v,g[j])]
 while True:
  j=next((i for i,x in enumerate(v) if u[i]==0 and x<0),None)
  if j is None:break
  t=v[j];v=[a-t*b for a,b in zip(v,g[j])]
 return (tuple(u),tuple(v))
def canon(name,z):
 roots,_=models[name]
 def op(sw,a,b):
  w=[can(q,tuple(a*x for x in v[sw]),tuple(b*x for x in v[1-sw])) for q,v in zip(roots,z)]
  if name in ('D8x2','E7x2'):w[1:]=sorted(w[1:])
  return tuple(w)
 return min(op(sw,a,b) for sw in (0,1) for a in (-1,1) for b in (-1,1))
def run(name):
 import collections
 idx=set(np.loadtxt(name+'.shadow',dtype=int,ndmin=2)[:,0]);cs=collections.defaultdict(list); ok={}
 for i,s in enumerate(open(name+'.reps')):
  k=canon(name,json.loads(s));cs[k].append(i)
  assert k not in ok or ok[k]==(i in idx)
  ok[k]=i in idx
 with open(name+'.canon','w') as out:
  for k,li in cs.items():
   if ok[k]:print(li[0],len(li),file=out)
 print(name,'total canon',len(cs),'passing',sum(ok.values()),flush=True)
if __name__=='__main__':
 for k in models:run(k)
