#include <bits/stdc++.h>
using namespace std;using V=array<int,17>;int n,det[18],h[18][17][17],isB,cap;
void go(int k,V&v){if(k==n){long s=0;for(int i=0;i<n;i++)for(int j=0;j<n;j++)s+=v[i]*v[j]*h[n][i][j];cout<<s;for(int i=0;i<n;i++)cout<<" "<<v[i];cout<<"\n";return;}
 for(int t=-3;t<=3;t++){v[k]=t;long s=0;for(int i=0;i<=k;i++)for(int j=0;j<=k;j++)s+=v[i]*v[j]*h[k+1][i][j];if(s<=cap*det[k+1])go(k+1,v);}}
int main(int ac,char**av){cap=atoi(av[1]);cin>>n>>isB;for(int k=1;k<=n;k++){cin>>det[k];for(int i=0;i<k;i++)for(int j=0;j<k;j++)cin>>h[k][i][j];}V v={};go(0,v);}
