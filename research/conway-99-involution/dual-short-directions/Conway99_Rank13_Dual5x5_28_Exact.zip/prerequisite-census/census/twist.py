import numpy as np,json,itertools,sys,time
from collections import Counter,defaultdict
from functools import lru_cache
from scipy.linalg import block_diag
from join import F,cgen,models,form
from pre import shape
from reduce import canon
def isos(a,b):
 n=len(a); prev=0
 cs=list(a.diagonal())+list(b.diagonal())
 while len(set(cs))!=prev:
  prev=len(set(cs));sig=[]
  for k,x in enumerate([a,b]):
   c=cs[k*n:(k+1)*n]
   for i in range(n):sig.append((c[i],tuple(sorted((c[j],x[i,j]) for j in range(n) if x[i,j] and j!=i))))
  mp={k:j for j,k in enumerate(sorted(set(sig)))};cs=[mp[k] for k in sig]
 ca=cs[:n];cb=cs[n:];found={};used=set()
 if Counter(ca)!=Counter(cb):return
 def rec():
  if len(found)==n:yield dict(found);return
  ds=[([j for j in range(n) if j not in used and ca[i]==cb[j] and all(a[i,x]==b[j,y] for x,y in found.items())],i) for i in range(n) if i not in found]
  opts,i=min(ds,key=lambda z:len(z[0]))
  for j in opts:
   found[i]=j;used.add(j);yield from rec();del found[i];used.remove(j)
 yield from rec()
@lru_cache(None)
def pre(name):
 qs,wd=models[name];C=cgen(qs,*wd);G=block_diag(*[np.asarray(shape(q),dtype=np.int64) for q in qs]);T=block_diag(*[form(q) for q in qs]);cs=np.array([sum(map(list,c),[]) for c in C]);gen=np.vstack([G,cs@G//F]);assert not np.any(cs@G%F)
 def diag(g):return g
 return G,T,{tuple(c) for c in cs},gen,diag(G),diag
@lru_cache(None)
def fourblock(q):
 a=np.loadtxt(q+'.s4',dtype=int,ndmin=2);n=int(q[1:]);dt=int(open(q+'.form').read().splitlines()[-1].split()[0]);g=form(q);v=a[:,1:]@g;gs=defaultdict(lambda:defaultdict(list))
 for k,w,dd in zip(a[:,0]*F//dt,a[:,1:],v):gs[tuple(dd%F)][k].append(w)
 return gs
@lru_cache(None)
def four(name):
 qs,wd=models[name];C=cgen(qs,*wd);ns=[];ps=[]
 for z in C:
  gs=[fourblock(q)[c] for q,c in zip(qs,z)]
  for dd in itertools.product(*(g.keys() for g in gs)):
   s=sum(dd)
   if s>4*F or s%F:continue
   a=[np.array(g[d],dtype=np.int16) for g,d in zip(gs,dd)];nn=[len(t) for t in a]
   cols=[np.tile(np.repeat(x,int(np.prod(nn[k+1:],dtype=int)),axis=0),(int(np.prod(nn[:k],dtype=int)),1)) for k,x in enumerate(a)]
   p=np.hstack(cols);ns.extend([s//F]*len(p));ps.append(p)
 p=np.vstack(ps);return np.array(ns,dtype=np.int16),p,(p@pre(name)[1]).astype(np.int16)
@lru_cache(None)
def maps(name):
 qs,_=models[name];lines=[json.loads(l) for l in open(name+'.reps')];m={canon(name,lines[int(l.split()[0])]):int(l.split()[0]) for l in open(name+'.canon')}
 return lines,m
# Root systems by numbers of units and ordinary norm-two vectors. 
@lru_cache(None)
def rootdict():
 ans=defaultdict(list)
 for k in models:
  n,p,v=four(k);ans[(sum(n==1),sum(n==2))].append(k)
 return ans
def twist(name,i):
 rr=maps(name)[0][i];c=np.concatenate([e[0] for e in rr]);d=np.concatenate([e[1] for e in rr]);n,p,v=four(name);a=v@c//F;b=v@d//F
 ok=(abs(a)<=3)&(abs(b)<=3);a=a[ok];b=b[ok];sw=(2*a+2*b+3)%7-3;tw=(-2*a+2*b+3)%7-3
 new=7*n[ok]-a*a-b*b+sw*sw+tw*tw;assert np.all(new%7==0)
 kk=(new==7)|(new==14);target=(int(sum(new==7)),int(sum(new==14))); nsnew=new[kk]//7
 r=(7*p[ok][kk]+(sw[kk]-a[kk])[:,None]*c+(tw[kk]-b[kk])[:,None]*d).astype(np.int64)
 s=sw[kk];t=tw[kk]; tr=[(int(x),int(y),tuple(z)) for x,y,z in zip(s,t,r)];pos=[z for z in tr if z>(0,0,(0,)*17)];pos.sort();prs={e[2] for e in pos};sim=[];xx=[];yy=[]
 for u,vv,raw in pos:
  v2=np.array(raw,dtype=np.int64)
  if any(tuple(v2-k) in prs for k in sim):continue
  sim.append(v2);xx.append(u);yy.append(vv)
 sroots=np.array(sim);assert sroots.shape==(17,17),(name,i,target,len(pos),len(sim))
 G,T,C,gens,_,diag=pre(name);mg=sroots@T@sroots.T;assert not np.any(mg%(F*49));mg//=F*49;hs=diag(mg)
 ap=gens@T@c//F;bp=gens@T@d//F;nw=np.vstack([7*gens+(ap+2*bp)[:,None]*c+(-2*ap+bp)[:,None]*d,7*c,7*d]);pv=nw@T@sroots.T;assert not np.any(pv%(F*49));pv//=F*49
 ans=set()
 for k in rootdict().get(target,[]):
  qs,_=models[k];gg,tt,cc,_,ht,_=pre(k)
  for pp in isos(hs,ht):
   idx=np.argsort([pp[j] for j in range(17)]);sr=np.array(xx)[idx];ds=np.array(yy)[idx]
   if any(tuple(row) not in cc for row in (pv[:,idx]@tt)%F): continue
   z=[];s0=0
   for q in qs:
    s2=s0+int(q[1:]);z.append([sr[s0:s2],ds[s0:s2]]);s0=s2
   key=canon(k,z);assert key in maps(k)[1],(name,i,k,z)
   ans.add((k,maps(k)[1][key]))
 assert ans,(name,i,target)
 return sorted(ans)
def run(name):
 with open(name+'.twists','w') as out:
  for i in maps(name)[1].values():
   z=twist(name,i);print(i,' '.join(k+':'+str(j) for k,j in z),file=out,flush=True)
 print(name,len(maps(name)[1]),flush=True)
if __name__=='__main__':
 for name in (sys.argv[1:] or models):run(name)
