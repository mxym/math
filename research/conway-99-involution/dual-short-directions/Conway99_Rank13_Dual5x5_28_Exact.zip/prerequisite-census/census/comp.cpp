#include <bits/stdc++.h>
using namespace std; using V=array<int,17>;
int n,isB,det[18],h[18][17][17]; string shape;
long norm(const V&v,int k){long s=0;for(int i=0;i<k;i++)for(int j=0;j<k;j++)s+=long(v[i])*v[j]*h[k][i][j];return s;}
long dot(const V&v,const V&w){long s=0;for(int i=0;i<n;i++)for(int j=0;j<n;j++)s+=long(v[i])*w[j]*h[n][i][j];return s;}
void run(int k,V&c,V&d,bool second){
 V&v=second?d:c;
 if(k==n){
   if(isB){int u=0;for(int i=n-1;i>=0;i--){u+=v[i];if(abs(u)>1)return;}}
   if(!second){run(0,c,d,1);return;}
   cout<<norm(c,n)<<" "<<norm(d,n)<<" "<<dot(c,d);
   for(int i=0;i<n;i++)cout<<" "<<c[i];for(int i=0;i<n;i++)cout<<" "<<d[i];cout<<"\n";
   return;
 }
 int lo=second&&c[k]>0?-3:0;
 for(v[k]=lo;v[k]<=3;v[k]++){
  if(norm(v,k+1)>7*det[k+1])continue;
  run(k+1,c,d,second);
 }
}
int main(int argc,char**argv){if(!(cin>>n>>isB))return 1;for(int k=1;k<=n;k++){cin>>det[k];for(int i=0;i<k;i++)for(int j=0;j<k;j++)cin>>h[k][i][j];}V c={},d={};run(0,c,d,0);}
