from sieve import *
from scipy.linalg import block_diag
from pre import shape
@lru_cache(None)
def chb(q):
 n=int(q[1:]);T=form(q)
 try: a=np.loadtxt(q+'.chi',dtype=np.int64,ndmin=2)
 except Exception:return {}
 if not len(a):return {}
 de=int(open(q+'.form').read().splitlines()[-1].split()[0]);out=defaultdict(lambda:defaultdict(list))
 for z in a:
  x=z[1:];v=x@T;out[tuple(v%F)][z[0]*(F//de)].append((x,v))
 return out
@lru_cache(None)
def chars(name):
 roots,words=models[name];C=cgen(roots,*words);G=block_diag(*[np.array(shape(q),dtype=np.int64) for q in roots]);Cmat=np.array([sum(map(list,z),[]) for z in C]);quad=np.sum((Cmat@G)*Cmat,axis=1);assert np.all(quad%(F*F)==0)
 req=F*(quad//(F*F))%(2*F)
 p=[];v=[]
 for a in C:
  if any(not chb(q) for q in roots):continue
  gs=[chb(q)[c] for q,c in zip(roots,a)]
  for dt in product(*(s.keys() for s in gs)):
   if sum(dt)!=9*F:continue
   for z in product(*(s[t] for s,t in zip(gs,dt))):
    pv=np.concatenate([u[0] for u in z]);
    if np.any((Cmat@pv)%(2*F)!=req):continue
    p.append(pv);v.append(np.concatenate([u[1] for u in z]))
 if not p:return np.zeros((0,17),dtype=np.int16),np.zeros((0,17),dtype=np.int16)
 return np.array(p,dtype=np.int16),np.array(v,dtype=np.int16)
def run(name):
 c,d=readpairs(name);p,v=chars(name);idx=np.loadtxt(name+'.pass',dtype=int,ndmin=2)[:,0];hs=Counter()
 if len(v):
  with open(name+'.shadow','w') as out:
   for o in range(0,len(idx),32):
    z=idx[o:o+32];a=v@c[z].T;b=v@d[z].T;assert np.all((a%F==0)&(b%F==0));a//=F;b//=F
    de=63-a*a-b*b;mm=de.min(axis=0)
    for j,k in enumerate(mm):
     hs[int(k)]+=1
     if k>=21:print(z[j],k,np.sum(de[:,j]==21)//2,file=out)
 else:
  with open(name+'.shadow','w') as out:
   for k in idx:print(k,0,0,file=out)
 print(name,'char9',len(v),'minima',sorted(hs.items()),flush=True)
if __name__=='__main__':
 for name in models:run(name)
