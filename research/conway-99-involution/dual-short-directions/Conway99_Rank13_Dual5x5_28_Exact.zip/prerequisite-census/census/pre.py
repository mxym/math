import sympy as sp,numpy as np, pathlib,sys
def shape(q):
 typ=q[0]; n=int(q[1:]);g=2*sp.eye(n);
 if typ in 'AB': edges=[(i,i+1) for i in range(n-1)]
 if typ=='B':g[n-1,n-1]=1
 if typ=='D':edges=[(i,i+1) for i in range(n-3)]+[(n-3,n-2),(n-3,n-1)]
 if typ=='E':edges=[(i,i+1) for i in range(n-2)]+[(2,n-1)]
 for i,j in edges:g[i,j]=g[j,i]=-1
 return g
shapes=['B17','B9','E8','B5','D12','B3','E7','B2','A15','B1','D8','A11','E6']
for q in shapes:
 g=shape(q);n=g.rows
 with open(q+'.form','w') as f:
  print(n,int(q[0]=='B'),file=f)
  for k in range(1,n+1):
   s=g[:k,:k];d=s.det();h=d*s.inv();assert all(int(x)==x for x in h)
   print(d,*h,file=f)
 if q.startswith('E'):
  print(q,g.inv().diagonal(),g.det())
