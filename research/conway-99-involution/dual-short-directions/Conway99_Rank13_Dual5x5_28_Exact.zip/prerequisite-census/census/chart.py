from pathlib import Path
from collections import defaultdict,Counter
ds={}
for f in Path('.').glob('*.twists'):
 for l in open(f):
  a,*b=l.split();ds[(f.stem,int(a))]={(n,int(x)) for n,x in (e.split(':') for e in b)}
assert all(k in ds[v] for k,vs in ds.items() for v in vs)
print('nodes',len(ds),'target counts',Counter(map(len,ds.values())))
seen=set();cs=[]
for k in ds:
 if k in seen:continue
 b={k};q=[k]
 while q:
  for v in ds[q.pop()]:
   if v not in b:q.append(v);b.add(v)
 cs.append(tuple(sorted(b)));seen.update(b)
print('classes',len(cs),'component sizes',Counter(map(len,cs)));print('family couplings',Counter(tuple(sorted({p for p,i in k})) for k in cs))
with open('K_classes.tsv','w') as f:
 for i,b in enumerate(sorted(cs)):print(i,*[p+':'+str(j) for p,j in b],sep='\t',file=f)
