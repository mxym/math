import numpy as np
from itertools import product
from collections import Counter,defaultdict
from functools import lru_cache
import json
from join import form,models,cgen,F
@lru_cache(None)
def sc(q):
 T=form(q); a=np.loadtxt(q+'.short',dtype=np.int64,ndmin=2);denom=int(open(q+'.form').read().splitlines()[-1].split()[0]);b=a[:,1:];v=b@T
 out=defaultdict(lambda:defaultdict(list))
 for n,p,cp in zip(a[:,0]*(F//denom),b,v):out[tuple(cp%F)][n].append((p,cp))
 return out
@lru_cache(None)
def small(name):
 roots,words=models[name];ca=cgen(roots,*words);ns=[];p=[];v=[]
 for a in ca:
  gs=[sc(q)[x] for q,x in zip(roots,a)]
  for degs in product(*(s.keys() for s in gs)):
   deg=sum(degs)
   if deg>3*F or deg%F:continue
   for z in product(*(s[t] for s,t in zip(gs,degs))):
    ns.append(deg//F);p.append(np.concatenate([w[0] for w in z])); v.append(np.concatenate([w[1] for w in z]))
 return np.array(ns,dtype=np.int16),np.array(p,dtype=np.int16),np.array(v,dtype=np.int16)
def readpairs(name):
 C=[];D=[]
 for s in open(name+'.reps'):
  zz=json.loads(s);C.append(sum((v[0] for v in zz),[]));D.append(sum((v[1] for v in zz),[]))
 return np.array(C,dtype=np.int16),np.array(D,dtype=np.int16)
def run(name):
 n,p,v=small(name); C,D=readpairs(name);hs=Counter();sig=Counter()
 with open(name+'.pass','w') as out:
  for start in range(0,len(C),16):
   c=C[start:start+16];d=D[start:start+16];a=v@c.T;b=v@d.T;assert(np.all((a%F==0)&(b%F==0)))
   a//=F;b//=F
   de=7*n[:,None]-a*a-b*b
   for j,w in enumerate(de.T):
    # all cosets with delta<=7 are represented up to D shifts with |a|,|b|<=3; for delta=7, ||u||²≤25/7.
    iz=(abs(a[:,j])<=3)&(abs(b[:,j])<=3)&(n>0)
    u=min(w[iz]);hs[int(u)]+=1
    if u<5:continue
    arr=tuple(np.sum((w==x)&iz)//2 for x in (5,6,7));sig[arr]+=1
    print(start+j,*arr,file=out)
 print(name,'short',len(n),'delta_min',sorted(hs.items()),'pass',sum(sig.values()),'short-type-count',len(sig),flush=True)
if __name__=='__main__':
 for k in models:run(k)
