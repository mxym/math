import numpy as np
from functools import lru_cache
from collections import defaultdict, Counter
from itertools import product
import json,itertools,sys,pathlib
F=48;target=(7*F,7*F,0)
def form(q):
 r=open(q+'.form').read().splitlines();n=int(q[1:]);x=np.fromstring(r[-1],sep=' ',dtype='int64');return (F//x[0])*x[1:].reshape(n,n)
def cgen(roots,*words):
 cs=[tuple(tuple([0]*int(q[1:])) for q in roots)]
 for choices in words:
  o=tuple(tuple(sum((form(q)[:,i-1] for i in ch),start=np.zeros(int(q[1:]),dtype=int))%F) for q,ch in zip(roots,choices))
  def add(r):return tuple(tuple((x+y)%F for x,y in zip(p,q)) for p,q in zip(r,o))
  s=set(cs)
  for k in cs:
   t=add(k)
   while t not in s:s.add(t);t=add(t)
  cs=list(s)
 return sorted(cs)
models={'I17':(['B17'],[]),'E8':(['B9','E8'],[]),'D12p':(['B5','D12'],[[[],[12]]]),'E7x2':(['B3','E7','E7'],[[[],[6],[6]]]),'A15p':(['B2','A15'],[[[],[4]]]),'D8x2':(['B1','D8','D8'],[[[],[8],[1]],[[],[1],[8]]]),'A11E6':(['A11','E6'],[[[2],[1]]])}
@lru_cache(None)
def paired(q):
 T=form(q);a=np.loadtxt(q+'.pair',dtype=np.int64,ndmin=2);n=int(q[1:])
 denom=int(open(q+'.form').read().splitlines()[-1].split()[0]);h=a[:,:3]*(F//denom)
 p=a[:,3:3+n];v=a[:,3+n:];u=p@T%F;w=v@T%F
 bucket=defaultdict(lambda:defaultdict(list))
 for i in range(len(a)):
  bucket[(tuple(u[i]),tuple(w[i]))][tuple(h[i])].append((p[i].tolist(),v[i].tolist()))
 return bucket
def sub(t,s):return tuple(x-y for x,y in zip(t,s))
def rec(bs,goal):
 if len(bs)==1:
  for e in bs[0].get(goal,()):yield [e]
  return
 for k,es in bs[0].items():
  if k[0]>goal[0] or k[1]>goal[1]:continue
  for z in rec(bs[1:],sub(goal,k)):
   for e in es:yield [e]+z
def run(name):
 roots,words=models[name]; C=cgen(roots,*words);print(name,'glue',len(C),end=' ',flush=True)
 num=0
 with open(name+'.reps','w') as out:
  for a,b in product(C,repeat=2):
   ds=[paired(q)[ca,cb] for q,ca,cb in zip(roots,a,b)]
   for rr in rec(ds,target):
    print(json.dumps(rr,separators=(',',':')),file=out);num+=1
 print('W-pairs',num,flush=True)
if __name__=='__main__':
 for q in models:run(q)
