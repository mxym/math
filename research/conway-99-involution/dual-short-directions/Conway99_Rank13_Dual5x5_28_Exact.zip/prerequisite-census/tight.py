import itertools,numpy as np,collections
I=np.eye(7,dtype=int);r=lambda a,b:I[a%7]-I[b%7]
def blocks():
 out=collections.defaultdict(list)
 for e in itertools.permutations([1,2,3]):
  # hash the length of the root on support difference d; each root direction once.
  for fa in itertools.product(range(7),repeat=3):
   pairs=[(i,i+j) for i,j in zip(fa,e)]
   for orient in itertools.product([1,-1],repeat=3):
    a=[h*r(i,j) for h,(i,j) in zip(orient,pairs)]
    b0=[h*r(i-d,j-d) for d,(h,(i,j)) in enumerate(zip(orient,pairs),1)]
    for rel in itertools.product([1,-1],repeat=3):
     b=[u*t for u,t in zip(b0,rel)]
     if not np.any(sum(a+b)):out[rel].append(np.array(a+b))
 return out
def get():
 ds=blocks();counts={z:len(v) for z,v in ds.items()};print('cube-diff count',counts)
 for re,as_ in ds.items():
  op=tuple(-x for x in re)
  if not ds.get(op):continue
  a=as_[0];b=ds[op][0]
  u=np.vstack((np.eye(3,dtype=int),-np.eye(3,dtype=int)[[1,2,0]]));y={}
  for i,d in itertools.product(range(7),[1,2,3,-1,-2,-3]):
   h=[1,2,3,-1,-2,-3].index(d);y[i,(i+d)%7]=np.r_[np.roll(a[h],i),np.roll(b[h],i),u[h]]
  ns=[];ws=[];z=[];ch=[]
  for i in range(7):assert np.array_equal(sum(y[i,j] for j in range(7) if i!=j),np.zeros(17,dtype=int))
  Y=np.array(list(y.values()));assert np.all(np.sum(Y**2,axis=1)==5)
  for i,j in itertools.combinations(range(7),2):
   assert y[i,j]@y[j,i]==0
   for sg in [1,-1]:
    ws.append(y[i,j]+sg*y[j,i]);z.append(I[i]+sg*I[j])
  w=np.array(ws);z=np.array(z);P=14*np.eye(17,dtype=int);P[:7,:7]-=2;P[7:14,7:14]-=2
  assert np.array_equal(Y.T@Y,P) and np.array_equal(w.T@w,2*P) and not np.any(z.T@w)
  # integral mod-2 cut fails: I^3 columns are nonempty and invariant under rotation of seven axes, impossible for a cut.
  cut_ok=[]
  for k in range(17):
   rr=w[::2,k]%2;tri={p:int(q)for p,q in zip(itertools.combinations(range(7),2),rr)}
   cut_ok.append(all((tri[i,j]^tri[i,h]^tri[j,h])==0 for i,j,h in itertools.combinations(range(7),3)))
  print('chosen rel',re,op,'axis coefficients',a.tolist(),b.tolist(),'cut-passing coordinates',cut_ok)
  np.savetxt('I17_seven_frame.dat',np.array([y[i,j] for i in range(7) for j in range(7) if i!=j]),fmt='%d')
  return y
if __name__=='__main__':get()
