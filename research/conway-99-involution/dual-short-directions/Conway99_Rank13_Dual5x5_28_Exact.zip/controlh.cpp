#define main discovery_main
#include "physical.cpp"
#undef main
int main(){
 for(int i=0;i<pr.size();i++)for(int j=0;j<pr[i];j++)qr[i][j*j%pr[i]]=1;
 int n;cin>>D>>detF>>n;physmode=false;lead.resize(11);for(auto &v:lead)cin>>v;hinit();fhasse();for(auto&r:I)for(auto&x:r)cin>>x;Sig sig;for(auto&x:sig)cin>>x;vector<int> ch;
 for(int j=0;j<n;j++){Meta m;m.d=0;for(auto&x:m.v)cin>>x;int a,b;cin>>a>>b;ch.push_back((a+1)*3+b+1);for(int j=0;j<12;j++)m.av[j]=dot(I[j],m.v);m.nu=10*D-dot(m.av,m.v);md.push_back(m);}
 Run c(sig);vector<X>x;for(int j=0;j<n;j++){auto&v=c.pool[ch[j]];auto i=find_if(v.begin(),v.end(),[&](X const&w){return w.j==j;});demand(i!=v.end());x.push_back(*i);}
 int ct=0,no=0;for(int i=0;i<n;i++)for(int j=0;j<n;j++){int s;cin>>s;demand(c.vals(x[i],x[j],-s));ct++;if(!c.vals(x[i],x[j],70-s))no++;}
 demand(no==ct);cout<<"PASS, all "<<ct<<" genuine pairs accepted, "<<no<<" impossible pairs rejected.\n";
}
