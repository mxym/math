#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p work
CXX=${CXX:-g++}
FLAGS=(-O3 -std=c++17 -mpopcnt)
"$CXX" "${FLAGS[@]}" catalog.cpp -o work/catalog
work/catalog >work/layouts.tsv 2>work/catalog-burnside.txt
cmp layouts.tsv work/layouts.tsv
python3 check_inputs.py
python3 check_witnesses.py
"$CXX" "${FLAGS[@]}" cutcheck.cpp -o work/cutcheck
work/cutcheck
"$CXX" "${FLAGS[@]}" controlh.cpp -lgmpxx -lgmp -o work/controlh
work/controlh <controlh.in
"$CXX" "${FLAGS[@]}" rank_census.cpp -lgmpxx -lgmp -o work/rank_census
work/rank_census >work/ranks.tsv
python3 checkledger.py expected/ranks.tsv work/ranks.tsv
"$CXX" "${FLAGS[@]}" singular.cpp -lgmpxx -lgmp -o work/singular
work/singular >work/singular.tsv
python3 checkledger.py expected/singular.tsv work/singular.tsv
"$CXX" "${FLAGS[@]}" physical.cpp -lgmpxx -lgmp -o work/physical
if [ "${1:-full}" = 'quick' ]; then
 work/physical 890 891 1 >work/pilot.tsv
 grep -e '^890 ' expected/positive.tsv >work/pilot-expected.tsv
 python3 checkledger.py work/pilot.tsv work/pilot-expected.tsv
else
 work/physical 0 3580 1 >work/positive.tsv
 python3 checkledger.py expected/positive.tsv work/positive.tsv
fi
python3 checkledger.py
