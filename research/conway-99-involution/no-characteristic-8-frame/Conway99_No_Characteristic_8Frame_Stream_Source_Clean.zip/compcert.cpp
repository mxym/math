#include<bits/stdc++.h>
using namespace std;using U=uint32_t;using W=uint64_t;int pc(W v){return __builtin_popcountll(v);}using Dom=array<vector<int>,42>;int want[276],dif[2048][276];int nodes,lim;int dfs(Dom d){
 if(++nodes>lim)return -1;
 bool again=true;while(again){again=false;for(int i=0;i<276;i++){
  int mi[42],ma[42],lo=0,hi=0;for(int l=0;l<42;l++){mi[l]=1;ma[l]=0;for(int q:d[l])mi[l]&=dif[q][i],ma[l]|=dif[q][i];lo+=mi[l];hi+=ma[l];}
  if(want[i]<lo||want[i]>hi)return 0;if(lo==hi||(lo!=want[i]&&hi!=want[i]))continue;
  for(int l=0;l<42;l++)if(mi[l]!=ma[l]){int g=(want[i]==hi);auto &v=d[l];v.erase(remove_if(v.begin(),v.end(),[&](int q){return dif[q][i]!=g;}),v.end());assert(!v.empty());again=true;}
 }}
 int l=-1;for(int i=0;i<42;i++)if(d[i].size()>1&&(l<0||d[i].size()<d[l].size()))l=i;if(l<0)return 1;
 auto z=d[l];for(int q:z){d[l]={q};int a=dfs(d);if(a!=0)return a;}return 0;
}

struct Trit {W a[5]{},b[5]{};int get(int k)const{return ((a[k>>6]>>(k&63))&1)+2*((b[k>>6]>>(k&63))&1);}void set(int k,int x){if(x==1)a[k>>6]|=1ULL<<(k&63);if(x==2)b[k>>6]|=1ULL<<(k&63);}void neg(){for(int t=0;t<5;t++)swap(a[t],b[t]);} void sub(const Trit &w,bool neg){for(int t=0;t<5;t++){W x=a[t],y=b[t],u=neg?w.b[t]:w.a[t],v=neg?w.a[t]:w.b[t],z=~(x|y),h=~(u|v);a[t]=(x&h)|(z&v)|(y&u);b[t]=(y&h)|(z&u)|(x&v);}}int pivot()const{for(int t=0;t<5;t++)if(a[t]|b[t])return t*64+__builtin_ctzll(a[t]|b[t]);return 320;}};
struct G3 {Trit basis[318];bool used[318]{};bool add(Trit v){while(1){int i=v.pivot();if(i==320)return false;int x=v.get(i);if(used[i])v.sub(basis[i],x==2);else{if(x==2)v.neg();basis[i]=v;used[i]=true;return true;}}}};
Trit QV[2048];
int dot(Trit const&v,Trit const&w){int k=0;for(int t=0;t<5;t++)k+=pc((v.a[t]&w.a[t])|(v.b[t]&w.b[t]))-pc((v.a[t]&w.b[t])|(v.b[t]&w.a[t]));return (k%3+3)%3;}
bool linearcheck(Dom const&dom){G3 g;Trit r;int loc[276];copy_n(want,276,loc);
 for(int j=0;j<42;j++){int b=dom[j][0];for(int i=0;i<276;i++)loc[i]-=dif[b][i];
  for(int q:dom[j])if(q!=b){auto v=QV[q];v.sub(QV[b],false);g.add(v);}}
 for(int i=0;i<276;i++)r.set(i,(loc[i]%3+3)%3);
 int k;while(1){k=r.pivot();if(k==320)return true;if(!g.used[k])break;r.sub(g.basis[k],r.get(k)==2);}
 // Recover a left-kernel witness. Check it against the ORIGINAL, uneliminated one-per-label system.
 Trit y;y.set(k,1);for(int p=k-1;p>=0;p--)if(g.used[p])y.set(p,(3-dot(y,g.basis[p]))%3);
 int lhs=0,rhs=0;for(int i=0;i<276;i++)lhs+=want[i]*y.get(i);
 for(auto &d:dom){int z=dot(y,QV[d[0]]);for(int q:d)assert(dot(y,QV[q])==z);rhs+=z;}
 assert((lhs-rhs)%3!=0);return false;
}
int main(int ac,char**av){string d=av[1];vector<U>G,O;U u,C,D,V;ifstream co(d+"/code.dat"),mf(d+"/markpool.dat");while(co>>u){G.push_back(u);if(pc(u)==8)O.push_back(u);}string line;getline(mf,line);set<pair<U,U>> cm;while(mf>>C>>D>>V)cm.insert({C,D});vector<pair<U,U>>ms(cm.begin(),cm.end());vector<vector<array<int,7>>>fr(ms.size());for(int h=0;h<ms.size();h++){ifstream f(d+"/ureps"+to_string(h)+".dat");array<int,7>t;while(f>>t[0]){for(int i=1;i<7;i++)f>>t[i];fr[h].push_back(t);}}for(int q=0;q<2048;q++){int n=0;for(int i=0;i<24;i++)for(int j=0;j<i;j++)QV[q].set(n, dif[q][n]=((G[q]>>i)^(G[q]>>j))&1),n++;}
 int h,j,lh=-1,lj=-1,a,b,ax[7][24],off[276];W s,ls=~0ull;array<vector<int>,42>P;long long total=0,yes=0;while(cin>>h>>j>>s>>a>>b){if(h!=lh||j!=lj||s!=ls){lh=h;lj=j;ls=s;tie(C,D)=ms[h];auto t=fr[h][j];for(int i=0;i<7;i++)for(int z=0;z<24;z++){ax[i][z]=0;if(O[t[i]]>>z&1){int k=8*i+pc(O[t[i]]&((1u<<z)-1));ax[i][z]=(s>>k&1)?-2:2;}}
 for(auto &v:P)v.clear();for(int q=0;q<2048;q++){int ids[7],n=0,sg=0;bool ok=1;for(int i=0;i<7;i++){int v=0;for(int z=0;z<24;z++)v+=ax[i][z]*(G[q]>>z&1?-1:1);assert(v%8==0);v/=8;if(v){if(abs(v)!=1){ok=0;break;}ids[n++]=i;sg^=(v<0);}}if(ok&&n==2){int i=ids[0],j=ids[1];P[2*(i*6-i*(i-1)/2+j-i-1)+sg].push_back(q);}}
 int n=0;for(int u=0;u<24;u++)for(int v=0;v<u;v++){int z=42;for(int i=0;i<7;i++)z+=ax[i][u]*ax[i][v];off[n++]=z;}}
 int cc[24],dd[24];for(int i=0;i<24;i++){cc[i]=((C>>i&1)?-3:1)*(G[a]>>i&1?-1:1);dd[i]=((D>>i&1)?-3:1)*(G[b]>>i&1?-1:1);}int n=0;for(int u=0;u<24;u++)for(int v=0;v<u;v++){int z=off[n]+cc[u]*cc[v]+dd[u]*dd[v];assert(z%2==0);want[n++]=z/2;}
 Dom dom;for(int k=0;k<42;k++){for(int q:P[k]){U x=G[q]^G[a],y=G[q]^G[b];if(pc(x)-4*pc(x&C)==4&&pc(y)-4*pc(y&D)==4)dom[k].push_back(q);}assert(!dom[k].empty());}
 if(linearcheck(dom)){yes++;cout<<h<<" "<<j<<" "<<s<<" "<<a<<" "<<b<<"\n";}total++;}cerr<<"TOTAL "<<total<<" residue survivors "<<yes<<endl;}
