from pathlib import Path
from sympy.combinatorics import Permutation as P,PermutationGroup as PG
from functools import lru_cache
from collections import deque
import sys,itertools
d=Path(sys.argv[1]);z=list(map(int,(d/'group.dat').read_text().split()));gens=tuple(tuple(z[1+24*i:1+24*(i+1)]) for i in range(z[0]));ident=tuple(range(24));N=PG([P(g) for g in gens]).order()
def img(p,a):
 u=0
 while a:i=a&-a;u|=1<<p[i.bit_length()-1];a-=i
 return u
def mul(p,q):return tuple(q[t] for t in p)
def iv(a):
 p=[0]*24
 for j,x in enumerate(a):p[x]=j
 return tuple(p)
@lru_cache(None)
def stab(seq):
 if not seq:return N,gens
 n,gg=stab(seq[:-1]);b=seq[-1];t={b:ident};s=deque([b])
 while s:
  a=s.popleft()
  for g in gg:
   u=img(g,a)
   if u not in t:t[u]=mul(t[a],g);s.append(u)
 want=n//len(t);v={u:iv(g) for u,g in t.items()};H=PG([P(ident)]);ng=[]
 if want==1:return 1,()
 for u,p in t.items():
  for g in gg:
   h=mul(mul(p,g),v[img(g,u)])
   if not H.contains(P(h)):
    ng.append(h);H=PG([P(k) for k in ng])
    if H.order()==want:return want,tuple(ng)
 assert H.order()==want;return want,tuple(ng)
def dump(f,h,ts):
 n,gg=stab(tuple(ts));print(h,n,len(gg),*itertools.chain.from_iterable(gg),file=f)
ls=sorted(set(tuple(map(int,l.split()[:2])) for l in (d/'markpool.dat').read_text().splitlines()[1:]));f=(d/'pairgens.dat').open('w')
for h,p in enumerate(ls):dump(f,h,p)
