#include<bits/stdc++.h>
using namespace std;using U=uint32_t;int pc(U x){return __builtin_popcount(x);}struct Cand{int w,sq,sy,sm,ca,cb;};int checkU(U x){return 0;}
struct Driver{int col[24]{},val[4096][2],c[24],d[24],t[24],tail[25];bool even[4096]{};vector<Cand>a[24];int bound=48;int sumhi=0,mval=99,qual=0;long long leaf=0;
 void rec(int i,int sq,int sy,int sm,int ca,int cb){if(i==24){if((sm&1)||abs(ca)>24||abs(cb)>24)return;assert(ca%8==0&&cb%8==0&&sq%8==0&&even[sy]);int E=7*(sq/8)-(ca/8)*(ca/8)-(cb/8)*(cb/8);assert(E>=0);val[sy][(sm&3)/2]=min(val[sy][(sm&3)/2],E);leaf++;return;}
 for(auto v:a[i])if(sq+v.sq+tail[i+1]<=bound)rec(i+1,sq+v.sq,sy^v.sy,sm+v.sm,ca+v.ca,cb+v.cb);}
 void run(U C,U D,U V){fill(&val[0][0],&val[0][0]+4096*2,999);for(int i=0;i<24;i++){c[i]=(C>>i&1)?-3:1;d[i]=((D>>i&1)?-3:1)*((V>>i&1)?-1:1);}
 for(int h=0;h<4;h++)for(int e:{0,2}){tail[24]=0;for(int i=23;i>=0;i--){int t=e+(h&1?c[i]:0)+(h&2?d[i]:0);a[i].clear();int best=999;
 for(int w=-8;w<=8;w++)if((w-t)%4==0){int x=(w-t)/4;best=min(best,w*w);a[i].push_back({w,w*w,(x&1)?col[i]:0,x,w*c[i],w*d[i]});}tail[i]=tail[i+1]+best;}if(tail[0]<=bound)rec(0,0,0,0,0,0);}
 sumhi=0;mval=999;qual=0;for(int s=0;s<4096;s++)if(even[s]){int w=val[s][0]+val[s][1];mval=min(mval,w);if(w<42)qual++;int hi=min(6,2*((w-42)/4));sumhi+=max(0,hi);}
 }
};
int main(int ac,char**av){string p=av[1];ifstream co(p+"/code.dat"),m(p+"/markpool.dat");U C,D,V,v;vector<U>gs;while(co>>v)gs.push_back(v);Driver r;if(ac>2)r.bound=8*atoi(av[2]);for(int k=0;k<12;k++)for(int j=0;j<24;j++)if(gs[1<<k]>>j&1)r.col[j]|=1<<k;r.even[0]=true;for(int i=0;i<24;i++)for(int j=0;j<i;j++)for(int s=0;s<4096;s++)if(r.even[s])r.even[s^r.col[i]^r.col[j]]=true;assert(count(r.even,r.even+4096,true)==2048);
 string l;getline(m,l);int n=0,fail=0,agg=0;map<pair<int,int>,int> hist;while(m>>C>>D>>V){r.run(C,D,V);n++;if(r.qual)fail++;else if(r.sumhi<7168)agg++;else cout<<C<<" "<<D<<" "<<V<<" "<<r.sumhi<<"\n";hist[{r.mval,r.sumhi}]++;if(n%250==0)cerr<<n<<" "<<fail<<" "<<agg<<" "<<r.leaf<<endl;}
 cerr<<"done "<<n<<" pairfail "<<fail<<" aggfail "<<agg<<" survive "<<n-fail-agg<<endl;for(auto [k,z]:hist)cerr<<k.first<<' '<<k.second<<' '<<z<<'\n';}
