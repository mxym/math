from glue import *
expected={frozenset('000 033 111 122 203 230 312 321'.split()),frozenset('000 033 103 130 211 222 312 321'.split())}
p=[('D',8)]*3
hs={frozenset(''.join(map(str,r)) for r in z[h].tolist()) for z,w,d,h,plus in groups(p,1024)}
assert hs==expected
print('Both 3D8 classes match the exact glue signatures for the eight-column orthogonality proof.')
