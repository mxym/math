from minuscule import *
import numpy as np
from functools import lru_cache
from itertools import chain
def groups(ps,cap=4096):
 sz=[len(options(*p)) for p in ps];n=math.prod(sz)
 if n>cap:return
 op=[options(t,k) if t!='D' or k%2==0 else [0,Q(k,4),1,Q(k,4)] for t,k in ps];den=math.lcm(*(Q(v).denominator for z in op for v in z));tu=list(product(*[range(s) for s in sz]));z=np.array(tu,dtype=np.int16);stride=np.array([math.prod(sz[j+1:]) for j in range(len(sz))]);alph=[np.array([int(den*x) for x in y],dtype=int) for y in op];w=np.column_stack([a[z[:,i]] for i,a in enumerate(alph)]);subn=w.sum(axis=1);ok=(subn%den==0)&(subn>=3*den);ok[0]=True;pn=[];sg=[]
 for i,(t,k) in enumerate(ps):
  s=sz[i];xor=t=='D' and not k%2;a=z[:,i];pn.append((a[:,None]^a if xor else (a[:,None]+a)%s).astype(np.int16)*stride[i])
  perms=[]
  if xor:perms=[[0,1,3,2]]+([[0,2,1,3]] if k==4 else [])
  elif s>2:perms=[(-np.arange(s))%s]
  for pi in perms:sg.append(np.arange(n)+(np.asarray(pi)[a]-a)*stride[i])
  for j in range(i-1,-1,-1):
   if ps[i]==ps[j]:
    b=z[:,j];sg.append(np.arange(n)+(b-a)*(stride[i]-stride[j]));break
 plus=sum(pn).astype(np.int32);cyc=[]
 for a in range(n):
  u=0;orb=[u]
  while True:
   u=plus[u,a]
   if not u:break
   orb.append(int(u))
  cyc.append(tuple(orb))
 g=[a for a in range(1,n) if all(ok[list(cyc[a])]) and a==min(x for x in cyc[a] if len(cyc[x])==len(cyc[a]))] if False else [a for a in range(1,n) if all(ok[list(cyc[a])]) and a==min(x for x in cyc[a] if x%1==0 and set(cyc[x])==set(cyc[a]))]
 gens=[np.array(cyc[x],dtype=int) for x in g];ng=math.isqrt(n);assert ng*ng==n;seen={(0,)};q=[(0,)];out=[]
 while q:
  s=q.pop();h=np.array(s);opt=ok.copy();opt[h]=False
  for C in gens:
   if not opt[C[1]]:continue
   vals=plus[h[:,None],C];
   if np.any((subn[vals]-subn[h,None]-subn[C])%(2*den)):continue
   ss=tuple(sorted(set(vals.ravel().tolist())))
   if len(ss)>ng or ng%len(ss) or not np.all(ok[np.array(ss)]):continue
   # each coset generator with same span now covered by global seen
   if ss in seen:continue
   seen.add(ss);stack=[ss]
   while stack:
    H=np.array(stack.pop())
    for p in sg:
     aa=tuple(sorted(p[H].tolist()))
     if aa not in seen:seen.add(aa);stack.append(aa)
   if len(ss)==ng:out.append(ss)
   else:q.append(ss)
 for h in out:
  if any((subn[list(h)]//den)%2):yield z,w,den,np.array(h),plus
def assess(ps,z,w,den,h,plus):
  nr=np.array([n for t,n in ps]);tot=len(ps);bd=h[w[h].sum(axis=1)==3*den];v=np.unique(w[bd],axis=0);graph=[{i} for i in range(tot)]
  for row in v:
   S=set(np.flatnonzero(row));u=[x for x in graph if x&S]
   for x in u:graph.remove(x)
   if u:graph.append(set.union(*u))
  if len(graph)!=1 or not len(v):return 'separate'
  n=1<<tot;bits=((np.arange(n)[:,None]>>np.arange(tot))%2);low=np.array([lower(x)*den for x in bits@nr]);M=v@bits.T
  if any(42*M.max(0)<low):return 'trace'
  # genuine rational LP infeasibility certified by integer separation via verified Farkas ray
  from scipy.optimize import linprog
  A=M.T;N=len(v);q=linprog(np.r_[np.zeros(N),np.ones(n)],A_ub=np.hstack((-A,-np.eye(n))),b_ub=-low,A_eq=[np.r_[np.ones(N),np.zeros(n)]],b_eq=[42],bounds=(0,None),method='highs')
  assert q.success
  if q.fun>1.e-7:
   y=np.rint(-1.e7*q.ineqlin.marginals).astype(np.int64);assert np.min(y)>=0 and int(y@low)>42*int(max(M@y))
   return 'LP'
  return 'survives'
if __name__=='__main__':
 for ps,name,c in catalogue():
  if sum(n for t,n in ps)!=24 or math.prod(len(options(*p)) for p in ps)>int(sys.argv[1]):continue
  g=Counter(assess(ps,z,w,de,h,plus) for z,w,de,h,plus in groups(ps,int(sys.argv[1])));print(name,c,g,flush=True);assert sum(g.values())==c
