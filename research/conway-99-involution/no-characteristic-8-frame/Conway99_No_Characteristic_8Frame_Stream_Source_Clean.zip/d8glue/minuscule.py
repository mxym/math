from fractions import Fraction as Q
from itertools import product,combinations
from collections import Counter
import math,sys,re
def catalogue():
 tab=[]
 for l in open('root24.txt'):
  w=l.split()
  if len(w)<=2:continue
  s=w[:-2];parts=[]
  for token in s:
   if token=='empty':continue
   m=re.fullmatch(r'(\d*)([ADE])(\d+)',token);parts += [(m[2],int(m[3]))]*int(m[1] or 1)
  tab.append((parts,' '.join(s),int(w[-1])))
 assert len(tab)==149 and sum(b[2] for b in tab)==156
 return tab
def options(t,n):
 if t=='A':return [Q(k*(n+1-k),n+1) for k in range(n+1)]
 if t=='E':return {6:[0,Q(4,3),Q(4,3)],7:[0,Q(3,2)],8:[0]}[n]
 if t=='D':return [0,1,Q(n,4),Q(n,4)]
def types(rs,full,proper=False):
 opt=[options(*r) for r in rs];out=[]
 def rec(i,s,z):
  if i==len(rs):
   if s==3 or not full:out.append(tuple(z)+(() if full else (3-s,)))
   return
  for k,v in enumerate(opt[i]):
   if not proper and v in opt[i][:k]:continue
   if s+v<=3:rec(i+1,s+v,z+[k if proper else v])
 rec(0,0,[]);return out
def lower(d):return 3*min(7,max(0,d-2))+7*max(0,d-9)
def reject(ps,name):
  # Skip cheap but expensive large cases; this is an explicit partial filter.
  if len(ps)>11:return
  ns=[n for _,n in ps];full=sum(ns)==24;vs=types(ps,full)
  if not full:ns.append(24-sum(ns))
  sets=[{j for j,v in enumerate(a) if v} for a in vs]
  # If graph of nonzero projections is disconnected then b's cannot generate all roots (and span dimension≥22).
  atoms=[{i} for i in range(len(ns))]
  for e in sets:
   met=[u for u in atoms if u&e]
   if not met:continue
   k=set.union(*met)
   for u in met:atoms.remove(u)
   atoms.append(k)
  if not any(set(range(len(ps)))<=k and sum(ns[j] for j in k)>=22 and any(e for e in sets if e<=k) for k in atoms):return 'span'
  # Every interior subset ignoring residual has per-b projection max≤3; exact trace lower test.
  import numpy as np
  if len(ns)==0:return
  den=math.lcm(*(Q(x).denominator for v in vs for x in v));A=np.array([[int(x*den) for x in v] for v in vs]);total=1<<len(ns);bits=((np.arange(total)[:,None]>>np.arange(len(ns)))%2); low=np.array([lower(s) for s in bits@ns]);M=A@bits.T
  ix=np.flatnonzero(42*M.max(axis=0)<den*low)
  if len(ix):
   j=ix[0];return ('trace',int(j),int(M[:,j].max()),int(den),int(low[j]))
if __name__=='__main__':
 c=0
 for ps,name,z in catalogue():
  why=reject(ps,name)
  if why:print(name,z,why,flush=True);c+=z
 print('excluded',c)
