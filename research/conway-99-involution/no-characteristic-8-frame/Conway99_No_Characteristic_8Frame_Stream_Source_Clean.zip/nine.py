"""Recover each code tetrad-system invariant and rank-24 root-system type from scratch."""
from pathlib import Path
import itertools, sympy as sp
def components(vs,dot):
 left=set(range(len(vs)));ans=[]
 while left:
  a=left.pop();cs=[a]
  for x in cs:
   ns=[y for y in left if dot(vs[x],vs[y])];cs.extend(ns);left.difference_update(ns)
  ans.append([vs[x] for x in cs])
 return ans
seen=set()
for f in sorted(Path('nine').glob('*.dat')):
 G=list(map(int,f.read_text().split()));bs=[G[1<<j] for j in range(12)];assert G==sorted(set(G)) and len(G)==4096 and all(v.bit_count()%4==0 for v in G) and all(G[i^(1<<j)]==w^bs[j] for i,w in enumerate(G)for j in range(12))
 assert all((v&w).bit_count()%2==0 for v in bs for w in bs);ts=[w for w in G if w.bit_count()==4];tc=components(ts,lambda a,b:a&b);sig=tuple(sorted((__import__('functools').reduce(int.__or__,c).bit_count(),len(c))for c in tc));assert sig not in seen;seen.add(sig)
 if f.stem=='golay':assert not sig
 else:assert '_'.join(str(a)+'x'+str(b)for a,b in sig)==f.stem
 rs=[]
 for t in ts:
  pos=[j for j in range(24)if t>>j&1]
  for m in (0,3,5,6):
   v=[0]*24
   for i,j in enumerate(pos):v[j]=2*(-1 if m>>i&1 else 1)
   rs.append(v)
 rc=components(rs,lambda a,b:sum(x*y for x,y in zip(a,b)))
 ty=sorted((sp.Matrix(c).rank(),2*len(c))for c in rc)
 expect={'golay':[],'4x1_4x1_4x1_4x1_4x1_4x1':[(1,2)]*24,'6x3_6x3_6x3_6x3':[(3,12)]*8,'8x6_8x6_8x6':[(4,24)]*6,'12x15_12x15':[(6,60)]*4,'7x7_7x7_10x10':[(5,40)]*2+[(7,56)]*2,'24x66':[(12,264)]*2,'8x14_16x28':[(8,112)]*3,'8x14_8x14_8x14':[(8,112)]*3}
 assert ty==expect[f.stem]; assert not f.stem.startswith('8x14') or sum(any(sum(rr)!=0 for rr in c)for c in rc)==(2 if f.stem=='8x14_16x28' else 3); print(f.stem,ty,'nonzero projections of all-ones norm-three:',sum(any(sum(rr)!=0 for rr in c)for c in rc))
assert len(seen)==9
