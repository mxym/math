#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c MANIFEST.sha256 >/dev/null
case "${1:-stream}" in
stream) MARK=compmark_stream;;
canonical) MARK=compmark;;
*) echo "usage: bash verify.sh [stream|canonical]" >&2; exit 2;;
esac
for x in markscan sets ocquot cucap "$MARK" compcert;do g++ -O3 -std=c++17 -march=native "$x.cpp" -o "$x";done
python nine.py
python d8glue/d8check.py
for d in type_24A1;do
 python validate.py "$d"
 ./markscan "$d" emit > "$d/markpool.dat" 2>"$d/markscan.log"
 python stabs.py "$d"
 (while read -r h _;do ./sets "$d" "$h" emit 2>"$d/set$h.log" | ./ocquot "$d" "$h" >"$d/ureps$h.dat";done <"$d/pairgens.dat") 2>"$d/ureps.log"
 ./cucap "$d" 6 >"$d/cap6.out" 2>"$d/cap6.log"
 "./$MARK" "$d" 2>"$d/cm.log" | ./compcert "$d" >"$d/residue.out" 2>"$d/cc.log"
 cmp "$d/cm.log" expected_cm.log; cmp "$d/cc.log" expected_cc.log
 target=22252181;marks=3555;pairs=39
 test ! -s "$d/residue.out";cat "$d/cc.log";grep -Fx "TOTAL $target residue survivors 0" "$d/cc.log" >/dev/null
 test "$(( $(wc -l < "$d/markpool.dat") - 1 ))" -eq "$marks";test "$(wc -l < "$d/pairgens.dat")" -eq "$pairs"
done
echo ALL VERIFIED
