#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c MANIFEST.sha256 >/dev/null
for x in markscan sets ocquot cucap compmark compcert;do g++ -O3 -std=c++17 -march=native "$x.cpp" -o "$x";done
for d in type_6D4 type_8A3;do
 python validate.py "$d"
 ./markscan "$d" emit > "$d/markpool.dat" 2>"$d/markscan.log"
 python stabs.py "$d"
 (while read -r h _;do ./sets "$d" "$h" emit 2>"$d/set$h.log" | ./ocquot "$d" "$h" >"$d/ureps$h.dat";done <"$d/pairgens.dat") 2>"$d/ureps.log"
 ./cucap "$d" 6 >"$d/cap6.out" 2>"$d/cap6.log"
 ./compmark "$d" 2>"$d/cm.log" | ./compcert "$d" >"$d/residue.out" 2>"$d/cc.log"
 target=904780;marks=2820;pairs=27
 if [[ "$d" == type_8A3 ]];then target=21032703;marks=4853;pairs=48;fi
 test ! -s "$d/residue.out";cat "$d/cc.log";grep -Fx "TOTAL $target residue survivors 0" "$d/cc.log" >/dev/null
 test "$(( $(wc -l < "$d/markpool.dat") - 1 ))" -eq "$marks";test "$(wc -l < "$d/pairgens.dat")" -eq "$pairs"
done
echo ALL VERIFIED
