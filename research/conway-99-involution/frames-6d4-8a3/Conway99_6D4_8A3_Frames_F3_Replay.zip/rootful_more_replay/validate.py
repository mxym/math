from pathlib import Path
from collections import Counter
import itertools, sys, sympy as sp
p=Path(sys.argv[1]);G=list(map(int,(p/'code.dat').read_text().split()));cs=set(G);bs=[G[1<<j] for j in range(12)]
assert len(cs)==4096 and G==sorted(cs) and G[-1]==(1<<24)-1 and all(v.bit_count()%4==0 for v in G)
for i,w in enumerate(G):assert all(G[i^(1<<j)]==w^bs[j] for j in range(12))
assert all((u&v).bit_count()%2==0 for u in bs for v in bs)
gen=list(map(int,(p/'group.dat').read_text().split()));assert len(gen)==1+24*gen[0]
def img(q,w):return sum(1<<q[j] for j in range(24) if w>>j&1)
for i in range(gen[0]):
 q=gen[1+24*i:1+24*(i+1)];assert sorted(q)==list(range(24)) and all(img(q,w) in cs for w in bs)
rs=[]
for t in G:
 if t.bit_count()!=4:continue
 pos=[i for i in range(24) if t>>i&1]
 for n in [0,3,5,6]: # one antipodal representative of each even sign pattern
  w=[0]*24
  for i,j in enumerate(pos):w[j]=(-2 if n>>i&1 else 2)
  rs.append(w)
left=set(range(len(rs)));comp=[]
while left:
 seed=left.pop();stack=[seed];c=[seed]
 while stack:
  a=stack.pop();ne=[b for b in left if sum(x*y for x,y in zip(rs[a],rs[b]))]
  c+=ne;stack+=ne;left.difference_update(ne)
 comp.append((sp.Matrix([rs[i] for i in c]).rank(),2*len(c)))
expect={'type_6D4':[(4,24)]*6,'type_8A3':[(3,12)]*8}[p.name]
assert sorted(comp)==sorted(expect)
print('Validated code & ambient roots',str(p),sorted(comp),flush=True)
