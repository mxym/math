#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
g++ -std=c++17 -O3 rup.cpp -o "$D/check"
python test_totalizer.py
python -u replay.py
for f in rup/*.rup.gz; do
  h=${f##*/}; h=${h%%.*}
  python replay.py "$h" "$D/instance.cnf"
  gzip -cd "$f" | "$D/check" "$D/instance.cnf"
done
