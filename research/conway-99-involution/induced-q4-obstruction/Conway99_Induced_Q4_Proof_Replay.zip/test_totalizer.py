from cnf import CNF
from itertools import product
# Independent unit-propagation sanity check on all subsets and both bounds at sizes 1..7.
def forced(clauses,v):
 v=dict(v)
 while True:
  old=len(v)
  for c in clauses:
   if any(v.get(abs(x))==(x>0) for x in c):continue
   a=[x for x in c if abs(x) not in v]
   if not a:return False
   if len(a)==1:v[abs(a[0])]=(a[0]>0)
  if len(v)==old:return True
for n in range(1,8):
 for k in range(n+1):
  for eq in (False,True):
   C=CNF(n);C.constraint(range(1,n+1),k,eq)
   for a in product((False,True),repeat=n):
    assert forced(C.cs,dict(enumerate(a,1)))==(sum(a)==k if eq else sum(a)<=k)
print('Totalizer exhaustive truth-table controls 1..7 passed.')
