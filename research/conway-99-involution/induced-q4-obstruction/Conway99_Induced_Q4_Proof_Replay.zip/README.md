# Induced Q4 obstruction for Conway's 99-graph
Read Theorem.md for the self-contained reduction and its limits. Run `bash verify.sh` to rebuild every rational, linear and Boolean test and check all stored certificates. Dependencies: Python 3, numpy, scipy, sympy, gzip, and g++ (C++17). No SAT solver, LP solver, network, GPU or user account is needed. A fresh run takes several minutes.

The proof assumes an induced four-cube but no graph automorphism. It does **not** settle Conway's graph-existence question. The 41 files under rup/ are finite reverse-unit-propagation refutations; the reader may generate a particular core's DIMACS file with `python replay.py 89 example.cnf`. Proof literal 1 is an independently true sentinel; each mathematical variable j is numbered j+1 in its proof.
