"""Independent certificate replay: no external service and no numerical optimization.
Run either all local moment separations, or generate a terminal Boolean CNF."""
import gzip,json,sys,math
from itertools import combinations,product
from collections import Counter
from pathlib import Path
from sympy import Matrix
import numpy as np
from scipy.sparse import csr_matrix,vstack
from enum_zero import Is,azorbit
from cnf import CNF
def bits(m,n):return [(m>>i)&1 for i in range(n)]
def mask(t):return sum(1<<i for i in t)
def incidence(A,E):
 X=np.array([bits(x,8) for x in A]);B=np.zeros((19,19),dtype=int);B[:11,11:]=X;B[11:,:11]=X.T
 for i,j in E:B[i,j]=B[j,i]=1
 R=12*np.eye(19,dtype=int)+2-B-B@B
 H=np.array([[int(i==j or (i+1)%8==j) for j in range(8)] for i in range(8)])
 R[11:,11:]-=2*(H@H.T);assert np.min(R)>=0
 allsig=[]
 for m in range(256):
  ii=[i for i in range(8) if m>>i&1]
  if len(ii)>4 or any(R[11+a,11+b]==0 for a,b in combinations(ii,2)):continue
  for nn in combinations([q for q in range(11) if all(R[q,11+i]>0 for i in ii)],len(ii)+1):
   if any(R[a,b]==0 for a,b in combinations(nn,2)):continue
   w=np.array(bits(mask(nn)+(m<<11),19))
   if max(B@w+w)>2:continue
   allsig.append(w)
 W=np.array(allsig);u,v=np.triu_indices(19);return B,H,R,W,(W[:,u]*W[:,v]).T,R[u,v]
def folded(B,H,R,W):
    groups=list(product(range(0,8,2),range(1,8,2)));spec=[(g,d,2*(2-int(d==1)-int((g[0]-g[1])%8 in (1,7)))) for g in groups for d in (1,3) if d!=1 or (g[0]-g[1])%8 not in (1,7)]
    dvec=np.array([[i in g for i in range(8)] for g,d,c in spec],int);D=H@dvec.T
    ii,jj=np.nonzero(np.all((B@W.T+W.T)[11:,:].T[:,None,:]+D.T[None,:,:]<=2,axis=2)&~np.any((W[:,11:,None]!=0)&(D[None,:,:]>0),axis=1))
    w=W[ii];g=dvec[jj];d=np.array([1 if spec[j][1]==1 else -1 for j in jj]);ok=np.ones(len(ii),dtype=bool)
    # Orbit-sum basis on cube antipodes and individual core vertices elsewhere.
    diag=np.array([2]*8+[1]*19);adj=np.zeros((27,27),dtype=int);adj[:8,:8]=np.array([[2*((i-j)%2!=0) for i in range(8)] for j in range(8)]);adj[:8,19:]=2*H.T;adj[19:,:8]=2*H;adj[8:,8:]=B
    for k,t,l,c in [(3,-1,9,1),(4,1,11,-2)]:
       M=l*(k*np.diag(diag)+t*adj)+c*np.outer(diag,diag)
       ix=list(range(1 if k==3 else 2,27))
       try:Z,de=Matrix(M[np.ix_(ix,ix)]).to_DM().inv_den()
       except Exception:
        ix=list(Matrix(M).rref()[1]);Z,de=Matrix(M[np.ix_(ix,ix)]).to_DM().inv_den()
       a=[int(v) for v in Z.to_Matrix()];de=int(de);factor=math.gcd(de,*a)*(-1 if de<0 else 1);a=[v//factor for v in a];de//=factor
       lim=max(abs(v) for v in a)*len(ix)**2*15**2*(k*k-4)+300*de
       Z=np.array(a,dtype=object if lim>=2**61 else 'int64').reshape(len(ix),len(ix));u=(t*l*np.hstack((g,w))+c*diag)[:,ix]
       # anti cube component has norm1 and internal adjacency moment +1 for distance1, -1 for distance3
       val=((u@Z)*u).sum(1);ok&=((k*k-4)*val+l*(k-t*d)*de<=(k*k-4)*(l*k+c)*de)
    w=w[ok];g=g[ok];j=jj[ok];u,v=np.triu_indices(19);sc=csr_matrix((np.ones(len(j),dtype=int),(j,np.arange(len(j)))),shape=(len(spec),len(j)))
    mat=vstack((sc,csr_matrix((w[:,u]*w[:,v]).T),csr_matrix(np.einsum('ij,ik->ijk',w,g).reshape(len(j),19*8).T))).tocsr()
    dem=np.r_[[s[2] for s in spec],R[u,v],np.vstack((4-2*B[:11,11:]@H,2-2*H)).ravel()]
    return mat,dem,w,g
def separated(Q,r,Y):
 y=np.zeros(len(r),dtype='int64')
 for i,z in Y.items():y[int(i)]=int(z)
 # conservatively check no 64-bit overflow
 assert sum(map(abs,map(int,y)))*max(64,int(np.max(abs(r))))<2**62
 assert int(y@r)>64*max(0,int(np.max(y@Q)))
def clauses(Q,r,w,g):
 col=[i for i,s in enumerate(w) for _ in range(2 if s.sum()==1 else 1)];Q=Q[:,col].tocsr();w=w[col];g=g[col];seen=set();C=CNF(len(col));vd=lambda q:[a+1 for a in q]
 for k in range(len(col)-1):
  if col[k]==col[k+1]:C.add(-(k+2),k+1)
 for i,k in enumerate(r):
  aa=vd(Q.indices[Q.indptr[i]:Q.indptr[i+1]].tolist());p=(tuple(aa),int(k),True)
  if p not in seen:C.constraint(*p);seen.add(p)
 triples={}
 for j,row in enumerate(w):
  for a in combinations(np.flatnonzero(row).tolist(),3):triples.setdefault(a,[]).append(j+1)
 for aa in triples.values():
  p=(tuple(aa),1,False)
  if p not in seen:C.constraint(*p);seen.add(p)
 for a,b in combinations(range(19),2):
  i0=w[:,a]*w[:,b]
  for z in range(8):
   p=(tuple(vd(np.flatnonzero(i0*g[:,z]).tolist())),2,False)
   if p not in seen:C.constraint(*p);seen.add(p)
 return C
def load():
 a=json.load(gzip.open('census19.json.gz','rt'));b={h:(i,s,y) for h,i,s,y in json.load(gzip.open('proof35_0.json.gz','rt'))};x,n=Is(0);assert len(x)==40 and sum(n.values())==404
 return a,b,x
if __name__=='__main__':
 a,b,x=load()
 if len(sys.argv)>1:
  h=int(sys.argv[1]);i,E,*_=a[h];B,H,R,W,*_=incidence(x[i],E);Q,r,w,g=folded(B,H,R,W);C=clauses(Q,r,w,g);C.outfile(sys.argv[2]);print(h,len(w),C.n,len(C.cs));sys.exit(0)
 h=0;c=Counter();term=[]
 for i,X in enumerate(x):
  for E,n in azorbit(X):
   ri,re,rn,rs,ry=a[h];assert (i,E,n)==(ri,tuple(map(tuple,re)),rn)
   B,H,R,W,Q0,r0=incidence(X,E)
   if rs=='no':separated(np.vstack((np.ones(len(W),dtype=int),Q0)),np.r_[64,r0],ry[0]);c['first']+=1
   else:
    bi,s,y=b[h];assert bi==i
    if s=='excluded':Q,r,w,g=folded(B,H,R,W);separated(Q,r,y);c['second']+=1
    else:term.append(h)
   h+=1
  print('finished zero-incidence class',i,flush=True)
 assert h==len(a)==2433 and len(b)==861 and c=={'first':1572,'second':820} and len(term)==41
 files={int(p.name.split('.')[0]) for p in Path('rup').glob('*.rup.gz')}
 assert files==set(term), ('terminal proof manifest differs',files^set(term))
 print('Exact moment audit complete:',c,'41 terminal cores',term)
