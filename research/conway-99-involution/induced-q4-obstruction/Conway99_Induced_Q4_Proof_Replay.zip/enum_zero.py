from itertools import combinations,combinations_with_replacement,permutations
from collections import Counter
import numpy as np
from functools import lru_cache
bc=int.bit_count
def mask(I):return sum(1<<i for i in I)
Z={k:[mask(S) for S in combinations(range(8),k) if all((i+1)%8 not in S for i in S)] for k in [2,3,4]}
G=[[(s+t*i)%8 for i in range(8)] for t in (1,-1) for s in range(8)]
tab=np.array([[mask(p[i] for i in range(8) if a>>i&1) for a in range(256)] for p in G])
def canon(X):return min(tuple(sorted(map(int,row))) for row in tab[:,X])
def Is(a=0):
 caps=[4+a*(i in [0,4]) for i in range(8)];Gm=G if not a else [g for g in G if {g[0],g[4]}=={0,4}]
 typ=np.array([[(x>>i)&1 for i in range(8)] for x in range(256)])
 num=Counter();out=set()
 for t in range(3):
  n1=2*(5+a)-2*t;n0=11-n1-t
  if n0<0:continue
  res2={}
  for S in combinations_with_replacement(Z[2],n0):
   key=tuple(typ[list(S)].sum(0));res2.setdefault(key,[]).append(S)
  for q in combinations(Z[4],t):
   for r in combinations([x for x in Z[3] if all(bc(x&y)<=2 for y in q)],n1):
    qr=q+r;v=tuple(caps-typ[list(qr)].sum(0))
    for s in res2.get(v,[]):
     L=tuple(sorted(qr+s));J=typ[list(L)];cross=J.T@J
     if any(cross[i,j]+int(a and (i,j)==(0,4))>2 for i,j in combinations(range(8),2)):continue
     num[t]+=1;out.add(canon(L) if not a else min(tuple(sorted(mask(p[j] for j in range(8) if x>>j&1) for x in L)) for p in Gm))
 return sorted(out),num
def Azs(X,a=0):
 V=list(range(11));typ=np.array([[(x>>i)&1 for i in range(8)] for x in X]);adj=[[j for j in range(i+1,11) if bc(X[i]&X[j])<=1] for i in V];deg=[bc(x)-2 for x in X];tri=typ@typ.T;A2=np.zeros((8,8),dtype='i1')
 if a:A2[0,4]=A2[4,0]=1
 Ed=[];mat=np.zeros((11,11),dtype='i1')
 def rec(i):
  if i==11:
   if np.any((tri+mat+mat@mat)[np.triu_indices(11,1)]>2) or np.max(typ+mat@typ+typ@A2)>2:return
   yield tuple(Ed);return
  for js in combinations([j for j in adj[i] if deg[j]],deg[i]):
   k=len(js)
   for j in js:deg[j]-=1;Ed.append((i,j));mat[i,j]=mat[j,i]=1
   yield from rec(i+1)
   for j in js:deg[j]+=1;Ed.pop();mat[i,j]=mat[j,i]=0
 yield from rec(0)
def azorbit(X):
 X=tuple(X);V=list(range(11));gg=[]
 for p in G:
  Y=tuple(mask(p[k] for k in range(8) if x>>k&1) for x in X)
  if sorted(Y)!=sorted(X):continue
  keys=sorted(set(X));S=[[i for i,y in enumerate(Y) if y==k] for k in keys];T=[[i for i,y in enumerate(X) if y==k] for k in keys]
  from itertools import product
  for pp in product(*[list(permutations(t)) for t in T]):
   v=list(range(11))
   for a,b in zip(S,pp):
    for i,j in zip(a,b):v[i]=j
   gg.append(v)
 seen=set()
 for e in Azs(X):
  f=tuple(sorted(e))
  if f in seen:continue
  orb={tuple(sorted(tuple(sorted((p[i],p[j]))) for i,j in e)) for p in gg};seen|=orb
  yield f,len(orb)
