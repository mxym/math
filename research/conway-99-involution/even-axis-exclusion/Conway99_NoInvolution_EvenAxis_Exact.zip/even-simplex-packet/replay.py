#!/usr/bin/env python3
"""Replay exact even-axis coverage. Python 3.10+, g++17, no network or solver."""
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from concurrent.futures import ThreadPoolExecutor
import sys,os,shutil,subprocess
P=Path(__file__).resolve().parent;mode=sys.argv[1]if len(sys.argv)>1 else 'quick';J=int(os.environ.get('JOBS','1'))
def ck(x):
 if not x:raise ArithmeticError('fresh replay differs from frozen evidence')
ck(mode in ('audit','quick','full','uniform','terminal')and J>=1)
def call(args,**kw):return subprocess.run([str(x)for x in args],check=True,**kw)
if (P/'MANIFEST.sha256').exists():call(['sha256sum','--quiet','-c','MANIFEST.sha256'],cwd=P)
call([sys.executable,'-B',P/'audit.py'])
with TemporaryDirectory()as td:
 tmp=Path(td);low=tmp/'low-simplex-packet'
 with ZipFile(P/'prerequisites/Conway99_Involution_SimplexLowRanks.zip')as z:z.extractall(tmp)
 call([sys.executable,'-B','audit.py'],cwd=low)
 if mode=='audit':sys.exit()
 if mode=='full' and os.environ.get('FULL_LOW','0')=='1':call(['bash','replay.sh','full'],cwd=low)
 work=tmp/'unsigned15';shutil.copytree(P/'unsigned15',work);shutil.copytree(P/'dualplanes',tmp/'dualplanes')
 sf=work/'sf-run';bindir=tmp/'bin';bindir.mkdir();(sf/'orbits').mkdir(exist_ok=True)
 def build(n):call(['g++','-O3','-std=c++17','-w',work/(n+'.cpp'),'-o',bindir/n])
 def output(n,*args,buf=None):
  return call([bindir/n,*args],cwd=work,input=buf,capture_output=True,text=True).stdout.strip().splitlines()
 def rows(f):return f.read_text().strip().splitlines()
 def clean(a):return [s.split(' cpu ')[0].strip()for s in a]
 def key(x):return [x[0],x[1],x[3]]
 def get(x,k):return int(x[x.index(k)+1])
 call(['g++','-O3','-std=c++17',tmp/'dualplanes/unary5-packet/catalog.cpp','-o',bindir/'catalog'])
 ck(output('catalog')==rows(tmp/'dualplanes/unary5-packet/layouts.tsv'))
 old=(sf/'coord6.tsv').read_bytes();call([sys.executable,'-B','sautdata.py'],cwd=work);ck(old==(sf/'coord6.tsv').read_bytes())
 for n,f in [('shighctrl','shighctrl.log'),('shighcaps','shighcaps.log'),('srealctrl','realctrl.log')]:
  build(n);ck(output(n)==rows(sf/f))
 print('PASS finite 7-space, isometry, product masks, literal graph and Cauchy controls',flush=True)
 build('sorbit-fast');build('strong-roster');build('seven-orbit');fresh=[]
 for i in (0,1,11):
  for p in (0,1):
   independent=output('sorbit-fast',i,p);real=output('strong-roster',i,p,0,0,1000000000)
   ck(real[:-1]==independent)
   (sf/'orbits'/f'{i}.{p}.fast').write_text('\n'.join(real[:-1])+'\n')
  fresh+=output('seven-orbit',i,i+1)
 ck(fresh==rows(sf/'seven-orbit.log'))
 print('PASS all six terminal chart/parity full-set orbit transport comparisons',flush=True)
 first=rows(sf/'direct-initial.tsv');strong=rows(sf/'direct-strong.tsv')
 fullkeys=sorted({tuple(map(int,key(v.split())))for v in first+strong});ck(len(fullkeys)==3156)
 if mode=='terminal':
  build('sref-range')
  def literal(k):
   i,p=k;ls=output('sref-range',i,p,0,0,1000000000);ck(len(ls)==1);w=ls[0].split();ck(all(get(w,z)==0 for z in ('open','limited','truncated'))and get(w,'checked')==get(w,'outer')==(42 if i==0 else 210))
  with ThreadPoolExecutor(J)as ex:list(ex.map(literal,[(i,p)for i in (0,1,11)for p in (0,1)]))
  print('PASS alternate scalar terminal reference: all 924 normalized terminal stars, no open',flush=True);sys.exit()
 if mode=='uniform':
  build('suniform')
  def uniform(keys):
   out=output('suniform',buf=''.join('%d %d %d\n'%k for k in keys));ck(len(out)==len(keys))
   for k,line in zip(keys,out):
    w=line.split();ck(tuple(map(int,w[:3]))==k and all(get(w,z)==0 for z in ('truncated','limited','open'))and get(w,'checked')==get(w,'outer'))
  with ThreadPoolExecutor(J)as ex:list(ex.map(uniform,[fullkeys[j::J]for j in range(J)]))
  print('PASS uniform uncapped direct replay: every one of 3156 even-axis jobs, 0 open',flush=True);sys.exit()
 for n,name in [('sref-range','even-ref-small.log'),('sref-depth','high-ref-positive.log')]:
  build(n);ls=rows(sf/name)
  for line in ls:
   w=line.split();a=w.index('range');args=key(w)+w[a+1:a+3]
   if n=='sref-depth':args.append(get(w,'ref'))
   ck(clean(output(n,*args))==clean([line]))
 print('PASS independent nonquotiented scalar terminal search, all six fixtures and both nonzero examples',flush=True)
 if mode=='full':
  for line in rows(sf/'high-literal.log'):
   w=line.split();a=w.index('range');ck(clean(output('sref-range',*key(w),*w[a+1:a+3]))==clean([line]))
  build('sstar');ck(clean(output('sstar',0,3580))==clean(rows(sf/'star.tsv')))
 build('srerun');build('sstrong-range')
 if mode=='quick':
  first=first[:2]+first[1000:1002]+first[-2:]
  term=[w for w in strong if int(w.split()[0])in(0,1,11)];ck(len(term)==6)
  strong=term+[strong[-1]]
 def baseRun(ls):
  cleaned=output('srerun',0,buf=''.join(' '.join(key(s.split()))+'\n'for s in ls));ck(clean(cleaned)==clean(ls))
 def strongRun(line):
  w=line.split();a=w.index('range');ck(clean(output('sstrong-range',*key(w),*w[a+1:a+3]))==clean([line]))
 with ThreadPoolExecutor(J)as ex:list(ex.map(baseRun,[first[j::J]for j in range(J)]));list(ex.map(strongRun,strong))
 print('PASS',mode,'uncapped baseline search rows freshly reproduced',len(first),'strong atomic blocks freshly reproduced',len(strong),flush=True)
