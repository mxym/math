"""Standalone exact cross-ledger reconstructed for ALL even-axis chart parities.
No odd-axis data, isomorphism transfer, prior maximum-degree theorem, or live
scheduler enters coverage. Supports -O (explicit checks, not assert)."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import hashlib,sys
P=Path(__file__).resolve().parent;S=P/'unsigned15'/'sf-run'
def ck(v):
 if not v:raise ArithmeticError('inconsistent inputs, orbit disposition, or incomplete search')
def lines(p):return [x.split()for x in Path(p).read_text().splitlines()if x.strip()]
def val(w,k):return int(w[w.index(k)+1])
def rank7(a):
 a=[[x%7 for x in v]for v in a];r=0
 for j in range(12):
  i=next((i for i in range(r,12)if a[i][j]),None)
  if i is None:continue
  a[r],a[i]=a[i],a[r];v=pow(a[r][j],-1,7)
  for i in range(r+1,12):
   h=a[i][j]*v%7;a[i]=[(y-h*x)%7 for y,x in zip(a[i],a[r])]
  r+=1
 return r
def physical(p,n):
 a=[0]*39
 def edge(i,j):ck(i!=j);a[i]|=1<<j;a[j]|=1<<i
 for j in range(7):edge(1+2*j,2+2*j);edge(0,1+2*j);edge(0,2+2*j)
 for j in range(12):
  for t in (0,1):
   v=15+2*j+t;edge(1+t,v);edge(3+2*(j//2)+(t^(j%2)),v)
   edge(v,15+2*p[j]+t);edge(v,15+2*n[j]+(t^1))
 return all((a[i]&a[j]).bit_count()+((a[i]>>j)&1)<=2 for i,j in combinations(range(39),2))
L=[list(map(int,v))for v in lines(P/'dualplanes/unary5-packet/layouts.tsv')];ck(len(L)==3580)
bad,unary=set(),{};rankcounts=Counter();degs={};G={}
for i,(r,*m)in enumerate(L):
 p,n=m[:12],m[12:];ck(len(n)==12 and all(sorted(v)==list(range(12))and all(j!=v[j]and v[v[j]]==j for j in range(12))for v in (p,n)))
 F=[[11*(a==b)+int((a^1)==b)-4*(p[a]==b)+4*(n[a]==b)-1 for b in range(12)]for a in range(12)];ck(rank7(F)==r)
 # Compare degree twice: from both labels' vector-sum squared norm, not only a boolean flag.
 d=sum(p[j]!=j+1 or n[j]!=j+1 for j in range(0,12,2))
 U=[5+5+2*(-1-2*int(p[j]==j+1)-2*int(n[j]==j+1))for j in range(0,12,2)]
 ck(d==sum(z>0 for z in U)and set(U)<={0,4,8});degs[i]=d;rankcounts[r]+=1
 if not physical(p,n):bad.add(i)
ck(rankcounts=={7:3,8:5,9:97,10:637,11:2838} and len(bad)==272)
sbad=set()
for v in lines(S/'star.tsv'):
 i=int(v[0]);ck(0<=i<3580)
 if v[1]=='bad':ck(len(v)==2 and i not in sbad);sbad.add(i);continue
 k=i,int(v[1]);ck(i not in bad and k not in unary and k[1]in(0,1)and val(v,'rank')==L[i][0]and val(v,'truncated')==0 and val(v,'outer')in(0,1));unary[k]=val(v,'outer')
ck(sbad==bad and set(unary)=={(i,p)for i in range(3580)if i not in bad for p in(0,1)})
complete={};blocks=defaultdict(list)
for w in lines(S/'direct-initial.tsv'):
 k=int(w[0]),int(w[1]),int(w[3]);ck(w[2]=='mode'and k not in complete and val(w,'truncated')==0 and val(w,'open')==0 and val(w,'nodes')>0);complete[k]='initial'
for w in lines(S/'direct-strong.tsv'):
 k=int(w[0]),int(w[1]),int(w[3]);ck(w[2]=='mode'and k not in complete and val(w,'truncated')==0 and val(w,'open')==0)
 a,b=map(int,w[w.index('range')+1:w.index('range')+3]);c=val(w,'outer');ck(0<=a<b and a<=c<=b and val(w,'checked')==c-a and val(w,'limited')in(0,1)and(val(w,'limited')==1)==(c==b));blocks[k].append((a,b,c,val(w,'limited')))
for k,v in blocks.items():
 v.sort();ck(v[0][0]==0 and v[-1][3]==0 and all(u[3]==1 and u[1]==w[0]for u,w in zip(v,v[1:])));complete[k]='strong'
from zipfile import ZipFile
z=P/'prerequisites/Conway99_Involution_SimplexLowRanks.zip';ck(hashlib.sha256(z.read_bytes()).hexdigest()=='9469414f1d94d6a55f3071a226873c44691f91eb82bd27a65c022c6f54783eb8')
out=['layout\tparity\tlocal_rank\tdegree\tmode\tdisposition'];need=set();counts=Counter();modes=Counter();distinct=Counter()
for i,(r,*m)in enumerate(L):
 d=degs[i]
 if d%2:continue
 distinct[(r,d)]+=1
 for p in(0,1):
  if i in bad:kind='physical';opts=[-1]
  elif not unary[(i,p)]:kind='unary';opts=[-1]
  elif r<10:kind='verified-low-rank';opts=[-1]
  else:kind='direct';opts=list(range(12-r))
  for m in opts:
   s=kind
   if s=='direct':
    k=(i,p,m);need.add(k);ck(k in complete);s=complete[k];modes[(d,r)]+=1
   counts[(d,s)]+=1;out.append(f'{i}\t{p}\t{r}\t{d}\t{m}\t{s}')
ck(need==set(complete)and len(need)==3156 and dict(sorted(Counter(degs[i]for i,p,m in need).items()))=={0:2,2:4,4:72,6:3078});ck(len(out)==len(set(out)))
ck({(i,p)for i,p,m in need if degs[i]<4}=={(i,p)for i in(0,1,11)for p in(0,1)})
c=P/'EvenCoverage.tsv';text='\n'.join(out)+'\n'
if '--write' in sys.argv:c.write_text(text)
else:ck(c.read_text()==text)
print('All charts 3580; literal bad bases',len(bad),'all physical chart-parities',len(unary),'even-axis raw chart-parities',sum(distinct.values())*2)
print('by (degree, disposition)',dict(sorted(counts.items())))
print('high by (degree, rank)',dict(sorted(modes.items())))
print('3156 required high cases, all directly closed, no parity transfer; search sources',dict(Counter(complete.values())),'strong atomic blocks',sum(map(len,blocks.values())))
for k in sorted(blocks):
 if degs[k[0]]<=2:print('terminal small',k,'normalized embeddings',blocks[k][-1][2])
print('PASS even-degree coverage')
