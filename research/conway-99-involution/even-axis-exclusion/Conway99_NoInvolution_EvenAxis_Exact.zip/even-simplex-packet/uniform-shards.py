"""Regenerate scope from the complete even-coverage table checked by audit.py,
partition only for load balancing, and stream closed job results to restartable
ledgers. usage: python3 -B uniform-shards.py prepare OUT N; then run OUT j for
each j=0..N-1 (may run concurrently); finally check OUT.
The stronger engine always starts each case with no positive node limit."""
from pathlib import Path
import subprocess,sys,os,hashlib
from collections import Counter
P=Path(__file__).resolve().parent;S=P/'unsigned15'/'sf-run';cmd=sys.argv[1];out=Path(sys.argv[2]).resolve()
def ck(v):
 if not v:raise ArithmeticError('invalid clean uniform shard')
def lines(p):return p.read_text().splitlines()
def get(w,k):return int(w[w.index(k)+1])
def key(s):w=s.split();return tuple(map(int,(w[0],w[1],w[3])))
ls=S/'direct-initial.tsv';hs=S/'direct-strong.tsv';cost=Counter()
for s in lines(ls)+lines(hs):cost[key(s)]+=round(float(s.split()[-1])*1000)
keys=sorted(cost);ck(len(keys)==3156);fmt=lambda k:'%d %d %d\n'%k
def checkfile(z,keys,final):
 ls=lines(z);ck(len(ls)<=len(keys));tot=0
 for k,s in zip(keys,ls):
  w=s.split();ck(tuple(map(int,w[:3]))==k and all(get(w,t)==0 for t in ('truncated','limited','open'))and get(w,'checked')==get(w,'outer'));tot+=get(w,'checked')
 if final:ck(len(ls)==len(keys))
 return len(ls),tot
if cmd=='prepare':
 n=int(sys.argv[3]);ck(n>0);out.mkdir(exist_ok=False)
 subprocess.run([sys.executable,'-B',P/'audit.py'],check=True)
 subprocess.run(['g++','-w','-O3','-std=c++17',P/'unsigned15/suniform.cpp','-o',out/'suniform'],check=True)
 global_order=sorted(keys,key=lambda k:(-cost[k],k));A=[[]for _ in range(n)];load=[0]*n
 for k in global_order:i=min(range(n),key=lambda i:load[i]);A[i].append(k);load[i]+=cost[k]
 for i,a in enumerate(A):(out/f'{i}.in').write_text(''.join(map(fmt,a)))
 (out/'count').write_text(str(n)+'\n');print('prepared',n,'shards;',list(map(len,A)),flush=True)
elif cmd=='run':
 j=int(sys.argv[3]);a=[tuple(map(int,q.split()))for q in lines(out/f'{j}.in')];z=out/f'{j}.tsv'
 k=checkfile(z,a,False)[0]if z.exists()else 0
 with z.open('a')as f:subprocess.run([out/'suniform'],cwd=P/'unsigned15',input=''.join(map(fmt,a[k:])),text=True,stdout=f,check=True)
 checkfile(z,a,True);print('PASS fresh shard',j,len(a),flush=True)
elif cmd=='check':
 n=int((out/'count').read_text());U=[];total=0
 for j in range(n):
  a=[tuple(map(int,q.split()))for q in lines(out/f'{j}.in')];_,num=checkfile(out/f'{j}.tsv',a,True);U+=a;total+=num
 ck(sorted(U)==keys);print('PASS all',len(keys),'distinct even-degree high-rank cases independently rerun from zero with one uniform uncapped method;',total,'normalized anchors tested; no open clique.')
else:raise ValueError(cmd)
