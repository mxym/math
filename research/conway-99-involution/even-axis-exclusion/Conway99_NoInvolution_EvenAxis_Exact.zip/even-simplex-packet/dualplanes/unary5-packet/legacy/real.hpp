#pragma once
#include "matrix.hpp"
using ll=long long;using i128=__int128;
struct RForm{
 ll A[12][12],D[12][12],det=0;
 int comp[12];int ncomp=0;
 RForm(const Form&F,const int*P,const int*N,int sign){ // signed F_0 or unsigned projector times 14
  fill(comp,comp+12,-1);
  if(sign){fill(comp,comp+12,0);ncomp=1;}
  else for(int i=0;i<12;i++)if(comp[i]<0){int t=ncomp++;vector<int> st={i};
   while(!st.empty()){int x=st.back();st.pop_back();if(comp[x]>=0)continue;comp[x]=t;
    for(int y:{P[x],N[x],x^1})if(comp[y]<0)st.push_back(y);
   }
  }
  ll H[12][24]{};for(int i=0;i<12;i++){for(int j=0;j<12;j++)H[i][j]=A[i][j]=(sign?F.A[i][j]:(5*(i==j)-((i^1)==j)-2*(P[i]==j)-2*(N[i]==j)))+(comp[i]==comp[j]); H[i][i+12]=1;}
  ll prev=1;
  for(int j=0;j<12;j++){ll p=H[j][j];assert(p>0);
   for(int i=0;i<12;i++)if(i!=j){ll q=H[i][j];for(int t=0;t<24;t++)if(t!=j){i128 a=(i128)p*H[i][t]-(i128)q*H[j][t];assert(a%prev==0);H[i][t]=a/prev;}H[i][j]=0;}
   prev=p;
  }det=prev;ll g=det;
  for(int i=0;i<12;i++)for(int j=0;j<12;j++)g=gcd(g,(D[i][j]=H[i][j+12]));
  for(int i=0;i<12;i++)for(int j=0;j<12;j++)D[i][j]/=g;
  det/=g;
  for(int i=0;i<12;i++)for(int j=0;j<12;j++){ll x=0;for(int t=0;t<12;t++)x+=A[i][t]*D[t][j];assert(x==det*(i==j));}
 }
 bool project(const int*f,ll*p,ll&n,int diag)const{
  int sums[12]{}; for(int t=0;t<12;t++)sums[comp[t]]+=f[t];
  for(int c=0;c<ncomp;c++)if(sums[c])return false;
  n=diag*det;for(int j=0;j<12;j++){p[j]=0;for(int k=0;k<12;k++)p[j]+=D[j][k]*f[k];n-=p[j]*f[j];}
  return n>=0;
 }
};
