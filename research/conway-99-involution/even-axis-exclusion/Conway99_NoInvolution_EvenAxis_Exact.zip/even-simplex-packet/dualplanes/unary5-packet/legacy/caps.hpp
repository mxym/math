#pragma once
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long U;
inline U bit(int i){return 1ULL<<i;}
inline int pop(U i){return __builtin_popcountll(i);}
inline int low(U i){return __builtin_ctzll(i);}
inline U flip(U mask){ // lift inside vertex permutation: 0 fixed and odd/even pairs from 1
 const U m=0xaaaaaaaaaaaaaaaaULL; return (mask&1)|((mask&m)<<1)|((mask&(m<<1))>>1);
}
struct Cand{
 unsigned short a,b; // signed adjacency to anchor prescribed by a-b; a=+ same direction, b=-
 U mask; // 39-bit N(w) intersect base (root+14+24)
};
struct Shell{
 int P[12],N[12]; U G[39]{},bad[39]{},soft[39]{};
 int z[30][12]{},r[30][7]{};
 vector<Cand> domain[30];
 bool admissible=true;
 void tie(int i,int j){if(i==j) {cerr<<"loop";abort();}G[i]|=bit(j); G[j]|=bit(i);}
 int ax(int i,int s){return 1+2*i+s;}
 int an(int u,int s){return 15+2*u+s;}
 Shell(const int*PP,const int*NN){
  copy(PP,PP+12,P); copy(NN,NN+12,N);
  for(int i=0;i<7;i++)for(int s=0;s<2;s++){tie(0,ax(i,s));tie(ax(i,s),ax(i,s^1));}
  int k=0;
  for(int i=1;i<=6;i++)for(int j=i+1;j<=6;j++)for(int s=0;s<2;s++,k++){r[k][i]=1;r[k][j]=1-2*s;for(int u=0;u<12;u++) z[k][u]=(1-2*(u&1))*r[k][1+u/2];}
  for(int u=0;u<12;u++)for(int s=0;s<2;s++){
   int v=an(u,s);tie(ax(0,s),v); tie(ax(u/2+1,s^(u&1)),v);
   tie(v,an(P[u],s)); tie(v,an(N[u],s^1));
  }
  for(int i=0;i<39;i++)for(int j=i+1;j<39;j++){
   int slack=2-int((G[i]>>j)&1)-pop(G[i]&G[j]);
   if(slack<0)admissible=false;
   if(slack<=0){bad[i]|=bit(j);bad[j]|=bit(i);}
   if(slack==1){soft[i]|=bit(j);soft[j]|=bit(i);}
  }
 }
 bool caps(U M,U both) const{
  for(U x=M;x;x&=x-1){int u=low(x);if(bad[u]&M)return false;if((both&bit(u)) && (soft[u]&both))return false;}
  // count common neighbours of new w and each old node
  U once=0,twice=0,thrice=0;
  for(U x=M;x;x&=x-1){U g=G[low(x)];thrice|=twice&g;twice|=once&g;once|=g;}
  return !(thrice||(twice&M));
 }
 void gen(){
  if(!admissible)return;
  int a0[66];U mask0[66]{},mask1[66]{};int d=0;
  for(int u=0;u<12;u++)for(int v=0;v<u;v++,d++){
   a0[d]=(1<<u)|(1<<v);
   mask0[d]=bit(an(u,0))|bit(an(v,0));mask1[d]=bit(an(u,1))|bit(an(v,1));
  }
  for(int i=0;i<66;i++)for(int j=0;j<66;j++){
   if(i==j)continue; U M=mask0[i]|mask1[j],common=M&flip(M);
   // self complement tw shares 0 or 2 anchor neighbours, cannot share 4. Already i!=j.
   if(!caps(M,common)) continue;
   for(int k=0;k<30;k++){U W=M; for(int q=1;q<=6;q++) if(r[k][q])W|=bit(ax(q,r[k][q]<0));
    if(caps(W,common))domain[k].push_back({(unsigned short)a0[i],(unsigned short)a0[j],W});
   }
  }
 }
};
