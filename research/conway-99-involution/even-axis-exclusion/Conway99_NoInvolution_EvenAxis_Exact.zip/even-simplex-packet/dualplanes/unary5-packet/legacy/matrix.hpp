#pragma once
#include "caps.hpp"
inline int m7(int v){v%=7;return (v<0 ? v+7:v);}
struct Form{
 int A[12][12],C[12][12]{},pi[12],rank=0,det=1;
 Form(const int*P,const int*N){
  int H[12][12]{};int inv[]={0,1,4,5,2,3,6};
  for(int i=0;i<12;i++)for(int j=0;j<12;j++)H[i][j]=m7(A[i][j]=11*(i==j)+((i^1)==j)-4*(P[i]==j)+4*(N[i]==j)-1);
  for(int j=0;j<12;j++){int t=rank;while(t<12&&!H[t][j])t++;if(t==12)continue;
   for(int k=0;k<12;k++)swap(H[t][k],H[rank][k]);
   int h=inv[H[rank][j]];for(int k=0;k<12;k++) H[rank][k]=m7(H[rank][k]*h);
   for(t=rank+1;t<12;t++){int g=H[t][j];for(int k=0;k<12;k++)H[t][k]=m7(H[t][k]-g*H[rank][k]);}
   pi[rank++]=j;
  }
  int aug[12][24]{};
  for(int i=0;i<rank;i++){for(int j=0;j<rank;j++)aug[i][j]=m7(A[pi[i]][pi[j]]);aug[i][i+rank]=1;}
  for(int j=0;j<rank;j++){int t=j;while(t<rank&&!aug[t][j])t++;assert(t<rank);
   if(t!=j){for(int k=0;k<2*rank;k++)swap(aug[t][k],aug[j][k]);det=-det;}
   int p=aug[j][j];det=m7(det*p);int h=inv[p];for(int k=0;k<2*rank;k++)aug[j][k]=m7(aug[j][k]*h);
   for(t=0;t<rank;t++)if(t!=j){int g=aug[t][j];for(int k=0;k<2*rank;k++)aug[t][k]=m7(aug[t][k]-g*aug[j][k]);}
  }
  for(int i=0;i<rank;i++)for(int j=0;j<rank;j++)C[i][j]=aug[i][j+rank];
 }
 bool nonsquare()const{return det==3||det==5||det==6;}
};
