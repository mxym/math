#include <array>
#include <map>
#include <set>
#include <vector>
#include <numeric>
#include <algorithm>
#include <iostream>
#include <cassert>
using namespace std;
using M=array<int,12>;
M unite(const M &a,const M &p){M b;for(int i=0;i<12;i++)b[p[i]]=p[a[i]];return b;}
void gen(M &a,vector<M>& v){int i=0;while(i<12&&a[i]>=0)i++;if(i==12){v.push_back(a);return;}for(int j=i+1;j<12;j++)if(a[j]<0){a[i]=j;a[j]=i;gen(a,v);a[i]=a[j]=-1;}}
long choose(int n,int k){long z=1;for(int i=0;i<k;i++)z=z*(n-i)/(i+1);return z;}
long fixed_pairs(const M &g){
 int ns[13]={};bool used[12]={};for(int i=0;i<12;i++)if(!used[i]){
  int ell=0;for(int j=i;!used[j];j=g[j]){used[j]=1;ell++;}ns[ell]++;
 }
 long prod=1;
 for(int ell=1;ell<=12;ell++){int n=ns[ell];long res=0;
  for(int k=0;k<=n/2;k++)if((n==2*k)||(ell%2==0)){
   long count=choose(n,2*k);for(int j=1;j<=k;j++)count*=ell*(2*j-1);
   res+=count;
  }prod*=res;
 }
 return prod;
}
int rankof(const M &p,const M &n){
 int a[12][12];
 for(int i=0;i<12;i++)for(int j=0;j<12;j++)a[i][j]=(11*(i==j)+(j==(i^1))-4*(j==p[i])+4*(j==n[i])+6)%7;
 int r=0;
 for(int j=0;j<12;j++){int t=r;while(t<12&&!a[t][j])t++;if(t==12)continue;
  swap(a[t],a[r]);
  for(int i=r+1;i<12;i++)if(a[i][j]){int u=a[r][j],v=a[i][j];for(int k=j;k<12;k++)a[i][k]=(u*a[i][k]-v*a[r][k]+49)%7;}
  r++;
 }return r;
}
vector<int> partition(const M &p){bool used[12]={};vector<int> part;
 for(int i=0;i<12;i++)if(!used[i]){
  int ell=0;for(int j=i;!used[j];j=p[j^1]){used[j]=used[j^1]=1;ell++;}part.push_back(ell);
 }sort(part.begin(),part.end());return part;
}
int main(){
 M a;a.fill(-1);vector<M> ms,group;gen(a,ms);assert(ms.size()==10395);
 array<int,6> perm={0,1,2,3,4,5};
 do{for(int mask=0;mask<64;mask++){M g;for(int i=0;i<6;i++)for(int b=0;b<2;b++)g[2*i+b]=2*perm[i]+(b^((mask>>i)&1));group.push_back(g);}}while(next_permutation(perm.begin(),perm.end()));assert(group.size()==46080);
 set<M> pdone;set<vector<int>> parts;map<int,int> total;
 for(const auto &p:ms)if(!pdone.count(p)){
  vector<M> stab;
  for(const auto &g:group){M im=unite(p,g);pdone.insert(im);if(im==p)stab.push_back(g);}
  auto par=partition(p);assert(parts.insert(par).second);
  set<M> ndone;map<int,int> hist;long burn=0;for(const auto &g:stab)burn+=fixed_pairs(g);
  for(const auto &n:ms)if(!ndone.count(n)){
   for(const auto &g:stab)ndone.insert(unite(n,g));
   int r=rankof(p,n);hist[r]++;total[r]++;
   cout<<r;for(auto i:p)cout<<" "<<i;for(auto i:n)cout<<" "<<i;cout<<"\n";
  }
  assert(ndone.size()==ms.size());assert(burn%stab.size()==0);
  int count=0;for(const auto &[r,x]:hist)count+=x;assert(count==burn/static_cast<long>(stab.size()));
  cerr<<"partition";for(int l:par)cerr<<" "<<l;cerr<<" stabilizer="<<stab.size()<<" Burnside="<<count;for(const auto &[r,x]:hist)cerr<<" "<<r<<":"<<x;cerr<<"\n";
 }
 assert(pdone.size()==ms.size());assert(parts.size()==11);
 cerr<<"TOTAL";for(const auto &[r,x]:total)cerr<<" "<<r<<":"<<x;cerr<<"\n";
}
