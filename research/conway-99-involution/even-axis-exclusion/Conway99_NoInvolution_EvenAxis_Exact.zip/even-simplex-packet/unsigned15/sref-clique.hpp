 // Alternate terminal reference: no residual product bitset, no projected dot
 // cache, no first-vector normalization, no signed real-pair inequality and
 // directly check 903 physical caps on the literal 43-vertex lift. This is
 // intentionally slower: we use it only as an independent positive/negative
 // replay fixture for selected actual anchor assignments.
 long long depthHist[10]{};
 bool search(int chosen[12],int depth){
 struct Ref{int wid,aid,vec;};using Dom=vector<Ref>;vector<Dom>doms(30);
 auto dot=[&](int x,int y){return ((x%7)*(y%7)+(baseRank==11?dcoef:1)*(x/7%7)*(y/7%7)+dcoef*(x/49)*(y/49))%7;};
 const int q=baseRank==11?49:343,nv=nullv[0]+7*nullv[1]+49*nullv[2];
 for(int k=0;k<30;k++){int i=k+12;for(int w=0;w<192;w++){
 unsigned key=0;bool valid=true;for(int j=0;j<12;j++){auto a=LWords[cl[i]][w],b=LWords[cl[j]][chosen[j]];int sd=0;for(int c=0;c<15;c++)if(a.mask&b.mask&(1<<c))sd+=(a.neg^b.neg)&(1<<c)?-1:1;
 int v=1-pop(ax[i]&ax[j])-sd;if(v<0||v%2||v>4){valid=false;break;}key|=(v/2)<<(2*j);}
 if(!valid)continue;auto it=groups[k].find(key);if(it==groups[k].end())continue;
 for(int a:it->second){auto&t=atts[a];for(int v=0;v<q;v++)if(dot(v,v)==t.rho&&(!activeNull?t.cond==0:dot(v,nv)==t.cond))doms[k].push_back({w,a,v});}
 }if(doms[k].empty())return false;}
 unordered_map<U,bool>cache;auto literal=[&](const Att&a,const Att&b,int l,int t){U A[43];copy(base,base+39,A);fill(A+39,A+43,0);auto join=[&](int i,int j){A[i]|=bit(j);A[j]|=bit(i);};
 for(int i=0;i<39;i++){if(a.mask>>i&1)join(39,i);if(a.twin>>i&1)join(40,i);if(b.mask>>i&1)join(41,i);if(b.twin>>i&1)join(42,i);}
 if(t==2||l==1){join(39,41);join(40,42);}if(t==2||l==-1){join(39,42);join(40,41);}
 for(int i=0;i<43;i++)for(int j=0;j<i;j++)if(pop(A[i]&A[j])+int(A[i]>>j&1)>2)return false;return true;};
 auto agree=[&](const Ref&z,const Ref&w){auto&a=atts[z.aid],&b=atts[w.aid];int i=12+a.d,j=12+b.d,T=1-pop(ax[i]&ax[j])-val(LWords[cl[i]][z.wid],LWords[cl[j]][w.wid]);if(T<0||T>4||T%2)return false;T/=2;
 int g=dot(z.vec,w.vec);for(int t=0;t<7;t++)g+=r[a.d][t]*r[b.d][t];for(int t=0;t<baseRank;t++)g+=a.pi[t]*b.m[t];for(int l:{-1,0,1}){if(abs(l)!=T%2||m7(g+4*l))continue;
 U key=U(min(w.aid,z.aid))+(U(max(w.aid,z.aid))<<16)+(U(1+l+3*T)<<32);auto it=cache.find(key);if(it==cache.end())it=cache.emplace(key,literal(a,b,l,T)).first;if(it->second)return true;}return false;};
 function<bool(vector<Dom>,int)>dfs=[&](vector<Dom>d,int step){depthHist[step]++;if(step==depth||d.empty())return true;
 int min=0;for(int j=1;j<d.size();j++)if(d[j].size()<d[min].size())min=j;
 auto curr=move(d[min]);d.erase(d.begin()+min);for(auto&x:curr){vector<Dom> nxt;bool ok=true;for(auto&z:d){Dom a;for(auto&y:z)if(agree(x,y))a.push_back(y);if(a.empty()){ok=false;break;}nxt.push_back(move(a));}if(ok&&dfs(move(nxt),step+1))return true;}return false;};
 return dfs(move(doms),0);}
