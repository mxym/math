/* Independent 12-column signed support/Gram census (no shared code or DFS).
   At full embeddings export natural-index sign-gauge representatives. */
#include <bits/stdc++.h>
using namespace std;
void ck(bool x){if(!x)throw runtime_error("independent stars");}
using row=array<short,12>;using W=pair<int,int>;
int pc(int n){return __builtin_popcount((unsigned)n);}int pairid[7][7];vector<W>D[21];map<W,int>Drev[21];int label[12],H[12][12],ord[12],cur[12];vector<row>stars;
int ip(W a,W b){int m=a.first&b.first;return pc(m)-2*pc(m&(a.second^b.second));}
void dfs(int t,int used){if(t==12){int flip=0,all=0;row z;for(int i=0;i<12;i++){auto w=D[label[i]][cur[i]];flip|=w.second&~all;all|=w.first;w.second^=flip&w.first;z[i]=Drev[label[i]].at(w);}stars.push_back(z);return;}
 int j=ord[t];for(int c=0;c<192;c++){auto w=D[label[j]][c];if(w.second&~used)continue;bool ok=1;for(int i=0;i<t&&ok;i++)ok=ip(w,D[label[ord[i]]][cur[ord[i]]])==H[j][ord[i]];if(ok){cur[j]=c;dfs(t+1,used|w.first);}}}
int main(int argc,char**argv){ck(argc==3);int lo=stoi(argv[1]),hi=stoi(argv[2]);ifstream f("simplex.tsv");int t=0;for(int i=0;i<7;i++)for(int j=i+1;j<7;j++,t++){pairid[i][j]=pairid[j][i]=t;for(int k=0;k<6;k++){int m;ck(bool(f>>m)&&pc(m)==5);for(int s=m;;s=(s-1)&m){Drev[t][{m,s}]=D[t].size();D[t].push_back({m,s});if(!s)break;}}}
 ifstream g("../dualplanes/unary5-packet/layouts.tsv");int r,p[12],n[12],id=0;while(g>>r){for(int&v:p)g>>v;for(int&v:n)g>>v;if(id>=lo&&id<hi){for(int s=0;s<2;s++){
 for(int i=0;i<12;i++){int v=i/2+1;if(s&&v<=2)v=3-v;label[i]=pairid[0][v];for(int j=0;j<12;j++)H[i][j]=5*int(i==j)-int((i^1)==j)-2*int(p[i]==j)-2*int(n[i]==j);}
 int assigned=0;for(int z=0;z<12;z++){int a=-1,b=-1;for(int i=11;i>=0;i--)if(!(assigned>>i&1)){int sc=0;for(int j=0;j<12;j++)if(assigned>>j&1)sc+=-H[i][j];if(b<sc){a=i;b=sc;}}ord[z]=a;assigned|=1<<a;}
 stars.clear();dfs(0,0);sort(stars.begin(),stars.end());ck(adjacent_find(stars.begin(),stars.end())==stars.end());for(const auto&t:stars){cout<<id<<" "<<s;for(int i=0;i<12;i++){auto d=D[label[i]][t[i]];cout<<" "<<((d.first<<15)|d.second);}cout<<"\n";}
 }}id++;}ck(id==3580);}
