#define main real_search
#include "sstrong.cpp"
#undef main
int main(){init();ifstream f("../dualplanes/unary5-packet/layouts.tsv");int P[12],N[12],id=0,r;long long pos=0,neg=0,weak=0;unsigned seed=4142401;auto R=[&](){seed=seed*1664525u+1013904223u;return seed;};
while(f>>r){for(auto&i:P)f>>i;for(auto&i:N)f>>i;if(id!=890&&id!=1395&&id!=2260&&id!=14&&id!=1748){id++;continue;}id++;Shell sh(P,N);sh.gen();Form F(P,N);RForm S(F,P,N,1),H(F,P,N,0);int cl[42]{},ax[42]{};auto p=make_unique<Plane>(sh,F,S,H,cl,ax,0);vector<array<ll,12>>proj(p->rr.size());vector<ll>rho(p->rr.size());for(int j=0;j<p->rr.size();j++){int v[12];for(int k=0;k<12;k++)v[k]=p->rr[j].f[k];if(!S.project(v,proj[j].data(),rho[j],10))abort();}
for(int s=0;s<50000;s++){int x=R()%p->rr.size(),y=R()%p->rr.size();auto&a=p->rr[x],&b=p->rr[y];for(int l=-1;l<=1;l++){int z=4*l+p->zd[p->atts[x].d][p->atts[y].d];ll t=-(ll)z*S.det;int ap=-128*z;for(int k=0;k<12;k++){t-=proj[x][k]*b.f[k];ap-=int(a.m[k])*b.f[k];}int u=max(0,abs(ap)-10);bool exact=(i128)t*t<=(i128)rho[x]*rho[y],lo=u*u<=a.n*b.n;if(!lo&&exact)abort();if(exact)pos++;else if(!lo)neg++;else weak++;}}
}if(id!=3580||!pos||!neg||!weak)abort();cout<<"direct signed-rational 2x2 determinant comparison: valid "<<pos<<", exact negatives caught "<<neg<<", permissive near-boundary negatives "<<weak<<"\n";}
