#include "../dualplanes/unary5-packet/legacy/real.hpp"
using D3=array<unsigned long long,3>;
struct Word{int mask,neg;};
signed char Wdot[21][192][21][192]; Word LWords[21][192];D3 C[21][192][21][11];int pairs[21][2],by[7][7];
int val(Word a,Word b){int k=a.mask&b.mask;return pop(k)-2*pop(k&(a.neg^b.neg));}
void init(){ifstream f("simplex.tsv");int j=0;for(int a=0;a<7;a++)for(int b=a+1;b<7;b++,j++){pairs[j][0]=a;pairs[j][1]=b;by[a][b]=by[b][a]=j;
 for(int h=0;h<6;h++){int x;f>>x;if(pop(x)!=5)abort();int t=0;for(int s=x;;s=(s-1)&x){LWords[j][h*32+t++]={x,s};if(!s)break;}if(t!=32)abort();}}
 for(int i=0;i<21;i++)for(int j=0;j<192;j++)for(int k=0;k<21;k++)for(int h=0;h<192;h++)C[i][j][k][(Wdot[i][j][k][h]=val(LWords[i][j],LWords[k][h]))+5][h/64]|=1ull<<(h%64);}
#include "splanemask.hpp"
struct Test{
unique_ptr<Plane>plan;bool applicable=0;
 int P[12],N[12],cl[42],gram[12][12],ax[42],order[12];vector<unsigned>allowed[30];unordered_set<unsigned>prefix[30][13];
 long long nodes=0,full=0,outer=0,cut=0;long long maxn=0;bool truncated=false,stop1=false;
 Test(int*pp,int*nn,int parity,long long mx,int mode){copy(pp,pp+12,P);copy(nn,nn+12,N);maxn=mx;
 for(int i=0;i<42;i++){int a=pairs[i/2][0],b=pairs[i/2][1];ax[i]=1<<a|1<<b;auto f=[&](int x){return parity&&x==1?2:parity&&x==2?1:x;};cl[i]=by[f(a)][f(b)];}
 for(int i=0;i<12;i++)for(int j=0;j<12;j++)gram[i][j]=5*(i==j)-(j==(i^1))-2*(P[i]==j)-2*(N[i]==j);
 Shell sh(P,N);sh.gen();Form sf(P,N);RForm S(sf,P,N,1),H(sf,P,N,0);
 if(sf.rank==11||sf.rank==10){applicable=true;plan=make_unique<Plane>(sh,sf,S,H,cl,ax,mode);}
 for(int d=0;d<30;d++){set<unsigned>s;for(auto &w:sh.domain[d]){int u[12],f[12];unsigned h=0;bool bad=0;for(int j=0;j<12;j++){int a=w.a>>j&1,b=w.b>>j&1;if(a&&b&&P[j]==N[j])bad=1;
 h|=(a+b)<<(2*j);u[j]=1-abs(sh.z[d][j])-2*(a+b);f[j]=-sh.z[d][j]-4*(a-b);}ll pr[12],n;if(!bad&&S.project(f,pr,n,10)&&H.project(u,pr,n,5))s.insert(h);}allowed[d].assign(s.begin(),s.end());}
 int used=0;for(int t=0;t<12;t++){int best=-1,idx=-1;for(int i=0;i<12;i++)if(!(used>>i&1)){int sc=0;for(int j=0;j<12;j++)if(used>>j&1)sc+=8*(P[i]==j)+8*(N[i]==j)+3*((i^1)==j);if(sc>best){best=sc;idx=i;}}
 order[t]=idx;used|=1<<idx;}
 for(int d=0;d<30;d++)for(auto u:allowed[d]){unsigned v=0;for(int t=0;t<12;t++){v|=((u>>(2*order[t]))&3u)<<(2*t);prefix[d][t+1].insert(v);}}}
 int chosen[12];
 bool ext(int t){for(int d=0;d<30;d++){int k=12+d,g=cl[k];bool good=0;for(int l=0;l<192&&!good;l++){unsigned m=0;bool ok=1;for(int h=0;h<t;h++){int i=order[h];int ip=val(LWords[cl[i]][chosen[i]],LWords[g][l]);int u=1-pop(ax[i]&ax[k])-ip;if((u&1)||u<0||u>4){ok=0;break;}m|=(u/2)<<(2*h);}if(ok&&prefix[d][t].count(m))good=1;}if(!good)return false;}return true;}
 void dfs(int t,int used,D3 ds[12]){if(truncated||stop1)return;if(maxn&&++nodes>maxn){truncated=true;return;}if(!maxn)nodes++;
 if(t==12){full++;if(ext(t)){outer++;if(plan->search(chosen,8))stop1=true;}return;}
 int i=order[t],g=cl[i];for(int w=0;w<3;w++)for(U m=ds[i][w];m&&!truncated&&!stop1;m&=m-1){int h=64*w+low(m);auto a=LWords[g][h];if(a.neg&~used)continue;chosen[i]=h;D3 next[12];bool ok=1;
 for(int v=t+1;v<12;v++){int j=order[v];auto&b=C[g][h][cl[j]][gram[i][j]+5];U any=0;for(int z=0;z<3;z++)any|=(next[j][z]=ds[j][z]&b[z]);if(!any){ok=0;break;}}
 if(ok&&(t+1==6||t+1==9)&&!ext(t+1)){cut++;ok=0;}if(ok)dfs(t+1,used|a.mask,next);}}
 void go(){if(!applicable)return;D3 all[12];for(auto &v:all)v={~0ull,~0ull,~0ull};dfs(0,0,all);}
};
int main(int ac,char**av){if(ac!=4)abort();init();int shard=stoi(av[1]),nshard=stoi(av[2]);long mx=stol(av[3]);
 ifstream in("../dualplanes/unary5-packet/layouts.tsv");vector<array<int,25>>L;array<int,25>v;while(in>>v[0]){for(int i=1;i<25;i++)if(!(in>>v[i]))abort();L.push_back(v);}if(L.size()!=3580)abort();
 ifstream P("sf-run/plan.tsv");int ix=0,id,parity,mode;while(P>>id>>parity>>mode){if(ix++%nshard!=shard)continue;auto&r=L[id];if(r[0]<10||r[0]>11||mode>11-r[0])abort();auto t=clock();Test p(&r[1],&r[13],parity,mx,mode);p.go();cout<<id<<" "<<parity<<" mode "<<mode<<" nodes "<<p.nodes<<" full "<<p.full<<" outer "<<p.outer<<" cut "<<p.cut<<" open "<<p.stop1<<" pairs "<<p.plan->tests<<" truncated "<<p.truncated<<" cpu "<<(clock()-t)/double(CLOCKS_PER_SEC)<<endl;} }
