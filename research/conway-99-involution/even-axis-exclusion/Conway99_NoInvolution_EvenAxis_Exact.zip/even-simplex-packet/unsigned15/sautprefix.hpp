// Act by even peripheral permutations (central and omitted fixed) and
// orientations of the six peripheral axis pairs preserving BOTH matchings.
// All actions used at a prefix stabilize its set; coordinate sign renaming
// is gauge-fixed again in the same order. Reject only a lex-smaller image.
struct ChartAut{
 struct Lift {array<int,6> q;array<int,15> s;unsigned short perm[3][32];int apply(int x)const{return perm[0][x&31]|perm[1][(x>>5)&31]|perm[2][x>>10];}};
 struct Act{unsigned short qi;unsigned char pre[12];};
 const int*cl;const int*ord;vector<Act>G;vector<int>can[13];inline static vector<Lift> K;inline static map<array<int,6>,int>ids;
 static void setup(){if(!K.empty())return;ifstream f("sf-run/coord6.tsv");Lift a;while(f>>a.q[0]){for(int i=1;i<6;i++)if(!(f>>a.q[i]))abort();for(int&i:a.s)if(!(f>>i))abort();
 if(set<int>(a.q.begin(),a.q.end()).size()!=6||set<int>(a.s.begin(),a.s.end()).size()!=15)abort();
 for(int k=0;k<3;k++)for(int m=0;m<32;m++){int v=0;for(int b=0;b<5;b++)if(m>>b&1)v|=1<<a.s[k*5+b];a.perm[k][m]=v;}ids[a.q]=K.size();K.push_back(a);}if(K.size()!=360||ids.size()!=360)abort();}
 ChartAut(const int*P,const int*N,const int*o,const int*c,int parity):cl(c),ord(o){setup();int oi[12];for(int i=0;i<12;i++)oi[ord[i]]=i;
 for(auto&it:K){auto perm=it.q;auto h=[&](int x){return parity&&x<2?1-x:x;};array<int,6>target;for(int j=0;j<6;j++)target[h(j)]=h(perm[j]);int qi=ids.at(target);for(int m=0;m<64;m++){int p[12];for(int i=0;i<12;i++)p[i]=2*perm[i/2]+((i%2)^((m>>(i/2))&1));bool ok=true;for(int i=0;i<12;i++)if(p[P[i]]!=P[p[i]]||p[N[i]]!=N[p[i]])ok=false;if(!ok)continue;
 Act a;a.qi=qi;for(int i=0;i<12;i++)a.pre[oi[p[i]]]=oi[i];int mask=0;for(int i=0;i<12;i++){mask|=1<<a.pre[i];if(mask==(1<<(i+1))-1)can[i+1].push_back(G.size());}
 G.push_back(a);}}if(G.empty())abort();}
 bool accept(int t,const int*chosen)const{if(G.size()==1)return true;int code[12];Word w[12];for(int h=0;h<t;h++){int i=ord[h];w[h]=LWords[cl[i]][chosen[i]];code[h]=(w[h].mask<<15)|w[h].neg;}
 for(int k:can[t]){auto&a=G[k];auto&pr=K[a.qi];int seen=0,flip=0;for(int h=0;h<t;h++){auto x=w[a.pre[h]];int m=pr.apply(x.mask),n=pr.apply(x.neg);flip|=n&~seen;seen|=m;n^=flip&m;int z=(m<<15)|n;if(z<code[h])return false;if(z>code[h])break;}}return true;}
};
