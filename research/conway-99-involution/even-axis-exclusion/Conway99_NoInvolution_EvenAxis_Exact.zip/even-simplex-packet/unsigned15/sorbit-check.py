from itertools import permutations,product
from pathlib import Path
from collections import defaultdict
import sys
def ck(v):
 if not v:raise ArithmeticError('orbit mismatch')
def permute(w,perm):
 z=0
 while w:v=w&-w;w-=v;z|=1<<perm[v.bit_length()-1]
 return z
P=[list(map(int,s.split()))for s in Path('sf-run/coord6.tsv').read_text().splitlines()];L=[list(map(int,s.split()))for s in Path('../dualplanes/unary5-packet/layouts.tsv').read_text().splitlines()]
G={tuple(p[:6]):p[6:]for p in P};ck(len(G)==360)
for id in map(int,sys.argv[1:]):
 _,*v=L[id];p,n=v[:12],v[12:];auts=[]
 for a in G:
  for s in range(64):
   b=tuple(2*a[i//2]+((i%2)^((s>>(i//2))&1))for i in range(12))
   if all(b[p[i]]==p[b[i]]and b[n[i]]==n[b[i]]for i in range(12)):auts.append((a,b))
 for par in (0,1):
  s=lambda j: 1-j if par and j<2 else j
  acts=[]
  for a,b in auts:
   q=tuple(s(a[s(i)])for i in range(6));pm=G[q];inv=[b.index(i)for i in range(12)];acts.append((inv,pm))
  def im(w,g):
   inv,pm=g;seen=flip=0;y=[]
   for i in inv:
    m=permute(w[i]>>15,pm);q=permute(w[i]&32767,pm);flip|=q&~seen;seen|=m;y.append((m<<15)|(q^(flip&m)))
   return tuple(y)
  R={tuple(map(int,t.split()[2:]))for t in Path(f'sf-run/orbits/{id}.raw').read_text().splitlines()if int(t.split()[1])==par};F=[tuple(map(int,t.split()[1:]))for t in Path(f'sf-run/orbits/{id}.{par}.fast').read_text().splitlines()]
  marked=set()
  for f in F:
   ck(f in R and f not in marked);w={im(f,g)for g in acts};ck(w<=R);marked.update(w)
  ck(marked==R);print(id,par,'group',len(acts),'bare',len(R),'orbits',len(F),'all covered',flush=True)
