struct Att{int d;U mask,twin,tight=0,slack=0;int sm,tm,cond=0,pi[11]{},m[11]{},rho;unsigned key;};
struct PC{int id,p,a,b;}; // label-specific word, signed anchor ID, 7-plane coordinates, uses fields id=word,p=attachment
struct Plane{
 const int*cl;const int*ax;vector<Att>atts;vector<vector<int>>dom[30];unordered_map<unsigned,vector<int>>groups[30];vector<pair<int,int>>sol[7][7],canon[7][7];int nullv[3]{},kNonpivot=-1;bool activeNull;int dcoef,baseRank;long long tests=0,nodes=0,tolerated=0;
 U base[39],blocked[39]{};int r[30][7]{},zd[30][30]{};
 Plane(Shell&sh,Form&F,RForm&sg,RForm&H,const int*to,const int*xx,int mode):cl(to),ax(xx),activeNull(mode){
 baseRank=F.rank;if(F.rank<10 || F.rank>11)abort();dcoef=F.nonsquare()?3:1;
 if(baseRank==11&&mode)abort();int nd=13-baseRank;
 // residual vector encoded (a,b+7*c); diagonal metric (1,dcoef)
 // or (1,1,dcoef), with no integer beyond 48 used.
 if(nd==3){for(int i=0;i<11;i++)if(find(F.pi,F.pi+baseRank,i)==F.pi+baseRank)kNonpivot=i;if(kNonpivot<0)abort();
  for(int a=0;a<7&&!nullv[0]&&!nullv[1]&&!nullv[2];a++)for(int b=0;b<7&&!nullv[0]&&!nullv[1]&&!nullv[2];b++)for(int c=0;c<7;c++)if((a||b||c)&&(a*a+b*b+dcoef*c*c)%7==0){nullv[0]=a;nullv[1]=b;nullv[2]=c;break;}}
 for(int a=0;a<7;a++)for(int b=0;b<7;b++)for(int c=0;c<(nd==3?7:1);c++){int n=(a*a+(nd==2?dcoef:1)*b*b+dcoef*c*c)%7;
 int cond=mode?(a*nullv[0]+b*nullv[1]+dcoef*c*nullv[2])%7:0;auto v=make_pair(a,b+7*c);sol[n][cond].push_back(v);
 auto&cs=canon[n][cond];bool zero=!a&&!b&&!c;
 // stabilizer of a fixed nonzero null n acts transitively at fixed norm and
 // inner product unless the vector is a multiple of n. Every multiple is
 // individually retained. For mode zero also distinguish the zero vector.
 bool special=zero||(mode&&cond==0&&n==0);
 if(special||none_of(cs.begin(),cs.end(),[](auto z){return z.first||z.second;}))cs.push_back(v);}
 copy(sh.G,sh.G+39,base);for(int i=0;i<39;i++)for(int j=0;j<39;j++)if(j!=i&&2-int(base[i]>>j&1)-pop(base[i]&base[j])<=1)blocked[i]|=bit(j);
 for(int k=0;k<30;k++)copy(sh.r[k],sh.r[k]+7,r[k]);for(int j=0;j<30;j++)for(int k=0;k<30;k++)for(int t=0;t<7;t++)zd[j][k]+=r[j][t]*r[k][t];
 for(int k=0;k<30;k++)for(auto&w:sh.domain[k]){unsigned key=0;int f[12],u[12];ll pf[12],n;bool bad=0;for(int t=0;t<12;t++){
 int a=w.a>>t&1,b=w.b>>t&1;if(a&&b&&sh.P[t]==sh.N[t])bad=1;f[t]=-4*(a-b)-sh.z[k][t];u[t]=1-abs(sh.z[k][t])-2*(a+b);key|=(a+b)<<(2*t);}
 if(bad||!sg.project(f,pf,n,10)||!H.project(u,pf,n,5))continue;Att v;v.d=k;v.mask=w.mask;v.twin=flip(v.mask);for(int i=0;i<39;i++){int k=2-int(v.mask>>i&1)-pop(base[i]&v.mask);if(!k)v.tight|=bit(i);if(k==1)v.slack|=bit(i);}v.sm=w.a;v.tm=w.b;v.key=key;
 for(int i=0;i<baseRank;i++){v.pi[i]=m7(f[F.pi[i]]);int m=0;for(int j=0;j<baseRank;j++)m+=F.C[i][j]*f[F.pi[j]];v.m[i]=m7(m);}
 int y=3;for(int i=0;i<baseRank;i++)y-=v.pi[i]*v.m[i];v.rho=m7(y);if(kNonpivot>=0){int cond=f[kNonpivot];for(int i=0;i<baseRank;i++)cond-=F.A[kNonpivot][F.pi[i]]*v.m[i];v.cond=m7(cond);}if(sol[v.rho][v.cond].empty())continue;
 groups[k][key].push_back(atts.size());atts.push_back(v);
 }prodinit();}
 bool caps(const Att&x,const Att&y,int l,int t)const{
 U a=x.mask,b=x.twin,c=y.mask,d=y.twin;bool p=t==2||l==1,n=t==2||l==-1;
 if(t==2&&((a&b)||(c&d)))return false;
 if(pop(a&c)+p>2||pop(a&d)+n>2)return false;
 // Old/old common-neighbor capacity for new contributions whose two twin sets overlap.
 for(U u:{a,b})for(U v:{c,d}){U o=u&v;for(U s=o;s;s&=s-1){int i=low(s);if(blocked[i]&o)return false;if(((a&b)>>i&1)&&((a&b&o)&~bit(i)))return false;if(((c&d)>>i&1)&&((c&d&o)&~bit(i)))return false;}}
 if(p&&((x.tight&c)||(y.tight&a)))return false;
 if(n&&((x.tight&d)||(y.tight&b)))return false;
 if(t==2&&((x.slack&c&d)||(y.slack&a&b)))return false;
 return true;}
 U prodMasks[343][7][7][7]{},canonMasks[7][7]{};
 void prodinit(){for(int n=0;n<7;n++)for(int d=0;d<7;d++){auto&s=sol[n][d];if(s.size()>64)abort();for(int i=0;i<int(s.size());i++){auto e=s[i];if(find(canon[n][d].begin(),canon[n][d].end(),e)!=canon[n][d].end())canonMasks[n][d]|=bit(i);
  for(int v=0;v<(baseRank==11?49:343);v++){int w=v%7*e.first+(baseRank==11?dcoef:1)*(v/7%7)*(e.second%7)+dcoef*(v/49)*(e.second/7);prodMasks[v][n][d][w%7]|=bit(i);}
 }}}
 struct Cg{unsigned short p;unsigned char id;U rem;};
 U arc(const Cg&x,int vi,const Cg&y){auto&a=atts[x.p],&b=atts[y.p];int i=a.d,j=b.d;
 int t=1-pop(ax[12+i]&ax[12+j])-Wdot[cl[12+i]][x.id][cl[12+j]][y.id];if(t<0||t>4||(t&1))return 0;t/=2;
 int z=zd[i][j];for(int k=0;k<baseRank;k++)z+=a.m[k]*b.pi[k];int zn=m7(-z);auto const& ms=prodMasks[vi][b.rho][b.cond];
 U u=0;for(int l=-(t%2);l<=int(t%2);l+=2){U cand=y.rem&ms[m7(zn-4*l)];if(cand){tests++;if(caps(a,b,l,t))u|=cand;}}
 return u;}
 long long depthHist[10]{};
 bool search(int chosen[12],int depth){vector<vector<Cg>> ds(30);int count[30]{};
 for(int k=0;k<30;k++){int y=12+k;for(int w=0;w<192;w++){unsigned key=0;bool ok=1;for(int i=0;i<12;i++){int t=1-pop(ax[i]&ax[y])-Wdot[cl[i]][chosen[i]][cl[y]][w];if(t<0||t>4||(t&1)){ok=0;break;}key|=(t/2)<<(2*i);}
 if(!ok)continue;auto it=groups[k].find(key);if(it==groups[k].end())continue;for(int id:it->second){auto& a=atts[id];int z=sol[a.rho][a.cond].size();if(id>=65536||z>64||!z)abort();ds[k].push_back({(unsigned short)id,(unsigned char)w,z==64?~0ull:bit(z)-1});count[k]+=z;}
 }if(ds[k].empty())return false;}
 int k0=min_element(count,count+30)-count;for(auto&c:ds[k0]){auto&a=atts[c.p];c.rem&=canonMasks[a.rho][a.cond];if(!c.rem)abort();}
 auto size=[](const vector<Cg>&g){size_t c=0;for(const Cg&v:g)c+=pop(v.rem);return c;};
 sort(ds.begin(),ds.end(),[&](auto&a,auto&b){return size(a)<size(b);});
 function<bool(vector<vector<Cg>>&,int)>dfs=[&](auto &d,int step){nodes++;depthHist[step]++;if(step>=depth||d.empty())return true;
 int idx=0;size_t best=SIZE_MAX;for(int i=0;i<d.size();i++){auto n=size(d[i]);if(n<best){idx=i;best=n;}}swap(d.front(),d[idx]);
 for(auto&pick:d.front()){auto&sx=sol[atts[pick.p].rho][atts[pick.p].cond];for(U s=pick.rem;s;s&=s-1){auto v=sx[low(s)];int w=v.first+7*v.second;bool ok=true;
 for(int j=1;j<d.size();j++){bool found=false;for(auto&z:d[j])if(arc(pick,w,z)){found=true;break;}if(!found){ok=false;break;}}if(!ok)continue;
 vector<vector<Cg>> next(d.size()-1);for(int j=1;j<d.size();j++)for(auto z:d[j]){z.rem=arc(pick,w,z);if(z.rem)next[j-1].push_back(z);}if(dfs(next,step+1))return true;
 }}return false;};return dfs(ds,0);}
};
