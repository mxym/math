#define main hyper_search_entry
#include "sbatch.cpp"
#undef main
void chk(bool v){if(!v)throw runtime_error("split-control mismatch");}
bool literal(const Plane &pl,const Att&x,const Att&y,int l,int t){U A[43]{};copy(pl.base,pl.base+39,A);auto join=[&](int u,int v){A[u]|=bit(v);A[v]|=bit(u);};for(int i=0;i<39;i++){if(x.mask>>i&1)join(39,i);if(x.twin>>i&1)join(40,i);if(y.mask>>i&1)join(41,i);if(y.twin>>i&1)join(42,i);}
 if(t==2||l==1){join(39,41);join(40,42);}if(t==2||l==-1){join(39,42);join(40,41);}
 for(int i=0;i<43;i++)for(int j=0;j<i;j++)if(pop(A[i]&A[j])+int(A[i]>>j&1)>2)return false;return true;}
int main(){int cl[42]{},ax[42]{},P[12],N[12],r,id=0;ifstream f("../dualplanes/unary5-packet/layouts.tsv");long acc=0,neg=0;
 while(f>>r){for(int&v:P)chk(bool(f>>v));for(int&v:N)chk(bool(f>>v));bool yes=(id==14||id==64||id==890||id==2260||id==1748);id++;if(!yes)continue;Shell sh(P,N);sh.gen();Form F(P,N);RForm S(F,P,N,1),H(F,P,N,0);auto p=make_unique<Plane>(sh,F,S,H,cl,ax,0);
 unsigned rng=438005+id;auto R=[&](){rng=1664525u*rng+1013904223u;return rng;};
 for(int j=0;j<10000;j++){auto &x=p->atts[R()%p->atts.size()],&y=p->atts[R()%p->atts.size()];if(x.d==y.d)continue;
 for(int t=0;t<3;t++)for(int ell=-(t%2);ell<=t%2;ell+=2){bool ok=literal(*p,x,y,ell,t);chk(ok==p->caps(x,y,ell,t));if(ok)acc++;else neg++;}
 }}chk(id==3580&&acc&&neg);cout<<"PASS literal 43-vertex graph capacities vs high-rank cap: "<<acc<<" compatible and "<<neg<<" incompatible.\n";}
