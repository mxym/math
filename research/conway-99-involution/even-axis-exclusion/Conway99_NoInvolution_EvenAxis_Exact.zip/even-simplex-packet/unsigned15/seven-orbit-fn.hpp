// Separate from production prefix/stabilizer implementation. Apply the group
// only to completed stars, in natural physical-index coordinate-sign gauge.
// Compare union of exact full orbits against a literal independent DFS.
struct Gl{array<int,6>q;int pm[3][32];int apply(int n)const{return pm[0][n&31]|pm[1][n/32%32]|pm[2][n/1024];}};
void audited(int id,int s,const int*p,const int*n){
 map<array<int,6>,Gl> lift;ifstream co("sf-run/coord6.tsv");Gl x;array<int,15>bm;while(co>>x.q[0]){for(int j=1;j<6;j++)co>>x.q[j];for(auto&j:bm)co>>j;for(int a=0;a<3;a++)for(int b=0;b<32;b++){x.pm[a][b]=0;for(int c=0;c<5;c++)if(b>>c&1)x.pm[a][b]|=1<<bm[5*a+c];}lift.emplace(x.q,x);}ck(lift.size()==360);
 struct Elem{const Gl *g;array<int,12>pre;};vector<Elem>G;
 for(auto&[q,v]:lift){auto par=[&](int x){return s&&x<2?1-x:x;};array<int,6>w;for(int j=0;j<6;j++)w[par(j)]=par(q[j]);const auto*g=&lift.at(w);
 for(int h=0;h<64;h++){array<int,12>im,pre;for(int i=0;i<12;i++){int y=2*q[i/2]+(i%2^(h>>(i/2)&1));im[i]=y;pre[y]=i;}bool good=true;for(int i=0;i<12;i++)if(im[p[i]]!=p[im[i]]||im[n[i]]!=n[im[i]])good=false;if(good)G.push_back({g,pre});}}
 auto index=[&](const row&a){auto it=lower_bound(stars.begin(),stars.end(),a);ck(it!=stars.end()&&*it==a);return int(it-stars.begin());};
 vector<bool>marked(stars.size());string word;ifstream fs("sf-run/orbits/"+to_string(id)+"."+to_string(s)+".fast");int reps=0;
 while(fs>>word){ck(word=="word");array<W,12>w;row orig;for(int i=0;i<12;i++){int v;ck(bool(fs>>v));w[i]={v>>15,v&32767};orig[i]=Drev[label[i]].at(w[i]);}ck(!marked[index(orig)]);reps++;
 for(const auto&M:G){int seen=0,flip=0;row b;for(int i=0;i<12;i++){auto[a,z]=w[M.pre[i]];int m=M.g->apply(a),n=M.g->apply(z);flip|=n&~seen;seen|=m;b[i]=Drev[label[i]].at({m,n^(flip&m)});}marked[index(b)]=true;}}
 ck(reps>0&&all_of(marked.begin(),marked.end(),[](bool x){return x;}));cout<<id<<" "<<s<<" raw "<<stars.size()<<" full-group "<<G.size()<<" representatives "<<reps<<" exact union all raw embeddings\n";
}
