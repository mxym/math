#define main baseline_main
#include "sbatch.cpp"
#undef main
// Independent direct enumeration of every orthogonal transformation and each
// scalar/refined-vector product. No use of classification or Witt transitivity.
void req(bool ok){if(!ok)throw logic_error("high-rank finite control failed");}
int main(){
 ifstream f("../dualplanes/unary5-packet/layouts.tsv");int r,p[12],n[12],id=0,cl[42]{},ax[42]{};bool seen[12][2]{};
 long long groupchecks=0,maskchecks=0,transported=0,classes=0;int fixtures=0;
 while(f>>r){for(auto&v:p)req(bool(f>>v));for(auto&v:n)req(bool(f>>v));int ix=id++;if(r<10)continue;
 Form F(p,n);int t=F.nonsquare();if(seen[r][t])continue;seen[r][t]=1;Shell sh(p,n);sh.gen();RForm sg(F,p,n,1),H(F,p,n,0);int nd=13-r,gdim=nd==2?49:343,D=t?3:1;
 auto digits=[](int x){return array<int,3>{x%7,x/7%7,x/49};};
 auto dot=[&](int x,int y){auto X=digits(x),Y=digits(y);int z=0;for(int i=0;i<nd;i++)z+=X[i]*Y[i]*(i==nd-1?D:1);return z%7;};
 auto im=[&](const vector<int>&M,int x){auto X=digits(x);int k=0;for(int i=0;i<nd;i++){int z=0;for(int j=0;j<nd;j++)z+=digits(M[j])[i]*X[j];k+=(z%7)*(i==2?49:i==1?7:1);}return k;};
 vector<vector<int>>group;vector<int>B;function<void()> walk=[&](){int k=B.size();if(k==nd){group.push_back(B);return;}for(int i=0;i<gdim;i++){if(dot(i,i)!=(k==nd-1?D:1))continue;if(any_of(B.begin(),B.end(),[&](int j){return dot(j,i)!=0;}))continue;B.push_back(i);walk();B.pop_back();}};walk();
 req(group.size()==(nd==2?(D==1?16:12):672));
 for(int m=0;m<12-r;m++){
 auto E=make_unique<Plane>(sh,F,sg,H,cl,ax,m);req(E->dcoef==D);int nv=E->nullv[0]+7*E->nullv[1]+49*E->nullv[2];vector<vector<int>>G;for(auto&a:group)if(!m||im(a,nv)==nv)G.push_back(a);if(m){req(nv&&dot(nv,nv)==0&&G.size()==14);set<int>norb,expected;for(auto&a:group)norb.insert(im(a,nv));for(int x=1;x<gdim;x++)if(!dot(x,x))expected.insert(x);req(norb==expected&&norb.size()==48);}groupchecks+=G.size();set<int>all;
 for(int a=0;a<7;a++)for(int b=0;b<7;b++){
 auto&cs=E->canon[a][b];auto&ss=E->sol[a][b];set<int>S,orb;
 for(int u=0;u<gdim;u++)if(dot(u,u)==a&&(!m?b==0:dot(u,nv)==b))S.insert(u);
 for(auto v:cs){int x=v.first+7*v.second;req(S.count(x));for(auto&M:G){orb.insert(im(M,x));transported++;}}
 req(orb==S);for(auto z:ss)req(all.insert(z.first+7*z.second).second);
 for(int i=0;i<int(ss.size());i++){int x=ss[i].first+7*ss[i].second;req(S.erase(x)==1);bool can=find(cs.begin(),cs.end(),ss[i])!=cs.end();req(((E->canonMasks[a][b]>>i)&1)==can);
 for(int u=0;u<gdim;u++){int g=dot(u,x);for(int h=0;h<7;h++)req(bool((E->prodMasks[u][a][b][h]>>i)&1)==(g==h));maskchecks+=7;}}
 req(S.empty());classes+=!orb.empty();}
 req(all.size()==gdim);fixtures++;cout<<"layout "<<ix<<" rank "<<r<<" determinant representative "<<D<<" mode "<<m<<" group "<<G.size()<<"\n";
 }}
 req(id==3580&&fixtures==6);cout<<"PASS fixtures "<<fixtures<<" stabilizer sizes sum "<<groupchecks<<" represented fibers "<<classes<<" direct isometry images "<<transported<<" individual dot-mask booleans "<<maskchecks<<"\n";
}
