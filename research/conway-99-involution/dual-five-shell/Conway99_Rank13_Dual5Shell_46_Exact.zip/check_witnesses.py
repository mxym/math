"""Independent, exact integer check of the 283 selected dual pairs. No shell enumeration necessary."""
from pathlib import Path
import json,itertools
from collections import Counter
root=Path('base/census')
model={'I17':(['B17'],[]),'E8':(['B9','E8'],[]),'D12p':(['B5','D12'],[[[],[12]]]),'E7x2':(['B3','E7','E7'],[[[],[6],[6]]]),'A15p':(['B2','A15'],[[[],[4]]]),'D8x2':(['B1','D8','D8'],[[[],[8],[1]],[[],[1],[8]]]),'A11E6':(['A11','E6'],[[[2],[1]]])}
def chk(v):
 if not v:raise ValueError('witness verification failed')
def gen(name):
 blocks,labels=model[name];T=[[0]*17 for i in range(17)];offset=0;sz=[]
 for B in blocks:
  g=list(map(int,(root/(B+'.form')).read_text().splitlines()[-1].split()));d=g.pop(0);k=int(B[1:]);sz.append(k);chk(48%d==0 and k*k==len(g))
  for i in range(k):
   for j in range(k):T[i+offset][j+offset]=g[k*i+j]*48//d
  offset+=k
 chk(offset==17)
 def cov(u):return tuple(sum(v*w for v,w in zip(u,row)) for row in T)
 def ip(u,v):
  n=sum(a*b for a,b in zip(cov(u),v));chk(n%48==0);return n//48
 S={(0,)*17}
 for l in labels:
  off=0;u=[0]*17
  for k,w in zip(sz,l):
   for j in w:u[off+j-1]+=1
   off+=k
  t=cov(u); stack=list(S)
  while stack:
   v=tuple((a+b)%48 for a,b in zip(stack.pop(),t))
   if v not in S:S.add(v);stack.append(v)
 def contains(v):return len(v)==17 and tuple(a%48 for a in cov(v)) in S
 return ip,contains
M={n:gen(n) for n in model};pairs={n:[json.loads(l) for l in (root/(n+'.reps')).read_text().splitlines()] for n in model}
L=(root/'K_classes.tsv').read_text().splitlines();W=[json.loads(l) for l in Path('realwitnesses.jsonl').read_text().splitlines()];chk(len(L)==len(W)==283)
counts=Counter()
for i,(l,w) in enumerate(zip(L,W)):
 j,key,*_=l.split();n,k=key.split(':');k=int(k);chk(int(j)==i==w['K'] and n==w['model'] and k==w['mark']);q=pairs[n][k]
 c,d=([v for b in q for v in b[h]] for h in (0,1));u,v=w['u'],w['v'];ip,contains=M[n];chk(all(contains(a) for a in (c,d,u,v)))
 chk(ip(c,c)==ip(d,d)==7 and ip(c,d)==0)
 A,B,C,D=[ip(z,t) for z in (u,v) for t in (c,d)];chk([A,B,C,D]==w['R'])
 f=7*ip(u,u)-A*A-B*B;h=7*ip(v,v)-C*C-D*D;g=7*ip(u,v)-A*C-B*D
 chk([f,g,h]==w['M'] and 5<=f<=h<=9 and 0<f*h-g*g<=72);counts[f,h,abs(g)]+=1
print('PASS: 283 explicit real-independent pairs, Gram determinants <=72.',sorted(counts.items()))
