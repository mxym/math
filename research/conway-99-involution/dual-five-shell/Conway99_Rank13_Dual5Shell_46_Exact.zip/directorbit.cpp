#include <array>
#include <vector>
#include <map>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <set>
#include <algorithm>
using namespace std;using R=array<int,42>;using Pair=array<R,2>;using Words=array<signed char,84>;
void must(bool v){if(!v)throw runtime_error("bad orbit");}
int E[42][3],eid[7][7][2];
int own(R const&r){int m=0;for(int i=0;i<6;i++)if(r[2*i]%2)m|=1<<(i+1);if(__builtin_popcount(m)>3)m^=127;must(__builtin_popcount(m)==2);for(int j=0;j<42;j++)must(!!(r[j]%2)==(((m>>E[j][0])^(m>>E[j][1]))&1));return m;}
pair<Words,int> st(Pair a,int mark){
 int U=own(a[0]),V=own(a[1]);int d=0;for(int i=0;i<42;i++)d+=a[0][i]*a[1][i];must(abs(d)==8);if(d<0)for(auto&v:a[1])v=-v;
 array<int,7>p={0,1,2,3,4,5,6};Words best,tar;best.fill(2);int allowed=0;do{
  // p maps canonical axes to given ones. Sort by (is in first cut, is in second cut), descending.
  bool ok=true;int prev=4;for(int k:p){int z=2*((U>>k)&1)+((V>>k)&1);if(z>prev)ok=false;prev=z;}if(!ok)continue;
  array<int,7>q;for(int i=0;i<7;i++)q[p[i]]=i;
  for(int signs=0;signs<128;signs++){
   for(int k=0;k<42;k++){int i=E[k][0],j=E[k][1],minus=E[k][2],p0=q[i],p1=q[j],a0=(signs>>i)&1,a1=((signs>>j)&1)^minus;int s=a0^a1;
    int n=eid[min(p0,p1)][max(p0,p1)][s],eps=(p0<p1?a0:a1)?-1:1;
    tar[2*n]=eps*a[0][k];tar[2*n+1]=eps*a[1][k];}
   if(tar<best){best=tar;allowed=1<<q[mark];}else if(tar==best)allowed|=1<<q[mark];
  }
 }while(next_permutation(p.begin(),p.end()));return{best,allowed};
}
int main(int argc,char**argv){int k=0;for(int i=0;i<7;i++)for(int j=i+1;j<7;j++)for(int s=0;s<2;s++){E[k][0]=i;E[k][1]=j;E[k][2]=s;eid[i][j][s]=k++;}
 map<Words,int> group;map<Words,Words> sw;map<Pair,pair<Words,int>> cache;set<int> charts;int lines=0;for(int f=1;f<argc;f++){ifstream in(argv[f]);must(bool(in));int id,d;while(in>>id>>d){Pair a;int dot=0;for(auto&r:a)for(auto&x:r)must(bool(in>>x));for(int i=0;i<42;i++)dot+=a[0][i]*a[1][i];must(dot==4*d&&(own(a[0])&1));charts.insert(id);lines++;
 if(!cache.count(a))cache[a]=st(a,0);auto [k,b]=cache[a];group[k]|=b;
 if(!sw.count(k)){swap(a[0],a[1]);sw[k]=st(a,0).first;}
 }}
 int both=0,all=0;for(auto &[k,b]:group)if((b&3)==3){both++;auto i=group.find(sw[k]);if(i!=group.end()&&(i->second&3)==3)all++;}
 cout<<"direct signed D7 action: "<<lines<<" rows, "<<charts.size()<<" charts, "<<group.size()<<" ordered orbits, "<<both<<" both first, "<<all<<" both pairs.\n";must(all==0);}
