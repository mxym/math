from pathlib import Path
from collections import Counter
import sys
def ck(v):
 if not v:raise ArithmeticError('ledger mismatch')
def read(f):
 q={}
 for l in Path(f).read_text().splitlines():
  k,*w=l.split();k=int(k);ck(k not in q);q[k]=w[:w.index('cpu')] if 'cpu' in w else w
 return q
if len(sys.argv)>2:ck(read(sys.argv[1])==read(sys.argv[2]));print('PASS ledger',sys.argv[1]);raise SystemExit
tot=[]
for s,d in [('plus',2),('minus',-2)]:
 e=Path('expected');R=read(e/(s+'-rank.tsv'));P=read(e/(s+'.tsv'));S=read(e/(s+'-5.tsv'));ct=Counter();n=m=a=0
 for l in (e/('heavy-'+s+'.rows')).read_text().splitlines():
  i,m0,*v=map(int,l.split());ck(m0==d and len(v)==84 and sum(x*y for x,y in zip(v[:42],v[42:]))==4*d);ct[i]+=1
 ck(len(R)==len(P)==3580)
 for i,stats in R.items():
  pp=P[i]
  if stats==['bad-shell']:ck(pp==stats and S[i]==stats);continue
  r,k,xx,ww=map(int,stats);n+=xx;m+=ww
  if not k:ck(pp==['no-positive-pair','degenerate='+str(ww)])
  else:ck(pp[0]=='r'+str(r) and int(pp[4])==k and int(pp[11])==ww and sum(map(int,pp[6:10]))==xx and int(pp[9])==0)
  if ww:
   ss=S[i];ck(int(ss[11])==ww and sum(map(int,ss[6:10]))==ww and int(ss[9])==ct[i]);a+=ct[i]
  else:ck(i not in S and not ct[i])
 ck(a==sum(ct.values()));tot.append((d,n,m,a))
ck(tot==[(2,5640934,26824,438),(-2,3353994,14076,414)])
print('PASS signed coverage:',tot)
