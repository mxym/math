"""Canonical ordered pair of signed D7 root rows; record all images of marked central axis."""
from pathlib import Path
from collections import defaultdict, Counter
import itertools as I
import functools,sys
def fail(x):
 if not x:raise ArithmeticError
def dirs(w):
 E=[[0]*7 for _ in range(7)];part=0;t=0
 for i,j in I.combinations(range(7),2):
  a,b=w[t:t+2];t+=2;fail((a-b)%2==0);E[i][j]=(a+b)//2;E[j][i]=(a-b)//2
  if i==0 and (a%2):part|=1<<j
 fail(all(sum(s)==0 for s in E))
 if part.bit_count()>3:part^=127
 fail(part.bit_count()==2)
 return E,part
@functools.cache
def ps(mask,msk):
 # order old indices corresponding to canonical new positions; positions 0,1 always first two cut axes. Intersection first.
 groups=([i for i in range(7) if (mask>>i&1,msk>>i&1)==t] for t in [(1,1),(1,0),(0,1),(0,0)])
 return [sum(c,()) for c in I.product(*(I.permutations(x) for x in groups))]
@functools.lru_cache(maxsize=20000)
def canon(w,m,center):
 g,ga=dirs(w);h,ha=dirs(m);d=sum(x*y for x,y in zip(w,m))
 fail(abs(d)==8 and ((ga&ha).bit_count() in (0,1,2)))
 if d<0:h=[[-t for t in row]for row in h]
 key=None;poss=0
 for p in ps(ga,ha):
  words=[]
  for i in p:
   vals=tuple(t for j in p if i!=j for t in (g[i][j],h[i][j]))
   words.append(min(vals,tuple(-v for v in vals)))
  k=bytes(1+x for row in words for x in row);c=1<<p.index(center)
  if key is None or k<key:key=k;poss=c
  elif key==k:poss|=c
 return key,poss
def rows(files):
 for p in files:
  for l in open(p):
   i,d,*r=map(int,l.split());w=tuple(r[:42]);h=tuple(r[42:]);fail(sum(a*b for a,b in zip(w,h))==4*d)
   yield i,w,h
fs=['expected/heavy-plus.rows','expected/heavy-minus.rows'] if len(sys.argv)<2 else sys.argv[1:]
allr=list(rows(fs));mask=defaultdict(int);N=Counter();representatives={};ids=Counter()
for i,w,h in allr:
 k,s=canon(w,h,0);mask[k]|=s;N[k]+=1;representatives[k]=(w,h);ids[i]+=1
one=[k for k in mask if mask[k]&3==3];two=[k for k in one if mask.get(canon(representatives[k][1],representatives[k][0],0)[0],0)&3==3]
print('rows',len(allr),'layouts',len(ids),'ordered-global-pair classes',len(N),'both first-cut axes',len(one),'both cuts after swap',len(two),'orbit-mask counts',Counter(mask.values()),'surviving rows',sum(N[k]for k in two))
print('surviving charts', sorted({i for i,w,h in allr if canon(w,h,0)[0]in two}))
