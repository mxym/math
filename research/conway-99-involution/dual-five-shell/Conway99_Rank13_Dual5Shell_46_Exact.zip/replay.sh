#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"; mkdir -p work; CXX=${CXX:-g++}; F=(-O3 -std=c++17 -mpopcnt)
(cd base && python3 check_inputs.py)
python3 check_witnesses.py
for t in positive singular rank; do "$CXX" "${F[@]}" "$t.cpp" -lgmpxx -lgmp -o "work/$t";done
for s in plus minus;do
 if [ "$s" = plus ];then d=2;else d=-2;fi
 work/rank 0 3580 1 "$d" >"work/$s-rank.tsv"
 python3 ledger.py "work/$s-rank.tsv" "expected/$s-rank.tsv"
 work/singular 0 3580 1 "$d" "work/heavy-$s.rows" >"work/$s-5.tsv"
 python3 ledger.py "work/$s-5.tsv" "expected/$s-5.tsv"
 cmp "work/heavy-$s.rows" "expected/heavy-$s.rows"
 if [ "${1:-full}" = full ];then
 work/positive 0 3580 1 "$d" >"work/$s.tsv"
 python3 ledger.py "work/$s.tsv" "expected/$s.tsv"
 else
 work/positive 890 891 1 "$d" >"work/$s-pilot.tsv"
 grep '^890 ' "expected/$s.tsv" >"work/$s-expected.tsv"
 python3 ledger.py "work/$s-pilot.tsv" "work/$s-expected.tsv"
 fi
done
python3 ledger.py;python3 pairglobal.py work/heavy-plus.rows work/heavy-minus.rows
"$CXX" "${F[@]}" directorbit.cpp -o work/directorbit
work/directorbit work/heavy-plus.rows work/heavy-minus.rows
