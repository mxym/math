#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c INPUTS.sha256 >/dev/null
for a in core2label axis2; do g++ -std=c++17 -O3 "$a.cpp" -o "$a"; done
./core2label 0 >allk2c0.dat
./core2label 1 >allk2c1.dat
python coreorbit.py
./axis2 <k2c0.dat >k2axes.regenerated
cmp k2axes.regenerated k2axes.dat
OPENBLAS_NUM_THREADS=1 python first_only.py
