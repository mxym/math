#include <algorithm>
#include <array>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
// A one-sided proof checker: ignores deletion and never assumes solver input "i" clauses; only original DIMACS and independently verified RUP clauses can imply contradiction.
struct RUP {
 int n; vector<vector<int>> wl,cls; vector<signed char> val;vector<int> trail;size_t propagated=0; bool contradiction=false;
 RUP(int n):n(n),wl(2*n+4),val(n+2,0){}
 int id(int x){return (abs(x)<<1)+(x<0);}
 int lit(int x){return x<0?-val[-x]:val[x];}
 bool push(int x){auto &v=val[abs(x)];if(v)return lit(x)>0;v=x<0?-1:1;trail.push_back(x);return true;}
 bool prop(){
  while(propagated<trail.size()){
   int f=-trail[propagated++];auto &ww=wl[id(f)];size_t j=0;
   while(j<ww.size()){
    int ci=ww[j];auto &q=cls[ci];if(q[0]==f)swap(q[0],q[1]);assert(q[1]==f);
    if(lit(q[0])>0){j++;continue;}
    size_t k=2;while(k<q.size()&&lit(q[k])<0)k++;
    if(k<q.size()){swap(q[1],q[k]);wl[id(q[1])].push_back(ci);ww[j]=ww.back();ww.pop_back();continue;}
    if(!push(q[0]))return false;j++;
   }
  }return true;
 }
 void insert(vector<int> q){
  if(contradiction)return;
  sort(q.begin(),q.end());q.erase(unique(q.begin(),q.end()),q.end());
  for(int x:q){assert(x&&abs(x)<=n);if(lit(x)>0)return;}
  q.erase(remove_if(q.begin(),q.end(),[&](int a){return lit(a)<0;}),q.end());
  if(q.empty()){contradiction=true;return;}
  if(q.size()==1){if(!push(q[0])||!prop())contradiction=true;return;}
  int i=cls.size();cls.push_back(q);wl[id(q[0])].push_back(i);wl[id(q[1])].push_back(i);
 }
 bool check(const vector<int>&q){
  if(contradiction)return true;size_t mark=trail.size();bool ok=true;
  for(int a:q){if(!push(-a)){ok=false;break;}}
  if(ok)ok=prop();
  while(trail.size()>mark){val[abs(trail.back())]=0;trail.pop_back();}propagated=mark;
  return !ok;
 }
};
int main(int argc,char**argv){
 if(argc<2){cerr<<"usage: rup input.cnf < proof.drat\n";return 2;}
 ofstream clean;if(argc>=3)clean.open(argv[2]);ifstream cnf(argv[1]);string p,cn;int n,m;cnf>>p>>cn>>n>>m;assert(p=="p"&&cn=="cnf");RUP db(n+1);
 db.insert({1}); // sentinel=true, problem variable j is proof variable j+1
 int cln=0;vector<int> row;int x;
 while(cnf>>x){if(x)row.push_back(x>0?x+1:x-1);else{db.insert(row);row.clear();cln++;}}assert(m==cln);
 string line;long long acc=0,sk=0;
 while(getline(cin,line)){
  if(line.empty()||isalpha(line[0]))continue;
  const char *s=line.c_str();char*e;row.clear();
  while(true){long y=strtol(s,&e,10);if(e==s||!y)break;if(abs(y)>n+1){cerr<<"unknown variable\n";return 3;}row.push_back(y);s=e;}
  if(db.check(row)){if(argc>=3)clean<<line<<"\n";acc++;db.insert(row);if(row.empty()){cout<<"VERIFIED RUP. Learned "<<acc<<"; unused "<<sk<<".\n";return 0;}}
  else sk++;
 }cerr<<"NO VERIFIED CONTRADICTION: checked "<<acc<<", rejected "<<sk<<"\n";return 1;
}
