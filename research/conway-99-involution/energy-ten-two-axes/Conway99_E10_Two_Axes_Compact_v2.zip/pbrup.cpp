#include <algorithm>
#include <array>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
// A one-sided proof checker: ignores deletion and never assumes solver input "i" clauses; only original DIMACS and independently verified RUP clauses can imply contradiction.
struct RUP {
 int n; vector<vector<int>> wl,cls; vector<signed char> val;vector<int> trail;size_t propagated=0; bool contradiction=false;
 struct Row {int b,slack,mw;vector<pair<int,int>> ls;bool dirty=false;};vector<Row> pb;vector<vector<pair<int,int>>> occ; vector<int> dq;
 RUP(int n):n(n),wl(2*n+4),val(n+2,0),occ(2*n+4){}
 void addrow(int b,vector<pair<int,int>> ls){int k=pb.size(),sw=0,mw=0;for(auto [v,w]:ls){assert(v&&abs(v)<=n&&w>0);sw+=w;mw=max(mw,w);occ[id(v)].push_back({k,w});}pb.push_back({b,sw-b,mw,move(ls),true});dq.push_back(k);}
 void clearq(){for(int k:dq)pb[k].dirty=false;dq.clear();}
 void rollback(size_t mark){clearq();while(trail.size()>mark){int v=trail.back();for(auto [k,w]:occ[id(-v)])pb[k].slack+=w;val[abs(v)]=0;trail.pop_back();}propagated=mark;}

 int id(int x){return (abs(x)<<1)+(x<0);}
 int lit(int x){return x<0?-val[-x]:val[x];}
 bool push(int x){auto &v=val[abs(x)];if(v)return lit(x)>0;v=x<0?-1:1;trail.push_back(x);for(auto [k,w]:occ[id(-x)]){auto &r=pb[k];r.slack-=w;if(r.slack<r.mw&&!r.dirty){r.dirty=true;dq.push_back(k);}}return true;}
 bool prop(){
  while(propagated<trail.size()||!dq.empty()){
   if(!dq.empty()){int k=dq.back();dq.pop_back();auto &r=pb[k];r.dirty=false;if(r.slack<0)return false;if(r.slack<r.mw)for(auto [v,w]:r.ls){if(w>r.slack&&lit(v)==0&&!push(v))return false;}continue;}

   int f=-trail[propagated++];auto &ww=wl[id(f)];size_t j=0;
   while(j<ww.size()){
    int ci=ww[j];auto &q=cls[ci];if(q[0]==f)swap(q[0],q[1]);assert(q[1]==f);
    if(lit(q[0])>0){j++;continue;}
    size_t k=2;while(k<q.size()&&lit(q[k])<0)k++;
    if(k<q.size()){swap(q[1],q[k]);wl[id(q[1])].push_back(ci);ww[j]=ww.back();ww.pop_back();continue;}
    if(!push(q[0]))return false;j++;
   }
  }return true;
 }
 void insert(vector<int> q){
  if(contradiction)return;
  sort(q.begin(),q.end());q.erase(unique(q.begin(),q.end()),q.end());
  for(int x:q){assert(x&&abs(x)<=n);if(lit(x)>0)return;}
  q.erase(remove_if(q.begin(),q.end(),[&](int a){return lit(a)<0;}),q.end());
  if(q.empty()){contradiction=true;return;}
  if(q.size()==1){if(!push(q[0])||!prop())contradiction=true;return;}
  int i=cls.size();cls.push_back(q);wl[id(q[0])].push_back(i);wl[id(q[1])].push_back(i);
 }
 bool check(const vector<int>&q){
  if(contradiction)return true;size_t mark=trail.size();bool ok=true;
  for(int a:q){if(!push(-a)){ok=false;break;}}
  if(ok)ok=prop();
  rollback(mark);
  return !ok;
 }
};
int main(int argc,char**argv){if(argc<2)return 2;int n,m;ifstream f(argv[1]);f>>n>>m;assert(f&&n>0&&m>0);RUP db(n);for(int j=0;j<m;j++){int b,k;f>>b>>k;vector<pair<int,int>> ls;while(k--){int v,w;f>>v>>w;ls.push_back({v,w});}db.addrow(b,ls);}assert(f);db.contradiction=!db.prop();ofstream out;if(argc>2)out.open(argv[2]);bool reasons=argc>3;string line;vector<int> row;long long ok=0,sk=0;
 while(getline(cin,line)){if(line.empty())continue;const char*s=line.c_str();if(line[0]=='r'||line[0]=='a'){if(!reasons)continue;s+=2;}else if(isalpha(line[0]))continue;
 char*e;row.clear();bool end=false,unknown=false;while(*s){long y=strtol(s,&e,10);if(e==s)break;if(y==0){end=true;break;}if(abs(y)>n)unknown=true;row.push_back(y);s=e;}if(!end||unknown){sk++;continue;}
 if(db.check(row)){if(out){for(int v:row)out<<v<<' ';out<<"0\n";}ok++;db.insert(row);if(row.empty()){cout<<"VERIFIED PB-RUP "<<ok<<" unused "<<sk<<"\n";return 0;}}
 else sk++;}cerr<<"NO VERIFIED CONTRADICTION "<<ok<<" rejected "<<sk<<"\n";return 1;}
