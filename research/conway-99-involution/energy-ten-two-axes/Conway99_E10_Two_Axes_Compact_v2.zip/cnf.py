"""Balanced bidirectional totalizer, with checker-friendly DIMACS IDs."""
from functools import lru_cache
class CNF:
 def __init__(self,n):
  self.n=n;self.cs=[];self.memo={};self.fresh0=n
 def fresh(self):self.n+=1;return self.n
 def add(self,*q):
  self.cs.append(q)
 def merge(self,ls,k):
  if len(ls)==1:return ls
  key=(ls,min(len(ls),k))
  if key in self.memo:return self.memo[key]
  mid=len(ls)//2;a=self.merge(ls[:mid],k);b=self.merge(ls[mid:],k);y=tuple(self.fresh() for _ in range(min(len(ls),k)))
  for t,v in enumerate(y,1):
   for i in range(max(0,t-len(b)),min(t,len(a))+1):
    j=t-i;self.add(*((-a[i-1],) if i else ()),*((-b[j-1],) if j else ()),v)
   for i in range(max(0,t-1-len(b)),min(t-1,len(a))+1):
    j=t-1-i;self.add(-v,*((a[i],) if i<len(a) else ()),*((b[j],) if j<len(b) else ()))
  self.memo[key]=y;return y
 def constraint(self,ls,k,eq):
  ls=tuple(ls)
  if k<0 or eq and len(ls)<k:self.add();return
  if not ls:return
  if k==0:
   for x in ls:self.add(-x)
   return
  if k==1 and len(ls)<=7:
   from itertools import combinations
   for i,j in combinations(ls,2):self.add(-i,-j)
   if eq:self.add(*ls)
   return
  if k>=len(ls):
   if eq:
    for x in ls:self.add(x)
   return
  y=self.merge(ls,k+1)
  if eq:self.add(y[k-1])
  self.add(-y[k])
 def outfile(self,file):
  with open(file,'w') as f:
   print('p cnf',self.n,len(self.cs),file=f)
   for row in self.cs:print(*row,0,file=f)
