"""Deterministic first-layer checker (no external data or optimizer)."""
import json
from pathlib import Path
from k2level import base,charts,np
records=[json.loads(l) for l in open('k2level.jsonl')]
assert len(charts)==len(records)==194 and [z[0] for z in records]==list(range(194))
coverage={int(k):v for k,v in json.load(open('coverage.json')).items()}
bad=[];kept=[];nc=0

def products(y,r,Q):
    # int64 is exact under this common bound. Use ordinary Python integers for it.
    y=list(map(int,y)); u=max(map(abs,y),default=0)
    v=max(int(np.max(np.abs(r.astype(np.int64)))),int(np.max(np.abs(Q.data.astype(np.int64)))))
    assert len(y)==len(r) and len(y)*u*v+10**6<2**62
    y=np.asarray(y,dtype=np.int64)
    return int(y@r),y@Q

for h,kind,payload in records:
    H,R,z,G,Q,r=base(charts[h])
    if kind=='NO':
        ry,yQ=products(payload,r,Q)
        assert ry>34*max(0,int(max(yQ)))
        bad.append(h)
    else:
        assert kind=='PASS' and payload==len(z) and h in coverage
        kept.append(h)
        f=Path('prunes')/f'{h}.jsonl'
        if not f.exists():continue
        got=set()
        for line in f.open():
            t,pairs=json.loads(line); assert 0<=t<len(z) and t not in got;got.add(t)
            y=[0]*len(r); seen=set()
            for j,w in pairs:
                assert 0<=j<len(r) and j not in seen; seen.add(j); y[j]=w
            ry,yQ=products(y,r,Q);yQ[t]+=10**6
            assert max(yQ)<=0 and ry>-10**6
        nc+=len(got)
        family=coverage[h]
        if family[0]=='branches':
            assert all(set(b[2])<=got for b in family[1])
assert len(bad)==156 and len(kept)==38 and set(kept)==set(coverage)
files={line.split(None,1)[1].strip() for line in open('OMITTED_PROOFS.sha256')}
models=set()
for kind,dat in coverage.values():
    if kind=='branches':models.update('proofs/'+b[-1] for b in dat)
    else:models.add('proofs/'+dat)
assert len(files)==94 and files==models
print('First layer: 156/194 charts excluded by exact integer separation.')
print('Additional conditional style exclusions checked:',nc)
print('The 38 charts requiring omitted terminal certificates:',','.join(map(str,kept)))
print('Verified exact one-to-one coverage of the 94 omitted proof files.')
