#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c OMITTED_PROOFS.sha256 >/dev/null
bash verify_first_layer.sh
for a in rupfilter pbrup treeverify; do g++ -std=c++17 -O3 "$a.cpp" -o "$a"; done
OPENBLAS_NUM_THREADS=1 python verify.py "$@"
