from levelsat import *
from pathlib import Path
def dump(h,strong):
 H,R,z,G,Q,r=base(charts[h]);n,C=cons(h);N=34;gs=[np.flatnonzero(G==i)for i in range(N)];size=[len(x)for x in gs];assert max(size)<=64;al=[(1<<m)-1 for m in size];rows=set()
 def add(w,lo,hi):
  sr=[]
  for j in range(N):
   u=w[gs[j]];k=int(min(u));lo-=k;hi-=k;u=u-k
   if max(u):sr.append((j,*[sum(1<<int(i)for i in np.flatnonzero(u>=e)) for e in range(1,int(max(u))+1)]))
  if not sr and lo<=0<=hi:return
  rows.add((max(0,lo),min(sum(len(v)-1 for v in sr),hi),tuple(sr)))
 for u,b,e in C:
  if not e and len(u)<=b:continue
  w=np.bincount(u,minlength=n) if u else np.zeros(n,int);add(w,b if e else -10000,b)
 if strong:
  z2=np.vstack([z,z[:,MOV]]);ii=np.r_[np.arange(n),np.arange(n)]
  for t,v in enumerate(z):
   res=2-v-H@v;can=(G[ii]!=G[t])&(z2[:,res==0].sum(1)==0)&(z2@v<=1);W=z2*can[:,None];V=W[:n]+W[n:]
   for p in range(1,len(H)):
    b=int(res[p])
    if b<=0:continue
    u=V[:,p].copy();ms=[int(u[g].min())for g in gs];d=b-sum(ms)
    if d<=0:continue
    if sum(int(u[g].max()!=x)for g,x in zip(gs,ms))>18:continue
    u[gs[G[t]]]=b;u[t]=0;add(u,b,10000)
 with open(f'csp_{h}_{strong}.dat','w')as f:
  print(N,*size,len(rows),file=f)
  for l,y,sr in sorted(rows):print(l,y,len(sr),*[v for row in sr for v in (row[0],len(row)-1,*row[1:])],file=f)
if __name__=='__main__':
 for h in map(int,sys.argv[2:]):dump(h,int(sys.argv[1]))
