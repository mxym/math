from pathlib import Path
import numpy as np,itertools,sys
from collections import Counter,defaultdict
from itertools import combinations,product
from scipy import sparse
M=np.array([[(int(z)>>j)&1 for j in range(10)] for z in open('k2c0.dat').read().split()],np.int16)
EE=[i for i in range(10) if i not in (2,3)]
px=[15+2*EE.index(i) if i in EE else 1+2*(i-2) for i in range(10)];nx=[i+1 for i in px]
MOV=np.r_[0,(np.arange(30)^1)+1];I,J=np.triu_indices(31);V=np.arange(31);F=np.zeros(31,dtype=np.int16);F[px]=1;F[nx]=-1
P=np.array(list(product(range(2),repeat=16)),np.int16)
P=P[(np.sum(P[:,::2]*P[:,1::2],axis=1)<=1)&(np.sum(P[:,::2],1)<=3)&(np.sum(P[:,1::2],1)<=3)]
Ls=list(combinations(range(7),2));roots=[(i,j,s) for i,j in Ls for s in [0,1]]
charts=[tuple(map(int,l.split())) for l in open('k2axes.dat')]
def base(q):
 axis=q+(0,)*(5-len(q));H=np.zeros((31,31),np.int16)
 def link(i,j):H[i,j]=H[j,i]=1
 for i in range(7):link(0,1+2*i);link(0,2+2*i);link(1+2*i,2+2*i)
 for x in (px,nx):link(x[0],x[1])
 for i,j in zip(*np.where(M)):link(px[i],nx[j]);link(nx[i],px[j])
 for k,m in enumerate(axis):
  for j in range(20):
   if m>>j&1:
    a=5+2*k;p=(px+nx)[j];link(a,p);link(MOV[a],MOV[p])
 assert np.array_equal(H@F,-4*F)
 R=12*np.eye(31,dtype=np.int16)+2-H-H@H
 if R.min()<0:return
 used=[]
 for e in range(8):
  l=np.flatnonzero(H[1:15,15+2*e]);assert len(l)==2
  used.append((l[0]//2,l[1]//2,(l[0]^l[1])%2))
 if len(set(used))!=8:return
 exc=2-sum((m.bit_count()//2 in [0,3]) for m in axis);assert exc>=0
 A=[];ix=[]
 for tl,(i,j,s) in enumerate(t for t in roots if t not in used):
  z=np.zeros((len(P),31),np.int16);z[:,1+2*i]=z[:,1+2*j+s]=1;z[:,15:]=P
  h=z[:,px].sum(1);z=z[(z@F==0)&(h<=2)&((exc>0)|(h>0))]
  z=z[np.max(z@H+z,axis=1)<=2]
  q=z[:,I]*z[:,J]+z[:,MOV[I]]*z[:,MOV[J]]
  z=z[np.max(q-R[I,J],axis=1)<=0]
  A.extend(z);ix.extend([tl]*len(z))
 z=np.array(A,dtype=np.int16).reshape(-1,31);ix=np.array(ix);q=z[:,I]*z[:,J]+z[:,MOV[I]]*z[:,MOV[J]];q=sparse.csr_matrix(np.vstack([q.T,ix==np.arange(34)[:,None]]),dtype=np.int32)
 # At E=10,e=1 there are precisely two h=0 zero orbits, no h=3 (see proof).
 # L=1_{h=2} - 1_{h=0} on zero vertices, zero on support.
 XX=(F!=0).astype(np.int16);HH=np.zeros(31,dtype=np.int16);HH[px[:2]+nx[:2]]=1
 hh=H[:,px].sum(1);L=((hh==2).astype(np.int16)-(hh==0).astype(np.int16))*(1-XX)
 rhs=6*XX+6-3*(H@XX)//2-H@HH-H@L
 star=z[:,px].sum(1);d=((star==2).astype(np.int16)-(star==0).astype(np.int16))
 extra=(d[:,None]*(z+z[:,MOV])).T
 # Convert signed coefficients to nonnegative blockwise using one choice per label.
 for i in range(31):
  for t in range(34):
   arr=extra[i,ix==t]
   if len(arr)==0:continue
   mn=int(np.min(arr));extra[i,ix==t]-=mn;rhs[i]-=mn
 q=sparse.vstack((q,sparse.csr_matrix(extra)),format='csr')
 return H,R,z,ix,q,np.r_[R[I,J],np.ones(34,dtype=np.int16),rhs]
