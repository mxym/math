from itertools import permutations,product
from pathlib import Path
rows=lambda f:{tuple(map(int,l.split())) for l in open(f) if l.strip()}
D=next(iter(rows('k2c0.dat')));O=set()
for p,q,r in product(permutations((0,1)),permutations((2,3)),permutations(range(4,10))):
 f=p+q+r;A=[0]*10
 for i in range(10):
  for j in range(10):
   if D[i]>>j&1:A[f[i]]|=1<<f[j]
 O.add(tuple(A))
assert len(O)==2880 and O==rows('allk2c0.dat') and not rows('allk2c1.dat')
print('Exact labeled support-matrix orbit: 2880+0; one orbit with trivial stabilizer')
