"""No SAT, CP or LP solver: regenerate mathematical constraints and check exact witnesses."""
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip,sys,json,subprocess,shutil
from certsimple import groupcnf
from newgroup import branchcnf
from pbbase import *
from cspinput import dump
def checked_binary(tool,inp,proof):
 p=subprocess.Popen([tool,str(inp)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 try:
  with gzip.open(proof,'rb')as f:shutil.copyfileobj(f,p.stdin,1<<18)
  p.stdin.close()
 except BrokenPipeError:pass
 msg=p.stdout.read().decode();rc=p.wait();assert rc==0,(proof,msg,rc)
 if tool.endswith('pbrup'):assert ' unused 0' in msg and 'VERIFIED PB-RUP' in msg
 elif tool.endswith('rupfilter'):assert 'unused 0.'in msg and 'VERIFIED RUP' in msg
 else:assert 'VERIFIED EXHAUSTIVE DOMAIN TREE' in msg
 return msg.strip()
def prune(h,Q,r):
 f=Path('prunes')/f'{h}.jsonl';d={}
 if f.exists():
  for line in f.open():
   t,y0=json.loads(line);y=np.zeros(len(r),np.int64)
   for k,w in y0:y[k]=w
   q=y@Q;q[t]+=1000000
   assert max(q)<=0 and y@r>-1000000;d[t]=True
 return d
def verify(only=None):
 data={h:(s,l)for h,s,l in map(json.loads,open('k2level.jsonl'))};assert set(data)==set(range(194))
 mfs=json.load(open('coverage.json'));cnt=Counter()
 for h in (range(194)if only is None else only):
  s,a=data[h];H,R,z,G,Q,r=base(charts[h]);n=len(z)
  if s=='NO':
   y=np.array(a,dtype=np.int64);assert y@r>34*max(0,max(y@Q));cnt['first-layer integer separator']+=1;continue
  assert s=='PASS' and len(z)==a;dd=prune(h,Q,r);rr=mfs[str(h)];td=Path('verify_temp');td.mkdir(exist_ok=True);cn=td/'verify.cnf';pbr=td/'verify.pb'
  if rr[0]=='RUP':
   C=groupcnf(h);C.outfile(cn);out=checked_binary('./rupfilter',cn,Path('proofs')/rr[1]);cnt['unbranched RUP']+=1
  elif rr[0]=='PB':
   pbbase(h,pbr);out=checked_binary('./pbrup',pbr,Path('proofs')/rr[1]);cnt['unbranched PB-RUP']+=1
  elif rr[0]=='tree':
   dump(h,0);out=checked_binary('./treeverify',f'csp_{h}_0.dat',Path('proofs')/rr[1]);cnt['unbranched exact tree']+=1
  else:
   assert rr[0]=='branches';bb=rr[1];tfs=[v[0]for v in bb];grp=np.argmin(np.bincount(G))
   assert tfs==[-1] or set(tfs)==set(np.flatnonzero(G==grp).tolist()) and len(tfs)==len(set(tfs))
   for t,cut,skip,pf in bb:
    assert all(v in dd for v in skip);C=branchcnf(h,t,cut,skip);C.outfile(cn);out=checked_binary('./rupfilter',cn,Path('proofs')/pf);print(h,t,out,flush=True)
   cnt['pruned/partitioned RUP']+=1
  print('OK',h,rr[0],out,flush=True)
 if only is None:
  assert cnt['first-layer integer separator']==156 and sum(cnt.values())==194 and {int(h)for h in mfs}=={h for h,(s,_)in data.items()if s=='PASS'}
 print('ALL CHECKED',dict(cnt),flush=True)
if __name__=='__main__':verify([int(s)for s in sys.argv[1:]]if len(sys.argv)>1 else None)
