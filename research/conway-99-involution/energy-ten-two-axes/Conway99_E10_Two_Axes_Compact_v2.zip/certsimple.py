from levelsat import *
def groupcnf(h,strong=False):
 H,R,z,G,Q,r=base(charts[h]);n,C=cons(h)
 grp=[np.flatnonzero(G==i).tolist() for i in range(34)];All=[(1<<len(x))-1 for x in grp];idx=np.zeros(n,dtype=int)
 c=CNF(n);tags={}
 for i,x in enumerate(grp):
  for j,k in enumerate(x):idx[k]=j
  c.constraint([k+1 for k in x],1,True)
 def prop(i,S):
  key=(i,S)
  if key in tags:return tags[key]
  if (i,All[i]^S) in tags:return -tags[(i,All[i]^S)]
  if 2*S.bit_count()>len(grp[i]):return -prop(i,All[i]^S)
  ls=[k+1 for j,k in enumerate(grp[i]) if S>>j&1]
  assert ls
  if len(ls)==1:y=ls[0]
  else:
   y=c.fresh();c.add(-y,*ls)
   for x in ls:c.add(-x,y)
  tags[key]=y;return y
 done=set()
 for u,b,e in C:
  if not e and len(u)<=b:continue
  w=Counter(u);d={}
  for k,nv in w.items():
   l=G[k];p=d.setdefault(l,[0]*nv);p.extend([0]*max(0,nv-len(p)))
   for i in range(nv):p[i]|=1<<int(idx[k])
  y=[]
  for l,p in sorted(d.items()):
   for x in p:
    if x==All[l]:b-=1
    else:y.append(prop(l,x))
  y=tuple(sorted(y));key=y,b,e
  if key not in done:c.constraint(y,b,e);done.add(key)
 if strong:
  H,R,z,G,Q,r=base(charts[h]);z2=np.vstack([z,z[:,MOV]]);ii=np.r_[np.arange(n),np.arange(n)]
  groups=[np.asarray(v)for v in grp]
  for t,v in enumerate(z):
   res=2-v-H@v;can=(G[ii]!=G[t])&(z2[:,res==0].sum(1)==0)&(z2@v<=1);W=z2*can[:,None];V=W[:n]+W[n:]
   for p in range(1,len(H)):
    b=int(res[p]);y=[]
    if b<=0:continue
    ws=[V[g,p] for g in groups];b-=sum(int(w.min())for w in ws)
    if b<=0:continue
    if sum(int(w.min()!=w.max())for w in ws)>18:continue
    for i,w in enumerate(ws):
     for e in range(w.min()+1,w.max()+1):
      ss=sum(1<<int(k)for k in np.flatnonzero(w>=e));y.append(prop(i,ss))
    y=tuple(sorted(y))
    if b>len(y):c.add(-t-1)
    elif b==1:c.add(-t-1,*y)
    else:
     assert b==2
     ct=Counter(y);ks=sorted(ct)
     c.add(-t-1,*ks)
     for q in ks:
      if ct[q]==1:c.add(-t-1,*(j for j in ks if j!=q))
 return c
