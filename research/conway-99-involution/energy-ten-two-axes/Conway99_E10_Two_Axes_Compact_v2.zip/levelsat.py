from k2level import *
from cnf import CNF
def cons(h):
 H,R,z,ix,Q,r=base(charts[h]);C=set();n=len(z)
 for j,b in enumerate(r):
  qa,qb=Q.indptr[j:j+2];u=tuple(k for k,v in zip(Q.indices[qa:qb],Q.data[qa:qb]) for _ in range(v));C.add((u,int(b),True))
 T=defaultdict(list)
 for k,v in enumerate(z):
  for t in [v,v[MOV]]:
   for tri in combinations(np.flatnonzero(t).tolist(),3):T[tri].append(k)
 for tri,u in T.items():C.add((tuple(u),1-int(np.prod(H[list(tri)],axis=0).sum()),False))
 return n,sorted(C)
