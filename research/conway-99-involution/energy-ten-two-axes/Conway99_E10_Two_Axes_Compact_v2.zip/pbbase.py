from levelsat import *
def pbbase(h,f):
 n,C=cons(h);rows=[[1,((1,1),)]]
 for u,b,e in C:
  if not e and len(u)<=b:continue
  if b<0 or e and len(u)<b:rows.append([1,()]);continue
  if not u:continue
  m=Counter(int(k)+2 for k in u);q=tuple(m.items())
  if e:rows.append((b,q))
  rows.append((len(u)-b,tuple((-v,w)for v,w in q)))
 with open(f,'w')as g:
  print(n+1,len(rows),file=g)
  for b,q in rows:print(b,len(q),*(k for vw in q for k in vw),file=g)
