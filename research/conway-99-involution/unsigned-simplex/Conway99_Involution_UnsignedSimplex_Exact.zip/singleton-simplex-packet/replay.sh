#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c MANIFEST.sha256 >/dev/null
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
cd unsigned15; mkdir -p replay-out
cxx="${CXX:-g++}"
flags=(-std=c++17 -O3 -mpopcnt)
"$cxx" "${flags[@]}" ../dualplanes/unary5-packet/catalog.cpp -o replay-out/catalog
./replay-out/catalog >replay-out/layouts.tsv 2>replay-out/burnside.txt;cmp replay-out/layouts.tsv ../dualplanes/unary5-packet/layouts.tsv
"$cxx" "${flags[@]}" code15.cpp -o replay-out/code15
./replay-out/code15 >replay-out/code15.tsv; cmp replay-out/code15.tsv code15.tsv
python3 checkcodes.py
python3 code7e8.py >replay-out/code7e8.tsv;cmp replay-out/code7e8.tsv code7e8.tsv
python3 wittcheck.py
python3 rootedges.py >replay-out/rootedges.txt;cmp replay-out/rootedges.txt expected/rootedges.txt
python3 fixturescheck.py >replay-out/fixture-counts.txt;cmp replay-out/fixture-counts.txt expected/fixture-counts.txt
"$cxx" "${flags[@]}" auditroot.cpp -o replay-out/auditroot -lgmpxx -lgmp
./replay-out/auditroot >replay-out/audit.tsv;cmp replay-out/audit.tsv expected/audit.tsv
"$cxx" "${flags[@]}" hsym-frozen.cpp -o replay-out/first -lgmpxx -lgmp
"$cxx" "${flags[@]}" hpair.cpp -o replay-out/pair -lgmpxx -lgmp
"$cxx" "${flags[@]}" h1controls.cpp -o replay-out/h1controls -lgmpxx -lgmp
./replay-out/h1controls >replay-out/controls.txt;cmp replay-out/controls.txt expected/controls.txt
python3 h1ledger.py
case "${1:-quick}" in
quick) for i in 183 890 1395; do ./replay-out/first "$i" "$((i+1))" 1;done >replay-out/first.log ;;
full) ./replay-out/first 0 3580 1 >replay-out/first.log ;;
*) echo "expected quick or full" >&2;exit 1;; esac
python3 h1ledger.py first replay-out/first.log "${1:-quick}"
while read -r id tail;do ./replay-out/pair "$id" "$((id+1))" 1;done <expected/pair.tsv >replay-out/pair.log
python3 h1ledger.py pair replay-out/pair.log all
echo "All required checks passed in ${1:-quick} mode."
