"""I7+E8 mixed glue C with injective projection to F2^7: enumerate all
short unit-coordinate support candidates for the e=21 metric classes."""
from itertools import combinations,permutations
from collections import Counter
from functools import cache
pc=int.bit_count
def sp(B):
 S=[0]
 for x in B:S+= [i^x for i in S]
 return tuple(sorted(S))
def basis(S):
 d={}
 for x in sorted(S):
  while x and x.bit_length() in d:x^=d[x.bit_length()]
  if x:d[x.bit_length()]=x
 return list(d.values())
def spaces(S,k):
 L={(0,)}
 for _ in range(k):
  K=set()
  for V in L:
   for x in S:
    if x not in V:K.add(tuple(sorted((*V,*(j^x for j in V)))))
  L=K
 return sorted(L)
def Q(x):return pc((x&(x>>1))&85)%2
def B(x,y):return Q(x)^Q(y)^Q(x^y)
Per=[]
for p in permutations(range(7)):
 Per.append([sum((1<<p[i])for i in range(7)if (u>>i)&1)for u in range(128)])
def q7(x):return pc(x)//2%2
def eq(x,y):return pc(x&y)%2
def maps(D,R):
 bs=basis(R);A=[];h=list(bs)
 for x in D:
  if x not in sp(h):A.append(x);h.append(x)
 def rec(old):
  if len(old)==len(A):return old
  i=len(old);s=sp(old)
  for b in range(1,256):
   if b not in s and Q(b)==q7(A[i]) and all(B(y,b)==eq(x,A[i]) for x,y in zip(A,old)):
    ret=rec(old+[b])
    if ret is not None:return ret
 old=rec([]);assert old is not None
 V={x:0 for x in R}
 for x,y in zip(A,old):V.update({i^x:j^y for i,j in list(V.items())})
 assert set(V)==set(D) and {x for x,y in V.items()if not y}==set(R)
 return V
def qq(x):return (pc(x%128)+2*Q(x//128))%4
def bb(x,y):return eq(x%128,y%128)^B(x//128,y//128)
def classify():
 E=[x for x in range(128) if pc(x)%2==0];DD=spaces(E,4);assert len(DD)==651
 seen=set();result=[]
 for D in DD:
  if D in seen:continue
  stabil=[]
  for f in Per:
   u=tuple(sorted(f[x] for x in D));seen.add(u)
   if u==D:stabil.append(f)
  radical=[x for x in D if not q7(x) and not any(eq(x,y) for y in D)];rseen=set()
  for k in range(len(radical).bit_length()):
   for R in spaces(radical,k):
    if R in rseen:continue
    rseen.update(tuple(sorted(f[x]for x in R))for f in stabil)
    V=maps(D,R);C=[x|y<<7 for x,y in V.items()];result.append((D,R,C))
 assert set(DD)==seen
 return result
def go(idx,C):
 U=basis(C);X={};S=[];word=[];canon={}
 for x in range(32768):
  if any(bb(x,c)for c in U):continue
  t=min(x^w for w in C);i=canon.get(t)
  if i is None:i=len(S);canon[t]=i;S.append(t);word.append(set())
  X[x]=i;u=x%128;k=pc(u);v=x>>7
  if not(k==1 and v and not Q(v) or k==3 and Q(v) or k==5 and not v):continue
  good=True
  for w in C:
   a=w%128;b=w//128
   if pc(a)==4 and not b and pc(u&a)>2:good=False;break
   if pc(a)==2 and Q(b):
    n=2 if v==b else B(v,b)
    if pc(u&a)+n>2:good=False;break
  if good:word[i].add(u)
 assert len(S)==128
 def rec(a,j):
  if len(a)==7:return a
  for k in range(j,128):
   t=S[k]
   if qq(t)!=1 or any(bb(x,t)for x in a):continue
   b=rec(a+[t],k+1)
   if b is not None:return b
 a=rec([],0);assert a is not None
 for o in range(8):
  s=[word[X[(a[i] if j==7 else 127^a[i]^a[j])]] for i,j in combinations([e for e in range(8)if e!=o],2)]
  n=0
  if all(s):
   n=1
   if all(sum(all(m>>i&1 for m in a)for a in s)<=7<=sum(any(m>>i&1 for m in a)for a in s)for i in range(7)):n=2
  print(idx,o,n,' '.join(','.join(str(t) for t in sorted(v))if v else '-'for v in s),flush=True)
if __name__=='__main__':
 import sys
 if not __debug__:raise RuntimeError('assertions required')
 C=classify();print('identified',len(C),'codes; D orbits',len(set(d for d,r,c in C)),file=sys.stderr)
 for i,(D,R,c)in enumerate(C):go(i,c)
