/* Independent exhaustive signed-permutation stabilizer and direct star
   cofactor test; intentionally does not use the main search headers. */
#include <bits/stdc++.h>
using namespace std;using ll=long long;using W=array<int,12>;using U=uint64_t;
void ck(bool a){if(!a)throw runtime_error("bad certificate");}
ll det(vector<vector<ll>>a){int n=a.size();if(!n)return 1;ll d=1;int sign=1;for(int j=0;j+1<n;j++){int k=j;while(k<n&&!a[k][j])k++;if(k==n)return 0;if(k!=j){swap(a[j],a[k]);sign=-sign;}ll w=a[j][j];for(int i=j+1;i<n;i++)for(int k=j+1;k<n;k++){__int128 x=(__int128)a[i][k]*w-(__int128)a[i][j]*a[j][k];ck(x%d==0&&x/d<=LLONG_MAX&&x/d>=LLONG_MIN);a[i][k]=x/d;}d=w;}return sign*a.back().back();}
bool phys(const W&p,const W&n){U A[39]={};auto add=[&](int i,int j){ck(i!=j);A[i]|=1ull<<j;A[j]|=1ull<<i;};for(int a=0;a<7;a++){add(0,1+2*a);add(0,2+2*a);add(1+2*a,2+2*a);}for(int i=0;i<12;i++)for(int s=0;s<2;s++){int v=15+2*i+s;add(v,1+s);add(v,3+2*(i/2)+(s^(i&1)));add(v,15+2*p[i]+s);add(v,15+2*n[i]+(s^1));}
for(int i=0;i<39;i++)for(int j=0;j<i;j++)if(__builtin_popcountll(A[i]&A[j])+int((A[i]>>j)&1)>2)return false;return true;}
int main(){vector<W>gs;array<int,6>Z={0,1,2,3,4,5};do{for(int t=0;t<64;t++){W a;for(int i=0;i<12;i++)a[i]=2*Z[i/2]+((i&1)^((t>>(i/2))&1));gs.push_back(a);}}while(next_permutation(Z.begin(),Z.end()));ck(gs.size()==46080);
ifstream in("../dualplanes/unary5-packet/layouts.tsv");int r,id=0;W p,n;while(in>>r){for(int&j:p)ck(bool(in>>j));for(int&j:n)ck(bool(in>>j));if(!phys(p,n)){cout<<id++<<" bad\n";continue;}
 vector<W const*>grp;for(auto&g:gs){bool ok=1;for(int i=0;i<12&&ok;i++)ok=p[g[i]]==g[p[i]]&&n[g[i]]==g[n[i]];if(ok)grp.push_back(&g);}
 vector<vector<int>>C;int used=0;for(int i=0;i<12;i++)if(!(used>>i&1)){vector<int>st{i},cc;while(!st.empty()){int v=st.back();st.pop_back();if(used>>v&1)continue;used|=1<<v;cc.push_back(v);for(int u:{v^1,p[v],n[v]})st.push_back(u);}sort(cc.begin(),cc.end());C.push_back(cc);}
 vector<int>R;for(auto&cc:C)for(int i:cc)if(i!=cc.front())R.push_back(i);int s=R.size();vector<vector<ll>> A(s,vector<ll>(s)),adj=A;
 for(int i=0;i<s;i++)for(int j=0;j<s;j++){int x=R[i],y=R[j];A[i][j]=5*(x==y)-((x^1)==y)-2*(p[x]==y)-2*(n[x]==y);}
 ll d=det(A);ck(d>0);for(int i=0;i<s;i++)for(int j=0;j<=i;j++){vector<vector<ll>>a;for(int k=0;k<s;k++)if(k!=i){a.emplace_back();for(int v=0;v<s;v++)if(v!=j)a.back().push_back(A[k][v]);}adj[i][j]=adj[j][i]=((i+j)%2?-1:1)*det(a);}
 int ng=0,orb=0,z=0,pos=0;for(int g=1;g<4096;g+=2)if(__builtin_popcount((unsigned)g)==6){int sig[12],e=0;for(int i=0;i<12;i++)sig[i]=2*((g>>i)&1)-1;for(int i=0;i<12;i++)e+=(sig[i]==sig[p[i]])+(sig[i]==sig[n[i]]);if(e>4)continue;ng++;
 bool canon=1;for(auto *b:grp){int h=0;for(int i=0;i<12;i++)if(g>>i&1)h|=1<<(*b)[i];if(!(h&1))h^=4095;if(h<g){canon=false;break;}}if(!canon)continue;orb++;bool range=1;for(auto&cc:C){int k=0;for(int t:cc)k+=sig[t];if(k)range=false;}if(!range)continue;
 ll E=2*d;for(int i=0;i<s;i++)for(int j=0;j<s;j++)E-=sig[R[i]]*sig[R[j]]*adj[i][j];z+=E==0;pos+=E>0;}
 cout<<id++<<" "<<s<<" "<<grp.size()<<" "<<orb<<" "<<ng<<" "<<z<<" "<<pos<<"\n";}ck(id==3580);}
