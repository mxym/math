"""Verify that actual integral E8 root reflections suffice to cover every
ordered partial embedding used in the mixed binary-glue atlas."""
from code7e8 import *
def check(i,D,R,C):
 f={x&127:x>>7 for x in C}
 h=basis(R);xs=[]
 for x in D:
  if x not in sp(h):xs.append(x);h.append(x)
 ys=[];stats=[]
 for k,x in enumerate(xs):
  span=sp(ys);cand={i for i in range(1,256)if i not in span and Q(i)==q7(x) and all(B(i,z)==eq(x,v)for (z,v)in zip(ys,xs))}
  trans=[u for u in range(1,256)if Q(u) and all(B(u,y)==0 for y in ys)]
  s={f[x]};todo=list(s)
  while todo:
   y=todo.pop()
   for u in trans:
    h=y^(B(u,y)*u)
    if h not in s:s.add(h);todo.append(h)
  stats.append((len(s),len(cand)))
  if s!=cand:raise ArithmeticError(('incomplete transvection orbit',i,k,len(s),len(cand)))
  ys.append(f[x])
 print(i,stats)
if __name__=='__main__':
 if not __debug__:raise RuntimeError('assertions required')
 from roots7e8 import e8
 ip,roots=e8();assert len(roots)==120 and all(ip(t,t)==2 for t in roots.values())
 four={i^j for i in roots for j in roots if i<j and ip(roots[i],roots[j])==0};assert four=={i for i in range(1,256)if not Q(i)} and len(four)==135
 print('240 integral roots, 120 opposite pairs; 135 nonzero singular classes with explicit norm-four lifts')
 for i,(D,R,C)in enumerate(classify()):check(i,D,R,C)
