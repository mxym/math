"""Fail-closed accounting, first-layer group coverage, pair fallback, atlas and controls."""
import sys,collections
from pathlib import Path
from fractions import Fraction
def ck(v,msg):
 if not v: raise ArithmeticError(msg)
def load(path):
 a={}
 for line in Path(path).read_text().splitlines():
  row=line.split();i=int(row[0]);ck(i not in a,('duplicate chart',i,path))
  if row[-1]!='bad':
   ck(row[-2]=='cpu' and float(row[-1])>=0,('bad timing field',i));row=row[:-2]
  a[i]=row
 return a
def counts(folder='expected'):
 e=Path(folder);even=load(e/'even.log');odd=load(e/'odd.log');pair=load(e/'pair.tsv')
 ck(set(even)==set(range(0,3580,2)) and set(odd)==set(range(1,3580,2)), 'shard coverage');main=even|odd
 audits={int(l.split()[0]):l.split()[1:] for l in (e/'audit.tsv').read_text().splitlines()}
 ck(set(audits)==set(main),'audit rows')
 opens=set();H=collections.Counter()
 for i,row in sorted(main.items()):
  if row[1]=='bad':ck(row[1:]==audits[i],('bad',i));H['bad']+=1;continue
  def v(n):return row[row.index(n)+1]
  ck([v(n)for n in ('r','group','orbits','g','z','p')]==audits[i],('audit',i))
  ck(int(v('z'))+int(v('p'))>=int(v('retained')),('Schur count',i))
  if int(v('good')):opens.add(i)
  for n in ('orbits','g','z','p','match','quad','cap','good'):H[n]+=int(v(n))
 ck(opens==set(pair),('missing/extra second-stage IDs',opens,set(pair)))
 for i,x in pair.items():
  ck(x[x.index('good')+1]=='0',('second-stage open',i))
  for n in ('r','group','orbits','g','z','p','retained'):ck(main[i][main[i].index(n)+1]==x[x.index(n)+1],('pair replay prefix',n,i))
 print('3,580 disjoint chart IDs; independent stabilizer, all raw root signs, component rank, Schur guard and normalized root counts agree')
 print('totals (g includes all unquotiented modulo global negation):',dict(H));print('first-layer open IDs, all fully closed on pair replay:',sorted(opens))
 return main,pair
def atlas():
 hist=collections.Counter();ret=collections.defaultdict(set)
 for j,l in enumerate(Path('code7e8.tsv').read_text().splitlines()):
  t=l.split();i,o,res=map(int,t[:3]);ck((i,o)==divmod(j,8),'mixed order');ck(len(t)==24,'mixed cells');hist[res]+=1
  if res==2:ret[i].add(o)
 ck(sum(hist.values())==88 and hist[2]==56 and set(ret)=={3,5,6,7,8,9,10} and all(v==set(range(8)) for v in ret.values()),'mixed code atlas')
 print('mixed binary geometries by empty(0)/marginal-fail(1)/retained(2):',dict(hist))
def compare(path,source,req):
 ar=load(path);ck(set(ar)==({183,890,1395} if req=='quick' else set(source)) and all(source.get(i)==row for i,row in ar.items()),('replay ledger',path))
if __name__=='__main__':
 if not __debug__:raise RuntimeError('assertions required')
 a,b=counts();atlas()
 if len(sys.argv)>1:compare(sys.argv[2],{'first':a,'pair':b}[sys.argv[1]],sys.argv[3])
