struct RankS{
 int q[16][16],r=0,I[16],inverse[16][16]{};
 RankS(const LiftCore&l){for(int i=0;i<12;i++)for(int j=0;j<12;j++)q[i][j]=m7(l.F.A[i][j]);
 for(int i=0;i<4;i++){q[12+i][12+i]=3;for(int j=0;j<12;j++)q[12+i][j]=q[j][12+i]=m7(l.sel[i]->f[j]);for(int j=0;j<i;j++){int z=0;for(int t=0;t<7;t++)z+=l.sh.r[l.C[l.hkey[i]].d][t]*l.sh.r[l.C[l.hkey[j]].d][t];q[12+i][12+j]=q[12+j][12+i]=m7(-4*l.ls[i][j]-z);}}
 int a[16][32]={};for(int i=0;i<16;i++)copy(q[i],q[i]+16,a[i]);int inv[]={0,1,4,5,2,3,6};
 for(int j=0;j<16;j++){int k=r;while(k<16&&!a[k][j])k++;if(k==16)continue;I[r]=j;swap(a[k],a[r]);for(int i=r+1;i<16;i++){int z=a[i][j]*inv[a[r][j]]%7;if(z)for(int s=j;s<16;s++)a[i][s]=m7(a[i][s]-z*a[r][s]);}r++;}
 if(r>13)abort();if(r<12)return;memset(a,0,sizeof(a));for(int i=0;i<r;i++){for(int j=0;j<r;j++)a[i][j]=q[I[i]][I[j]];a[i][r+i]=1;}
 for(int j=0;j<r;j++){int k=j;while(k<r&&!a[k][j])k++;if(k==r)abort();swap(a[k],a[j]);int d=inv[a[j][j]];for(int i=0;i<2*r;i++)a[j][i]=a[j][i]*d%7;
 for(int t=0;t<r;t++)if(t!=j&&a[t][j]){int z=a[t][j];for(int i=0;i<2*r;i++)a[t][i]=m7(a[t][i]-z*a[j][i]);}}
 for(int i=0;i<r;i++)copy(a[i]+r,a[i]+2*r,inverse[i]);}
 bool live(const SC&z,const int d[4],array<int,4>const&s)const{
 if(r<12)return true;int a[16],c[16];for(int i=0;i<12;i++)a[i]=m7(z.f[i]);for(int i=0;i<4;i++)a[12+i]=m7(-4*s[i]-d[i]);
 for(int i=0;i<r;i++){int b=0;for(int j=0;j<r;j++)b+=inverse[i][j]*a[I[j]];c[i]=b%7;}
 for(int i=0;i<16;i++){int b=0;for(int j=0;j<r;j++)b+=q[i][I[j]]*c[j];if(b%7!=a[i])return false;}
 if(r==13){int b=0;for(int j=0;j<r;j++)b+=a[I[j]]*c[j];if(b%7!=3)return false;}return true;}
};
