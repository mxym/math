#include <bits/stdc++.h>
#include <gmpxx.h>
#include "../dualplanes/unary5-packet/legacy/real.hpp"
using namespace std;
struct SC{array<int,12>f;array<long long,12>pf;unsigned a,b;U mask;};
struct CandH {vector<SC>opt;int d,m,ep;long long maskkey;unsigned short a,b;array<int,12>f;array<long long,12>pf;long long nu;};
#include "hexjoint.hpp"
typedef mpz_class Big;
long long ipf(const CandH&m,const CandH&n){long long r=0;for(int i=0;i<12;i++)r+=m.pf[i]*n.f[i];return r;}
Big deta(long long F[12][12],vector<int> p){Big a[12][12];int k=p.size();for(int i=0;i<k;i++)for(int j=0;j<k;j++)a[i][j]=(long)F[p[i]][p[j]];Big den=1;for(int i=0;i+1<k;i++){if(a[i][i]==0)abort();for(int j=i+1;j<k;j++)for(int l=i+1;l<k;l++)a[j][l]=(a[j][l]*a[i][i]-a[j][i]*a[i][l])/den;den=a[i][i];}return a[k-1][k-1];}
Big cv128(i128 x){bool neg=x<0;unsigned __int128 u=neg?-x:x;Big r=(unsigned long)(u>>64);r<<=64;r+=(unsigned long)u;return neg?-r:r;}
#include "hsignjoint.hpp"
#include "holdseven.hpp"
#include "symstar.hpp"
int main(int ac,char**av){ifstream in("../dualplanes/unary5-packet/layouts.tsv");int id=0,R,P[12],N[12];int lo=ac>1?atoi(av[1]):0,hi=ac>2?atoi(av[2]):3580;int step=ac>3?atoi(av[3]):1;while(in>>R){for(int&v:P)in>>v;for(int&v:N)in>>v;if(id<lo||id>=hi||(id-lo)%step){id++;continue;}
clock_t tm=clock();Shell sh(P,N);if(!sh.admissible){cout<<id++<<" bad\n";continue;}Form F(P,N);RForm sg(F,P,N,1),H(F,P,N,0);sh.gen();vector<int> cuts;set<int>skip;for(int i=0;i<12;i++)if(!skip.insert(H.comp[i]).second)cuts.push_back(i);long long T0[12][12]{};for(int i=0;i<12;i++)for(int j=0;j<12;j++)T0[i][j]=H.A[i][j]-(H.comp[i]==H.comp[j]);Big vol=deta(T0,cuts);
ll pow8[18];pow8[0]=1;for(int i=1;i<18;i++)pow8[i]=8*pow8[i-1];vector<int> signedcuts(11);iota(signedcuts.begin(),signedcuts.end(),0);long long sf[12][12];for(int i=0;i<12;i++)for(int j=0;j<12;j++)sf[i][j]=F.A[i][j];Big ds=deta(sf,signedcuts)/1024;int ed[30],rev[64];for(int d=0;d<30;d++){ed[d]=0;for(int t=1;t<7;t++)if(sh.r[d][t])ed[d]|=1<<(t-1);rev[ed[d]]=d/2;}
vector<CandH>C;for(int d=0;d<30;d++){map<int,int>seen;for(auto k:sh.domain[d]){int s[12];ll q[12],nu;CandH m;m.d=d;m.ep=ed[d];m.a=k.a;m.b=k.b;m.maskkey=0;for(int e=0;e<6;e++)m.maskkey+=pow8[12+e]*((ed[d]>>e)&1);
for(int i=0;i<12;i++){int a=(k.a>>i)&1,b=(k.b>>i)&1;m.maskkey+=pow8[i]*(a+b);s[i]=-4*(a-b)-sh.z[d][i];m.f[i]=1-abs(sh.z[d][i])-2*(a+b);}
if(!sg.project(s,q,nu,10)||!H.project(m.f.data(),m.pf.data(),m.nu,5))continue;int key=(k.a|k.b)*4096+(k.a&k.b);bool bad=0;for(int i=0;i<12;i++)if((k.a&k.b)>>i&1)if(P[i]==N[i])bad=true;if(bad)continue;int ix;if(seen.count(key))ix=seen.at(key);else{ix=C.size();seen[key]=ix;C.push_back(m);}SC sc;copy(s,s+12,sc.f.begin());copy(q,q+12,sc.pf.begin());sc.a=k.a;sc.b=k.b;sc.mask=k.mask;C[ix].opt.push_back(sc);}}
vector<vector<int>>groups(30);for(int i=0;i<C.size();i++)groups[C[i].d].push_back(i);int xs=0,zs=0,ps=0,ls=0,psmin=INT_MAX,psmax=0;ll npos=0,nneg=0,njoin=0,nquad=0,ncap=0,ngood=0,zerogo=0,fullgo=0;
auto grp=stabs(P,N);bool unseen[4096];fill(unseen,unseen+4096,true);int orb=0,mult=0;for(int g=1;g<4096;g+=2)if(pop(g)==6){int q[12],es=0;for(int i=0;i<12;i++)q[i]=2*((g>>i)&1)-1;for(int i=0;i<12;i++)es+=(q[i]==q[P[i]])+(q[i]==q[N[i]]);if(es>4)continue;xs++;if(!unseen[g])continue;orb++;int o=0;for(auto &f:grp){int b=imask(g,f);if(!(b&1))b^=4095;if(unseen[b]){unseen[b]=false;o++;}}if(!o)abort();mult+=o;
ll v[12],a;if(!H.project(q,v,a,2))continue;if(!a)zs++;else ps++;int ct[2]={};vector<int> dom[2];ll tk=0;for(int i=0;i<12;i++)tk+=(ll)(-q[i]*(1+(q[i]==q[P[i]])+(q[i]==q[N[i]])))*pow8[i];for(int i=0;i<6;i++)tk-=pow8[12+i]*((q[2*i]+q[2*i+1])/2);
for(auto &m:C){int load=pop(m.a&g)+pop(m.b&g);ll w=0;for(int t=0;t<12;t++)w+=m.f[t]*v[t];
for(int s:{-1,1}){int own=s==1?load:4-load;if(own>1||own>2-es/2)continue;ll x=2*s*H.det-w;
if((i128)m.nu*a<(i128)x*x)continue;ct[s>0]++;dom[s>0].push_back(&m-C.data());}}
int before=ncap;
struct Pr2{int x,y;};unordered_multimap<ll,Pr2> pos;
for(int i=0;i<ct[1];i++)for(int j=0;j<i;j++){int x=dom[1][i],y=dom[1][j];if(C[x].d==C[y].d)continue;pos.emplace(C[x].maskkey+C[y].maskkey,Pr2{x,y});}
bool solved=false;
for(int i=0;i<ct[0]&&!solved;i++)for(int j=0;j<i&&!solved;j++){int x=dom[0][i],y=dom[0][j];if(C[x].d==C[y].d)continue;
auto rg=pos.equal_range(C[x].maskkey+C[y].maskkey+tk);for(auto it=rg.first;it!=rg.second&&!solved;it++){int ids[4]={it->second.x,it->second.y,x,y};vector<int> labels;for(int t:ids)labels.push_back(C[t].d);sort(labels.begin(),labels.end());if(adjacent_find(labels.begin(),labels.end())!=labels.end())continue;njoin++;
int A[16][16]={},par[16];for(int i=0;i<12;i++){A[i][P[i]]++;A[i][N[i]]++;par[i]=1|(2<<(i/2));}
int w[4];for(int t=0;t<4;t++){auto&m=C[ids[t]];int own=pop(m.a&g)+pop(m.b&g);w[t]=(t<2?own:4-own);par[12+t]=ed[m.d]<<1;
for(int i=0;i<12;i++)A[12+t][i]=A[i][12+t]=((m.a>>i)&1)+((m.b>>i)&1);}
for(int p=0;p<=2&&!solved;p++)for(int n=0;n<=2&&!solved;n++)for(int b=0;b<=2&&!solved;b++){int c=2+w[0]+p-b,d=2+w[2]+n-b,e=2+w[1]+p-d;if(e+c!=2+w[3]+n||min({c,d,e})<0||max({c,d,e})>2)continue;
int ls[]={p,b,c,d,e,n};int k=0;for(int i=12;i<16;i++)for(int j=i+1;j<16;j++){A[i][j]=A[j][i]=ls[k++];}nquad++;bool ok=1;
for(int i=0;i<16&&ok;i++){int bd=0;for(int j=0;j<16;j++)bd+=A[i][j]==2;if(bd>1)ok=0;for(int j=0;j<i&&ok;j++){int u=A[i][j]+pop(par[i]&par[j]);for(int t=0;t<16;t++)u+=A[i][t]*A[j][t];if(u>4)ok=false;}}
if(!ok)continue;ncap++;
long long h[4][4];for(int i=0;i<4;i++)for(int j=0;j<=i;j++){auto&m=C[ids[i]],&n=C[ids[j]];long long v0=i==j?5:1-pop(par[i+12]&par[j+12])-2*A[i+12][j+12];h[i][j]=h[j][i]=H.det*v0-ipf(m,n);}
for(int i=0;i<4;i++)for(int j=0;j<i;j++)if((i128)h[i][i]*h[j][j]<(i128)h[i][j]*h[i][j])ok=false;if(!ok)continue;
auto det3=[&](array<int,3>r,array<int,3>c){i128 k=0;for(int j=0;j<3;j++){int u=(j+1)%3,v=(j+2)%3;k+=(i128)h[r[0]][c[j]]*((i128)h[r[1]][c[u]]*h[r[2]][c[v]]-(i128)h[r[1]][c[v]]*h[r[2]][c[u]]);}return k;};
array<int,3> r,cc;for(int i=0;i<4;i++){int k=0;for(int t=0;t<4;t++)if(t!=i)r[k++]=t;if(det3(r,r)<0)ok=false;}if(!ok)continue;
Big det4=0;r={1,2,3};for(int j=0;j<4;j++){int k=0;for(int t=0;t<4;t++)if(t!=j)cc[k++]=t;det4+=(j%2?-1:1)*(long)h[0][j]*cv128(det3(r,cc));}if(det4<0)continue;
if(H.ncomp==1&&det4>0){Big w=det4*vol,den=1;for(int k=0;k<4;k++)den*=(long)H.det;den*=12544;if(!mpz_divisible_p(w.get_mpz_t(),den.get_mpz_t()))continue;w/=den;if(!mpz_perfect_square_p(w.get_mpz_t()))continue;}
zerogo+=det4==0;fullgo+=det4>0;LiftCore lc(sh,F,sg,ids,A,C,ds.get_si());lc.checkfull=[&](){int mask=0;if(det4>0)mask=15;else{for(int a=0;a<4;a++)if(h[a][a]>0)mask=1<<a;for(int i=0;i<4;i++)for(int j=0;j<i;j++)if((i128)h[i][i]*h[j][j]>(i128)h[i][j]*h[j][i])mask=(1<<i)|(1<<j);for(int skip=0;skip<4;skip++){array<int,3>tt;int k=0;for(int i=0;i<4;i++)if(i!=skip)tt[k++]=i;if(det3(tt,tt)>0)mask=15^(1<<skip);}}const CandH*rows[]={&C[ids[0]],&C[ids[1]],&C[ids[2]],&C[ids[3]]};Extend ext(A,par,C,groups,ed,mask,cuts.size(),H.det,vol,h,rows);HoldSigned hs(lc);ext.lift=[&](auto&m,auto&v){return hs.next(m,v);};return ext.all(g,C[ids[0]].d,C[ids[1]].d,C[ids[2]].d,C[ids[3]].d);};solved=lc.dfs(0);
}}}ngood+=solved;
npos+=ct[1];nneg+=ct[0];int mini=min(ct[0],ct[1]);if(mini>=2)ls++;psmin=min(psmin,mini);psmax=max(psmax,mini);}
if(xs!=mult)abort();cout<<id++<<" r "<<12-H.ncomp<<" candidates "<<C.size()<<" group "<<grp.size()<<" orbits "<<orb<<" g "<<xs<<" z "<<zs<<" p "<<ps<<" retained "<<ls<<" range "<<psmin<<" "<<psmax<<" match "<<njoin<<" quad "<<nquad<<" cap "<<ncap<<" good "<<ngood<<" det-types "<<zerogo<<" "<<fullgo<<" dom "<<npos<<" "<<nneg<<" cpu "<<(clock()-tm)/double(CLOCKS_PER_SEC)<<"\n"<<flush;}}
