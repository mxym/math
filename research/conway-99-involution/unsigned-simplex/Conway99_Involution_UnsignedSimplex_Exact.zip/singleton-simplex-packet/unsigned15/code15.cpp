/* Binary coordinate glue codes of dimension 4 and length 15; also build
   all eight embeddings of the doubled-K7 support system modulo axis-label
   permutations in the nonsingular mod-2 Gram quotient. */
#include <bits/stdc++.h>
using namespace std;using Count=array<int,16>;int nW=0;vector<Count>gl;set<Count> seen;void ck(bool v){if(!v)abort();}
int pc(int i){return __builtin_popcount((unsigned)i);}
void group(){for(int i=1;i<16;i++)for(int j=1;j<16;j++)if(j!=i)for(int k=1;k<16;k++)if(k!=i&&k!=j&&k!=(i^j))for(int l=1;l<16;l++){
 Count b;bool bad=false;for(int m=0;m<8;m++){b[m]=((m&1)?i:0)^((m&2)?j:0)^((m&4)?k:0);if(b[m]==l)bad=true;b[m|8]=b[m]^l;}if(!bad)gl.push_back(b);}
 ck(gl.size()==20160);}
bool accept(const Count&c){for(int i=1;i<16;i++){int s=0;for(int j=0;j<16;j++)if(pc(i&j)&1)s+=c[j];if(s%4)return false;}return true;}
void make_codes(vector<Count>&list){Count c{};for(int j:{1,2,4,8})c[j]=1;function<void(int,int)> dfs=[&](int lo,int rem){if(!rem){if(!accept(c))return;nW++;if(seen.count(c))return;list.push_back(c);
 for(auto f:gl){Count d;for(int j=0;j<16;j++)d[f[j]]=c[j];seen.insert(d);}return;}
 for(int j=lo;j<16;j++){c[j]++;dfs(j,rem-1);c[j]--;}};dfs(0,11);}
int main(){group();vector<Count>Codes;make_codes(Codes);cerr<<"accepted systematic multiplicities "<<nW<<" codes "<<Codes.size()<<" relabelled patterns "<<seen.size()<<"\n";
 for(int idx=0;idx<Codes.size();idx++){auto&C=Codes[idx];int col[15],n=0;for(int g=0;g<16;g++)for(int j=0;j<C[g];j++)col[n++]=g;
 int W[16]{};for(int g=0;g<16;g++)for(int j=0;j<15;j++)W[g]|=(pc(g&col[j])%2)<<j;
 vector<int>rep,ww;map<int,int> rn;array<int,32768> X;X.fill(-1);vector<vector<int>> word;
 for(int x=0;x<32768;x++){bool ok=1;for(int j=1;j<16;j*=2)if(pc(x&W[j])&1)ok=0;if(!ok)continue;int r=x;for(int j=1;j<16;j++)r=min(r,x^W[j]);if(!rn.count(r)){rn[r]=rep.size();rep.push_back(r);word.push_back({});}int k=rn.at(r);X[x]=k;if(pc(x)==5)word[k].push_back(x);}
 ck(rep.size()==128);vector<int> basis;function<bool(int)> extend=[&](int at){if(basis.size()==7)return true;for(int j=at;j<128;j++)if(pc(rep[j])%4==1){bool ok=1;for(int k:basis)if(pc(rep[j]&k)&1)ok=0;if(ok){basis.push_back(rep[j]);if(extend(j+1))return true;basis.pop_back();}}return false;};ck(extend(0));
 int ch=32767;for(int o=0;o<8;o++){cout<<idx<<" "<<o<<" ";for(int j=0;j<16;j++)cout<<C[j]<<(j==15?"":" ");cout<<" ;";
 for(int i=0;i<8;i++)if(i!=o)for(int j=i+1;j<8;j++)if(j!=o){int m=(j==7?basis[i]:(ch^basis[i]^basis[j]));auto const& w=word[X[m]];cout<<" "<<w.size();for(int k:w)cout<<","<<k;}
 cout<<"\n";}
 }
}
