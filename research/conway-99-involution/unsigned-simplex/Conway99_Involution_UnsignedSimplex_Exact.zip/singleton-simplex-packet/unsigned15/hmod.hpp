struct Rmod{
 int p,rank=-1,D,detK,dfa,dim;
 int h[4][4],index[4],iv[4][4];const CandH*ms[4];vector<bool>qr;
 int mo(long long x)const{int z=x%p;return z<0?z+p:z;}
 int inv(int y)const{int s=1;for(int e=p-2;e;e/=2){if(e%2)s=s*y%p;y=y*y%p;}return s;}
 void set(int pp,int mask,int dimA,long long den,unsigned long dfa0,long long F[4][4],const CandH*hh[4]){p=pp;D=mo(den);dfa=dfa0%p;if(!D||!dfa)return;int n=0;for(int i=0;i<4;i++){ms[i]=hh[i];if(mask>>i&1)index[n++]=i;for(int j=0;j<4;j++)h[i][j]=mo(F[i][j]);}
 int a[4][8]={};for(int i=0;i<n;i++){for(int j=0;j<n;j++)a[i][j]=h[index[i]][index[j]];a[i][i+n]=1;}
 int d=1;for(int i=0;i<n;i++){int k=i;while(k<n&&!a[k][i])k++;if(k==n)return;if(k!=i){for(int j=0;j<2*n;j++)swap(a[k][j],a[i][j]);d=mo(-d);}
 int z=a[i][i];d=d*z%p;int u=inv(z);for(int j=0;j<2*n;j++)a[i][j]=a[i][j]*u%p;
 for(int k=0;k<n;k++)if(k!=i){int c=a[k][i];for(int j=0;j<2*n;j++)a[k][j]=mo(a[k][j]-c*a[i][j]);}}
 for(int i=0;i<n;i++)for(int j=0;j<n;j++)iv[i][j]=a[i][j+n];detK=d;for(int i=0;i<=n;i++)detK=detK*inv(D)%p;detK=detK*dfa%p;dim=n+dimA;rank=n;
 qr.resize(p,false);for(int z=0;z<p;z++)qr[z*z%p]=true;
 }
 bool ok(long long c[4],long long nu,const array<int,4>&v)const{if(rank<0)return true;int t[4],w[4];for(int j=0;j<4;j++)t[j]=mo(c[j]-2LL*D*v[j]);for(int i=0;i<rank;i++){int s=0;for(int j=0;j<rank;j++)s+=iv[i][j]*t[index[j]];w[i]=s%p;}
 for(int j=0;j<4;j++){int s=0;for(int i=0;i<rank;i++)s+=h[j][index[i]]*w[i];if(s%p!=t[j])return false;}
 int x=mo(nu);for(int i=0;i<rank;i++)x=mo(x-w[i]*t[index[i]]);if(dim==15&&x)return false;if(dim==14&&!qr[x*detK%p])return false;return true;}
};
