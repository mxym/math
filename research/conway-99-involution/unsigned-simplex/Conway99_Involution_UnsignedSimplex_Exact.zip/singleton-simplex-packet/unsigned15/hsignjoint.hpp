struct LiftCore{
function<bool()> checkfull;int fullmask;
 const Shell& sh; const Form&F; const RForm&sg;int *hkey;int (*ua)[16];const vector<CandH>&C;
 const SC* sel[4];int ls[4][4]{};unsigned long long Adj[47];
 long long nr[4][4]{};unsigned long long gd;int target; // initially only require rank modulo 7 and rational PSD + determinant
 LiftCore(const Shell&sh0,const Form&F0,const RForm&f,int h[4],int m[16][16],const vector<CandH>&c,long long sd):sh(sh0),F(F0),sg(f),hkey(h),ua(m),C(c),gd(sd){}
 bool graph(int k){int n=39+2*(k+1);copy(sh.G,sh.G+39,Adj);fill(Adj+39,Adj+n,0);
 for(int i=0;i<=k;i++){int b=39+2*i;unsigned long long v[]={sel[i]->mask,flip(sel[i]->mask)};for(int z=0;z<2;z++){Adj[b+z]|=v[z];for(U s=v[z];s;s&=s-1)Adj[low(s)]|=bit(b+z);}
 for(int j=0;j<i;j++)for(int t=0;t<2;t++)for(int z=0;z<2;z++)if(ua[12+i][12+j]==2||(ua[12+i][12+j]==1&&((z==t)==(ls[i][j]>0)))){int x=b+z,y=39+2*j+t;Adj[x]|=bit(y);Adj[y]|=bit(x);}}
 for(int i=0;i<n;i++)for(int j=0;j<i;j++)if(pop(Adj[i]&Adj[j])+int((Adj[i]>>j)&1)>2)return false;return true;
 }
 bool rank7(int k){int n=13+k,r=0;int a[16][16];for(int i=0;i<12;i++)for(int j=0;j<12;j++)a[i][j]=m7(F.A[i][j]);
 for(int i=0;i<=k;i++){for(int j=0;j<12;j++)a[12+i][j]=a[j][12+i]=m7(sel[i]->f[j]);a[12+i][12+i]=3;
 for(int j=0;j<i;j++){int d=dotz(i,j);a[12+i][12+j]=a[12+j][12+i]=m7(-4*ls[i][j]-d);}}
 int inv[]={0,1,4,5,2,3,6};for(int j=0;j<n;j++){int k=r;while(k<n&&!a[k][j])k++;if(k==n)continue;swap(a[r],a[k]);for(int t=r+1;t<n;t++){int b=inv[a[r][j]]*a[t][j]%7;if(b)for(int v=j;v<n;v++)a[t][v]=m7(a[t][v]-b*a[r][v]);}if(++r>13)return false;}return true;
 }
 int dotz(int i,int j)const{int q=0;for(int t=0;t<7;t++)q+=sh.r[C[hkey[i]].d][t]*sh.r[C[hkey[j]].d][t];return q;}
 bool pos(int k){for(int j=0;j<=k;j++){long long d=sg.det*(j==k?10:-4*ls[k][j]-dotz(k,j));for(int t=0;t<12;t++)d-=sel[k]->f[t]*sel[j]->pf[t];nr[k][j]=nr[j][k]=d;}
 for(int i=0;i<k;i++)if((i128)nr[i][i]*nr[k][k]<(i128)nr[i][k]*nr[i][k])return false;
 auto d3=[&](array<int,3>a,array<int,3>b){i128 d=0;for(int i=0;i<3;i++){int j=(i+1)%3,l=(i+2)%3;d+=(i128)nr[a[0]][b[i]]*((i128)nr[a[1]][b[j]]*nr[a[2]][b[l]]-(i128)nr[a[1]][b[l]]*nr[a[2]][b[j]]);}return d;};
 for(int j=1;j<k;j++)for(int i=0;i<j;i++)if(d3({i,j,k},{i,j,k})<0)return false;
 if(k==3){int m=0;for(int i=0;i<4;i++)if(nr[i][i]>0)m=1<<i;for(int i=0;i<4;i++)for(int j=0;j<i;j++)if((i128)nr[i][i]*nr[j][j]>(i128)nr[i][j]*nr[i][j])m=(1<<i)|(1<<j);for(int i=0;i<4;i++){int z=0;array<int,3>a;for(int j=0;j<4;j++)if(i!=j)a[z++]=j;if(d3(a,a)>0)m=15^(1<<i);}fullmask=m;Big det=0;for(int j=0;j<4;j++){array<int,3>b;int n=0;for(int v=0;v<4;v++)if(v!=j)b[n++]=v;det+=(j%2?-1:1)*(long)nr[0][j]*cv128(d3({1,2,3},b));}
 if(det<0)return false;if(det>0){fullmask=15;Big D=(long)sg.det;Big num=det*(unsigned long)gd,den=49*D*D*D*D;if(!mpz_divisible_p(num.get_mpz_t(),den.get_mpz_t()))return false;num/=den;if(!mpz_perfect_square_p(num.get_mpz_t()))return false;}}
 return true;}
 bool dfs(int k){if(k==4)return !checkfull||checkfull();for(auto&s:C[hkey[k]].opt){sel[k]=&s;int signs=0;for(int i=0;i<k;i++)signs+=(ua[12+k][12+i]==1);for(int mask=0;mask<1<<signs;mask++){
 int bit=0;for(int j=0;j<k;j++)ls[k][j]=ls[j][k]=ua[12+k][12+j]==1?(2*((mask>>(bit++))&1)-1):0;
 if(pos(k)&&graph(k)&&(k<2||rank7(k))&&dfs(k+1))return true;}}return false;}
};
