"""Independent all-subcode-chain census; exact standard-support and dual checks. No optimization libraries."""
from itertools import product
from pathlib import Path
from collections import Counter
def ck(x):
 if not x:raise ArithmeticError('census mismatch')
def GL(d):
 G=[(0,)]
 for _ in range(d):
  G=[a+tuple(x^j for j in a)for a in G for x in range(1,1<<d)if x not in a]
 return G
def transform(c,f):
 b=[0]*len(c)
 for i,j in enumerate(f):b[j]=c[i]
 return tuple(b)
def allnodes():
 codes=[(15,)];orbits={}
 for d in range(4):
  seen={};new=[];grp=GL(d+1)
  for c in codes:
   n=len(c)
   for t in product(*(range(k+1)for k in c)):
    if sum(t)%4 or any(sum(t[i]for i in range(n)if i>>j&1)%2 for j in range(d)):continue
    # Does the new word just repeat a linear combination of the old rows?
    if all(k==0 or k==a for k,a in zip(t,c)) and any(all(k==(((i&x).bit_count()%2)*a)for i,(k,a) in enumerate(zip(t,c)))for x in range(n)):continue
    f=tuple(k-a for k,a in zip(c,t))+t
    if f in seen:continue
    idx=len(new);new.append(f)
    for g in grp:seen[transform(f,g)]=idx
  codes=new;orbits=seen;print('extension flags dimension',d+1,'orbits',len(new),'labelled column multiplicities',len(seen))
 return orbits
def load():
 ids=allnodes();L=Path('code15.tsv').read_text().splitlines();ck(len(L)==160);seen=set();stats=Counter();certs={}
 for l in Path('dualcert.tsv').read_text().splitlines():
  g,o,t,*vals=map(int,l.split());ck(len(vals)==36 and (g,o)not in certs);certs[g,o]=(t,vals)
 def span(bs):
  s=[0]
  for b in bs:s+=[x^b for x in s]
  return s
 for j,l in enumerate(L):
  A,S=l.split(';');g,o,*c=map(int,A.split());ck((g,o)==divmod(j,8));key=ids[tuple(c)]
  if o==0:ck(key not in seen);seen.add(key)
  col=[i for i,n in enumerate(c)for _ in range(n)]
  C=span([sum(1<<i for i,x in enumerate(col)if x>>b&1)for b in range(4)]);ck(len(set(C))==16)
  V=[set(map(int,h.split(',')[1:]))for h in S.split()];ck(len(V)==21)
  # Exact verification of the word sets in the C++-specified quotient classes;
  # missing classes are included in C++ orthogonal-frame check.
  for T in V:
   if not T:continue
   m=next(iter(T));ck(T=={m^a for a in C if (m^a).bit_count()==5});ck(all(not (m&a).bit_count()%2 for a in C))
  M=[[m for m in T if all((a&m)!=a for a in C if a.bit_count()==4)]for T in V]
  if not all(M) or any(sum(all(m>>i&1 for m in s)for s in M)>7 or sum(any(m>>i&1 for m in s)for s in M)<7 for i in range(15)):
   stats['empty/marginal']+=1;continue
  if (g,o) in certs:
   val,n=certs.pop((g,o));ck(val==sum(n[:21])*2+sum(n[21:])*14 and val>0)
   ck(all(n[j]+sum(a for i,a in enumerate(n[21:])if m>>i&1)<=0 for j,S in enumerate(M)for m in S));stats['dual']+=1;continue
  ck(g in (17,18,19));stats['retained']+=1
 ck(set(ids.values())==seen and not certs and stats=={'empty/marginal':125,'dual':11,'retained':24})
 print('standard-ambient necessary census',dict(stats),'three remaining code types',17,18,19)
if __name__=='__main__':load()
