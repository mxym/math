#include "srank.hpp"
struct HoldSigned{
 LiftCore &L;RankS seven;U G[47],bad[47]{},soft[47]{};Rmod rr[3];
 vector<array<int,4>>signs[81];
 HoldSigned(LiftCore&l):L(l),seven(l){
 copy(L.Adj,L.Adj+47,G);for(int i=0;i<47;i++)for(int j=0;j<i;j++){int a=2-int((G[i]>>j)&1)-pop(G[i]&G[j]);if(a<0)abort();if(!a){bad[i]|=bit(j);bad[j]|=bit(i);}if(a==1){soft[i]|=bit(j);soft[j]|=bit(i);}}
 int prs[]={97,257,1031};const CandH* hs[4];for(int i=0;i<4;i++)hs[i]=&L.C[L.hkey[i]];for(int i=0;i<3;i++)rr[i].set(prs[i],L.fullmask,11,L.sg.det,(L.gd%prs[i])*1024%prs[i],L.nr,hs);
 for(int ix=0;ix<81;ix++){array<int,4>v;int n=ix,b=0;for(int i=0;i<4;i++,n/=3){v[i]=n%3;b+=(v[i]==1);}for(int j=0;j<(1<<b);j++){array<int,4>s;int k=0;for(int i=0;i<4;i++)s[i]=v[i]==1?(2*((j>>(k++))&1)-1):0;signs[ix].push_back(s);}}}
 bool caps(U a){U b=flip(a),both=a&b;if(pop(both)>2)return false;
 for(U u=a;u;u&=u-1){int j=low(u);if((bad[j]&a)||((both>>j&1)&&(soft[j]&both)))return false;}
 for(int j=0;j<47;j++)if(pop(G[j]&a)+int((a>>j)&1)>2)return false;return true;}
 bool next(const CandH &m,array<int,4>const&v){
 int ix=0;for(int j=3;j>=0;j--)ix=3*ix+v[j];int d0[4];for(int j=0;j<4;j++){d0[j]=0;for(int t=0;t<7;t++)d0[j]+=L.sh.r[m.d][t]*L.sh.r[L.C[L.hkey[j]].d][t];}
 for(auto &c:m.opt){long long fc[4],nu=10*L.sg.det;for(int t=0;t<12;t++)nu-=c.f[t]*c.pf[t];
 for(int j=0;j<4;j++){fc[j]=-L.sg.det*d0[j];for(int t=0;t<12;t++)fc[j]-=c.f[t]*L.sel[j]->pf[t];}
 for(auto &s:signs[ix]){array<int,4>b;U a=c.mask;for(int j=0;j<4;j++){b[j]=s[j]*2;int k=39+2*j;if(v[j]==2)a|=3ULL<<k;else if(v[j])a|=1ULL<<(k+int(s[j]<0));}
 bool ok=true;for(auto&f:rr)if(!f.ok(fc,nu,b)){ok=false;break;}if(ok&&seven.live(c,d0,s)&&caps(a))return true;}
 }return false;}
};
