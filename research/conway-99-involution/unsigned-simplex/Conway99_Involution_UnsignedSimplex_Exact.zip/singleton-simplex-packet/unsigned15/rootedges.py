# Classify L0 root frequency across eight possible omitted axes. All root
# vectors counted up to sign, classified by discriminant residue in K8.
from code7e8 import *
from pathlib import Path
def cov(C,root,model):
 if model==15:phi=lambda x:pc(x)%4;dot=lambda x,y:pc(x&y)%2;ch=32767
 else:phi=qq;dot=bb;ch=127
 X={};S=[];U=basis(C)
 for x in range(32768):
  if any(dot(x,t)for t in U):continue
  t=min(x^c for c in C)
  if t not in X:S.append(t)
  X[x]=t
 S=list(dict.fromkeys(S));assert len(S)==128
 def rec(s,j):
  if len(s)==7:return s
  for k in range(j,128):
   x=S[k]
   if phi(x)==1 and all(not dot(x,t)for t in s):
    a=rec(s+[x],k+1)
    if a:return a
 st=rec([],0);assert st
 m={X[(ch^st[i]if j==7 else st[i]^st[j])]:(i,j)for i,j in combinations(range(8),2)};assert len(m)==28
 cnt=Counter(m[X[x]] for x in root if x in X)
 return [sum(v for e,v in cnt.items() if j in e)for j in range(8)], len(cnt),sum(cnt.values())
L=Path('code15.tsv').read_text().splitlines()
for id in [17,18,19]:
 c=[int(x)for x in L[8*id].split(';')[0].split()[2:]];col=[j for j,k in enumerate(c)for _ in range(k)]
 C=[sum(1<<j for j,z in enumerate(col)if pc(z&t)%2)for t in range(16)]
 roots=[(1<<i)|(1<<j)for i,j in combinations(range(15),2)for s in range(2)]
 print('standard',id,cov(C,roots,15),flush=True)
for id,(_,_,C) in enumerate(classify()):
 roots=[(1<<i)|(1<<j)for i,j in combinations(range(7),2)for s in range(2)]+[b<<7 for b in range(256)if Q(b)]
 print('mixed',id,cov(C,roots,8),flush=True)
