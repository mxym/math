from code7e8 import *
from functools import lru_cache
from itertools import product
def e8():
 adj=[(0,2),(2,3),(1,3),(3,4),(4,5),(5,6),(6,7)]
 def q(x):return (pc(x)+sum((x>>i&1)*(x>>j&1)for i,j in adj))%2
 def ip(x,y):return sum(2*a*b for a,b in zip(x,y))-sum(x[i]*y[j]+x[j]*y[i] for i,j in adj)
 def bil(x,y):return q(x)^q(y)^q(x^y)
 roots0=[tuple(int(r==i)for r in range(8))for i in range(8)];S=set(roots0);K=roots0[:]
 while K:
  x=K.pop()
  for i,y in enumerate(roots0):
   z=list(x);z[i]-=ip(x,y);z=tuple(z)
   if z not in S:S.add(z);K.append(z)
 assert len(S)==240
 B=[]
 for _ in range(4):
  U=sp(B)
  def good(x):return x not in U and all(not bil(x,y) for y in B)and not q(x)
  x=next(x for x in range(1,256)if good(x));y=next(y for y in range(1,256)if good(y) and bil(x,y));B += [x,y]
 M={0:0}
 for r,x in enumerate(B):M.update({i|(1<<r):z^x for i,z in list(M.items())})
 assert all(Q(i)==q(v) for i,v in M.items())
 kv={sum((x%2)<<i for i,x in enumerate(r)):r for r in sorted(S)}
 R={i:kv[M[i]] for i in range(256)if Q(i)};return ip,R
def maxclq(G):
 n=len(G);best=[]
 def dfs(st,m):
  nonlocal best
  if len(st)>len(best):best=st
  while m and len(st)+pc(m)>len(best):
   p=(m&-m).bit_length()-1;m^=1<<p;dfs(st+[p],m&G[p])
 dfs([], (1<<n)-1);return best
if __name__=='__main__':
 ip,K=e8();C=classify();zero=(0,)*8
 for id,(D,R,c) in enumerate(C):
  H=[(tuple(2*int(i==j)for i in range(7)),zero)for j in range(7)]
  for h in c:
   a=h&127;b=h>>7;P=[i for i in range(7) if a>>i&1]
   if len(P)==2 and Q(b) or len(P)==4 and not b:
    for signs in product((-1,1),repeat=len(P)):
     if not b and signs[0]<0:continue
     z=[0]*7
     for j,s in zip(P,signs):z[j]=s
     H.append((tuple(z),K[b] if b else zero))
  def inn(u,v):return sum(x*y for x,y in zip(u[0],v[0]))+ip(u[1],v[1])
  need=[sum(int(j!=i and inn(u,v)==0)<<j for j,v in enumerate(H))for i,u in enumerate(H)]
  best=maxclq(need);print(id,len(H),'perpendicular',len(best),flush=True)
