#include "hmod.hpp"
struct Extend {
 function<bool(const CandH&,array<int,4> const&)> lift;
 Rmod mod[3];long long den;const CandH*hh[4];int slack[16][16],mx[16];unsigned forbidden[16];int (*A)[16];int*par;int edg[30];
 vector<CandH>& C;vector<vector<int>>&groups;vector<array<int,4>>pat[9];
 Extend(int a[16][16],int*b,vector<CandH>&c,vector<vector<int>>&gr,int *ed,int mask,int dim,long long D,mpz_class vol,long long h[4][4],const CandH*rows[4]):A(a),par(b),C(c),groups(gr){
 den=D;for(int i=0;i<4;i++)hh[i]=rows[i];int primes[]={97,257,1031};for(int i=0;i<3;i++)mod[i].set(primes[i],mask,dim,D,mpz_fdiv_ui(vol.get_mpz_t(),primes[i]),h,rows);for(int i=0;i<30;i++)edg[i]=ed[i]<<1;
 for(int i=0;i<16;i++){int d=0;for(int j=0;j<16;j++)d+=A[i][j]==2;mx[i]=2-d;forbidden[i]=0;
 for(int j=0;j<16;j++)if(i!=j){int t=4-pop(par[i]&par[j])-A[i][j];for(int k=0;k<16;k++)t-=A[i][k]*A[j][k];if(t<0)abort();slack[i][j]=t;if(!t)forbidden[i]|=1u<<j;}}
 for(int i=0;i<81;i++){array<int,4> v;int s=0,k=i,ds=0;for(int j=0;j<4;j++,k/=3){v[j]=k%3;s+=(j<2?1:-1)*v[j];ds+=v[j]==2;}if(ds<=1)pat[4+s].push_back(v);}
 }
 bool one(int k,int g){int vertex=edg[k];for(auto h:groups[k]){auto&m=C[h];int occ=m.a|m.b,dbl=m.a&m.b,ft[4],rem[16];bool good=true;
 for(int i=0;i<12;i++)if((occ>>i&1)&&((forbidden[i]&occ)||((dbl>>i&1)&&mx[i]<2))){good=false;break;}if(!good)continue;
 int wA=pop(m.a&g)+pop(m.b&g);for(int i=0;i<16;i++){int t=4-pop(vertex&par[i])-(i<12?((m.a>>i&1)+(m.b>>i&1)):0);
 for(int j=0;j<12;j++)t-=A[i][j]*((m.a>>j&1)+(m.b>>j&1));if(t<0){good=false;break;}rem[i]=t;}if(!good)continue;
 long long fc[4];for(int j=0;j<4;j++){ll t=0;for(int i=0;i<12;i++)t+=hh[j]->pf[i]*m.f[i];fc[j]=den*(1-pop(par[12+j]&vertex))-t;}for(auto const&v:pat[6-wA]){bool ok=true;unsigned all=occ,tw=dbl;for(int j=0;j<4;j++)if(v[j]){all|=1u<<(12+j);if(v[j]==2)tw|=1u<<(12+j);}
 if(pop(tw)>1)continue;for(int j=0;j<4;j++)if(v[j]>mx[j+12]||v[j]&&((forbidden[j+12]&all)||v[j]>rem[12+j])){ok=false;break;}if(!ok)continue;
 for(int i=0;i<16&&ok;i++){int t=rem[i]-(i>=12?v[i-12]:0);for(int j=0;j<4;j++)t-=A[i][12+j]*v[j];if(t<0)ok=false;
 if((all>>i)&1)for(int j=0;j<i&&ok;j++)if(all>>j&1)if(slack[i][j]<(1+(tw>>i&1))*(1+(tw>>j&1)))ok=false;}
 if(ok){for(const auto&f:mod)if(!f.ok(fc,m.nu,v)){ok=false;break;}if(ok&&(!lift||lift(m,v)))return true;}
 }
 }return false;}
 bool all(int g,int h0,int h1,int h2,int h3){vector<int>labs;for(int k=0;k<30;k++)if(k!=h0&&k!=h1&&k!=h2&&k!=h3)labs.push_back(k);
 sort(labs.begin(),labs.end(),[&](int i,int j){return groups[i].size()<groups[j].size();});for(int k:labs)if(!one(k,g))return false;return true;}
};
