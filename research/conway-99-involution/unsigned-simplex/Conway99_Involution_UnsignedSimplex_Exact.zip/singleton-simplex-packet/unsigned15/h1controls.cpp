/* Compare published arithmetic and physical A+2 checks with independent
   literal Gram data and fully rebuilt physical induced adjacency tables. */
#define main enumerator_main
#include "hsym-frozen.cpp"
#undef main
void ck(bool x){if(!x)throw runtime_error("control mismatch");}
int main(){
 int good=0,den_skips=0,ar=0,phys=0,pass=0;
 const CandH*none[4]={};int primes[3]={97,257,1031};
 // Each sample is a realizable Euclidean Gram; star block is the standard
 // (15-codim)-form. Multiplying all residual products by D mimics the exact
 // Schur scale without altering the join.
 for(int p:primes)for(int k=0;k<=4;k++)for(int codim=0;codim<=1;codim++)
 for(int d:{1,8,119,p})for(int sign:{-1,1}){
  int h[4][5]{},y[5]{},n=k+codim;for(int a=0;a<4;a++)for(int b=0;b<k;b++)h[a][b]=a<k?(int(a==b)*(b+1)):((a+b)%3-1);for(int b=0;b<n;b++)y[b]=(b&1?sign:-sign)*(b+2);
  ll H[4][4]{},c[4]{},nu=0;for(int i=0;i<4;i++)for(int j=0;j<4;j++)for(int b=0;b<n;b++)H[i][j]+=d*h[i][b]*h[j][b];
  array<int,4>l={-1,0,1,2};for(int i=0;i<4;i++){for(int b=0;b<n;b++)c[i]+=d*h[i][b]*y[b];c[i]+=2*d*l[i];}for(int b=0;b<n;b++)nu+=d*y[b]*y[b];
  Rmod F;F.set(p,(1<<k)-1,15-n,d,1,H,none);ck(F.ok(c,nu,l));good++;if(F.rank<0){ck(d%p==0);den_skips++;continue;}
  if(k<4){c[k]+=1;ck(!F.ok(c,nu,l));c[k]-=1;ar++;}
  if(!codim){ck(!F.ok(c,nu+1,l));ar++;}
 }
 ifstream layouts("../dualplanes/unary5-packet/layouts.tsv"),fin("h1fixtures.tsv");vector<array<int,25>> reps;array<int,25> line;while(layouts>>line[0]){for(int i=1;i<25;i++)ck(bool(layouts>>line[i]));reps.push_back(line);}
 int id,g;while(fin>>id>>g){int V[4][3],E[4][4]{},L[4][4]{};for(auto&u:V)for(int&a:u)ck(bool(fin>>a));for(int i=0;i<4;i++)for(int j=0;j<i;j++){ck(bool(fin>>E[i][j]>>L[i][j]));E[j][i]=E[i][j];L[j][i]=L[i][j];}
 auto& A=reps.at(id);Shell s(&A[1],&A[13]);s.gen();Form F(&A[1],&A[13]);RForm sg(F,&A[1],&A[13],1);
 int ix[]={0,1,2,3},ua[16][16]{};vector<CandH>C(4);SC matches[4];LiftCore cfg(s,F,sg,ix,ua,C,1);cfg.fullmask=0;for(int i=0;i<4;i++){C[i].d=V[i][0];bool found=0;for(auto&a:s.domain[C[i].d])if(a.a==V[i][1]&&a.b==V[i][2]){found=1;matches[i].mask=a.mask;
 for(int j=0;j<12;j++)matches[i].f[j]=-4*(int(a.a>>j&1)-int(a.b>>j&1))-s.z[C[i].d][j];}ck(found);cfg.sel[i]=&matches[i];for(int j=0;j<4;j++){ua[12+i][12+j]=E[i][j];cfg.ls[i][j]=L[i][j];cfg.nr[i][j]=0;}}
 ck(cfg.graph(3));HoldSigned cap(cfg);for(int d=0;d<30;d++)if(none_of(V,V+4,[&](auto&a){return a[0]==d;}))for(int j=0;j<min(4,(int)s.domain[d].size());j++)for(int t=0;t<3;t++){U m=s.domain[d][j].mask;for(int k=0;k<4;k++)if((k+d+j+t)%3==0)m|=bit(39+2*k+t%2);
 U t0=flip(m),G[49];copy(cfg.Adj,cfg.Adj+47,G);G[47]=m;G[48]=t0;for(int i=0;i<47;i++){if(m&bit(i))G[i]|=bit(47);if(t0&bit(i))G[i]|=bit(48);}
 bool ok=1;for(int i=0;i<49&&ok;i++)for(int j=0;j<i;j++)if(pop(G[i]&G[j])+int(G[i]>>j&1)>2){ok=0;break;}ck(ok==cap.caps(m));phys++;pass+=ok;}}
 ck(good&&ar&&den_skips&&phys&&pass&&pass<phys);cout<<"valid Schur controls "<<good<<"; skipped primes "<<den_skips<<"; negative synthetic tests "<<ar<<"; candidate compact/literal 49-vertex cap tests "<<phys<<", positive "<<pass<<"\n";
}
