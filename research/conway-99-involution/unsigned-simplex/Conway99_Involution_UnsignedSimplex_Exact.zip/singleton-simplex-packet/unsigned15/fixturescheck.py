"""Independent literal 47-point/16-orbit controls. Each is a passed necessary
partial configuration, explicitly NOT a completion of the Conway 99 graph."""
from pathlib import Path
from itertools import combinations
from fractions import Fraction as Fr
from math import isqrt
from collections import Counter
def ck(b):
 if not b:raise ValueError('failed local control')
def pd(A):
 n=len(A);ix=list(range(n));B=[[Fr(x)for x in t]for t in A];R=[];det=1
 for k in range(n):
  j=next((v for v in range(k,n)if B[v][v]),None)
  if j is None:ck(all(not B[v][u]for v in range(k,n)for u in range(k,n)));break
  ck(B[j][j]>0);B[j],B[k]=B[k],B[j];ix[k],ix[j]=ix[j],ix[k]
  for t in B:t[j],t[k]=t[k],t[j]
  r=B[k][k];det*=r;R.append(ix[k])
  for i in range(k+1,n):
   s=B[i][k]/r
   for j in range(k+1,n):B[i][j]-=s*B[k][j]
 ck(det.denominator==1);return len(R),int(det)
def rank(A,p):
 a=[row[:]for row in A];r=0
 for j in range(len(a[0])):
  i=next((t for t in range(r,len(a))if a[t][j]%p),None)
  if i is None:continue
  a[i],a[r]=a[r],a[i];k=pow(a[r][j]%p,-1,p)
  for i in range(r+1,len(a)):
   v=a[i][j]*k%p;a[i]=[(s-v*t)%p for s,t in zip(a[i],a[r])]
  r+=1
 return r
L=Path('../dualplanes/unary5-packet/layouts.tsv').read_text().splitlines();hist=Counter();RR=Counter();Ds=[(i,j,s)for i,j in combinations(range(7),2)for s in (0,1)]
for rec in Path('h1fixtures.tsv').read_text().splitlines():
 v=list(map(int,rec.split()));id,g=v[:2];a=[tuple(v[j:j+3])for j in range(2,14,3)];local=v[14:];ck(len(local)==12)
 r,*v=map(int,L[id].split());P,N=v[:12],v[12:]
 H=[set()for _ in range(47)]
 def edge(i,j):
  ck(i!=j);H[i].add(j);H[j].add(i)
 def ax(i,s):return 1+2*i+s
 def out(i,s):return 15+2*i+s
 for i in range(7):
  for s in (0,1):edge(0,ax(i,s))
  edge(ax(i,0),ax(i,1))
 labels=list(Ds[:12])+[Ds[12+d]for d,_,_ in a]
 for h,(i,j,n)in enumerate(labels):
  for s in (0,1):edge(out(h,s),ax(i,s));edge(out(h,s),ax(j,s^n))
 for i in range(12):
  for s in (0,1):edge(out(i,s),out(P[i],s));edge(out(i,s),out(N[i],s^1))
 for k,(d,c,e)in enumerate(a):
  for i in range(12):
   for s in (0,1):
    if c>>i&1:edge(out(12+k,s),out(i,s))
    if e>>i&1:edge(out(12+k,s),out(i,s^1))
 u=iter(local)
 for i in range(4):
  for j in range(i):
   w,l=next(u),next(u)
   for p in (0,1):
    for q in (0,1):
     if w==2 or w==1 and (p==q)==(l>0):edge(out(12+i,p),out(12+j,q))
 for i,S in enumerate(H):
  for j in range(i):ck(len(S&H[j])<=2-int(j in S))
 F=[[0]*16 for _ in range(16)];G=[[0]*16 for _ in range(16)];T=[[0]*16 for _ in range(16)]
 def z(l):
  i,j,s=l;v=[0]*7;v[i]=1;v[j]=1-2*s;return v
 Z=list(map(z,labels));b=[[abs(x)for x in v]for v in Z];q=[1 if g>>i&1 else -1 for i in range(12)]+[2,2,-2,-2];ck(sum(q)==0 and sum(x*x for x in q)==28);ck(all(sum(row[j]*x for row,x in zip(b,q))==0 for j in range(7)))
 for i in range(16):
  for j in range(16):
   u=int(out(j,0) in H[out(i,0)]);v=int(out(j,1) in H[out(i,0)]);T[i][j]=u+v;F[i][j]=12*(i==j)-4*(u-v)-sum(a*b for a,b in zip(Z[i],Z[j]));G[i][j]=6*(i==j)-2*T[i][j]-sum(a*b for a,b in zip(b[i],b[j]))+1
  ck(sum(t*v for t,v in zip(T[i],q))==-4*q[i])
 for A,unit in [(G,112),(F,224)]:
  n,D=pd(A);ck(n<=15)
  if n==15:ck(D%(unit*unit)==0 and isqrt(D)**2==D)
  if A is F:ck(rank(F,7)<=13)
  RR['unsigned' if A is G else 'signed',n]+=1
 hist[id]+=1
print('literal independently verified partial star/quartet realizations',dict(hist),'rational PSD ranks',dict(RR))
