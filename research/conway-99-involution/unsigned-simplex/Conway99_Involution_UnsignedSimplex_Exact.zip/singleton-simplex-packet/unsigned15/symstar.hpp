using Perm12=array<signed char,12>;
vector<Perm12> stabs(const int*P,const int*N){
 vector<Perm12> G;Perm12 f;f.fill(-1);
 function<void(Perm12)> dfs=[&](Perm12 a){
 int v=0,seen=0;for(int i=0;i<12;i++)if(a[i]>=0)seen|=1<<a[i];while(v<12&&a[v]>=0)v++;
 if(v==12){G.push_back(a);return;}
 for(int w=0;w<12;w++)if(!(seen>>w&1)){auto b=a;int occ=seen;vector<pair<int,int>>Q={{v,w}};bool ok=1;while(ok&&!Q.empty()){
 auto [i,j]=Q.back();Q.pop_back();if(b[i]>=0){ok=b[i]==j;continue;}if(occ>>j&1){ok=false;break;}occ|=1<<j;b[i]=j;
 Q.push_back({i^1,j^1});Q.push_back({P[i],P[j]});Q.push_back({N[i],N[j]});}if(ok)dfs(b);}
 };dfs(f);if(G.empty())abort();return G;}
int imask(int v,Perm12 const&f){int b=0;while(v){int k=__builtin_ctz(v);b|=1<<f[k];v&=v-1;}return b;}
