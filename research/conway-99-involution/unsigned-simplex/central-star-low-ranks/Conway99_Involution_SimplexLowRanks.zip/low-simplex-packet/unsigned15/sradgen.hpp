struct RAtt{int d;U mask;unsigned key;unsigned short a,b;int h[4]{},pi[11]{},pr[11]{},n;};
struct Rad{
 const int*cl;const int*ax;int r,dc,d0;int freeidx[4]{},nfree=0;vector<RAtt> att;unordered_map<unsigned,vector<int>>data[30];vector<array<int,4>>normals;vector<vector<int>>hits;
 long long tested=0,retained=0;int hard=0;bool any=false;
 Rad(Shell&s,Form&F,RForm&sg,RForm&H,const int*to,const int*xx):cl(to),ax(xx){r=F.rank;d0=11-r;if(r<7||r>8)abort();
  for(int i=0;i<11;i++)if(find(F.pi,F.pi+r,i)==F.pi+r)freeidx[nfree++]=i;if(nfree!=d0)abort();
  int n=1;for(int i=0;i<d0;i++)n*=7;for(int j=1;j<n;j++){int a=j;array<int,4>c{};int k=0;for(int i=0;i<d0;i++){c[i]=a%7;a/=7;if(!k&&c[i])k=c[i];}if(k==1)normals.push_back(c);}
  for(int d=0;d<30;d++)for(auto&w:s.domain[d]){unsigned key=0;int f[12],u[12];ll pf[12],n;bool bad=0;for(int t=0;t<12;t++){int a=w.a>>t&1,b=w.b>>t&1;if(a&&b&&s.P[t]==s.N[t])bad=1;f[t]=-4*(a-b)-s.z[d][t];u[t]=1-abs(s.z[d][t])-2*(a+b);key|=(a+b)<<(2*t);}if(bad||!sg.project(f,pf,n,10)||!H.project(u,pf,n,5))continue;
   RAtt a;a.d=d;a.key=key;a.mask=w.mask;a.a=w.a;a.b=w.b;
   for(int i=0;i<r;i++){a.pi[i]=m7(f[F.pi[i]]);int z=0;for(int j=0;j<r;j++)z+=F.C[i][j]*f[F.pi[j]];a.pr[i]=m7(z);}
   for(int j=0;j<d0;j++){auto k=freeidx[j];int z=f[k];for(int i=0;i<r;i++)z-=F.A[k][F.pi[i]]*a.pr[i];a.h[j]=m7(z);}
   int z=3;for(int i=0;i<r;i++)z-=a.pr[i]*a.pi[i];a.n=m7(z);data[d][key].push_back(att.size());att.push_back(a);}
  for(auto&a:att){hits.emplace_back();for(int j=0;j<normals.size();j++){int z=0;for(int i=0;i<d0;i++)z+=normals[j][i]*a.h[i];if(z%7==0)hits.back().push_back(j);}}
 }
};
#include "slowext.hpp"
struct RadTest:public Rad{Low low;int depth=5;
 RadTest(Shell&s,Form&F,RForm&S,RForm&H,const int*to,const int*xx):Rad(s,F,S,H,to,xx),low(*this,s,F){}
 bool search(int chosen[12]){tested++;vector<vector<SX>>dom(30);
 for(int k=0;k<30;k++){int y=12+k;for(int w=0;w<192;w++){unsigned key=0;bool ok=1;for(int i=0;i<12;i++){int t=1-pop(ax[i]&ax[y])-val(LWords[cl[i]][chosen[i]],LWords[cl[y]][w]);if(t<0||t>4||(t&1)){ok=0;break;}key|=(t/2)<<(2*i);}
 if(!ok)continue;auto it=data[k].find(key);if(it!=data[k].end())for(auto a:it->second)dom[k].push_back({k,w,a});}if(dom[k].empty())return false;}
 bool b=low.run(dom,depth);if(b)hard++;return b;}
};
