"""Independent Hamming-coset and oriented K8 labeling check.
No quota dependence, no solver, and no imported chart enumeration."""
from pathlib import Path
from itertools import combinations, permutations
def ck(x):
 if not x:raise ArithmeticError('label atlas mismatch')
def w(i):return i.bit_count()
C=[sum(1<<i for i in range(15)if w(a&(i+1))%2) for a in range(16)]
X={i:min(i^c for c in C)for i in range(1<<15)if all(w(i&c)%2==0 for c in C)}
U=sorted(set(X.values()));ck(len(U)==128)
def dot(a,b):return w(a&b)%2
def frame(prefix,lo):
 if len(prefix)==7:return prefix
 for k in range(lo,128):
  m=U[k]
  if w(m)%4==1 and all(not dot(m,n)for n in prefix):
   a=frame(prefix+[m],k+1)
   if a:return a
b=frame([],0);edges=list(combinations(range(8),2))
R={(i,j):X[b[i]^b[j] if j<7 else 32767^b[i]]for i,j in edges};ck(len(set(R.values()))==28)
rr={v:k for k,v in R.items()};stars={frozenset(e for e in edges if i in e):i for i in range(8)}
cosets={e:X[32767^v]for e,v in R.items()}
words={x:[v for v,k in X.items()if k==x and w(v)==5]for x in set(cosets.values())}
atlas=[sorted(words[cosets[e]])for e in edges if 0 not in e];expected=[list(map(int,l.split()))for l in Path('simplex.tsv').read_text().splitlines()];ck(atlas==expected and all(len(T)==6 for T in words.values()))
def gl():
 for b in permutations(range(1,16),4):
  f=[0]
  for x in b:
   if x in f:break
   f+=[y^x for y in f]
  if len(f)==16:yield f
G=set();fix=set()
for f in gl():
 def im(v):
  p=0
  while v:a=v&-v;v-=a;p|=1<<(f[a.bit_length()]-1)
  return X[p]
 D={e:rr[im(v)]for e,v in R.items()};p=tuple(stars[frozenset(D[e]for e in E)]for E in stars)
 ck(len(set(p))==8 and sum(p[i]>p[j]for i,j in edges)%2==0);G.add(p)
 if p[:2]==(0,1):fix.add(p[2:])
ck(len(G)==20160 and len(fix)==360 and all(set(q)==set(range(2,8))for q in fix))
print('binary simplex weight-five support atlas: 168 words in 28 cosets, 6 each; direct check of 21 sampled classes. K8 induced permutations: all 20160 even elements. Fixed ordered omitted/central pair: exactly 360 even permutations of six peripheral axes.')
