#define main original_low_search
#include "slowgen9.cpp"
#undef main
int main(){ifstream f("../dualplanes/unary5-packet/layouts.tsv");int r,P[12],N[12],id=0,ccount=0,emp=0,fault=0,conf=0;int cl[42]{},ax[42]{};
 while(f>>r){for(auto&n:P)f>>n;for(auto&n:N)f>>n;if(id!=288&&id!=306&&id!=620&&id!=2264&&id!=166&&id!=197){id++;continue;}
 Shell sh(P,N);Form F(P,N);RForm sg(F,P,N,1),hg(F,P,N,0);Rad R(sh,F,sg,hg,cl,ax);Low A(R,sh,F);int m=13-r,nq=1;for(int j=0;j<m;j++)nq*=7;
 vector<array<int,6>>all(nq);for(int a=0;a<nq;a++){int z=a;for(int j=0;j<m;j++){all[a][j]=z%7;z/=7;}}int dc=F.nonsquare()?3:1;
 auto dot=[&](const array<int,6>&x,const array<int,6>&y){int c=0;for(int i=0;i<m;i++)c+=x[i]*y[i]*(i==m-1?dc:1);return c%7;};
 vector<int>I;for(int a=1;a<nq;a++)if(!dot(all[a],all[a])){bool good=true;for(int b:I){if(dot(all[a],all[b]))good=false;for(int i=1;i<7;i++){bool same=true;for(int j=0;j<m;j++)if(all[b][j]*i%7!=all[a][j])same=false;if(same)good=false;}}if(good)I.push_back(a);if(I.size()==2)break;}
 int mxi=m/2-((m%2==0)&&((dc==1)!=(m%4==0)));if(I.size()!=min(2,mxi))abort();int pts=R.d0;
 for(int k=0;k<=int(I.size());k++){vector<array<int,6>>L;for(int j=0;j<pts;j++){array<int,6>v{};for(int z=0;z<k;z++)for(int i=0;i<m;i++)v[i]=(v[i]+(j==z?1:j>=k?(2+j+z)%7:0)*all[I[z]][i])%7;L.push_back(v);}
 for(int j=0;j<m;j++){array<int,6>v{};v[j]=1;L.push_back(v);}for(int j=0;j<40;j++){
 auto l=L;l.push_back(all[(j*179+13)%nq]);l.push_back(all[(j*353+19)%nq]);int n=l.size();for(int a=0;a<n;a++)for(int b=0;b<n;b++)A.G[a][b]=dot(l[a],l[b]);for(int t=pts;t<=n;t++){if(!A.gram(t))abort();ccount++;}
 // append an extra independent perpendicular nonsingular coordinate
 for(int a=0;a<n;a++)A.G[a][n]=A.G[n][a]=0;A.G[n][n]=1;if(A.gram(n+1))abort();fault++;
 // replace last ambient diagonal discriminant by the opposite square class
 for(int a=0;a<n;a++)for(int b=0;b<n;b++)A.G[a][b]=(A.G[a][b]+2*dc*l[a][m-1]*l[b][m-1])%7;if(A.gram(n))abort();fault++;
 }
 // Independent checks that the full actual defect image is covered by some enumerated W.
 int covered=0; for(auto&w:A.W){set<int>inds(w.begin(),w.end());bool ok=1;for(auto&v:all){int h[4]{};for(int j=0;j<pts;j++)h[j]=dot(L[j],v);if(!inds.count(qcode(h,pts))){ok=false;break;}}covered+=ok;}if(!covered)abort();emp+=covered;
 }conf++;id++;
 }if(id!=3580||conf!=6)abort();cout<<"six signed determinant types checked locally, realizable partial/full residual Grams "<<ccount<<", rejected over-rank/wrong-type controls "<<fault<<", common defect-plane coverage checks (multiplicities) "<<emp<<"\n";}
