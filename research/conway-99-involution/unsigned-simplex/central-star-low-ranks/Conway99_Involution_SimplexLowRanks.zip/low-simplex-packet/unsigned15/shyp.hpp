struct Att{int d;U mask,twin,tight=0,slack=0;int sm,tm,cond=0,pi[11]{},m[11]{},rho;unsigned key;};
struct PC{int id,p,a,b;}; // label-specific word, signed anchor ID, 7-plane coordinates, uses fields id=word,p=attachment
struct Plane{
 const int*cl;const int*ax;vector<Att>atts;vector<vector<int>>dom[30];unordered_map<unsigned,vector<int>>groups[30];vector<pair<int,int>>sol[7][49],canon[7][49];int nonpivs[2]{},np=0;bool activeNull;int dcoef,baseRank;long long tests=0,nodes=0,tolerated=0;
 U base[39],blocked[39]{};int r[30][7]{},zd[30][30]{};
 Plane(Shell&sh,Form&F,RForm&sg,RForm&H,const int*to,const int*xx,int mode):cl(to),ax(xx),activeNull(mode){
 baseRank=F.rank;if(F.rank!=9)abort();dcoef=F.nonsquare()?3:1;
 if(baseRank!=9||F.nonsquare()||mode!=2)abort();for(int i=0;i<11;i++)if(find(F.pi,F.pi+9,i)==F.pi+9)nonpivs[np++]=i;if(np!=2)abort();
 for(int h=0;h<49;h++)for(int a=0;a<7;a++)for(int b=0;b<7;b++){int n=(2*(h%7*a+h/7*b))%7;auto v=make_pair(a,b);sol[n][h].push_back(v);if(!h||canon[n][h].empty())canon[n][h].push_back(v);}
 copy(sh.G,sh.G+39,base);for(int i=0;i<39;i++)for(int j=0;j<39;j++)if(j!=i&&2-int(base[i]>>j&1)-pop(base[i]&base[j])<=1)blocked[i]|=bit(j);
 for(int k=0;k<30;k++)copy(sh.r[k],sh.r[k]+7,r[k]);for(int j=0;j<30;j++)for(int k=0;k<30;k++)for(int t=0;t<7;t++)zd[j][k]+=r[j][t]*r[k][t];
 for(int k=0;k<30;k++)for(auto&w:sh.domain[k]){unsigned key=0;int f[12],u[12];ll pf[12],n;bool bad=0;for(int t=0;t<12;t++){
 int a=w.a>>t&1,b=w.b>>t&1;if(a&&b&&sh.P[t]==sh.N[t])bad=1;f[t]=-4*(a-b)-sh.z[k][t];u[t]=1-abs(sh.z[k][t])-2*(a+b);key|=(a+b)<<(2*t);}
 if(bad||!sg.project(f,pf,n,10)||!H.project(u,pf,n,5))continue;Att v;v.d=k;v.mask=w.mask;v.twin=flip(v.mask);for(int i=0;i<39;i++){int k=2-int(v.mask>>i&1)-pop(base[i]&v.mask);if(!k)v.tight|=bit(i);if(k==1)v.slack|=bit(i);}v.sm=w.a;v.tm=w.b;v.key=key;
 for(int i=0;i<baseRank;i++){v.pi[i]=m7(f[F.pi[i]]);int m=0;for(int j=0;j<baseRank;j++)m+=F.C[i][j]*f[F.pi[j]];v.m[i]=m7(m);}
 int y=3;for(int i=0;i<baseRank;i++)y-=v.pi[i]*v.m[i];v.rho=m7(y);{int h[2];for(int j=0;j<2;j++){int k=nonpivs[j],cond=f[k];for(int i=0;i<9;i++)cond-=F.A[k][F.pi[i]]*v.m[i];h[j]=m7(cond);}v.cond=h[0]+7*h[1];}if(sol[v.rho][v.cond].empty())continue;
 groups[k][key].push_back(atts.size());atts.push_back(v);
 }prodinit();}
 bool caps(const Att&x,const Att&y,int l,int t)const{
 U a=x.mask,b=x.twin,c=y.mask,d=y.twin;bool p=t==2||l==1,n=t==2||l==-1;
 if(t==2&&((a&b)||(c&d)))return false;
 if(pop(a&c)+p>2||pop(a&d)+n>2)return false;
 // Old/old common-neighbor capacity for new contributions whose two twin sets overlap.
 for(U u:{a,b})for(U v:{c,d}){U o=u&v;for(U s=o;s;s&=s-1){int i=low(s);if(blocked[i]&o)return false;if(((a&b)>>i&1)&&((a&b&o)&~bit(i)))return false;if(((c&d)>>i&1)&&((c&d&o)&~bit(i)))return false;}}
 if(p&&((x.tight&c)||(y.tight&a)))return false;
 if(n&&((x.tight&d)||(y.tight&b)))return false;
 if(t==2&&((x.slack&c&d)||(y.slack&a&b)))return false;
 return true;}
 U prodMasks[49][7][49][7]{},canonMasks[7][49]{};
 void prodinit(){for(int n=0;n<7;n++)for(int d=0;d<49;d++){auto&s=sol[n][d];if(s.size()>64)abort();for(int i=0;i<int(s.size());i++){auto e=s[i];if(find(canon[n][d].begin(),canon[n][d].end(),e)!=canon[n][d].end())canonMasks[n][d]|=bit(i);
  for(int v=0;v<49;v++){int w=v%7*e.first+v/7*e.second;prodMasks[v][n][d][w%7]|=bit(i);}
 }}}
 struct Cg{unsigned short p;unsigned char id;U rem;};
 U arc(const Cg&x,int vi,const Cg&y){auto&a=atts[x.p],&b=atts[y.p];int i=a.d,j=b.d;
 int t=1-pop(ax[12+i]&ax[12+j])-Wdot[cl[12+i]][x.id][cl[12+j]][y.id];if(t<0||t>4||(t&1))return 0;t/=2;
 int z=zd[i][j];for(int k=0;k<baseRank;k++)z+=a.m[k]*b.pi[k];int zn=m7(-z-(vi%7)*(b.cond%7)-(vi/7)*(b.cond/7));auto const& ms=prodMasks[a.cond][b.rho][b.cond];
 U u=0;for(int l=-(t%2);l<=int(t%2);l+=2){U cand=y.rem&ms[m7(zn-4*l)];if(cand){tests++;if(caps(a,b,l,t))u|=cand;}}
 return u;}
 long long depthHist[10]{};
 bool search(int chosen[12],int depth){vector<vector<Cg>> ds(30);int count[30]{};
 for(int k=0;k<30;k++){int y=12+k;for(int w=0;w<192;w++){unsigned key=0;bool ok=1;for(int i=0;i<12;i++){int t=1-pop(ax[i]&ax[y])-Wdot[cl[i]][chosen[i]][cl[y]][w];if(t<0||t>4||(t&1)){ok=0;break;}key|=(t/2)<<(2*i);}
 if(!ok)continue;auto it=groups[k].find(key);if(it==groups[k].end())continue;for(int id:it->second){auto& a=atts[id];int z=sol[a.rho][a.cond].size();if(id>=65536||z>64||!z)abort();ds[k].push_back({(unsigned short)id,(unsigned char)w,z==64?~0ull:bit(z)-1});count[k]+=z;}
 }if(ds[k].empty())return false;}
 int k0=min_element(count,count+30)-count;for(auto&c:ds[k0]){auto&a=atts[c.p];c.rem&=canonMasks[a.rho][a.cond];if(!c.rem)abort();}
 auto size=[](const vector<Cg>&g){size_t c=0;for(const Cg&v:g)c+=pop(v.rem);return c;};
 sort(ds.begin(),ds.end(),[&](auto&a,auto&b){return size(a)<size(b);});
 function<bool(vector<vector<Cg>>&,int)>dfs=[&](auto &d,int step){nodes++;depthHist[step]++;if(step>=depth||d.empty())return true;
 int idx=0;size_t best=SIZE_MAX;for(int i=0;i<d.size();i++){auto n=size(d[i]);if(n<best){idx=i;best=n;}}swap(d.front(),d[idx]);
 for(auto&pick:d.front()){auto&sx=sol[atts[pick.p].rho][atts[pick.p].cond];for(U s=pick.rem;s;s&=s-1){auto v=sx[low(s)];int w=v.first+7*v.second;bool ok=true;
 for(int j=1;j<d.size();j++){bool found=false;for(auto&z:d[j])if(arc(pick,w,z)){found=true;break;}if(!found){ok=false;break;}}if(!ok)continue;
 vector<vector<Cg>> next(d.size()-1);for(int j=1;j<d.size();j++)for(auto z:d[j]){z.rem=arc(pick,w,z);if(z.rem)next[j-1].push_back(z);}if(dfs(next,step+1))return true;
 }}return false;};return dfs(ds,0);}
};
