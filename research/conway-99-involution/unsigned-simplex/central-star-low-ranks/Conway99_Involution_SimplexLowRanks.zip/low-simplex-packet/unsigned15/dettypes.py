from pathlib import Path
def rr(a,p):
 a=[x[:]for x in a];r=0;d=1;I=[]
 for j in range(len(a)):
  k=next((k for k in range(r,len(a))if a[k][j]%p),None)
  if k is None:continue
  if r!=k:d=-d
  a[r],a[k]=a[k],a[r];z=a[r][j]%p;d=d*z%p;u=pow(z,-1,p)
  for i in range(r+1,len(a)):
   v=a[i][j]*u%p;a[i]=[(x-v*y)%p for x,y in zip(a[i],a[r])]
  I.append(j);r+=1
 return I,d%p
def data():
 L=Path('../dualplanes/unary5-packet/layouts.tsv').read_text().splitlines()
 for id,l in enumerate(L):
  r,*m=map(int,l.split());p,n=m[:12],m[12:];A=[[11*(i==j)+((i^1)==j)-4*(p[i]==j)+4*(n[i]==j)-1 for j in range(12)]for i in range(12)]
  I=rr(A,7)[0];d=rr([[A[i][j]for j in I]for i in I],7)[1]
  if len(I)!=r:raise ArithmeticError(id)
  yield id,(r,d)
if __name__=='__main__':
 rd=dict(data());f=open('sf-run/r9s.tsv','w');g=open('sf-run/r9n.tsv','w')
 for l in Path('sf-run/star.tsv').read_text().splitlines():
  v=l.split()
  if len(v)>2 and int(v[3])==9 and 'outer 1' in l:
   id,par=map(int,v[:2]);r,d=rd[id];print(id,par,file=f if d in (1,2,4)else g)
