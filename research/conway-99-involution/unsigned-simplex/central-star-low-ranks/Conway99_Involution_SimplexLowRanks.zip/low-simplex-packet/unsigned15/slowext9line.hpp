// Generic complementary rank test. Use all possible signed links and a
// necessary 2D constraint on the space of anchor-radical pairings.
struct SX{int d,w,id;};
int qcode(const int*v,int n){int x=0;for(int j=n-1;j>=0;j--)x=x*7+v[j];return x;}
struct Low{
 int d0,rank,cpChar;const int*cl,*ax; vector<RAtt>&att; vector<vector<int>> W,inc;vector<vector<SX>> dom;long long viable=0,clique=0,cnodes=0;bool solved=false;
 U base[39],blocked[39]{};int zd[30][30]{};vector<U> mt,xt,ys;
 Low(Rad&r_,Shell&sh,Form&F):d0(r_.d0),rank(F.rank),cpChar(F.nonsquare()?-1:1),cl(r_.cl),ax(r_.ax),att(r_.att){
 copy(sh.G,sh.G+39,base);for(int i=0;i<39;i++)for(int j=0;j<39;j++)if(i!=j&&2-int(base[i]>>j&1)-pop(base[i]&base[j])<=1)blocked[i]|=bit(j);
 for(int i=0;i<30;i++)for(int j=0;j<30;j++)for(int a=0;a<7;a++)zd[i][j]+=sh.r[i][a]*sh.r[j][a];
 int nq=1;for(int j=0;j<d0;j++)nq*=7;inc.resize(nq);
 // Every 2-space is uniquely represented by two RREF rows.
 if(rank!=9)for(int i=0;i<d0;i++)for(int j=i+1;j<d0;j++){int a[4]{},b[4]{};a[i]=1;b[j]=1;vector<int*>v;for(int t=i+1;t<d0;t++)if(t!=j)v.push_back(&a[t]);for(int t=j+1;t<d0;t++)v.push_back(&b[t]);
 function<void(int)>dfs=[&](int t){if(t<int(v.size())){for(*v[t]=0;*v[t]<7;(*v[t])++)dfs(t+1);return;}vector<int>c;
 for(int x=0;x<7;x++)for(int y=0;y<7;y++){int z[4];for(int k=0;k<d0;k++)z[k]=(x*a[k]+y*b[k])%7;int h=qcode(z,d0);c.push_back(h);inc[h].push_back(W.size());}
 W.push_back(c);};dfs(0);}
 if(rank==9){for(int i=0;i<d0;i++){int a[4]{};a[i]=1;int count=1;for(int u=i+1;u<d0;u++)count*=7;for(int c=0;c<count;c++){int y=c;for(int j=i+1;j<d0;j++){a[j]=y%7;y/=7;}vector<int>s;for(int j=0;j<7;j++){int z[4]{};for(int k=0;k<d0;k++)z[k]=a[k]*j%7;int h=qcode(z,d0);s.push_back(h);inc[h].push_back(W.size());}W.push_back(s);}}}
 if(!((rank==7&&W.size()==2850&&cpChar==1)||(rank==8&&W.size()==57)||(rank==9&&W.size()==8)))abort();
 for(auto&a:att){U m=a.mask,t=flip(m);mt.push_back(t);U x=0,y=0;for(int i=0;i<39;i++){int z=2-int(m>>i&1)-pop(base[i]&m);if(!z)x|=bit(i);if(z==1)y|=bit(i);}xt.push_back(x);ys.push_back(y);}
 }
 bool caps(int i,int j,int l,int t){U a=att[i].mask,b=mt[i],c=att[j].mask,d=mt[j];bool p=t==2||l==1,n=t==2||l==-1;
  if(t==2&&((a&b)||(c&d)))return false;if(pop(a&c)+p>2||pop(a&d)+n>2)return false;
  if(p&&((xt[i]&c)||(xt[j]&a))||n&&((xt[i]&d)||(xt[j]&b))||t==2&&((ys[i]&c&d)||(ys[j]&a&b)))return false;
  for(U u:{a,b})for(U v:{c,d}){U o=u&v;for(U s=o;s;s&=s-1){int k=low(s);if(blocked[k]&o)return false;if(((a&b)>>k&1)&&((a&b&o)&~bit(k)))return false;if(((c&d)>>k&1)&&((c&d&o)&~bit(k)))return false;}}return true;}
 // Return link possibilities, bit 0 for L=0, bit 1 for +1, bit 2 for -1.
 int pair(const SX&a,const SX&b){int t=1-pop(ax[12+a.d]&ax[12+b.d])-val(LWords[cl[12+a.d]][a.w],LWords[cl[12+b.d]][b.w]);if(t<0||t>4||(t&1))return 0;t/=2;
 int o=0;for(int l=-(t%2);l<=int(t%2);l+=2)if(caps(a.id,b.id,l,t))o|=l==0?1:l==1?2:4;return o;}
 int nc=0;SX sel[12];int G[17][17]{};
 // rank and full quotient determinant character of the residual form.
 bool gram(int n){int M[17][17]{},pi[17],r=0,v[17][17]{};for(int i=0;i<n;i++)copy(G[i],G[i]+n,M[i]);constexpr int inv[]={0,1,4,5,2,3,6};
 for(int j=0;j<n;j++){int k=r;while(k<n&&!M[k][j])k++;if(k==n)continue;swap(M[k],M[r]);pi[r]=j;int m=inv[M[r][j]];for(int i=r+1;i<n;i++){int z=M[i][j]*m%7;if(z)for(int t=j;t<n;t++)M[i][t]=m7(M[i][t]-z*M[r][t]);}if(++r>13-rank)return false;}
 if(r<13-rank)return true;for(int i=0;i<r;i++)for(int j=0;j<r;j++)v[i][j]=G[pi[i]][pi[j]];int d=1;
 for(int j=0;j<r;j++){int k=j;while(k<r&&!v[k][j])k++;if(k==r)abort();if(k!=j){swap(v[k],v[j]);d=-d;}int u=v[j][j];d=m7(d*u);for(int i=j+1;i<r;i++){int z=v[i][j]*inv[u]%7;for(int h=j;h<r;h++)v[i][h]=m7(v[i][h]-z*v[j][h]);}}
 return(d==1||d==2||d==4?1:-1)==cpChar;}
 template<class F>bool links(const SX&x,int k,F cont){
 int opt[12],v[12];for(int j=0;j<k;j++)if(!(opt[j]=pair(x,sel[j])))return false;auto&a=att[x.id];int n=d0+k;for(int i=0;i<d0;i++)G[n][i]=G[i][n]=a.h[i];G[n][n]=a.n;
 for(int j=0;j<k;j++){auto&b=att[sel[j].id];int t=-zd[x.d][sel[j].d];for(int i=0;i<rank;i++)t-=a.pr[i]*b.pi[i];v[j]=m7(t);}
 function<bool(int)>rec=[&](int j){if(j==k)return gram(n+1)&&cont();for(int z=0;z<3;z++)if(opt[j]>>z&1){int l=z==0?0:z==1?1:-1;G[n][d0+j]=G[d0+j][n]=m7(v[j]-4*l);if(rec(j+1))return true;}return false;};return rec(0);}
 bool search(vector<vector<SX>>&ds,int k,int maxDepth){cnodes++;if(k==maxDepth)return true;int iv=min_element(ds.begin(),ds.end(),[](auto&a,auto&b){return a.size()<b.size();})-ds.begin();swap(ds[0],ds[iv]);
 for(auto&x:ds.front()){sel[k]=x;if(links(x,k,[&](){vector<vector<SX>> next(ds.size()-1);
 for(int j=1;j<ds.size();j++){for(auto&y:ds[j])if(links(y,k+1,[](){return true;}))next[j-1].push_back(y);if(next[j-1].empty())return false;}return search(next,k+1,maxDepth);}))return true;}return false;}
 bool run(const vector<vector<SX>>&ds,int depthLimit){vector<vector<unsigned char>>pass(30,vector<unsigned char>(W.size(),0));for(int d=0;d<30;d++){
 vector<int> seen(inc.size());for(auto &x:ds[d])seen[qcode(att[x.id].h,d0)]=1;for(int i=0;i<seen.size();i++)if(seen[i])for(int b:inc[i])pass[d][b]=1;}
 for(int j=0;j<W.size();j++){bool live=true;for(int d=0;d<30;d++)if(!pass[d][j]){live=false;break;}if(!live)continue;viable++;
 vector<bool> ok(inc.size(),false);for(int h:W[j])ok[h]=true;vector<vector<SX>> D(30);for(int d=0;d<30;d++)for(auto&x:ds[d])if(ok[qcode(att[x.id].h,d0)])D[d].push_back(x);
 if(search(D,0,depthLimit)){clique++;return true;}}
 return false;}
};
