#define main hyper_search_entry
#include "shyp.cpp"
#undef main
void chk(bool v){if(!v)throw runtime_error("split-control mismatch");}
bool literal(const Plane &pl,const Att&x,const Att&y,int l,int t){U A[43]{};copy(pl.base,pl.base+39,A);auto join=[&](int u,int v){A[u]|=bit(v);A[v]|=bit(u);};for(int i=0;i<39;i++){if(x.mask>>i&1)join(39,i);if(x.twin>>i&1)join(40,i);if(y.mask>>i&1)join(41,i);if(y.twin>>i&1)join(42,i);}
 if(t==2||l==1){join(39,41);join(40,42);}if(t==2||l==-1){join(39,42);join(40,41);}
 for(int i=0;i<43;i++)for(int j=0;j<i;j++)if(pop(A[i]&A[j])+int(A[i]>>j&1)>2)return false;return true;}
int main(){int cl[42]{},ax[42]{},P[12],N[12],r,id=0;ifstream f("../dualplanes/unary5-packet/layouts.tsv");long acc=0,neg=0;int Pairs=0,vec=0,tot=0;
 while(f>>r){for(int&v:P)chk(bool(f>>v));for(int&v:N)chk(bool(f>>v));bool yes=(id==197||id==333||id==2274);id++;if(!yes)continue;Shell sh(P,N);sh.gen();Form F(P,N);RForm S(F,P,N,1),H(F,P,N,0);auto p=make_unique<Plane>(sh,F,S,H,cl,ax,2);
 // Every vector (u,h) in the split four-dimensional space, including all
 // vectors in the fixed plane, and all physical block realizations.
 if(!vec)for(int h=0;h<49;h++)for(int rho=0;rho<7;rho++){int h0=h%7,h1=h/7;auto &D=p->sol[rho][h];set<pair<int,int>>domain,orbits;for(int a=0;a<7;a++)for(int b=0;b<7;b++)if((2*(a*h0+b*h1))%7==rho)domain.insert({a,b});chk(domain==set<pair<int,int>>(D.begin(),D.end()));
 for(int i=0;i<D.size();i++)if(p->canonMasks[rho][h]>>i&1){auto[a,b]=D[i];for(int k=0;k<7;k++)orbits.insert({m7(a+k*h1),m7(b-k*h0)});}chk(orbits==domain);tot+=D.size();
 for(int hi=0;hi<49;hi++)for(int g=0;g<7;g++){U ref=0;for(int j=0;j<D.size();j++){auto[a,b]=D[j];if(((hi%7)*a+(hi/7)*b)%7==g)ref|=bit(j);}chk(ref==p->prodMasks[hi][rho][h][g]);Pairs++;}}
 vec++;
 unsigned rng=73877231+id;auto R=[&](){rng=1664525u*rng+1013904223u;return rng;};for(int i=0;i<6000;i++){auto&a=p->atts[R()%p->atts.size()],&b=p->atts[R()%p->atts.size()];if(a.d==b.d)continue;
 for(int e=0;e<4;e++){int l=e==1?1:e==2?-1:0,t=e==3?2:int(e!=0);bool y=literal(*p,a,b,l,t);chk(y==p->caps(a,b,l,t));if(y)acc++;else neg++;}}
 }chk(id==3580&&tot==2401&&vec==3&&acc>0&&neg>0);cout<<"independent hyperbolic coordinate and normalized shear orbit controls "<<tot<<"; pairing bitmask checks "<<Pairs<<"; literal 43-vertex accepted/rejected "<<acc<<"/"<<neg<<"\n";}
