#!/bin/bash
set -euo pipefail; cd "$(dirname "$0")"
mode=${1:-quick};[[ $mode == quick || $mode == full ]]
sha256sum -c MANIFEST.sha256
build=$(mktemp -d);trap 'rm -rf "$build"' EXIT
g++ -O3 -std=c++17 dualplanes/unary5-packet/catalog.cpp -o "$build/catalog";"$build/catalog" > "$build/layouts" 2> "$build/catalog.log";cmp "$build/layouts" dualplanes/unary5-packet/layouts.tsv
python3 -B audit.py
cd unsigned15
for source in local-unary sstar-independent simp-low-controls shyp-controls slowgen9line shyp;do g++ -w -O3 -std=c++17 "$source.cpp" -o "$build/$source";done
python3 -B slabels-check.py > "$build/labels-check.log"
"$build/local-unary" 0 3580 > "$build/unary.log"; "$build/sstar-independent" 0 3580 > "$build/independent-stars.tsv"
"$build/simp-low-controls" > "$build/lowctrl.log";"$build/shyp-controls" > "$build/hypctrl.log"
: > "$build/generic.log"
if [[ $mode == full ]];then
 (printf '288 0\n288 1\n306 0\n306 1\n620 0\n620 1\n2264 0\n2264 1\n'; cat sf-run/r9n.tsv sf-run/r9s.tsv)|while read -r i p;do "$build/slowgen9line" "$i" "$p" 5 0 >> "$build/generic.log";done
 "$build/shyp" 0 1 0 > "$build/hyp.log"
 cd ..;python3 -B audit.py "$build" full
else
 for q in '288 0' '306 1' '197 0' '166 0';do read -r i p <<<"$q";"$build/slowgen9line" "$i" "$p" 5 0 >> "$build/generic.log";done
 "$build/shyp" 4 22 0 > "$build/hyp.log"
 cd ..;python3 -B audit.py "$build"
fi
