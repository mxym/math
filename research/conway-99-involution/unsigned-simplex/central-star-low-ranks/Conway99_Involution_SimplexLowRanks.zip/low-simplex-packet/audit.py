from pathlib import Path
from collections import Counter
import sys
def ck(q):
 if not q:raise ArithmeticError('coverage or replay mismatch')
def lines(n):return Path(n).read_text().splitlines()
def drop(s):return s.split(' cpu ')[0]
def L(F):return [s.split()for s in lines(F)]
E=Path('expected');U=Path('unsigned15');sys.path.insert(0,str(U.resolve()))
from dettypes import rr
lay=[list(map(int,s.split()))for s in lines('dualplanes/unary5-packet/layouts.tsv')];rd={}
for i,(r,*v)in enumerate(lay):
 p,n=v[:12],v[12:];A=[[11*(j==k)+((j^1)==k)-4*(p[j]==k)+4*(n[j]==k)-1 for k in range(12)]for j in range(12)];I=rr(A,7)[0];D=rr([[A[j][k]for k in I]for j in I],7)[1];ck(r==len(I)and 0 not in [D]);rd[i]=(r,D)
ck(Counter(r for r,d in rd.values())=={7:3,8:5,9:97,10:637,11:2838})
local={};bad=set();candidates=set()
for v in L(E/'unary.log'):
 i=int(v[0]);ck(rd[i][0]<=9)
 if v[1]=='bad':ck(i not in bad);bad.add(i);continue
 k=i,int(v[1]);ck(k not in local and v[2]=='rank'and int(v[3])==rd[i][0]and 'truncated' in v and v[v.index('truncated')+1]=='0');local[k]=v
 if v[v.index('outer')+1]=='1':candidates.add(k)
ck(len(bad)==9 and set(local)=={(i,s)for i,(r,d)in rd.items()if r<=9 and i not in bad for s in(0,1)} and Counter(rd[i][0]for i,s in candidates)=={7:2,8:6,9:86})
bare={(int(i),int(p)):int(v)for i,p,v in L(E/'independent-stars.tsv')};ck(set(bare)=={(i,s)for i,(r,d)in rd.items()if r<=9 for s in(0,1)})
t0={k for k in candidates if rd[k[0]][0]<9};n9={k for k in candidates if rd[k[0]][0]==9 and rd[k[0]][1]in(3,5,6)};s9=candidates-n9-t0
ck(len(t0)==8 and len(n9)==64 and len(s9)==22)
for nm,want in [('r9s',s9),('r9n',n9)]:ck(set(tuple(map(int,v))for v in L(U/'sf-run'/(nm+'.tsv')))==want)
def parsed(*f):
 d={}
 for ff in f:
  for v in L(E/ff):
   k=tuple(map(int,v[:2]));ck(k not in d and v[v.index('open')+1]=='0');d[k]=v
 return d
groups=[(t0,parsed('generic-low.tsv','generic-low-1.tsv'),{}),(n9,parsed('r9n.log'),parsed('r9n-fallback.log')),(s9,parsed('r9line.log'),parsed('r9line-fallback.log'))]
def complete(w,d,o):
 ck(set(d)==w and set(o)=={k for k,v in d.items()if v[v.index('truncated')+1]=='1'});d=dict(d);d.update(o)
 for k,v in d.items():ck(v[v.index('truncated')+1]=='0'and int(v[v.index('star')+1])==bare[k])
 return d
final=[complete(*g)for g in groups]
hyp=parsed('r9hyp.log');ck(set(hyp)==s9);caph={k for k,v in hyp.items()if v[v.index('truncated')+1]=='1'};ck(caph=={(333,0),(333,1)})
for k in s9-caph:ck(int(hyp[k][hyp[k].index('star')+1])==bare[k])
blocks={}
for v in L(E/'hyp-blocks.log'):
 k=tuple(map(int,v[0:2]));ck(k in caph and v[2]=='range'and v[9]=='open'and v[10]=='0');a,b=map(int,v[3:5]);seen=int(v[6]);num=int(v[8]);lim=int(v[12]);t=bare[k]
 ck(a<min(b,t)and seen==min(b,t)and num==seen-a and lim==int(b<=t));blocks.setdefault(k,[]).append((a,min(b,t)))
for k in caph:
 T=sorted(blocks[k]);ck(T[0][0]==0 and T[-1][1]==bare[k]and all(a[1]==b[0] for a,b in zip(T,T[1:])))
if len(sys.argv)>1:
 folder=Path(sys.argv[1]);F=lambda n:[drop(s)for s in lines(folder/n)]
 ck(F('unary.log')==[drop(s)for s in lines(E/'unary.log')]);ck(lines(folder/'independent-stars.tsv')==lines(E/'independent-stars.tsv'))
 for fname in ['lowctrl.log','hypctrl.log','labels-check.log']:ck(lines(folder/fname)==lines(E/fname))
 def expectR(n):
  dd={k:v for q in final for k,v in q.items()};ls=F(n)
  for s in ls:k=tuple(map(int,s.split()[:2]));ck(s==drop(' '.join(dd[k])))
  return set(tuple(map(int,s.split()[:2]))for s in ls)
 ck(expectR('generic.log')==(candidates if len(sys.argv)>2 else {(288,0),(306,1),(197,0),(166,0)}))
 if len(sys.argv)>2:
  obs={tuple(map(int,s.split()[:2])):s for s in F('hyp.log')};ck(set(obs)==s9)
  for k,s in obs.items():
   if k not in caph:ck(s==drop(' '.join(hyp[k])))
   else:
    v=s.split();ck(v[v.index('open')+1]=='0'and v[v.index('truncated')+1]=='0'and int(v[v.index('star')+1])==bare[k])
 else:ck(F('hyp.log')==[drop(' '.join(hyp[433,0]))])
print('105 low-rank chart types, 9 invalid bases, 94 unary-surviving parities, all 8 rank≤8/64 nonsplit rank9/22 split rank9 covered. All 22 split independent-defect tests closed, including both complete 10424-element #333 scopes.')
