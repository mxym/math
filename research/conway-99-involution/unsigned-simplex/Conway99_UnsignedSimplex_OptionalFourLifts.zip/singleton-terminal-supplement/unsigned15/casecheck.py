"""Literal end-of-tree verifier for the four chart lifts and their two smallest
extension domains. Domain exhaustion is provided by the full primary replay.
All candidate-mask and integer Gram reconstruction herein are independent."""
from itertools import combinations,product
from pathlib import Path
from collections import Counter
from math import isqrt
from fixturescheck import pd,rank
D=[(i,j,s)for i,j in combinations(range(7),2) for s in (0,1)]
layouts=Path('../dualplanes/unary5-packet/layouts.tsv').read_text().splitlines()
def ck(t):
 if not t:raise ValueError('exception witness invalid')
def build(base,extra=(),last=None):
 i,g,low,vs,ls=base
 rr,*pp=map(int,layouts[i].split());P,N=pp[:12],pp[12:]
 att=vs+[l[:3]for l in extra];lab=D[:12]+[D[12+t[0]]for t in att];n=len(lab);G=[set()for _ in range(15+2*n)]
 def edge(i,j):
  ck(i!=j);G[i].add(j);G[j].add(i)
 def out(i,s):return 15+2*i+s
 for j in range(7):
  v=1+2*j;edge(0,v);edge(0,v+1);edge(v,v+1)
 for a,(j,k,v)in enumerate(lab):
  for s in (0,1):edge(out(a,s),1+2*j+s);edge(out(a,s),1+2*k+(s^v))
 for j in range(12):
  for s in (0,1):edge(out(j,s),out(P[j],s));edge(out(j,s),out(N[j],s^1))
 def interact(j,k,w,l):
  ck(w in (0,1,2)and (abs(l)==1 if w==1 else l==0))
  for a,b in product((0,1),repeat=2):
   if w==2 or w==1 and (a==b)==(l>0):edge(out(j,a),out(k,b))
 for j,(d,a,b)in enumerate(att):
  for k in range(12):
   w,z=a>>k&1,b>>k&1;interact(j+12,k,w+z,w-z)
 pp=iter(ls)
 for j in range(4):
  for k in range(j):interact(12+j,12+k,next(pp),next(pp))
 for j,x in enumerate(extra):
  for k in range(4):interact(j+16,k+12,*x[3+2*k:5+2*k])
 if len(extra)==2:interact(16,17,*last)
 if any(len(G[i]&G[j])+int(j in G[i])>2 for i in range(len(G))for j in range(i)):return 'physical'
 z=[[int(a==j)+(1-2*v)*int(b==j)for j in range(7)]for a,b,v in lab]
 f=[[0]*n for _ in range(n)];h=[[0]*n for _ in range(n)]
 for j in range(n):
  for k in range(n):
   a=int(out(k,0)in G[out(j,0)]);b=int(out(k,1) in G[out(j,0)]);zz=[x*y for x,y in zip(z[j],z[k])];f[j][k]=12*int(j==k)-4*(a-b)-sum(zz);h[j][k]=6*int(j==k)-2*(a+b)-sum(map(abs,zz))+1
 if rank(f,7)>13:return 'rank7'
 for name,M in [('unsigned',h),('signed',f)]:
  try:r,det=pd(M)
  except ValueError:return name+' indefinite'
  if r>15:return name+' rank'
  if r==15 and isqrt(det)**2!=det:return name+' nonsquare'
 return 'pass'
def verify(base,sm,can,dims):
 ck(len(dims)==26 and len(sm)==2 and all(len(l)==dims[k]for k,l in sm.items()))
 ck(build(base)=='pass');results=Counter()
 for x,y in product(*sm.values()):
  for q in [(0,0),(1,1),(1,-1),(2,0)]:results[build(base,(x,y),q)]+=1
 ck(not results['pass']);print(base[:3],'literal terminal pair failures',sorted(results.items()))
 if can:ck(len(can)==26 and set(dims)=={q[0]for q in can});print('26 supplied separate outside choices; physical/true rational checks',Counter(build(base,(q,))for q in can))
base=None;N=0
for l in Path('expected/case-witnesses.tsv').read_text().splitlines():
 s=l.split();tag=s[0]
 if tag=='case':
  if base is not None:verify(base,sm,can,dims)
  i,k,g,r,*w=map(int,s[1:]);ck(i in (183,3377) and r==11 and len(w)==24);base=(i,g,r,[w[t:t+3]for t in range(0,12,3)],w[12:]);sm={};can=[];N+=1
 elif tag=='domains':dims={int(a):int(b)for a,b in (z.split(':')for z in s[1:])}
 elif tag=='small':
  v=list(map(int,s[1:]));sm.setdefault(v[0],[]).append(v)
 elif tag=='candidate':can.append(list(map(int,s[1:])))
 elif tag=='summary':verify(base,sm,can,dims);base=None
 else:ck(False)
ck(N==4)
