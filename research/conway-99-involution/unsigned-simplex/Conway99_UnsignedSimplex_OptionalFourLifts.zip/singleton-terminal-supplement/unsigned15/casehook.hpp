struct Projected{
 int r[3][4]{},c[3][4]{},n[3]{};
 void init(const Rmod f[3],long long fc[4],long long nu,const array<int,4>&v){for(int k=0;k<3;k++){auto&a=f[k];if(a.rank<0)continue;for(int i=0;i<4;i++)r[k][i]=a.mo(fc[i]-2LL*a.D*v[i]);for(int i=0;i<a.rank;i++){int s=0;for(int j=0;j<a.rank;j++)s+=a.iv[i][j]*r[k][a.index[j]];c[k][i]=s%a.p;}int s=a.mo(nu);for(int i=0;i<a.rank;i++)s=a.mo(s-c[k][i]*r[k][a.index[i]]);n[k]=s;}}
 bool match(Projected const&v,const Rmod f[3],long long base)const{for(int k=0;k<3;k++){auto&a=f[k];if(a.rank<0)continue;
 int s=a.mo(base);for(int i=0;i<a.rank;i++)s=a.mo(s-c[k][i]*v.r[k][a.index[i]]);if(a.dim==15&&s||a.dim==14&&s*s%a.p!=n[k]*v.n[k]%a.p)return false;}return true;}
};
struct JointCand{
 const CandH*m;const SC*sc;array<int,4>t,l;U mask;Projected us,ss;int r7[16]{},c7[16]{},n7=0;bool dbl;
};
struct Hook{
 Extend& e;HoldSigned&h;vector<JointCand> dom[30];
 Hook(Extend&e0,HoldSigned&h0):e(e0),h(h0){}
 bool gen(const CandH&m,array<int,4>const&v){
 int ix=0;for(int j=3;j>=0;j--)ix=3*ix+v[j];int d0[4];long long fu[4];
 for(int j=0;j<4;j++){d0[j]=0;for(int q=0;q<7;q++)d0[j]+=h.L.sh.r[m.d][q]*h.L.sh.r[h.L.C[h.L.hkey[j]].d][q];fu[j]=e.den*(1-abs(0));int z=0;auto&nm=h.L.C[h.L.hkey[j]];for(int q=0;q<7;q++)z+=abs(h.L.sh.r[m.d][q])*abs(h.L.sh.r[nm.d][q]);fu[j]=e.den*(1-z);for(int t=0;t<12;t++)fu[j]-=nm.pf[t]*m.f[t];}
 Projected um;um.init(e.mod,fu,m.nu,v);
 for(auto &sc:m.opt){long long fc[4],nu=10*h.L.sg.det;for(int t=0;t<12;t++)nu-=sc.f[t]*sc.pf[t];
 for(int j=0;j<4;j++){fc[j]=-h.L.sg.det*d0[j];for(int t=0;t<12;t++)fc[j]-=sc.f[t]*h.L.sel[j]->pf[t];}
 for(auto &s:h.signs[ix]){array<int,4>b;U a=sc.mask;for(int j=0;j<4;j++){b[j]=s[j]*2;int k=39+2*j;if(v[j]==2)a|=3ULL<<k;else if(v[j])a|=1ULL<<(k+int(s[j]<0));}
 bool ok=true;for(auto&f:h.rr)if(!f.ok(fc,nu,b)){ok=false;break;}if(!ok||!h.seven.live(sc,d0,s)||!h.caps(a))continue;
 JointCand g;g.m=&m;g.sc=&sc;g.t=v;g.l=s;g.mask=a;g.dbl=(a&flip(a))!=0;g.us=um;g.ss.init(h.rr,fc,nu,b);
 auto&R=h.seven;if(R.r>=12){for(int i=0;i<12;i++)g.r7[i]=m7(sc.f[i]);for(int i=0;i<4;i++)g.r7[12+i]=m7(-4*s[i]-d0[i]);
 for(int i=0;i<R.r;i++){int t=0;for(int j=0;j<R.r;j++)t+=R.inverse[i][j]*g.r7[R.I[j]];g.c7[i]=t%7;}int n=3;for(int i=0;i<R.r;i++)n-=g.c7[i]*g.r7[R.I[i]];g.n7=m7(n);}
 dom[m.d].push_back(g);
 }}return false; // collect ALL, never short-circuit Extend::one
 }
 bool graph(const JointCand&x,const JointCand&y,int t,int l){
 U G[51];copy(h.G,h.G+47,G);fill(G+47,G+51,0);U a[]={x.mask,flip(x.mask),y.mask,flip(y.mask)};
 for(int i=0;i<4;i++){G[47+i]=a[i];for(U s=a[i];s;s&=s-1)G[low(s)]|=bit(47+i);}
 for(int i=0;i<2;i++)for(int j=0;j<2;j++)if(t==2||t==1&&(l==1)==(i==j)){G[47+i]|=bit(49+j);G[49+j]|=bit(47+i);}
 for(int i=0;i<51;i++)for(int j=0;j<i;j++)if(pop(G[i]&G[j])+int(G[i]>>j&1)>2)return false;return true;}
 bool match(const JointCand&x,const JointCand&y){
 int z=0,b=0;for(int t=0;t<7;t++){auto a0=h.L.sh.r[x.m->d][t],a1=h.L.sh.r[y.m->d][t];z+=a0*a1;b+=abs(a0*a1);}
 ll uu=e.den*(1-b),ss=-h.L.sg.det*z;
 for(int i=0;i<12;i++){uu-=x.m->pf[i]*y.m->f[i];ss-=x.sc->pf[i]*y.sc->f[i];}
 int u7=-z;if(h.seven.r>=12)for(int i=0;i<h.seven.r;i++)u7-=x.c7[i]*y.r7[h.seven.I[i]];
 for(int t=0;t<=2;t++){if(t==2&&(x.dbl||y.dbl))continue;if(!x.us.match(y.us,e.mod,uu-2*t*e.den))continue;
 for(int l=-(t%2);l<=t%2;l+=2){if(h.seven.r>=12){int v=m7(u7-4*l);if(h.seven.r==13&&v||h.seven.r==12&&v*v%7!=x.n7*y.n7%7)continue;}
 if(x.ss.match(y.ss,h.rr,ss-4*l*h.L.sg.det)&&graph(x,y,t,l))return true;}}return false;}
 bool test(int g,int d0,int d1,int d2,int d3){vector<int>ds;for(int i=0;i<30;i++)if(i!=d0&&i!=d1&&i!=d2&&i!=d3)ds.push_back(i);sort(ds.begin(),ds.end(),[&](int a,int b){return e.groups[a].size()<e.groups[b].size();});
 e.lift=[&](const CandH&m,auto&v){return gen(m,v);};for(int i:ds){e.one(i,g);if(dom[i].empty())return false;}
 sort(ds.begin(),ds.end(),[&](int i,int j){return dom[i].size()<dom[j].size();});vector<const JointCand*>pick;
 cases++;cerr<<"case "<<reportID<<" "<<cases<<" "<<g<<" "<<h.seven.r;
 for(int i=0;i<4;i++)cerr<<" "<<h.L.C[h.L.hkey[i]].d<<" "<<h.L.sel[i]->a<<" "<<h.L.sel[i]->b;
 for(int i=0;i<4;i++)for(int j=0;j<i;j++)cerr<<" "<<h.L.ua[12+i][12+j]<<" "<<h.L.ls[i][j];cerr<<endl;
 cerr<<"domains";for(int m:ds)cerr<<" "<<m<<":"<<dom[m].size();cerr<<endl;
 for(int j=0;j<2;j++){int m=ds[j];for(auto&s:dom[m]){cerr<<"small "<<m<<" "<<s.sc->a<<" "<<s.sc->b;for(int t=0;t<4;t++)cerr<<" "<<s.t[t]<<" "<<s.l[t];cerr<<endl;}}
 if(cases==1)for(int m:ds){auto&s=dom[m].front();cerr<<"candidate "<<m<<" "<<s.sc->a<<" "<<s.sc->b;for(int t=0;t<4;t++)cerr<<" "<<s.t[t]<<" "<<s.l[t];cerr<<endl;}
 
 function<bool(int)> rec=[&](int k){searchNodes++;dfsDepth[k]++;if(k==min(8,(int)ds.size()))return true;for(auto &v:dom[ds[k]]){bool ok=1;for(auto*w:pick)if(!match(*w,v)){ok=0;break;}if(ok){pick.push_back(&v);if(rec(k+1))return true;pick.pop_back();}}return false;};return rec(0);}
};
