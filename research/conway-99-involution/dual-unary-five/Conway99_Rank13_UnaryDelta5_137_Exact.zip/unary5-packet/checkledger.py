"""Check bijective chart coverage; fail closed under partial input and Python -O.
With two files, compare exact records, removing ONLY the processor-time field."""
from pathlib import Path
import re,sys
def ck(c):
 if not c:raise ValueError('incomplete or inconsistent chart ledger')
def data(fn):
 d={}
 for row in Path(fn).read_text().splitlines():
  lhs,sep,rt=row.partition(' cpu ')
  if sep:ck(re.fullmatch(r'[\d.eE+\-]+',rt) is not None and float(rt)>=0)
  i,*t=lhs.split();j=int(i);ck(i==str(j) and 0<=j<3580 and j not in d);d[j]=tuple(t)
 return d
if len(sys.argv)==3:
 ck(data(sys.argv[1])==data(sys.argv[2]));print('PASS replay records (only CPU time ignored):',sys.argv[1],sys.argv[2]);quit()
ck(len(sys.argv)==1)
R=data('expected/ranks.tsv');S=data('expected/zero.tsv');P=data('expected/positive.tsv')
ck(set(R)==set(P)==set(S)==set(range(3580)));stats=[0]*10
for j in range(3580):
 r,s,p=R[j],S[j],P[j]
 if r==('bad-shell',):
  ck(r==s==p);stats[0]+=1;continue
 ck(len(r)==10 and r[::2]==('rank','neg','zero','pos','signatures'))
 rk,neg,zero,pos,sg=map(int,r[1::2]);ck(7<=rk<=11 and min(neg,zero,pos,sg)>=0 and neg+zero+pos<=2136)
 ck(s==('rank',str(rk),'anchored',str(zero),'first-absent',str(zero),'open','0'))
 ck(len(p)==16 and (p[0],p[2],p[4],p[6],p[12],p[14])==('rank','signatures','rows','out','pivpairs','binpairs'));ck(list(map(int,(p[1],p[3],p[5])))==[rk,sg,pos])
 miss,kill,open_,zeropiv,pszero=map(int,p[7:12]);ck(min(miss,kill)>=0 and miss+kill==pos and open_==zeropiv==0 and pszero==zero)
 stats[1]+=neg;stats[2]+=zero;stats[3]+=pos;stats[4]+=miss;stats[5]+=kill;stats[6]+=int(zero>0);stats[7]+=int(p[13]);stats[8]+=int(p[15]);stats[9]+=sg
ck(stats[0]==272 and stats[2]==94 and stats[6]==7)
print('PASS all 3,580 layouts; bad, negative, zero, positive, empty, pivot-excluded, zero-layouts, pivot-tests, binary-tests, positive signatures:',stats)
