const int hn=7,hpr[hn]={2,3,5,7,11,13,17};
int hq[hn][20]; // quadratic squareclasses, packed
struct LC {int v,s;
 LC(i128 x,int p){demand(x!=0);v=0;while(x%p==0){x/=p;v^=1;}int m=p==2?8:p;s=int((x%m+m)%m);if(p>2){int k=find(hpr,hpr+hn,p)-hpr;demand(k<hn);s=hq[k][s];}}
 LC(int v,int s,int unused):v(v),s(s){}
 LC mul(LC y,int p)const{return LC(v^y.v,p==2?(s*y.s)%8:s*y.s,0);}
 int hil(LC y,int p)const{if(p==2)return (((s-1)*(y.s-1)/4+v*(y.s*y.s-1)/8+y.v*(s*s-1)/8)&1)?-1:1;
  return (p%4==3&&v&&y.v?-1:1)*(v?y.s:1)*(y.v?s:1);}
 bool isSq(int p)const{return v==0&&s==1;}
};
array<int,hn> fh{};vector<ll> lead;
void leadinit(int P[12],int N[12]){ll h[11][11]{};for(int i=0;i<11;i++)for(int j=0;j<11;j++)h[i][j]=11*(i==j)+((i^1)==j)-4*(P[i]==j)+4*(N[i]==j)-1;
 lead.clear();ll old=1;for(int i=0;i<11;i++){ll d=h[i][i];demand(d>0);lead.push_back(d);
  for(int j=i+1;j<11;j++)for(int k=i+1;k<11;k++){i128 t=(i128)d*h[j][k]-(i128)h[j][i]*h[i][k];demand(t%old==0 && t/old<LLONG_MAX&&t/old>LLONG_MIN);h[j][k]=t/old;}old=d;}demand(lead.back()==detF);
}
void hinit(){for(int j=0;j<hn;j++){int p=hpr[j];for(int u=0;u<p;u++)hq[j][u]=-1;for(int u=1;u<p;u++)hq[j][u*u%p]=1;}}
void fhasse(){for(int j=0;j<hn;j++){int p=hpr[j],hv=1;LC prod(1,p);for(ll n:lead){LC next(n,p);LC q=next.mul(prod,p);hv*=q.hil(prod,p);prod=next;}fh[j]=hv;}}
struct Loc{
 int p=0,target=0;LC nd{0,1,0},den{0,1,0};
 void init(int j,ll a,i128 det){
  p=hpr[j];LC fac((i128)7*D,p),d0(detF,p),a0(a,p),md(det,p),x=a0.mul(fac,p),y=md.mul(a0,p).mul(fac,p);
  LC d=d0.mul(md,p);nd=LC(-1,p).mul(d,p);den=LC(D,p).mul(md,p);
  int hB=fh[j]*d0.hil(x,p)*d0.mul(x,p).hil(y,p);
  target=(p==2||p==7?-1:1)*hB*d.hil(d,p);
 }
 bool ok(i128 n)const{return n==0|| LC(n,p).mul(den,p).hil(nd,p)==target;}
};
