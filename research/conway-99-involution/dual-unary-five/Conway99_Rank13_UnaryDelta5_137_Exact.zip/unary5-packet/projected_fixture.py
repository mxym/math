"""Cross-check the scaled projection algorithm using independently constructed
integral star generators and literal bordered determinants on a real star chart.
Input (Y+,Y−,Z,Y signs) sampled from the archived real-candidate fixtures."""
import itertools,sys
from pathlib import Path
from fractions import Fraction as F
from random import Random
def det(A):
 A=[list(h)for h in A];n=len(A);s=1;p=1
 for j in range(n-1):
  i=next((i for i in range(j,n)if A[i][j]),None)
  if i is None:return 0
  if i!=j:A[i],A[j]=A[j],A[i];s=-s
  q=A[j][j]
  for i in range(j+1,n):
   for t in range(j+1,n):
    v=A[i][t]*q-A[i][j]*A[j][t]
    if v%p:raise ValueError('not exact')
    A[i][t]=v//p
  p=q
 return A[-1][-1]*s
def ck(b):
 if not b:raise ArithmeticError
def mm(v,A,w):return sum(c*d*s for i,c in enumerate(v)if c for s,d in zip(A[i],w)if d)
rows=Path('forms.txt').read_text().splitlines();ids=list(map(int,Path('layouts.tsv').read_text().splitlines()[890].split()))
data=list(map(int,rows[890].split()));idx,D,DF=data[:3];I=[data[3+i*12:15+i*12] for i in range(12)];P,N=ids[1:13],ids[13:];r=Random(9981);ck(idx==890)
S0=[[int(i==j)*11+int((i^1)==j)-4*int(P[i]==j)+4*int(N[i]==j)-1 for j in range(12)]for i in range(12)]
S=[[int(j//2==i)*(1 if j%2==0 or sign>0 else -1) for j in range(12)] for sign in(1,-1)for i in range(5 if sign==1 else 6)]
G=[[mm(v,S0,w)//4 for w in S]for v in S];ds=det(G);ck(ds*1024==DF)
Z=[];E=list(itertools.combinations(range(7),2))
for i,j in E:
 for t in(1,-1):Z.append([int(k==i)+t*int(k==j)for k in range(7)])
ip=lambda x,y:sum(i*j for i,j in zip(x,y))
Q=[list(map(int,l.split())) for l in Path('cuts5.tsv').read_text().splitlines()];Q=[h for h in Q if sum(i*i for i in h[:12])==10]
raw=Path('fixture.raw') # actual anchor support pairs (feasibility not needed for arithmetic)
states=[list(map(int,l.split()))for l in raw.read_text().splitlines()[3:]];n=0;neg=0;pos=0;zero=0
for repeat in range(3400):
 g=r.choice(Q);gA=g[:12];a=20*D-28*mm(gA,I,gA)
 if a<=0:continue
 T=F(7*ds*a,4*D);B=[row+[0,0,ip(v,gA)//2]for v,row in zip(S,G)];B+=[[0]*11+[7,0,1],[0]*11+[0,7,1],[ip(v,gA)//2 for v in S]+[1,1,1]];ck(det(B)==T)
 C=[];ff=[];wy=[];lbl=[]
 while len(ff)<3:
  j,A,Bb=r.choice(states)
  if j in lbl:continue
  f=[-4*((A>>i&1)-(Bb>>i&1))-ip(Z[i],Z[12+j]) for i in range(12)]
  if any(ip(v,f)%2 for v in S):continue
  lbl.append(j);ff.append(f);wy.append([ip(v,f)//2 for v in S]+[0,0,g[12+j]])
 W=[[10 if i==j else 0 for j in range(3)]for i in range(3)]
 for i in range(3):
  for j in range(i):W[i][j]=W[j][i]=-4*r.choice([-1,0,1])-ip(Z[12+lbl[i]],Z[12+lbl[j]])
 def direct(U,V):return det([b+[wy[i][k]for i in V]for k,b in enumerate(B)]+[wy[j]+[W[j][i]for i in V]for j in U])
 for i in range(3):
  C.append([])
  for j in range(3):
   x=D*g[12+lbl[i]]-mm(gA,I,ff[i]);y=D*g[12+lbl[j]]-mm(gA,I,ff[j])
   c=F(7*ds*(a*(D*W[i][j]-mm(ff[i],I,ff[j]))-28*x*y),4*D*D)
   ck(c==direct([i],[j]));C[i].append(c)
 U=C[0][0];M=[[F(U*C[j][k]-C[0][j]*C[0][k],T)for k in(1,2)]for j in(1,2)]
 for j in(1,2):
  for k in(1,2):ck(M[j-1][k-1]==direct([0,j],[0,k]))
 if U:
  Nq=(M[0][0]*M[1][1]-M[0][1]**2)/U;ck(Nq==direct([0,1,2],[0,1,2]));pos+=Nq>0;neg+=Nq<0;zero+=not Nq
 n+=1
print('independent real-chart direct integral bordered determinants',n,'full signs',neg,zero,pos)
