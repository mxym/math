#include <bits/stdc++.h>
#include <gmpxx.h>
using namespace std;using i128=__int128_t;using ll=long long;typedef mpz_class Big; Big cv(i128 x){bool neg=x<0;unsigned __int128 w=neg?-x:x;Big r=(unsigned long)(w>>64);r<<=64;r+=(unsigned long)w;return neg?-r:r;}using V=array<ll,12>;
void demand(bool x){if(!x)throw runtime_error("exact bounds/indices violated");}
ll dot(V const&a,V const&b){i128 w=0;for(int i=0;i<12;i++)w+=(i128)a[i]*b[i];demand(w<LLONG_MAX&&w>LLONG_MIN);return ll(w);}
using Mask=unsigned long long;
Mask base[39],slackone[39]; bool physmode=true;
Mask flipmask(Mask m){const Mask k=0xaaaaaaaaaaaaaaaaULL;return (m&1)|((m&k)<<1)|((m&(k<<1))>>1);}
struct Meta{unsigned sm=0,tm=0;int d;V v,av;ll nu;Mask mask=0;bool paired=false; Mask twin=0,tight=0,slack=0,twinTight=0,twinSlack=0;};
bool explicit43(Meta const&x,Meta const&y,int l){
 if(!physmode)return true;
 Mask m[4]={x.mask,flipmask(x.mask),y.mask,flipmask(y.mask)};
 for(int intensity=abs(l);intensity<=2;intensity+=2){
  if(intensity==2&&(x.paired||y.paired))continue;
  Mask A[43]={};copy(base,base+39,A);copy(m,m+4,A+39);
  for(int i=0;i<4;i++)for(Mask q=m[i];q;q&=q-1)A[__builtin_ctzll(q)]|=1ULL<<(39+i);
  for(int i=0;i<2;i++)for(int j=0;j<2;j++)if(intensity==2||(intensity==1&&(l==1)==(i==j))){A[39+i]|=1ULL<<(41+j);A[41+j]|=1ULL<<(39+i);}
  bool ok=true;for(int i=0;i<43&&ok;i++)for(int j=i+1;j<43;j++)if(__builtin_popcountll(A[i]&A[j])>2-int((A[i]>>j)&1)){ok=false;break;}
  if(ok)return true;
 }return false;
}

void initcap(){
 for(int i=0;i<39;i++){slackone[i]=0;for(int j=0;j<39;j++)if(i!=j&&2-int((base[i]>>j)&1)-__builtin_popcountll(base[i]&base[j])<=1)slackone[i]|=1ULL<<j;}

}
bool compactcaps(Meta const&a,Meta const&b,int l,bool doubleedge){
 Mask w=a.mask,t=a.twin,r=b.mask,s=b.twin;bool p=doubleedge||l==1,n=doubleedge||l==-1;
 if(doubleedge&&(a.paired||b.paired))return false;
 if(__builtin_popcountll(w&r)+p>2||__builtin_popcountll(w&s)+n>2)return false;
 if(p&&((a.tight&r)||(b.tight&w)))return false;
 if(n&&((a.tight&s)||(b.tight&t)))return false;
 if(doubleedge&&((a.slack&r&s)||(b.slack&w&t)))return false;
 for(Mask u:{w,t})for(Mask v:{r,s}){Mask o=u&v;
  for(Mask y=o;y;y&=y-1){int i=__builtin_ctzll(y);if(slackone[i]&o)return false;
   if(((w&t)>>i&1)&&((w&t&o)&~(1ULL<<i)))return false;
   if(((r&s)>>i&1)&&((r&s&o)&~(1ULL<<i)))return false;
  }
 }return true;
}
bool physical(Meta const&a,Meta const&b,int l){
 bool ret=compactcaps(a,b,l,false);if(!l&&!ret)ret=compactcaps(a,b,0,true);
 #ifdef CAPCHECK
 if(ret!=explicit43(a,b,l))throw runtime_error("caps mismatch");
 #endif
 return ret;
}
struct X{int j;ll x,y;i128 nu;float sq;};
const vector<int> pr={17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193};
int qr[40][200];ll D,detF;int z[42][7],zd[30][30];V I[12];vector<Meta> md;
using Sig=array<int,24>;using Row=array<int,84>;
ll smod(i128 x,int p){ll w=x%p;return w<0?w+p:w;}
#include "local.hpp"

#include "smallint.hpp"
#include "allpr.hpp"

#include "broad5.hpp"
namespace old {
#include "legacy/real.hpp"
}
using Root=array<int,42>;
vector<Root> Gs;ll depPairs=0;
void readG(){
 ifstream q("cuts5.tsv");Root r{};while(q>>r[0]){for(int i=1;i<42;i++)q>>r[i];Gs.push_back(r);}demand(Gs.size()==7476);
 int k=0;for(int a=0;a<7;a++)for(int b=a+1;b<7;b++)for(int sign:{1,-1}){z[k][a]=1;z[k][b]=sign;k++;}
 for(int i=0;i<30;i++)for(int j=0;j<30;j++)for(int a=0;a<7;a++)zd[i][j]+=z[i+12][a]*z[j+12][a];
 for(int i=0;i<(int)pr.size();i++)for(int j=0;j<pr[i];j++)qr[i][j*j%pr[i]]=1;
}
int main(int argc,char**argv){
 primeinit();hinit();readG();loadA(argc>4?atoi(argv[4]):20);ifstream f("forms.txt"),p("layouts.tsv");int id,r,lo=argc>1?atoi(argv[1]):0,hi=argc>2?atoi(argv[2]):3580,step=argc>3?atoi(argv[3]):1;ll total=0;
 for(;;){if(!(f>>id>>D>>detF))break;demand(D>0&&D<1000000000&&detF>0);for(auto&v:I)for(auto&w:v)f>>w;
  int P[12],N[12];p>>r;for(int&a:P)p>>a;for(int&a:N)p>>a;if(id<lo||id>=hi||(id-lo)%step)continue;
  leadinit(P,N);fhasse();fcach.clear();clock_t tm=clock();old::Shell sh(P,N);if(!sh.admissible){cout<<id<<" bad-shell\n"<<flush;continue;}
  old::Form F(P,N);old::RForm sg(F,P,N,1),un(F,P,N,0);demand(sg.det==D);
  for(int a=0;a<12;a++)for(int b=0;b<12;b++)demand(I[a][b]==sg.D[a][b]);
  copy(sh.G,sh.G+39,base);initcap();sh.gen();md.clear();for(int k=0;k<30;k++)for(auto q:sh.domain[k]){
   int f[12],u[12];ll pf[12],pu[12],nf,nu;bool bad=false;
   for(int j=0;j<12;j++){int a=(q.a>>j)&1,b=(q.b>>j)&1;if(a&&b&&P[j]==N[j])bad=true;f[j]=-4*(a-b)-sh.z[k][j];u[j]=1-abs(sh.z[k][j])-2*(a+b);}
   if(bad||!sg.project(f,pf,nf,10)||!un.project(u,pu,nu,5))continue;
   Meta m;m.sm=q.a;m.tm=q.b;m.mask=q.mask;m.twin=flipmask(m.mask);for(int k=0;k<39;k++){int t=2-((m.mask>>k)&1)-__builtin_popcountll(base[k]&m.mask);if(t==0)m.tight|=1ULL<<k;if(t==1)m.slack|=1ULL<<k;}m.paired=(q.a&q.b)!=0;m.d=k;for(int i=0;i<12;i++){m.v[i]=f[i];m.av[i]=pf[i];}m.nu=nf;md.push_back(m);
  }
 ll ct[5]{},tests=0,checks=0,ng=0,rows=0;for(auto&[local,fs]:byAxis){
  V v;for(int i=0;i<12;i++)v[i]=dot(I[i],local);if(!anchorok(local,P,N))continue;ll a=energy*D-28*dot(local,v);if(a<0)continue;if(!a){ct[4]+=fs.size();continue;}ng++;
  Ternary ter(a,v,local);for(auto ii:fs){auto&g=fullA[ii];ct[ter.check(g)]++;rows++;}tests+=ter.pairtests;checks+=ter.binchecks;
 }
 cout<<id<<" rank "<<r<<" signatures "<<ng<<" rows "<<rows<<" out";for(auto x:ct)cout<<" "<<x;cout<<" pivpairs "<<tests<<" binpairs "<<checks<<" cpu "<<double(clock()-tm)/CLOCKS_PER_SEC<<endl;
 }}
