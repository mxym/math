from pathlib import Path
import sys
def need(v):
 if not v:raise ValueError('bad local input')
def det(A):
 prev=1
 for i in range(len(A)-1):
  p=A[i][i];need(p>0)
  for j in range(i+1,len(A)):
   for k in range(i+1,len(A)):
    t=p*A[j][k]-A[j][i]*A[i][k];q,r=divmod(t,prev);need(r==0);A[j][k]=q
  prev=p
 return A[-1][-1]
L=Path('layouts.tsv').read_text().splitlines();G=Path('forms.txt').read_text().splitlines();need(len(L)==len(set(L))==len(G)==3580)
for id,(lay,row) in enumerate(zip(L,G)):
 r,*v=map(int,lay.split());P,N=v[:12],v[12:];k,D,d,*y=map(int,row.split());need(len(y)==144 and k==id and 0<D<10**9 and r in range(7,12))
 F=[[11*(i==j)+((i^1)==j)-4*(P[i]==j)+4*(N[i]==j)-1 for j in range(12)] for i in range(12)];need(not any(map(sum,F)))
 need(d==det([q[:11] for q in F[:11]]))
 for i in range(12):
  for j in range(12):need(sum((F[i][q]+1)*y[12*q+j] for q in range(12))==D*(i==j))
print('PASS all 3580 exact cofactor and inverse forms')
