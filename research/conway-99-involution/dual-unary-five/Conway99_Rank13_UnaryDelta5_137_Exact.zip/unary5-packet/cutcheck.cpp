#include <bits/stdc++.h>
using namespace std;int main(){set<array<int,42>> got,ref;array<int,42>a;ifstream in("cuts5.tsv");while(in>>a[0]){for(int i=1;i<42;i++)in>>a[i];if(!in||!ref.insert(a).second)abort();}
for(int u=0;u<7;u++)for(int v=u+1;v<7;v++){
 vector<array<int,4>>E;int id=0;for(int i=0;i<7;i++)for(int j=i+1;j<7;j++)for(int s:{1,-1}){if((i==u||i==v)!=(j==u||j==v))E.push_back({id,i,j,s});id++;}
 if(E.size()!=20)abort();int z[7]={};a.fill(0);function<void(int)>dfs=[&](int i){if(i==20){if(all_of(z,z+7,[](int t){return !t;}))got.insert(a);return;}auto [k,p,q,s]=E[i];for(int val:{1,-1}){if(!i&&val<0)continue;z[p]+=val;z[q]+=s*val;a[k]=val;dfs(i+1);z[p]-=val;z[q]-=s*val;}};dfs(0);
}if(got!=ref||got.size()!=7476)abort();cout<<"PASS direct +/- DFS: all 7,476 normalized rows on all 21 cuts."<<endl;}
