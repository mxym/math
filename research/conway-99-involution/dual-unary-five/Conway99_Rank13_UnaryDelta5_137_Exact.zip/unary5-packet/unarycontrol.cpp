#define main actual_search_main
#include "broad5.cpp"
#undef main
using V6=array<ll,6>;
ll dp(V6 const&u,V6 const&v){ll n=0;for(int i=0;i<6;i++)n+=u[i]*v[i];return n;}
Big detx(vector<V6> a,vector<V6>b){int n=a.size();vector<vector<Big>>M(n,vector<Big>(n));for(int i=0;i<n;i++)for(int j=0;j<n;j++)M[i][j]=cv(dp(a[i],b[j]));
 // Arbitrary-precision recursive cofactor expansion, no pivot assumptions.
 auto rec=[&](auto&&self,int row,int mask)->Big{if(!mask)return 1;Big u=0;int sign=1;for(int i=0;i<n;i++)if(mask>>i&1){u+=sign*M[row][i]*self(self,row+1,mask^(1<<i));sign=-sign;}return u;};
 return rec(rec,0,(1<<n)-1);}
int main(){hinit();primeinit();detF=1024;lead=vector<ll>(10,1);lead.push_back(1024);fhasse();
 V6 c={0,0,2,1,1,1},d={0,0,-1,2,-1,1},r={0,0,-1,1,2,-1},t={0,0,-1,-1,1,2}; // quaternion columns
 demand(dp(c,c)==7&&dp(d,d)==7&&dp(r,r)==7&&dp(t,t)==7&&dp(c,d)==0&&dp(c,r)==0&&dp(c,t)==0&&dp(d,r)==0&&dp(d,t)==0&&dp(r,t)==0);
 mt19937_64 rng(91257);int total=0,half=0,zeros=0,deg=0,hits=0,frac=0,shift=0; 
 for(int it=0;it<800;it++){D=1+rng()%128;int s=1+(it%3==0);V6 u;for(auto&z:u){z=(int)(rng()%7)-3;if(s==2)z=2*z+1;}if(s==1&&it%5==0)u={0,0,-1,-1,-1,0};ll de=7*dp(u,u)-dp(u,c)*dp(u,c)-dp(u,d)*dp(u,d);
 if(de==0)continue;ll a=4*D*de/(s*s);demand(4*D*de==a*s*s);int add=0;
 array<V6,3>v;for(auto&v0:v){for(int i=0;i<6;i++)v0[i]=0;v0[0]=(int)(rng()%7)-3;v0[1]=(int)(rng()%7)-3;
 int x=(int)(rng()%5)-2,y=(int)(rng()%5)-2;for(int i=2;i<6;i++)v0[i]=x*r[i]+y*t[i];if(s==2&&dp(v0,v0)%2)v0[0]++;demand(dp(u,v0)%s==0);}
 if(it%7==0)v[2]=v[1];if(it%13==0)v[0]={};if(it%17==0)v[2]={};
 ll T=7*s*s*a/(4*D);demand(T==49*dp(u,u)-7*dp(u,c)*dp(u,c)-7*dp(u,d)*dp(u,d));Scale st;st.init(7*s*s,(i128)4*D*D);vector<V6>b={c,d,u};demand(cv(T)==detx(b,b));ll Q[3][3];
 for(int j=0;j<3;j++)for(int k=0;k<3;k++){auto U=b,V=b;U.push_back(v[j]);V.push_back(v[k]);ll x=D*dp(u,v[j])/s,y=D*dp(u,v[k])/s;
 Q[j][k]=st((i128)a*D*dp(v[j],v[k])-28*(i128)x*y);demand(cv(Q[j][k])==detx(U,V));}
 total++;half+=s==2;frac+=dp(c,u)%7!=0||dp(d,u)%7!=0;hits+=de==5;
 ll N=Q[0][0];if(!N){zeros++;continue;}Scale dt,dn;dt.init(1,T);dn.init(1,N);ll M[2][2];for(int j=1;j<3;j++)for(int k=1;k<3;k++){
 M[j-1][k-1]=dt((i128)N*Q[j][k]-(i128)Q[0][j]*Q[0][k]);auto U=b,V=b;U.push_back(v[0]);V.push_back(v[0]);U.push_back(v[j]);V.push_back(v[k]);demand(cv(M[j-1][k-1])==detx(U,V));}
 for(int k=0;k<2;k++){ll ny=M[k][k];for(int j=0;j<hn;j++){Htest h;h.setup(j,a,T,N);demand(h.test(ny));}for(int p:smallpr){if(p>131)break;if(p>17&&N%p&&legend(-N,p)==-1)demand(SimpleInert(p).ok(ny));}}
 ll f=dn((i128)M[0][0]*M[1][1]-(i128)M[0][1]*M[0][1]);auto V=b;for(auto&w:v)V.push_back(w);demand(cv(f)==detx(V,V)&&isquare(f));if(!f)deg++;
 for(int l:{-1,0,1}){ll c0=M[0][1]+4*l*N;ll q0=dn((i128)M[0][0]*M[1][1]-(i128)c0*c0);demand(q0+8*l*c0-16*l*l*N==f);shift++;}
 }
 cout<<"unimodular 17D controls "<<total<<" half-characteristic "<<half<<" fractional marked projections "<<frac<<" delta5 "<<hits<<" zero pivots "<<zeros<<" singular final Grams "<<deg<<" signed shifts "<<shift<<" all exact minors and local tests pass\n";
}
