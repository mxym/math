/* Independent reconstruction of admissible anchor graph and positive, zero
   and negative Schur assignment counts. No physical search code reused. */
#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
using namespace std;
using B=array<int,12>;
using M=unsigned long long;
void need(bool x){if(!x)throw runtime_error("unexpected input");}
bool possible(B P,B N){array<M,39> A{};
 auto add=[&](int i,int j){need(i!=j);A[i]|=1ULL<<j;A[j]|=1ULL<<i;};
 for(int h=0;h<7;h++)for(int t=0;t<2;t++){add(0,1+2*h+t);add(1+2*h,2+2*h);}
 for(int i=0;i<12;i++)for(int s=0;s<2;s++){int v=15+2*i+s;
 add(v,1+s);add(v,3+2*(i/2)+(s^(i&1)));add(v,15+2*P[i]+s);add(v,15+2*N[i]+(s^1));}
 for(int i=0;i<39;i++)for(int j=0;j<i;j++)if(__builtin_popcountll(A[i]&A[j])+((A[i]>>j)&1)>2)return false;
 return true;}
int main(){ifstream C("cuts5.tsv"),L("layouts.tsv"),F("forms.txt");int r,q;map<B,int> anchored;
 int nr=0,ir;while(C>>ir){B v;v[0]=ir;for(int i=1;i<42;i++){need(bool(C>>ir));if(i<12)v[i]=ir;}int w=0;for(int t:v)w+=t*t;if(w==10)++anchored[v];nr++;}
 need(nr==7476&&anchored.size()==756);int nrac=0;for(auto &it:anchored)nrac+=it.second;need(nrac==2136);int id=0;
 while(L>>r){B P,N;for(int&v:P)need(bool(L>>v));for(int&v:N)need(bool(L>>v));int j;long long D,F0,I[12][12];need(bool(F>>j>>D>>F0)&&j==id);for(auto&row:I)for(auto&v:row)need(bool(F>>v));
 int counts[3]={};int gpos=0;
 if(!possible(P,N)){cout<<id<<" bad-shell\n";id++;continue;}
 for(auto const&entry:anchored){auto g=entry.first;int h=-1;for(int i=0;i<6;i++)if(!g[2*i]&&!g[2*i+1]){need(h<0);h=i;}need(h>=0);
 bool good=true;for(int i=0;i<12;i++){int avail=(i/2==h?2:4),s=-4*g[i];
 for(int k=0;k<12;k++){int p=P[i]==k,n=N[i]==k;if(k/2==h)avail-=p+n;s-=(p-n)*g[k];}
 if(s>avail||s< -avail||((avail+s)%2)){good=false;break;}}
 if(!good)continue;__int128 a=(__int128)20*D;for(int i=0;i<12;i++)for(int k=0;k<12;k++)a-=(__int128)28*g[i]*I[i][k]*g[k];
 counts[a<0?0:a==0?1:2]+=entry.second;gpos+=a>0;}
 cout<<id<<" rank "<<r<<" neg "<<counts[0]<<" zero "<<counts[1]<<" pos "<<counts[2]<<" signatures "<<gpos<<"\n";id++;}need(id==3580);}
