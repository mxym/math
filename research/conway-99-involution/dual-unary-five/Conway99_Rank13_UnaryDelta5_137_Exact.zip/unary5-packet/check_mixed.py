"""Independent, exact integer check of the 283 selected dual pairs. No shell enumeration necessary."""
from pathlib import Path
import json,itertools
from collections import Counter
root=Path('census')
model={'I17':(['B17'],[]),'E8':(['B9','E8'],[]),'D12p':(['B5','D12'],[[[],[12]]]),'E7x2':(['B3','E7','E7'],[[[],[6],[6]]]),'A15p':(['B2','A15'],[[[],[4]]]),'D8x2':(['B1','D8','D8'],[[[],[8],[1]],[[],[1],[8]]]),'A11E6':(['A11','E6'],[[[2],[1]]])}
def chk(v):
 if not v:raise ValueError('witness verification failed')
def gen(name):
 blocks,labels=model[name];T=[[0]*17 for i in range(17)];offset=0;sz=[]
 for B in blocks:
  g=list(map(int,(root/(B+'.form')).read_text().splitlines()[-1].split()));d=g.pop(0);k=int(B[1:]);sz.append(k);chk(48%d==0 and k*k==len(g))
  for i in range(k):
   for j in range(k):T[i+offset][j+offset]=g[k*i+j]*48//d
  offset+=k
 chk(offset==17)
 def cov(u):return tuple(sum(v*w for v,w in zip(u,row)) for row in T)
 def ip(u,v):
  n=sum(a*b for a,b in zip(cov(u),v));chk(n%48==0);return n//48
 S={(0,)*17}
 for l in labels:
  off=0;u=[0]*17
  for k,w in zip(sz,l):
   for j in w:u[off+j-1]+=1
   off+=k
  t=cov(u); stack=list(S)
  while stack:
   v=tuple((a+b)%48 for a,b in zip(stack.pop(),t))
   if v not in S:S.add(v);stack.append(v)
 def contains(v):return len(v)==17 and tuple(a%48 for a in cov(v)) in S
 diag=[]
 for B in blocks:
  k=int(B[1:]);diag.extend(([2]*(k-1)+[1])if B.startswith('B') else [2]*k)
 def char(v):
  if any((x-d)%2 for x,d in zip(v,diag)):return False
  for lab in labels:
   u=[0]*17;o=0
   for k,ls in zip(sz,lab):
    for j in ls:u[o+j-1]+=1
    o+=k
   if (ip(v,u)-ip(u,u))%2:return False
  return True
 return ip,contains,char
M={n:gen(n) for n in model};pairs={n:[json.loads(l) for l in (root/(n+'.reps')).read_text().splitlines()] for n in model}
L=(root/'K_classes.tsv').read_text().splitlines();W=[json.loads(l) for l in Path('mixed.jsonl').read_text().splitlines()];chk(len(L)==len(W)==283)
counts=Counter(); ordinary5=[]
for i,(l,w) in enumerate(zip(L,W)):
 j,key,*_=l.split();n,k=key.split(':');k=int(k);chk(int(j)==i==w['K'] and n==w['model'] and k==w['mark']);q=pairs[n][k]
 c,d=([v for b in q for v in b[h]] for h in (0,1));u,v=w['uv'];ip,contains,char=M[n];chk(all(contains(a)for a in(c,d,u,v)))
 chk(ip(c,c)==ip(d,d)==7 and ip(c,d)==0)
 div=w['coeff'];chk(len(div)==2 and all(z in (1,2)for z in div))
 for y,a in zip([u,v],div):
  if a==2:chk(char(y))
 G=[];Q=[u,v]
 for j,x in enumerate(Q):
  line=[]
  for k,y in enumerate(Q):
   nr=4*(7*ip(x,y)-ip(x,c)*ip(y,c)-ip(x,d)*ip(y,d));den=div[j]*div[k];chk(nr%den==0);line.append(nr//den)
  G.append(line)
 chk(G==w['G'] and 0<G[0][0]<=G[1][1]<=32 and G[0][0]*G[1][1]>G[0][1]**2)
 counts[G[1][1]]+=1
 if any(div[k]==1 and G[k][k]==20 for k in range(2)):ordinary5.append(i)
print('PASS all 283 mixed ordinary/half-characteristic row witnesses, energies',sorted(counts.items()))

chk(len(ordinary5)==137)
print('PASS 137 distinct K with explicit integral lift of Delta=5:', *ordinary5)
prev={w['K'] for w in map(json.loads,Path('prior-realwitnesses.jsonl').read_text().splitlines()) if w['M'][0]==w['M'][2]==5}
chk(len(prev)==46 and prev<=set(ordinary5) and len(set(ordinary5)-prev)==91)
print('PASS prior published 46 form a subset: 91 further K excluded, 146 not excluded here.')
