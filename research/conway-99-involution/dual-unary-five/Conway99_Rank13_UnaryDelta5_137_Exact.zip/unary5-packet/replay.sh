#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p work
CXX=${CXX:-g++}
FLAGS=(-O3 -std=c++17 -mpopcnt)
"$CXX" "${FLAGS[@]}" catalog.cpp -o work/catalog
work/catalog > work/layouts.tsv 2>work/burnside.txt
cmp layouts.tsv work/layouts.tsv
python3 check_inputs.py
python3 check_mixed.py
"$CXX" "${FLAGS[@]}" cutcheck.cpp -o work/cutcheck
work/cutcheck
python3 projected_fixture.py
"$CXX" "${FLAGS[@]}" unarycontrol.cpp -lgmpxx -lgmp -o work/unarycontrol
work/unarycontrol > work/unarycontrol.txt
cmp work/unarycontrol.txt expected/controls.txt
"$CXX" "${FLAGS[@]}" rowaudit.cpp -o work/rowaudit
work/rowaudit > work/ranks.tsv
cmp work/ranks.tsv expected/ranks.tsv
"$CXX" "${FLAGS[@]}" zero5.cpp -lgmpxx -lgmp -o work/zero5
work/zero5 > work/zero.tsv
cmp expected/zero.tsv work/zero.tsv
"$CXX" "${FLAGS[@]}" broad5.cpp -lgmpxx -lgmp -o work/broad5
if [ "${1:-full}" = quick ]; then
 work/broad5 890 891 1 > work/positive-pilot.tsv
 python3 checkledger.py expected/pilot.tsv work/positive-pilot.tsv
elif [ "${1:-full}" = full ]; then
 work/broad5 0 3580 1 > work/positive.tsv
 python3 checkledger.py expected/positive.tsv work/positive.tsv
else echo 'expected quick or full' >&2;exit 2;fi
python3 checkledger.py
