int legend(ll a,int p){
 a%=p;if(a<0)a+=p;demand(a!=0);int s=1;ll b=p;while(a){int t=__builtin_ctzll(a);a>>=t;if((t&1)&&(b%8==3||b%8==5))s=-s;if(a%4==3&&b%4==3)s=-s;ll w=a;a=b%a;b=w;}demand(b==1);return s;
}
struct PC{
 int v,s;PC(i128 a,int p){demand(a!=0);v=0;while(a%p==0){a/=p;v^=1;}s=legend((ll)(a%p),p);}
 PC(int a,int b,bool):v(a),s(b){}
 PC mul(PC z)const{return PC(v^z.v,s*z.s,true);}
 int hil(PC z,int p)const{return (p%4==3&&v&&z.v?-1:1)*(v?z.s:1)*(z.v?s:1);}
};
map<int,int> fcach;
struct PL{
 int p,target; PC minus,d0;
 PL(int p_,ll T,ll a,i128 det):p(p_),minus(-(i128)T,p),d0(T,p){
  int hf=1;if(fcach.count(p))hf=fcach[p];else{PC b(1,p);for(ll m:lead){PC w(m,p);hf*=w.mul(b).hil(b,p);b=w;}fcach[p]=hf;}
  PC d0f(detF,p),fac(7*(i128)D,p),aa(a,p),dt(det,p),x=aa.mul(fac),y=dt.mul(aa).mul(fac);
  int hB=hf*d0f.hil(x,p)*d0f.mul(x).hil(y,p);target=hB*d0.hil(d0,p); // p>17, h(K)=+1
 }
 bool impossible()const{return !minus.v&&minus.s==1&&target<0;}
 bool ok(ll n)const{if(n==0)return true;return PC(n,p).mul(d0).hil(minus,p)==target;}
};
vector<int> smallpr;
void primeinit(){for(int i=2;i<50000;i++){bool prime=1;for(auto p:smallpr){if(p*p>i)break;if(i%p==0){prime=0;break;}}if(prime)smallpr.push_back(i);}}
struct SimpleInert{ul inv,th;int p;SimpleInert(int p_):p(p_){inv=p;for(int i=0;i<6;i++)inv*=ul(2)-inv*p;th=UINT64_MAX/p;}
 bool ok(ul n)const{if(n==0)return true;ul v=n*inv;if(v>th)return true;bool odd=1;for(;;){v*=inv;if(v>th)break;odd=!odd;}return !odd;}
};
