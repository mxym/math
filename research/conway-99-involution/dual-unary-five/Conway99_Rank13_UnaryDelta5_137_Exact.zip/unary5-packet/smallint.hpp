using u128=unsigned __int128;using ul=uint64_t;
inline i128 gcd128(i128 a,i128 b){while(b){i128 r=a%b;a=b;b=r;}return a;}
struct Scale{
 i128 num=1,den=1,mask=0;int sh=0;ul mult=1;
 void init(i128 n,i128 d){
  demand(n>0&&d>0);i128 g=gcd128(n,d);num=n/g;den=d/g;i128 t=den;sh=0;while(!(t&1)){sh++;t>>=1;}demand(sh<=60);mask=(i128(1)<<sh)-1;
  ul odd=ul(t),inv=odd;for(int i=0;i<6;i++)inv*=ul(2)-odd*inv;demand(odd*inv==1);mult=inv*ul(num);
 }
 ll operator()(i128 x)const{
  demand((x&mask)==0);ul r=ul(u128(x)>>sh)*mult;
  ll k=(r<=LLONG_MAX)?ll(r): -1-ll(~r);
  demand(den*(i128)k==num*x);return k;
 }
};
inline bool isquare(ll n){
 if(n<0)return false;
 const uint64_t sq=0x0202021202030213ULL;
 if(!((sq>>(n&63))&1))return false;
 ll s=(ll)sqrt((double)n);
 while(s*s>n)s--;while((s+1)*(s+1)<=n)s++;return s*s==n;
}
