"""Exact labelled signed row counts. No shells or L except for stated ordinary coordinate bound/empty cut.
Choose one fixed cut of cardinality s. Dividing by 2 gives the global-sign
normalization, NOT a quotient by permutations. Two abs=3 forbidden at E=20/24
by pointwise Cauchy with norm-10 w. Delta5 additionally only permits cut 2."""
from functools import cache
from itertools import product
from math import comb
import sys,time

@cache
def opts(cross,cap,characteristic):
 p,q=(0,1) if characteristic else (cross,cross)
 # ordinary both even/odd on each edge, branch in coordinates for half form.
 # char plus even minus odd; use Zq coordinates directly, not half.
 return tuple(((a+b)//(1 if characteristic else 2),(a-b)//(1 if characteristic else 2),a*a+b*b-p-q)
   for a,b in product(range(-cap,cap+1),repeat=2) if (a-p)%2==0 and (b-q)%2==0)

def count(s,E,char=False):
 cap=(3 if char or E>=28 else 2);base=21 if char else 2*s*(7-s)
 @cache
 def rec(t,A,B,extra):
  if not A and not B:return int(extra==0)
  if A:A=list(A);v=A.pop(0);sa=1
  else:B=list(B);v=B.pop(0);sa=0
  C=list(A)+list(B);n=len(C);aa=len(A)
  # normalized residual imbalances of unseen vertices. Residual v already includes
  # all earlier edges. Vertex signs preserve the ordinary cut, but for char the
  # fixed + even/- odd convention only permutations (and total sign) survive.
  def norm(P):
   return tuple(sorted(P if char else [abs(x) for x in P]))
  comp={}
  def dfs(i,budget,w):
   if i==n:
    if w==0:
     k=(norm(C[:aa]),norm(C[aa:]),budget)
     comp[k]=comp.get(k,0)+1
    return
   cross=(i>=aa) if sa else False
   old=C[i]
   for d,h,k in opts(int(cross),cap,char):
    if k<=budget:
     C[i]=old+h
     dfs(i+1,budget-k,w+d)
   C[i]=old
  dfs(0,extra,v)
  return sum(mul*rec(t+1,A2,B2,remain) for (A2,B2,remain),mul in comp.items())
 return rec(0,(0,)*s,(0,)*(7-s),E-base) if E>=base else 0

if __name__=='__main__':
 for E in map(int,sys.argv[1:] or [20,21,24,28,29,32]):
  tm=time.monotonic()
  if E%2:
   c=count(0,E,True); print(E,'fixed positive/negative convention',c,'full rows up to overall sign',c*32,flush=True)
  else:
   z=[count(s,E) if E!=20 or s==2 else 0 for s in [1,2,3]]
   print(E,'per fixed cut',z,'all cuts up to overall sign',sum(c*comb(7,s) for s,c in enumerate(z,1))//2,'seconds',round(time.monotonic()-tm,2),flush=True)
