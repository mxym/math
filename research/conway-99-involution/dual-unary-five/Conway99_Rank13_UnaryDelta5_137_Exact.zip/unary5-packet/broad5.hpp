using R42=array<signed char,42>;
map<V,vector<int>>byAxis;vector<R42>fullA;int energy=20,ss=1;
void addA(R42 r){V x;for(int i=0;i<12;i++)x[i]=r[i];if(energy==20&&dot(x,x)!=10)return;byAxis[x].push_back(fullA.size());fullA.push_back(r);}
void loadA(int e){
 energy=e;demand(e==20||e==21);ss=e==21?2:1;
 if(e==20){ifstream f("cuts5.tsv");int k;R42 r;while(f>>k){r[0]=k;for(int j=1;j<42;j++){f>>k;r[j]=k;}addA(r);}}
 else throw runtime_error("this replay only accepts ordinary E20 rows");
}
int second(V const&g){int q=-1;for(int j=0;j<6;j++)if(!g[2*j]&&!g[2*j+1]){demand(q<0);q=j;}demand(q>=0);return q;} 
bool anchorok(V const&g,int P[12],int N[12]){if(energy!=20)return true;int q=second(g);
 for(int y=0;y<12;y++){ll n=(y/2==q?2:4)-(P[y]/2==q)-(N[y]/2==q);ll b=-4*g[y]-g[P[y]]+g[N[y]];if(abs(b)>n||(n-b)%2)return false;}return true;}
bool outerok(Meta const&m,V const&g,int q,int t){
 ll b=-4*t;for(int i=0;i<12;i++)b-=g[i]*(((m.sm>>i)&1ll)-((m.tm>>i)&1ll));
 int n=4-2*abs(z[12+m.d][q+1])-__builtin_popcount((m.sm>>(2*q))&3)-__builtin_popcount((m.tm>>(2*q))&3);
 return abs(b)<=n&&(n-b)%2==0;}
struct P3 {int k;ll x,n;};
struct P2 {P3 const*p;ll c,n;};
struct Htest {LC targetc{0,1,0};int hv,p;
 bool test(ll n)const{return !n||LC(n,p).hil(targetc,p)==hv;}
 void setup(int i,ll a,ll T,ll n){
 p=hpr[i];LC A=LC(a,p).mul(LC(28*(i128)D,p),p),B=LC(n,p).mul(LC(T,p),p),dF(detF,p),d(n,p);
 targetc=LC(-1,p).mul(d,p);int hB=fh[i]*dF.hil(A,p)*dF.mul(A,p).hil(B,p);
 hv=(p==2||p==7?-1:1)*hB*d.hil(d,p)*d.hil(targetc,p);
 }
};
struct Ternary{
 ll a,T;Scale ns,divT;vector<P3> pool[30][3];ll pairtests=0,binchecks=0;
 Ternary(ll aa,V const&v,V const&g):a(aa){int o=energy==20?second(g):0;
  ll ds=detF/1024;demand(ds*1024==detF);Scale st;st.init(7*ss*ss*ds,4*D);T=st(a);ns.init(7*ss*ss*ds,(i128)4*D*D);divT.init(1,T);
  for(int j=0;j<md.size();j++){auto&m=md[j];ll w=dot(v,m.v);for(int h=-1;h<=1;h++){
   if(energy==20&&!outerok(m,g,o,h))continue;ll x=D*h-w;i128 nu=(i128)m.nu*a-28*(i128)x*x;if(nu>=0){ll n=ns(nu);demand(n>=0&&n<=10*T);pool[m.d][1+h].push_back({j,x,n});}
  }}
 }
 ll ip0(P3 const&x,P3 const&y){ll v=0;for(int i=0;i<12;i++)v+=md[x.k].av[i]*md[y.k].v[i];
  return ns((-(i128)D*zd[md[x.k].d][md[y.k].d]-v)*a-28*(i128)x.x*y.x);}
 struct Pivot{
  Ternary&U;P3 const&x;Scale divN;Htest H[hn];unordered_map<ll,bool>cache;vector<SimpleInert>inert;
  vector<P2> P[30];Pivot(Ternary&u,P3 const&xx):U(u),x(xx){divN.init(1,x.n);
   for(int i=0;i<hn;i++)H[i].setup(i,U.a,U.T,x.n);
   for(auto p:smallpr){if(p>131)break;if(p>17&&x.n%p&&legend(-x.n,p)==-1)inert.emplace_back(p);}}
  bool gen(int d,vector<P3>const&ys){auto&out=P[d];for(auto&y:ys){ll c0=U.ip0(x,y);
    auto h0=U.divT((i128)x.n*y.n-(i128)c0*c0);for(int l=-1;l<=1;l++){ll c=c0-4*l*U.T;
     ll n=h0+8*l*c0-16*l*l*U.T;if(n<0)continue;auto it=cache.find(n);bool ok=1;if(it==cache.end()){
      for(auto&h:inert)if(!h.ok(n)){ok=0;break;}for(int j=0;j<hn&&ok;j++)ok=H[j].test(n);cache[n]=ok;}else ok=it->second;
     if(ok&&physical(md[x.k],md[y.k],l))out.push_back({&y,c,n});
    }U.pairtests++;
   }return !out.empty();}
  bool match(P2 const&y,P2 const&z){U.binchecks++;ll cyz=U.ip0(*y.p,*z.p),c0=U.divT((i128)x.n*cyz-(i128)y.c*z.c);
   ll q=divN((i128)y.n*z.n-(i128)c0*c0);
   for(int l=-1;l<=1;l++)if(isquare(q+8*l*c0-16*l*l*x.n)&&physical(md[y.p->k],md[z.p->k],l))return true;
   return false;}
  bool any(int i,int j){for(auto&y:P[i])for(auto&z:P[j])if(match(y,z))return true;return false;}
  vector<int>keys;vector<P2 const*>picked;
  bool dfs(int i,int end){if(i==end)return true;for(auto&y:P[keys[i]]){bool ok=1;for(auto*p:picked)if(!match(*p,y)){ok=0;break;}
    if(ok){picked.push_back(&y);if(dfs(i+1,end))return true;picked.pop_back();}}return false;}
  bool possible(vector<int> const& ids,R42 const&row){for(int k=1;k<30;k++){int d=ids[k];if(!gen(d,U.pool[d][1+row[d+12]]))return false;
    if(k==2&&!any(ids[1],d))return false;
    if(k==3&&(!any(ids[1],d)||!any(ids[2],d)))return false;
   }
   keys.assign(ids.begin()+1,ids.end());stable_sort(keys.begin(),keys.end(),[&](int i,int j){return P[i].size()<P[j].size();});return dfs(0,8);
  }
 };
 int check(R42 const&r){vector<int>ids(30);iota(ids.begin(),ids.end(),0);
  auto key=[&](int i){auto&p=pool[i][1+r[i+12]];return make_pair(any_of(p.begin(),p.end(),[](auto&y){return !y.n;}),p.size());};stable_sort(ids.begin(),ids.end(),[&](int i,int j){return key(i)<key(j);});
  if(key(ids[0]).second==0)return 0;int pivot=ids[0];for(auto&x:pool[pivot][r[pivot+12]+1]){if(!x.n)return 3;Pivot P(*this,x);if(P.possible(ids,r))return 2;}
  return 1;
 }
};
