#include<bits/stdc++.h>
using namespace std;using W=uint64_t;using U=uint32_t;int pc(W x){return __builtin_popcountll(x);}W bit(int i){return W(1)<<i;}U ob[759];U G[4096];int R[7][24],coord[7][8];struct GF{W x[57]{};int rank=0;void add(W a){for(int j=55;j>=0;j--){if(!(a&bit(j)))continue;if(x[j])a^=x[j];else{x[j]=a;rank++;return;}}if(a)x[56]=a;}};
int main(int ac,char**av){int mode=ac>1?atoi(av[1]):0;ifstream co("code.dat");for(auto&x:G)co>>x;ifstream t("tables");for(auto&x:ob)t>>x;array<int,7> tbl;int h=0;map<int,int> hist,validhist;unsigned long long nv=0,tests=0;while(cin>>tbl[0]){for(int j=1;j<7;j++)cin>>tbl[j];for(int i=0;i<7;i++){fill(R[i],R[i]+24,-1);int w=0;for(int j=0;j<24;j++)if(ob[tbl[i]]>>j&1)coord[i][w]=j,R[i][j]=8*i+w++;assert(w==8);}
 GF eq,gu;W rr[7];for(int i=0;i<7;i++){rr[i]=255*bit(8*i);eq.add(rr[i]);gu.add(rr[i]);}
 vector<array<W,3>> checked;
 for(int i=0;i<7;i++)for(int j=0;j<i;j++){U u=ob[tbl[i]]&ob[tbl[j]];if(!u)continue;W a=0,b=0;for(int k=0;k<24;k++)if(u>>k&1)a|=bit(R[i][k]),b|=bit(R[j][k]);eq.add(a|b|(pc(u)/2%2?bit(56):0));if(pc(u)>2)checked.push_back({a,b,W(pc(u)/2)});}
 // A basis of the Golay words instead of all elements suffices.
 GF code;for(U g:G){int pr=code.rank;code.add(g);if(code.rank==pr)continue;W w=0;for(int i=0;i<7;i++)for(int j=0;j<8;j++)if(g>>coord[i][j]&1)w|=bit(8*i+j);gu.add(w);}assert(code.rank==12);
 for(int i=0;i<56;i++)if(gu.x[i])eq.add(bit(i));if(eq.x[56]){hist[-1]++;h++;continue;}
 W base=0;vector<W> ker;for(int i=0;i<56;i++){if(!eq.x[i])ker.push_back(bit(i));else{if((pc(base&eq.x[i])%2)^(eq.x[i]>>56))base|=bit(i);for(auto&v:ker)if(pc(v&eq.x[i])%2)v|=bit(i);}}
 int d=ker.size();hist[d]++;cout<<h<<" "<<d<<"\n";if(mode && (ac<3 || d<=atoi(av[2]))){long long dt=0;W cur=base;for(W z=0;z<bit(d);z++){if(z)cur^=ker[__builtin_ctzll(z)];bool ok=true;
  for(auto [a,b,k]:checked){W m=0;for(;a;a&=a-1,b&=b-1)m+=(!!(cur&bit(__builtin_ctzll(a))))^(!!(cur&bit(__builtin_ctzll(b))));if(m!=k){ok=false;break;}}
  if(ok){dt++;if(mode>1)cout<<h<<" "<<cur<<"\n";}
 }nv+=dt;tests+=bit(d);validhist[dt?1:0]++;}
 h++;}
 cerr<<"hist ";for(auto k:hist)cerr<<k.first<<":"<<k.second<<" ";cerr<<" ; tests "<<tests<<" feasible "<<nv<<" frames "<<validhist[1]<<endl;}
