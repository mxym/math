#include<bits/stdc++.h>
using namespace std;using U=uint32_t;using I64=uint64_t;using Q=array<int,4>;using Set=array<int,7>;struct Pair{int a,b;U x,y;};const U all=(1u<<24)-1;int16_t id[1<<24],pc[759][759];uint16_t fx[759][759];uint8_t pin[759][759][24];U oc[759];I64 key(Q a){sort(a.begin(),a.end());return a[0]|(I64(a[1])<<10)|(I64(a[2])<<20)|(I64(a[3])<<30);}int mapoct(int a,const uint8_t*p){U m=oc[a],w=0;while(m){int x=__builtin_ctz(m);m&=m-1;w|=U(1)<<p[x];}return id[w];}
int main(int argc,char**argv){
 ifstream t("tables"),act("stabs.tab");FILE *f=fopen("transport.bin","rb");int n,rr,cc;auto read=[&](void*p,size_t s,size_t count){assert(fread(p,s,count,f)==count);};read(&rr,4,1);read(&cc,4,1);vector<int16_t>par(rr),can(cc);read(par.data(),2,rr);read(can.data(),2,cc);read(fx,2,759*759);read(pc,2,759*759);read(pin,1,759*759*24);
 fill_n(id,1<<24,int16_t(-1));for(int i=0;i<759;i++){t>>oc[i];id[oc[i]]=i;}t>>n;assert(n==cc);map<U,vector<Pair>> buckets;
 for(int a=0;a<759;a++)for(int b=a;b<759;b++){U x=oc[a],y=oc[b];buckets[x^y].push_back({a,b,x|y,x&y});}
 int tot=0,nr=0;for(int k=0;k<n;k++){
  int p,q,r,stab;t>>p>>q>>r>>stab;int ng;act>>ng;vector<array<int,759>>gen(ng);for(auto&x:gen)for(int&i:x)act>>i;
  if(argc>1 && k!=atoi(argv[1]))continue;
  unordered_map<I64,int> tab;tab.reserve(1<<18);vector<Q> rep;U a=oc[p],b=oc[q],c=oc[r],s1=a|b|c,s2=(a&b)|(a&c)|(b&c),s3=a&b&c,target=all^a^b^c;int count=0;
  for(auto const &[u,ab]:buckets){auto iter=buckets.find(u^target);if(iter==buckets.end())continue;auto const&cd=iter->second;
   for(auto&a:ab){if((a.x&s3)||(a.y&s2))continue;
    for(auto&b:cd){if(a.b>b.a)continue;if(b.x&s3||b.y&s2||(s2&a.x&b.x)||(s2&a.x&b.y)||(s1&a.y&b.x)||(s1&a.x&b.y)||(a.y&b.y))continue;
     ++count;Q origin={a.a,a.b,b.a,b.b};int rid=rep.size();if(!tab.emplace(key(origin),rid).second)continue;rep.push_back(origin);vector<Q> todo={origin};while(!todo.empty()){Q x=todo.back();todo.pop_back();for(auto &g:gen){Q y={g[x[0]],g[x[1]],g[x[2]],g[x[3]]};if(tab.emplace(key(y),rid).second)todo.push_back(y);}}
    }
   }
  }assert(count==tab.size());int nkeep=0;for(int i=0;i<(int)rep.size();i++){Q w=rep[i];Set s={p,q,r,w[0],w[1],w[2],w[3]};bool keep=true;
   for(int mask=1;mask<128&&keep;mask++)if(__builtin_popcount(mask)==3){
    int u[3],v[4],ui=0,vi=0;for(int x=0;x<7;x++)if(mask>>x&1)u[ui++]=s[x];else v[vi++]=s[x];
    for(int h=0;h<3&&keep;h++){auto &g=fx[u[h]];int x=g[u[(h+1)%3]],y=g[u[(h+2)%3]],s0=pc[x][y],kt=par[s0];if(kt<k){keep=false;break;}if(kt>k||s0!=can[k])continue;
     Q to;for(int j=0;j<4;j++)to[j]=mapoct(g[v[j]],pin[x][y]);auto it=tab.find(key(to));assert(it!=tab.end());if(it->second<i)keep=false;
    }
   }
   if(keep){sort(s.begin(),s.end());for(int x:s)cout<<x<<" ";cout<<"\n";nkeep++;}
  }
  tot+=nkeep;nr+=rep.size();cerr<<k<<" "<<count<<" -> "<<rep.size()<<" -> "<<nkeep<<endl;
 }
 cerr<<"TOTAL "<<nr<<" -> "<<tot<<endl;
}
