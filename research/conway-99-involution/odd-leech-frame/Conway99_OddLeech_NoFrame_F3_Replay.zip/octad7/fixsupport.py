from pathlib import Path
import sys
sys.path.insert(0,str(Path('.').resolve()))
from marks import *
from collections import deque
from functools import lru_cache
full=[[int((i+1)%23) for i in range(23)]+[23],[23]+[int(-pow(i,-1,23)%23) for i in range(1,23)]+[0],[(4*pow(i,4,23)-3*pow(i,15,23))%23 for i in range(23)]+[23]]
for j,a in enumerate(full):
 if any(valper(a,o) not in set(G) for o in O):
  k=5;full[j]=[a[(k*i)%23]*pow(k,-1,23)%23 for i in range(23)]+[23]
ident=tuple(range(24));O=set(O);obs=sorted(O);pidx={o:i for i,o in enumerate(obs)}
def inv(a):
 p=[0]*24
 for i,x in enumerate(a):p[x]=i
 return tuple(p)
def mul(a,b):return tuple(b[t] for t in a)
@lru_cache(None)
def stab(prefix):
 if not prefix:return 244823040,tuple(map(tuple,full))
 n,old=stab(prefix[:-1]);O=obs[prefix[-1]];ts={O:ident};qs=deque([O])
 while qs:
  o=qs.popleft()
  for p in old:
   u=valper(p,o)
   if u not in ts:ts[u]=mul(ts[o],p);qs.append(u)
 want=n//len(ts);si={k:inv(p) for k,p in ts.items()}
 if want==1:return 1,()
 H=PermutationGroup([P(ident)]);gg=[]
 for a,v in ts.items():
  for p in old:
   u=valper(p,a);g=mul(mul(v,p),si[u])
   if not H.contains(P(g)):
    gg.append(g);H=PermutationGroup([P(x) for x in gg]);z=H.order()
    if z==want:return want,tuple(gg)
 assert H.order()==want;return want,tuple(gg)
dd=dict(np.loadtxt('octad7/dim.dat',dtype=int).tolist());data=np.loadtxt('octad7/reps7.dat',dtype=int);f=open('octad7/sgens.dat','w')
for h,os in enumerate(data):
 if dd.get(h,0)<18:continue
 s=tuple(dict.fromkeys(os));n,gs=stab(s);print(h,n,len(gs),*sum((list(p) for p in gs),[]),file=f,flush=True);print(h,dd[h],n,flush=True)
