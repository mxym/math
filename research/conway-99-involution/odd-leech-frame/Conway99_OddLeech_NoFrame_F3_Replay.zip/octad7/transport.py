import sys
from pathlib import Path
sys.path.insert(0,str(Path('.').resolve()))
from marks import *
from collections import deque
def build():
 full=[[int((i+1)%23) for i in range(23)]+[23],[23]+[int(-pow(i,-1,23)%23) for i in range(1,23)]+[0],[(4*pow(i,4,23)-3*pow(i,15,23))%23 for i in range(23)]+[23]]
 Os=list(map(int,O));ot={a:i for i,a in enumerate(Os)}
 for j,a in enumerate(full):
  if any(valper(a,o) not in ot for o in Os):
   k=5;a=[a[(k*i)%23]*pow(k,-1,23)%23 for i in range(23)]+[23];full[j]=a
  assert all(valper(a,o) in ot for o in Os)
 def inv(p):return tuple(np.argsort(p).tolist())
 def mul(a,b):return tuple(b[x] for x in a)
 tabs=[[ot[valper(a,o)] for o in Os] for a in full];trans={0:tuple(range(24))};q=deque([0]);gs=set()
 while q:
  i=q.popleft()
  for a,p in zip(full,tabs):
   u=p[i];h=mul(trans[i],a)
   if u in trans:gs.add(mul(h,inv(trans[u])))
   else:trans[u]=h;q.append(u)
 assert len(trans)==759;G=PermutationGroup([P(list(range(24)))]);st=[]
 for a in sorted(gs):
  if not G.contains(P(a)):
   st.append(a);G=PermutationGroup([P(s) for s in st]);
   if G.order()==322560:break
 assert G.order()==322560
 actions=[[ot[valper(a,o)] for o in Os] for a in st]
 pc=np.full((759,759),-1,np.int32);reps=[];sizes=[]
 for i in range(759):
  for j in range(i,759):
   if pc[i,j]>=0:continue
   k=len(reps);reps.append((i,j));pc[i,j]=pc[j,i]=k;q=[(i,j)];sz=0
   while q:
    a,b=q.pop();sz+=1
    for p in actions:
     x,y=p[a],p[b]
     if pc[x,y]<0:pc[x,y]=pc[y,x]=k;q.append((x,y))
   sizes.append(sz)
 Pts=defaultdict(list)
 for k,(u,v) in enumerate(reps):
  t=(0,u,v);oo=[]
  for j in range(3):
   p=inv(trans[t[j]]);x,y=[ot[valper(p,Os[t[h]])] for h in range(3) if h!=j]
   oo.append(pc[x,y])
  Pts[min(oo)].append(k)
 oo=open('octad7/tables','w');print(*Os,file=oo);print(len(Pts),file=oo)
 for k,ids in sorted(Pts.items()):
  t=(0,*reps[k]);s=759*sum(sizes[i] for i in ids)//len(set(t));assert 244823040%s==0
  print(*t,244823040//s,file=oo)
 # Canonical transport rooted pair -> its chosen representative, as permutation on 24 coordinates.
 pin=np.zeros((759,759,24),dtype=np.uint8);done=np.zeros((759,759),dtype=np.uint8);e=np.arange(24,dtype=np.uint8);sinv=[np.array(inv(v),dtype=np.uint8) for v in st]
 for ix,(a,b) in enumerate(reps):
  pin[a,b]=pin[b,a]=e;done[a,b]=done[b,a]=1;stack=[(a,b)]
  while stack:
   x,y=stack.pop()
   for pi,si in zip(actions,sinv):
    u,v=pi[x],pi[y]
    if not done[u,v]:
     done[u,v]=done[v,u]=1;pin[u,v]=pin[v,u]=pin[x,y][si];stack.append((u,v))
 parents=np.zeros(len(reps),np.int16);keys=[];fo=open('octad7/stabs.tab','w')
 for h,(k,ids) in enumerate(sorted(Pts.items())):
  for ix in ids:parents[ix]=h
  keys.append(k);x,y=reps[k];t=(0,x,y);order=244823040*len(set(t))//(759*sum(sizes[i] for i in ids))
  want=322560//sizes[k];G0=PermutationGroup([P(list(e))]);zs=[];order0=1;xx,yy=np.where(np.triu(pc==k))
  for a,b in zip(xx,yy):
   if order0==want:break
   it=np.argsort(pin[a,b])
   for ss,prm in zip(st,actions):
    z=pin[prm[a],prm[b]][np.array(ss)[it]].tolist()
    if not G0.contains(P(z)):
     zs.append(z);G0=PermutationGroup([P(v) for v in zs]);order0=G0.order()
  assert order0==want
  for j in range(1,3):
   if t[j]==0:continue
   pp=inv(trans[t[j]]);a,b=[ot[valper(pp,Os[t[g]])] for g in range(3) if g!=j]
   if pc[a,b]!=k:continue
   zz=pin[a,b][list(pp)].tolist()
   if not G0.contains(P(zz)):
    zs.append(zz);G0=PermutationGroup([P(v) for v in zs])
  assert G0.order()==order,(h,order,G0.order())
  print(len(zs),file=fo)
  for z in zs:print(*[ot[valper(z,v)] for v in Os],file=fo)
 fix=np.empty((759,759),np.uint16)
 for h in range(759):pp=inv(trans[h]);fix[h]=[ot[valper(pp,v)] for v in Os]
 with open('octad7/transport.bin','wb') as fh:
  for aa in (np.array([len(reps),len(keys)],np.int32),parents,np.array(keys,np.int16),fix,pc.astype(np.int16),pin):fh.write(aa.tobytes())
 print('group generators',len(st),'rooted triple types',len(reps),'unmarked triple types',len(Pts),flush=True)
from collections import defaultdict
if __name__=='__main__':build()
