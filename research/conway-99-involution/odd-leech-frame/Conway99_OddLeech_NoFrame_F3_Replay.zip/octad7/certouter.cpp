#include<bits/stdc++.h>
using namespace std;using U=uint32_t;using W=uint64_t;int pc(W v){return __builtin_popcountll(v);}using Dom=array<vector<int>,42>;int want[276],dif[2048][276];int nodes,lim;int dfs(Dom d){
 if(++nodes>lim)return -1;
 bool again=true;while(again){again=false;for(int i=0;i<276;i++){
  int mi[42],ma[42],lo=0,hi=0;for(int l=0;l<42;l++){mi[l]=1;ma[l]=0;for(int q:d[l])mi[l]&=dif[q][i],ma[l]|=dif[q][i];lo+=mi[l];hi+=ma[l];}
  if(want[i]<lo||want[i]>hi)return 0;if(lo==hi||(lo!=want[i]&&hi!=want[i]))continue;
  for(int l=0;l<42;l++)if(mi[l]!=ma[l]){int g=(want[i]==hi);auto &v=d[l];v.erase(remove_if(v.begin(),v.end(),[&](int q){return dif[q][i]!=g;}),v.end());assert(!v.empty());again=true;}
 }}
 int l=-1;for(int i=0;i<42;i++)if(d[i].size()>1&&(l<0||d[i].size()<d[l].size()))l=i;if(l<0)return 1;
 auto z=d[l];for(int q:z){d[l]={q};int a=dfs(d);if(a!=0)return a;}return 0;
}

struct Trit {W a[5]{},b[5]{};int get(int k)const{return ((a[k>>6]>>(k&63))&1)+2*((b[k>>6]>>(k&63))&1);}void set(int k,int x){if(x==1)a[k>>6]|=1ULL<<(k&63);if(x==2)b[k>>6]|=1ULL<<(k&63);}void neg(){for(int t=0;t<5;t++)swap(a[t],b[t]);} void sub(const Trit &w,bool neg){for(int t=0;t<5;t++){W x=a[t],y=b[t],u=neg?w.b[t]:w.a[t],v=neg?w.a[t]:w.b[t],z=~(x|y),h=~(u|v);a[t]=(x&h)|(z&v)|(y&u);b[t]=(y&h)|(z&u)|(x&v);}}int pivot()const{for(int t=0;t<5;t++)if(a[t]|b[t])return t*64+__builtin_ctzll(a[t]|b[t]);return 320;}};
struct G3 {Trit basis[318];bool used[318]{};bool add(Trit v){while(1){int i=v.pivot();if(i==320)return false;int x=v.get(i);if(used[i])v.sub(basis[i],x==2);else{if(x==2)v.neg();basis[i]=v;used[i]=true;return true;}}}};
Trit QV[2048];
int dot(Trit const&v,Trit const&w){int k=0;for(int t=0;t<5;t++)k+=pc((v.a[t]&w.a[t])|(v.b[t]&w.b[t]))-pc((v.a[t]&w.b[t])|(v.b[t]&w.a[t]));return (k%3+3)%3;}
bool linearcheck(Dom const&dom){G3 g;Trit r;int loc[276];copy_n(want,276,loc);
 for(int j=0;j<42;j++){int b=dom[j][0];for(int i=0;i<276;i++)loc[i]-=dif[b][i];
  for(int q:dom[j])if(q!=b){auto v=QV[q];v.sub(QV[b],false);g.add(v);}}
 for(int i=0;i<276;i++)r.set(i,(loc[i]%3+3)%3);
 int k;while(1){k=r.pivot();if(k==320)return true;if(!g.used[k])break;r.sub(g.basis[k],r.get(k)==2);}
 // Recover a left-kernel witness. Check it against the ORIGINAL, uneliminated one-per-label system.
 Trit y;y.set(k,1);for(int p=k-1;p>=0;p--)if(g.used[p])y.set(p,(3-dot(y,g.basis[p]))%3);
 int lhs=0,rhs=0;for(int i=0;i<276;i++)lhs+=want[i]*y.get(i);
 for(auto &d:dom){int z=dot(y,QV[d[0]]);for(int q:d)assert(dot(y,QV[q])==z);rhs+=z;}
 assert((lhs-rhs)%3!=0);return false;
}
int main(int ac,char**av){lim=ac>1?atoi(av[1]):1000;U O[759],G[4096];ifstream tab("tables"),code("code.dat"),frames("reps7.dat");for(auto&o:O)tab>>o;for(auto&g:G)code>>g;vector<array<int,7>> D;array<int,7>v;while(frames>>v[0]){for(int i=1;i<7;i++)frames>>v[i];D.push_back(v);}
 for(int q=0;q<2048;q++){int r=0;for(int i=0;i<24;i++)for(int j=0;j<i;j++)dif[q][r++]=((G[q]>>i)^(G[q]>>j))&1;}
 for(int q=0;q<2048;q++)for(int i=0;i<276;i++)QV[q].set(i,dif[q][i]);map<int,int>sizes;int h,C,a,b,last=-1,signs=0;W s,prev=~W(0);array<int,7>tb;int B[8];int ax[7][24],cc[24],dd[24];int off[276];array<vector<int>,42>P;long long cases=0,hard=0,sol=0,mnodes=0,sumn=0;
 while(cin>>h>>s>>C>>a>>b){if(h!=last||s!=prev){last=h;prev=s;signs++;tb=D[h];int cnt=0;for(int u=0;u<24;u++){int ks=0;for(int i=0;i<7;i++){ax[i][u]=0;if(O[tb[i]]>>u&1){ks++;int pos=8*i+pc(O[tb[i]]&((1u<<u)-1));ax[i][u]=(s>>pos&1)?-2:2;}}if(ks==1)B[cnt++]=u;}assert(cnt==8);for(auto&x:P)x.clear();
  for(int q=0;q<2048;q++){int idx[2],sg=0,k=0;bool ok=1;for(int i=0;i<7;i++){int z=0;for(int u=0;u<24;u++)z+=ax[i][u]*((G[q]>>u&1)?-1:1);assert(z%8==0);z/=8;if(z){if(abs(z)!=1||k>=2){ok=false;break;}idx[k++]=i;sg^=(z<0);}}if(ok&&k==2){int i=idx[0],j=idx[1];P[2*(i*6-i*(i-1)/2+j-i-1)+sg].push_back(q);}}
  int it=0;for(int u=0;u<24;u++)for(int v=0;v<u;v++){int z=42;for(int i=0;i<7;i++)z+=ax[i][u]*ax[i][v];off[it++]=z;}
 }
 U cm=0,dm=0;for(int i=0;i<8;i++)if(C>>i&1)cm|=1u<<B[i];else dm|=1u<<B[i];for(int u=0;u<24;u++){cc[u]=((cm>>u&1)?-3:1)*((G[a]>>u&1)?-1:1);dd[u]=((dm>>u&1)?-3:1)*((G[b]>>u&1)?-1:1);}
 Dom dom;for(int l=0;l<42;l++)for(int q:P[l]){U z=G[q^a],w=G[q^b];if(pc(z)-4*pc(z&cm)==4 && pc(w)-4*pc(w&dm)==4)dom[l].push_back(q);}
 assert(all_of(dom.begin(),dom.end(),[](auto&v){return !v.empty();}));int it=0;for(int u=0;u<24;u++)for(int v=0;v<u;v++){int z=off[it]+cc[u]*cc[v]+dd[u]*dd[v];assert(z%2==0);want[it++]=z/2;}
 int sz=0;for(auto &x:dom)sz+=x.size();sizes[sz]++;nodes=0;int res=linearcheck(dom)?-1:0;cases++;mnodes=max(mnodes,(long long)nodes);sumn+=nodes;if(res){hard+=res<0;sol+=res>0;cout<<h<<" "<<s<<" "<<C<<" "<<a<<" "<<b<<" "<<res<<"\n";}
 }for(auto [b,n]:sizes)cerr<<b<<":"<<n<<" ";cerr<<endl;cerr<<"charts "<<cases<<" nontriv frame choices "<<signs<<" cap "<<hard<<" yes "<<sol<<" nodes "<<sumn<<" max "<<mnodes<<endl;
}
