#include<bits/stdc++.h>
using namespace std;using W=uint64_t;using U=uint32_t;int pc(W x){return __builtin_popcountll(x);}W bit(int i){return W(1)<<i;}U ob[759];U G[4096];int R[7][24],coord[7][8];struct GF{W x[57]{};int rank=0;void add(W a){for(int j=55;j>=0;j--){if(!(a&bit(j)))continue;if(x[j])a^=x[j];else{x[j]=a;rank++;return;}}if(a)x[56]=a;}};

typedef array<unsigned char,256> Tab;
vector<unsigned char> pick[7][256]; uint8_t ar[7][2048],num[256]; int8_t th[256]; bool okrel[2048],obc[256][2048];int lab[128],bb[8];U Bmask; U mo[256];long long checkedS=0,wmark=0,orth=0,filled=0,msbg=0;

std::unordered_map<U,int> ix,di;std::unordered_map<U,array<uint8_t,24>> perm;vector<uint8_t> cla;int cl[256][2048];W mb[7][256][128][32];W pro[7][256][3][32];vector<int> Cs;
U rel(U v){return min(v,v^16777215U);}U image(U x,array<uint8_t,24>const&p){U y=0;for(;x;x&=x-1)y|=1u<<p[__builtin_ctz(x)];return y;}
void maps0(){for(int i=0;i<4096;i++)ix[G[i]]=i;ifstream t("tetmap.dat");int c;while(t>>c){array<uint8_t,24> p;int a;for(int j=0;j<24;j++){t>>a;p[j]=a;}perm[c]=p;}int r=0;for(auto it:map<U,int>(di.begin(),di.end()))(void)it;vector<U> ds;for(auto &[m,p]:perm)if(!(m&15))ds.push_back(m);sort(ds.begin(),ds.end());for(auto d:ds)di[d]=r++;assert(r==4845);ifstream x("markclass.bin",ios::binary);cla.resize(r*2048);x.read((char*)cla.data(),cla.size());assert(x.good());}
// c index compressed to 0..69
vector<int>LZ;int cp[256];void fastinit(){Cs.clear();LZ.clear();for(int c=0;c<256;c++)if(num[c]==4){cp[c]=LZ.size();LZ.push_back(c);if(c<128)Cs.push_back(c);}for(int c:Cs){auto p=perm.at(mo[c]);int d=di.at(image(mo[255^c],p));for(int v=0;v<2048;v++)cl[c][v]=cla[d*2048+ix.at(rel(image(G[v],p)))];}
 for(int i=0;i<7;i++)for(int s=0;s<256;s++)if(num[s]%2==0){memset(pro[i][s],0,sizeof(pro[i][s]));memset(mb[i][s],0,70*sizeof(mb[i][s][0]));
  for(int q=0;q<2048;q++){int z=s^ar[i][q],w=th[z];if(abs(w)<=1)pro[i][s][w+1][q>>6]|=bit(q%64);}
  int g=0;for(int b=0;b<8;b++)if(R[i][bb[b]]>=0)g|=1<<b;
  bool ok[256][256]{};for(int v=0;v<256;v++)for(int x:pick[i][v])ok[v][x]=true;
  int memo[256];fill(memo,memo+256,-1);for(int c:LZ){auto dest=mb[i][s][cp[c]];int p=memo[c&g];if(p>=0){memcpy(dest,mb[i][s][p],32*8);continue;}memo[c&g]=cp[c];for(int q=0;q<2048;q++)if(ok[s^ar[i][q]][c&g])dest[q>>6]|=bit(q%64);}
 }}
long long passed=0;void fast(W cur,int h){checkedS++;int ss[7];for(int i=0;i<7;i++)ss[i]=cur>>(8*i)&255;
 vector<int>pool[42],marks[70];int sz[42]{};for(int j=0;j<32;j++){W zp[7],pp[7],np[7];for(int r=0;r<7;r++){np[r]=pro[r][ss[r]][0][j];zp[r]=pro[r][ss[r]][1][j];pp[r]=pro[r][ss[r]][2][j];}int l=0;
  for(int r=0;r<7;r++)for(int t=r+1;t<7;t++){W b=~0ULL;for(int v=0;v<7;v++)if(v!=r&&v!=t)b&=zp[v];for(W e:{b&((pp[r]&pp[t])|(np[r]&np[t])),b&((pp[r]&np[t])|(np[r]&pp[t]))}){sz[l]+=pc(e);for(;e;e&=e-1)pool[l].push_back(64*j+__builtin_ctzll(e));l++;}}}
 if(*min_element(sz,sz+42)==0)return;msbg++;array<int,42>ord; iota(ord.begin(),ord.end(),0);sort(ord.begin(),ord.end(),[&](int a,int b){return sz[a]<sz[b];});
 for(int c:LZ){auto &v=marks[cp[c]];for(int j=0;j<32;j++){W e=~0ULL;for(int i=0;i<7;i++)e&=mb[i][ss[i]][cp[c]][j];for(;e;e&=e-1)v.push_back(64*j+__builtin_ctzll(e));}}
 for(int c:Cs)for(int a:marks[cp[c]])for(int b:marks[cp[255^c]])if(cl[c][a^b]!=255){passed++;bool ok=true;for(int l:ord){bool hit=false;for(int q:pool[l])if(obc[c][a^q]&&obc[255^c][b^q]){hit=true;break;}if(!hit){ok=false;break;}}if(ok){filled++;cout<<h<<" "<<cur<<" "<<c<<" "<<a<<" "<<b<<"\n";}}
}
void initMark(array<int,7> const&tbl){
 Bmask=0;int cnt=0;for(int i=0;i<24;i++){int n=0;for(int j=0;j<7;j++)n+=!!(ob[tbl[j]]&(1u<<i));if(n==1){Bmask|=1u<<i;bb[cnt++]=i;}else assert(n==3);}assert(cnt==8);
 int k=0;for(int a=0;a<7;a++)for(int b=a+1;b<7;b++)lab[(1<<a)|(1<<b)]=2*(k++);
 for(int c=0;c<256;c++){num[c]=pc(c);th[c]=(8-2*pc(c))/4;U m=0;for(int j=0;j<8;j++)if(c>>j&1)m|=U(1)<<bb[j];mo[c]=m;
  if(pc(c)==4)for(int q=0;q<2048;q++)obc[c][q]=pc(G[q])-4*pc(G[q]&m)==4;}
 for(int q=0;q<2048;q++)okrel[q]=pc(G[q])-4*pc(G[q]&Bmask)==-4;
 for(int j=0;j<7;j++){
  int group=0;for(int u=0;u<8;u++)if((U(1)<<bb[u])&ob[tbl[j]])group|=1<<u;
  for(int q=0;q<2048;q++){int a=0;for(int h=0;h<8;h++)if(G[q]>>coord[j][h]&1)a|=1<<h;ar[j][q]=a;}
  for(int a=0;a<256;a++){auto &v=pick[j][a];v.clear();if(num[a]&1)continue;
   for(int x=group;;x=(x-1)&group){int v0=0;for(int b=0;b<8;b++)if(x>>b&1)v0+=(a>>(R[j][bb[b]]-8*j)&1)?-1:1;if(v0==th[a])v.push_back(x);if(!x)break;}}
 }
}
void mark(W cur,int h){
 vector<int>marks[256],pool[42];int ss[7];for(int i=0;i<7;i++)ss[i]=cur>>(8*i)&255;
 for(int q=0;q<2048;q++){
  int non=0,sign=0,n=0,prod=1;bool large=false;const vector<unsigned char>*z[7];
  for(int i=0;i<7;i++){int a=ss[i]^ar[i][q],v=th[a];if(v){n++;non|=1<<i;if(v<0)sign++;if(abs(v)>1)large=true;}z[i]=&pick[i][a];prod*=z[i]->size();}
  if(!large&&n==2){int l=lab[non]+(sign&1);pool[l].push_back(q);}
  if(!prod)continue;
  int st[2][256];st[0][0]=0;int m=1;for(int i=0;i<7;i++){int o=0;for(int k=0;k<m;k++)for(int s:*z[i])st[(i+1)%2][o++]=st[i%2][k]|s;m=o;}
  for(int k=0;k<m;k++){int c=st[1][k];if(num[c]==4)marks[c].push_back(q);}
 }
 ++checkedS;array<int,42> ord; iota(ord.begin(),ord.end(),0);sort(ord.begin(),ord.end(),[&](int a,int b){return pool[a].size()<pool[b].size();});if(pool[ord[0]].empty())return;msbg++;
 bool yes=false;for(int c=0;c<128;c++)if(num[c]==4)for(int a:marks[c])for(int b:marks[255^c])if(okrel[a^b]){yes=true;orth++;bool good=true;
  for(int l:ord){bool hit=false;for(int q:pool[l])if(obc[c][a^q]&&obc[255^c][b^q]){hit=true;break;}if(!hit){good=false;break;}}
  if(good){filled++;cout<<h<<" "<<cur<<" "<<c<<" "<<a<<" "<<b<<"\n";}}
 wmark+=yes;
}
int main(int ac,char**av){int mode=ac>1?atoi(av[1]):0;ifstream co("code.dat");for(auto&x:G)co>>x;ifstream t("tables");for(auto&x:ob)t>>x;array<int,7> tbl;int h=0;maps0();map<int,int> hist,validhist;unsigned long long nv=0,tests=0;while(cin>>tbl[0]){for(int j=1;j<7;j++)cin>>tbl[j];for(int i=0;i<7;i++){fill(R[i],R[i]+24,-1);int w=0;for(int j=0;j<24;j++)if(ob[tbl[i]]>>j&1)coord[i][w]=j,R[i][j]=8*i+w++;assert(w==8);}
 if(ac>4&&(h<atoi(av[3])||h>=atoi(av[4]))){h++;continue;}initMark(tbl);GF eq,gu;W rr[7];for(int i=0;i<7;i++){rr[i]=255*bit(8*i);eq.add(rr[i]);gu.add(rr[i]);}
 vector<array<W,3>> checked;
 for(int i=0;i<7;i++)for(int j=0;j<i;j++){U u=ob[tbl[i]]&ob[tbl[j]];if(!u)continue;W a=0,b=0;for(int k=0;k<24;k++)if(u>>k&1)a|=bit(R[i][k]),b|=bit(R[j][k]);eq.add(a|b|(pc(u)/2%2?bit(56):0));if(pc(u)>2)checked.push_back({a,b,W(pc(u)/2)});}
 // A basis of the Golay words instead of all elements suffices.
 GF code;for(U g:G){int pr=code.rank;code.add(g);if(code.rank==pr)continue;W w=0;for(int i=0;i<7;i++)for(int j=0;j<8;j++)if(g>>coord[i][j]&1)w|=bit(8*i+j);gu.add(w);}assert(code.rank==12);
 for(int i=0;i<56;i++)if(gu.x[i])eq.add(bit(i));if(eq.x[56]){hist[-1]++;h++;continue;}
 W base=0;vector<W> ker;for(int i=0;i<56;i++){if(!eq.x[i])ker.push_back(bit(i));else{if((pc(base&eq.x[i])%2)^(eq.x[i]>>56))base|=bit(i);for(auto&v:ker)if(pc(v&eq.x[i])%2)v|=bit(i);}}
 int d=ker.size();hist[d]++;if(mode && (ac<3 || d<=atoi(av[2])) && (ac<6 || d>=atoi(av[5]))){fastinit();long long dt=0;W cur=base;for(W z=0;z<bit(d);z++){if(z)cur^=ker[__builtin_ctzll(z)];bool ok=true;
  for(auto [a,b,k]:checked){W m=0;for(;a;a&=a-1,b&=b-1)m+=(!!(cur&bit(__builtin_ctzll(a))))^(!!(cur&bit(__builtin_ctzll(b))));if(m!=k){ok=false;break;}}
  if(ok){dt++;if(mode>1)fast(cur,h);}
 }nv+=dt;tests+=bit(d);validhist[dt?1:0]++;}
 if(mode>1)cerr<<"frame "<<h<<" d="<<d<<" signs="<<checkedS<<" sig="<<msbg<<" marks="<<wmark<<" marked="<<passed<<" full="<<filled<<endl;h++;}
 cerr<<"hist ";for(auto k:hist)cerr<<k.first<<":"<<k.second<<" ";cerr<<" ; tests "<<tests<<" feasible "<<nv<<" frames "<<validhist[1]<<endl;return 0;}
