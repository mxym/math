#define main deadmain
#include "fastmark.cpp"
#undef main
using Point=array<uint8_t,24>;using Tpl=array<uint8_t,3>;int nm(int x){return min(x,255^x);}
struct Obj{vector<Tpl> v;unordered_map<int,int> ids;}objs[4];int on(Tpl const&z,int m){int a=0;for(int i=0;i<m;i++)a=a*128+z[i];return a;}
void genobjs(int m,int k,Tpl z){if(k==m){objs[m].ids[on(z,m)]=objs[m].v.size();objs[m].v.push_back(z);return;}for(int a=k?z[k-1]+1:0;a<128;a++)if(!(pc(a)%2)){bool ok=1;for(int j=0;j<k;j++)if(pc(a^z[j])!=4)ok=0;if(ok){z[k]=a;genobjs(m,k+1,z);}}}
struct GE{int h,q;};using AC=array<array<uint8_t,128>,7>;
struct Run{int id,nt=0,ix[7],mul[7]{},pos[7][3],sg[7][128][24]{},qres[2048][7],K0=0,mode=0;U ons[7],neg[7][128];bool compat[7][7][128][128]{};vector<int> iq[7][128];vector<Point> H0,gen;vector<AC> act;vector<int> hgens;int nH;long long rep=0,mass=0;Tpl picked[7];array<int,7>tb;
 void init(){map<int,vector<int>> ps;for(int j=0;j<7;j++)ps[tb[j]].push_back(j);vector<pair<int,int>> o;for(auto&[i,a]:ps)o.emplace_back(-a.size(),i);sort(o.begin(),o.end());nt=o.size();int z=0;for(auto [k,i]:o){mul[z]=-k;ix[z]=i;ons[z]=ob[i];assert(mul[z]<=3);copy(ps[i].begin(),ps[i].end(),pos[z]);z++;}
  for(int i=0;i<nt;i++)for(int a=0;a<128;a++){int h=0;U u=0;for(int k=0;k<24;k++)if(ons[i]>>k&1){if(a>>h&1)u|=1u<<k;h++;}neg[i][a]=u;}
  for(int i=0;i<nt;i++)for(int j=0;j<i;j++){U u=ons[i]&ons[j];for(int a=0;a<128;a++)for(int b=0;b<128;b++)compat[i][j][a][b]=2*pc((neg[i][a]^neg[j][b])&u)==pc(u);}
  for(int v=0;v<2048;v++){bool kernel=1;for(int t=0;t<nt;t++){int w=normq(t,G[v]);qres[v][t]=w;iq[t][w].push_back(v);if(w)kernel=0;}K0+=kernel;}
  Point e; iota(e.begin(),e.end(),0);map<Point,int> di;di[e]=0;H0.push_back(e);for(int u=0;u<(int)H0.size();u++)for(auto&p:gen){Point s;for(int j=0;j<24;j++)s[j]=p[H0[u][j]];if(!di.count(s)){di[s]=H0.size();H0.push_back(s);}}
  assert(H0.size()==nH);for(auto&p:gen)hgens.push_back(di[p]);act.resize(nH);for(int v=0;v<nH;v++)for(int i=0;i<nt;i++){auto &p=H0[v];U un=0;for(int j=0;j<24;j++)if(ons[i]>>j&1)un|=1u<<p[j];assert(un==ons[i]);for(int a=0;a<128;a++){U w=0;for(U r=neg[i][a];r;r&=r-1)w|=1u<<p[__builtin_ctz(r)];act[v][i][a]=normq(i,w);}}
 }
 int normq(int t,U r){int s=0,h=0;for(U x=ons[t];x;x&=x-1){if(r&(x&-x))s|=1<<h;h++;}return nm(s);}
 int trans(int t,GE e,Tpl x){int m=mul[t],s=qres[e.q][t];for(int j=0;j<m;j++)x[j]=nm(act[e.h][t][x[j]]^s);sort(x.begin(),x.begin()+m);return objs[m].ids.at(on(x,m));}
 void go(int t,vector<GE>const&A){if(t==nt){rep++;mass+=(long long)nH*2048/A.size();if(mode){W cur=0;for(int r=0;r<nt;r++)for(int j=0;j<mul[r];j++)cur|=(W)picked[r][j]<<(8*pos[r][j]);fast(cur,id);}return;}
 auto &os=objs[mul[t]].v;vector<uint8_t>seen(os.size());for(int i=0;i<(int)os.size();i++){if(seen[i])continue;Tpl x=os[i];bool ok=1;for(int j=0;j<t&&ok;j++)for(int a=0;a<mul[t]&&ok;a++)for(int b=0;b<mul[j];b++)if(!compat[t][j][x[a]][picked[j][b]]){ok=0;break;}if(!ok)continue;vector<GE> st;
 if(!t){vector<GE> g;for(int h:hgens)g.push_back({h,0});for(int j=0;j<11;j++)g.push_back({0,1<<j});vector<int> fr(1,i);seen[i]=1;for(int k=0;k<(int)fr.size();k++)for(GE e:g){int v=trans(t,e,os[fr[k]]);if(!seen[v])seen[v]=1,fr.push_back(v);}
 for(int h=0;h<nH;h++)for(int b=0;b<mul[t];b++){int r=nm(act[h][t][x[0]]^x[b]);auto &q=iq[t][r];if(!q.empty()&&trans(t,{h,q[0]},x)==i)for(int w:q)st.push_back({h,w});}assert(fr.size()*st.size()==(long long)nH*2048);}
 else{for(GE e:A){int v=trans(t,e,x);seen[v]=1;if(v==i)st.push_back(e);}}
 assert(!st.empty());picked[t]=x;go(t+1,st);
 }}
};
int main(int ac,char**av){for(int m=1;m<=3;m++)genobjs(m,0,{});ifstream co("code.dat");for(auto&x:G)co>>x;ifstream ta("tables");for(auto&x:ob)ta>>x;maps0();array<int,7>a;vector<array<int,7>>frames;ifstream f("reps7.dat");while(f>>a[0]){for(int j=1;j<7;j++)f>>a[j];frames.push_back(a);}ifstream k("sgens.dat");int h,n,s;while(k>>h>>n>>s){auto v=make_unique<Run>();v->nH=n;v->id=h;v->tb=frames[h];v->mode=atoi(av[1]);v->gen.resize(s);for(auto &p:v->gen)for(auto &t:p){int w;k>>w;t=w;}if(h<atoi(av[2])||h>=atoi(av[3]))continue;auto tb=v->tb;
 for(int i=0;i<7;i++){fill(R[i],R[i]+24,-1);int w=0;for(int j=0;j<24;j++)if(ob[tb[i]]>>j&1)coord[i][w]=j,R[i][j]=8*i+w++;assert(w==8);}if(v->mode){initMark(tb);fastinit();}v->init();v->go(0,{});long long nperm=1;for(int i=0;i<v->nt;i++)nperm*=v->mul[i]==3?6:v->mul[i];assert(v->mass%(2048/v->K0)==0 || v->mass*nperm%(2048/v->K0)==0);cerr<<"support "<<h<<" H "<<n<<" K "<<v->K0<<" reps "<<v->rep<<" equiv "<<v->mass*nperm*v->K0/2048<<" marked "<<passed<<" cover "<<filled<<endl;}}
