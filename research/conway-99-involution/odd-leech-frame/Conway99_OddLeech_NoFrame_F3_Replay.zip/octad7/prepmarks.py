import sys
from pathlib import Path
sys.path.insert(0,str(Path('.').resolve()))
from marks import *
from collections import deque
T=15;idx={x:i for i,x in enumerate(sorted(G))};assert len(idx)==4096
full=[[int((i+1)%23) for i in range(23)]+[23],[23]+[int(-pow(i,-1,23)%23) for i in range(1,23)]+[0],[(4*pow(i,4,23)-3*pow(i,15,23))%23 for i in range(23)]+[23]]
for j,a in enumerate(full):
 if any(valper(a,o) not in idx for o in O):
  k=5;full[j]=[a[(k*i)%23]*pow(k,-1,23)%23 for i in range(23)]+[23]
 assert all(valper(full[j],o) in idx for o in G)
inverse={15:list(range(24))};q=deque([15]);iFull=[np.argsort(p).tolist() for p in full]
while q:
 x=q.popleft();p=inverse[x]
 for a,ai in zip(full,iFull):
  y=valper(a,x)
  if y not in inverse:inverse[y]=[p[t] for t in ai];q.append(y)
assert len(inverse)==10626 and all(valper(p,x)==15 for x,p in inverse.items())
with open('octad7/tetmap.dat','w') as f:
 for x,p in sorted(inverse.items()):print(x,*p,file=f)
st=group();s11=sorted(G)[:2048];assert all(idx[x^y]==(idx[x]^idx[y]) for x in G for y in s11[::128]);ct=idx[ALL];assert ct==4095
actg=np.array([[min(idx[valper(p,x)],idx[valper(p,x)]^ct) for x in s11] for p in st],dtype=np.uint16)
qq=sorted(sum(1<<x for x in a) for a in combinations(range(4,24),4));Dix={x:i for i,x in enumerate(qq)}
actq=np.array([[Dix[valper(p,d)] for d in qq] for p in st],dtype=np.uint16)
ms=np.loadtxt('marks.dat',dtype=int); assert ms.shape==(231,4)
col=np.array([1<<j for j in range(24)]);Z=1-2*((np.array(s11)[:,None]&col)!=0).astype(int)
bad=set()
for l in open('octad7/witness153.dat'):
 h,*x=map(int,l.split()); x=np.array(x); assert x.shape==(24,) and x@x==128 and (Z@x%16==8).all()
 T,D,V,n=map(int,ms[h]);c=(1-4*((T&col)!=0).astype(int));d=(1-4*((D&col)!=0).astype(int))*(1-2*((V&col)!=0).astype(int));assert (x@c)%8==0 and (x@d)%8==0
 assert 112-(x@c//8)**2-(x@d//8)**2<42 and h not in bad;bad.add(h)
assert len(bad)==153
out=np.full((len(qq),2048),255,np.uint8)
for h in range(231):
 T,D,V,n=map(int,ms[h]);assert T==15 and D in Dix
 i,j=Dix[D],min(idx[V],idx[V]^ct);assert out[i,j]==255;assert V.bit_count()-4*(V&(T|D)).bit_count()==-4
 out[i,j]=h;q=[(i,j)];sz=0
 while q:
  i,j=q.pop();sz+=1;a,b=actq[:,i],actg[:,j];new=np.flatnonzero(out[a,b]==255)
  for k in new:
   t,w=int(a[k]),int(b[k])
   if out[t,w]==255:q.append((t,w));out[t,w]=h
 assert sz*2==n
# Exhaustiveness is checked directly on EVERY tetrad and signword, not inferred from the file of seeds.
for j,D in enumerate(qq):
 assert np.array_equal(out[j]!=255,[v.bit_count()-4*(v&(15|D)).bit_count()==-4 for v in s11])
assert np.count_nonzero(out!=255)==3302040
for h in bad:out[out==h]=255
assert np.count_nonzero(out!=255)==1036440 and len(set(out.ravel()))==79
out.tofile('octad7/markclass.bin')
open('octad7/code.dat','w').write(''.join(str(v)+'\n' for v in sorted(G)))
for i,w in enumerate(s11):
 assert w>>23==0 and all(s11[i^j]==w^s11[j] for j in [1<<r for r in range(11)])
print('All 3,302,040 normalized marker placements checked; 153 elementary witnesses leave 78 ordered marker classes.')
