from words import *
from sympy.combinatorics import Permutation as P,PermutationGroup
import itertools,sys
def valper(pp,u):
 return sum(1<<pp[i] for i in range(24) if (u>>i)&1)
def rotation(g,k):return [(x+k)%23 if x<23 else 23 for x in g[:23]]+[23]
def group():
 gg=[[int((i+1)%23) for i in range(23)]+[23], [23]+[int(-pow(i,-1,23)%23) for i in range(1,23)]+[0], [(4*pow(i,4,23)-3*pow(i,15,23))%23 for i in range(23)]+[23]]
 ref=set(O)
 for j in [0,1,2]:
  a=gg[j]
  if not all(valper(a,u) in ref for u in O):
   m=5;inv=pow(m,-1,23);aa=[a[(m*i)%23]*inv%23 for i in range(23)]+[23];assert all(valper(aa,u) in ref for u in O);gg[j]=aa
 pg=PermutationGroup([P(g) for g in gg]);assert pg.order()==244823040
 # tetrad setwise stabilizer: get chain pointwise then find elements permuting four coordinates.
 T=tuple([0,1,2,3]); point=pg.pointwise_stabilizer(list(T));ss=list(point.generators)
 for k in [1,2,3]:
  H=pg;u=P(list(range(24))); target=list(T);target[0],target[k]=target[k],target[0]
  for i,t in zip(T,target):
   x=u(i);q=H.orbit_transversal(x,pairs=True);v=dict(q)[t];u=u*v;H=H.stabilizer(t)
  ss.append(u)
 stab=PermutationGroup(ss);assert stab.order()==23040
 return [p.array_form for p in stab.generators]
def allreps():
 gens=group();T=15;gs=np.array(G);idx={a:i for i,a in enumerate(G)};permg=np.array([[idx[valper(p,a)] for a in G] for p in gens]);q4=[sum(1<<i for i in a) for a in combinations(range(4,24),4)];qs=set(q4);act4=[[valper(p,a) for a in q4] for p in gens];qindex={a:i for i,a in enumerate(q4)};pair=np.full((len(q4),4096),-2,dtype=np.int16);sg=np.arange(4096)^idx[ALL];rows=[];state=[]
 goodshort=np.array(G[::1],dtype=int);wm=np.array([s.bit_count() for s in G]);
 for a in q4:
  j=qindex[a];av=(wm-4*np.array([(s&(T|a)).bit_count() for s in G]))==-4
  pair[j,av]=-1
 for jj,a in enumerate(q4):
  for v in np.flatnonzero(pair[jj]==-1):
   if pair[jj,v]!=-1:continue
   b=(jj,v);st=[b];k=len(rows);sz=0;pair[b]=k
   while st:
    h,x=st.pop();sz+=1
    for g in range(len(gens)):
     ss=(qindex[act4[g][h]],permg[g][x])
     if pair[ss]!=k:assert pair[ss]==-1;pair[ss]=k;st.append(ss)
    ss=h,sg[x]
    if pair[ss]!=k:assert pair[ss]==-1;pair[ss]=k;st.append(ss)
   rows.append((T,a,G[v],sz));print('rep',k,'orbit',sz,flush=True)
 np.savetxt('marks.dat',np.array(rows),fmt='%d');print('TOTAL',len(rows),len(pair[pair>=0]),flush=True)
if __name__=='__main__':allreps()
