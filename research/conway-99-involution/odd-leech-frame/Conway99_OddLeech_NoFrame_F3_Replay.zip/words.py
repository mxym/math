from itertools import combinations
from collections import Counter,defaultdict
import numpy as np
ALL=(1<<24)-1
G=[0];g=sum(1<<e for e in [11,9,7,6,5,1,0]); 
for i in range(12):
 w=g<<i;w|=(w.bit_count()%2)<<23;G += [x^w for x in G]
assert Counter(x.bit_count() for x in G)=={0:1,8:759,12:2576,16:759,24:1}
O=sorted(x for x in G if x.bit_count()==8)
