#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
test ! -e MANIFEST.sha256 || sha256sum -c MANIFEST.sha256 >/dev/null
python octad7/prepmarks.py
python octad7/transport.py
cd octad7
for x in orbit7 dim fastmark symmark certouter; do g++ -O3 -std=c++17 -march=native "$x.cpp" -o "$x"; done
./orbit7 > reps7.dat 2> unsigned.log
test "$(wc -l < reps7.dat)" -eq 2742
./dim <reps7.dat >dim.dat 2>dim.log
cd ..
python octad7/fixsupport.py >octad7/sgens.log
cd octad7
test "$(wc -l < sgens.dat)" -eq 65
./fastmark 2 17 <reps7.dat 2>ordinary.log | ./certouter >ordinary.survivors 2>ordinary.check
test ! -s ordinary.survivors
./symmark 1 0 2742 2>exceptional.log | ./certouter >exceptional.survivors 2>exceptional.check
test ! -s exceptional.survivors
grep -q "^charts 5038108 .* cap 0 yes 0 " ordinary.check
grep -q "^charts 274518 .* cap 0 yes 0 " exceptional.check
tail -1 ordinary.check; tail -1 exceptional.check
echo VERIFIED
