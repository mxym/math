#include "plane_geometry.hpp"
int64_t Scnt[]={1,49,980,10388,63553,229908,486668,576856,346381,81095,980};
int cb(int n,int k){int s=1;for(int i=1;i<=k;i++)s=s*(n-i+1)/i;return s;}
using Counts=unordered_map<U,unsigned long long>;unsigned long long steps=0;
Counts grow(Counts r,int k){Counts n;n.reserve(2*r.size()); for(auto [u,m]:r){if(pc(u)+k>=9){for(U v:ext(u,k))n[v]+=m;}else{vector<U>v;gen(safe(u),k,0,v);for(U w:v)n[w]+=m;}}steps+=n.size();return n;}
using Code=array<U,7>;map<U,vector<int>> can;set<Code> allC;ofstream out3("three33.dat");
Code canon(Code A){Code best{};best.fill(~U(0));array<Code,3> D{};D[0]=A;
 for(int z=0;z<7;z++)for(U v=A[z];v;v&=v-1){int j=__builtin_ctzll(v),x=j/7,y=j%7;D[1][x]|=1ULL<<(7*y+z);D[2][y]|=1ULL<<(7*z+x);}
 for(auto &W:D)for(int j=0;j<7;j++){U P=W[j]|W[(j+1)%7];assert(pc(P)==pc(W[j])+pc(W[(j+1)%7]));if(pc(P)!=10)continue;
 for(int h:can.at(P)){Code f,r;for(int k=0;k<7;k++){f[k]=act(W[(j+k)%7],G[h]);r[k]=act(W[(j+1+7-k)%7],G[h]);}best=min({best,f,r});}}
 assert(best[0]!=~U(0));return best;}
void process(A q,int caseid){
 double best=1e100;A plan{};int km=0;
 for(int j=0;j<7;j++)for(int h:{1,6}){A z{};for(int k=0;k<7;k++)z[k]=q[(j+k*h)%7];if(z[0]+z[1]!=10)continue;
 for(int i=2;i<=6;i++){double f=0,b=0;auto cost=[&](int a,int b){return max(0.1,log(double(Scnt[a+b])*cb(a+b,a)/Scnt[a]));};
 for(int t=2;t<=i;t++)f+=cost(z[t-1],z[t]);for(int t=6;t>=i;t--)b+=cost(z[(t+1)%7],z[t]);double sc=max(f,b)+.05*min(f,b);if(sc<best){best=sc;plan=z;km=i;}}}
 unsigned long long ans=0,ct=0;vector<U>total;map<U,double>exp;
 for(U P:big)for(U a=P;a;a=(a-1)&P){if(pc(a)!=plan[0])continue;
  U b=P^a;bool minimal=true;for(auto &g:G)if(act(P,g)==P && act(a,g)<a){minimal=false;break;}if(!minimal)continue;
  array<Counts,8>l,r;l[1][b]=1;r[7][a]=1;for(int t=2;t<=km;t++)l[t]=grow(l[t-1],plan[t]);for(int t=6;t>=km;t--)r[t]=grow(r[t+1],plan[t]);unsigned long long n=0,nre=0;Code X{};X[0]=a;X[1]=b;
  function<void(int)>post=[&](int t){if(t==7){auto k=canon(X);if(allC.insert(k).second){for(U w:k)out3<<w<<" ";out3<<'\n';out3.flush();}nre++;return;}int size=plan[t];U prev=X[t-1];vector<U>w;gen(safe(prev),size,0,w);for(U v:w)if(r[t].count(v)){X[t]=v;post(t+1);}};
  function<void(int)>pre=[&](int t){if(t==1){post(km+1);return;}U prev=X[t+1];vector<U>w;gen(safe(prev),plan[t],0,w);for(U v:w)if(l[t].count(v)){X[t]=v;pre(t-1);}};
  for(auto [s,m]:l[km]){auto it=r[km].find(s);if(it!=r[km].end()){n+=m*it->second;X[km]=s;pre(km-1);}}assert(n==nre);
  ans+=n;++ct;
 }
 cout<<caseid<<" ";for(int x:plan)cout<<x;cout<<" k="<<km<<" representatives="<<ct<<" count="<<ans<<" steps="<<steps<<" iso="<<allC.size()<<" cache="<<cache.size()<<endl;
}
int main(int ac,char**av){
 for(int j=0;j<49;j++)for(int x:{-1,0,1})for(int y:{-1,0,1})nb[j]|=1ULL<<(7*((j/7+x+7)%7)+(j%7+y+7)%7);
 for(int sw:{0,1})for(int a:{1,6})for(int b:{1,6})for(int p=0;p<7;p++)for(int q=0;q<7;q++){array<int,49>g;for(int j=0;j<49;j++){int u=sw?j%7:j/7,v=sw?j/7:j%7;g[j]=7*((a*u+p)%7)+(b*v+q)%7;}G.push_back(g);}
 vector<U>v;gen(all,10,0,v);set<U>s;for(U x:v){U mn=x;for(auto &g:G)mn=min(mn,act(x,g));s.insert(mn);}big={s.begin(),s.end()};for(U p:v){for(int j=0;j<G.size();j++)if(s.count(act(p,G[j])))can[p].push_back(j);assert(can.count(p));}
 set<A> marg;A q{};function<void(int,int)>go=[&](int i,int n){if(i==7){if(n||q[0]+q[6]>10)return;A m=q;for(int j=0;j<7;j++)for(int h:{1,6}){A t;for(int k=0;k<7;k++)t[k]=q[(j+k*h)%7];m=min(m,t);}marg.insert(m);return;}for(int a=0;a<=min(n,10);a++){if(i&&q[i-1]+a>10)continue;q[i]=a;go(i+1,n-a);}};go(0,33);int i=0;for(auto q:marg){if(ac<=1||atoi(av[1])==i)process(q,i);i++;}
}
