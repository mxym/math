#include <bits/stdc++.h>
using namespace std;using U=uint64_t;int pc(U x){return __builtin_popcountll(x);}constexpr U all=(1ULL<<49)-1;
int main(){array<U,49>nb{};for(int i=0;i<49;i++)for(int x:{-1,0,1})for(int y:{-1,0,1})nb[i]|=1ULL<<(7*((i/7+x+7)%7)+(i%7+y+7)%7);vector<array<int,49>>g;for(int a:{1,6})for(int b:{1,6})for(int h:{0,1})for(int u=0;u<7;u++)for(int v=0;v<7;v++){array<int,49>t;for(int i=0;i<49;i++)t[i]=7*((a*(h?i%7:i/7)+u)%7)+(b*(h?i/7:i%7)+v)%7;g.push_back(t);}
 unordered_set<U>seen;array<int,11>cnt{};ofstream o("plane.dat");o<<"0\n";cnt[0]=1;function<void(U,U)>f=[&](U w,U p){if(!seen.count(w)){o<<w<<"\n";cnt[pc(w)]++;for(auto&t:g){U s=0;for(U z=w;z;z&=z-1)s|=1ULL<<t[__builtin_ctzll(z)];if(s&1)seen.insert(s);}}
 while(p){int i=__builtin_ctzll(p);p&=p-1;f(w|(1ULL<<i),p&~nb[i]);}};f(1,all&~nb[0]);for(int k=0;k<=10;k++)cerr<<k<<" "<<cnt[k]<<endl;}
