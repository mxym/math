#include <bits/stdc++.h>
using namespace std;using U=uint64_t;using P=array<int,33>;using G=array<int,343>;
int cb[343][343];vector<P>S;vector<G>g;vector<array<int,3>>coords;
int id(int a,int b,int c){return 49*((a+14)%7)+7*((b+14)%7)+(c+14)%7;}
void read(){for(int i=0;i<343;i++)coords.push_back({i/49,(i/7)%7,i%7});for(int a=0;a<343;a++)for(int b=0;b<343;b++)cb[a][b]=id(coords[a][0]-coords[b][0],coords[a][1]-coords[b][1],coords[a][2]-coords[b][2]);
 ifstream f("three33.dat");U mm;while(f>>mm){P z;int n=0;for(int i=0;i<7;i++){if(i)f>>mm;for(U w=mm;w;w&=w-1){int j=__builtin_ctzll(w);z[n++]=49*i+j;}}assert(n==33);S.push_back(z);}assert(S.size()==1016);array<int,3>p{0,1,2};do{for(int t=0;t<8;t++){G Gg;for(int i=0;i<343;i++){array<int,3>v;for(int j=0;j<3;j++)v[j]=(t>>j&1?-1:1)*coords[i][p[j]];Gg[i]=id(v[0],v[1],v[2]);}g.push_back(Gg);}}while(next_permutation(p.begin(),p.end()));}
