#!/bin/sh
set -eu
export LC_ALL=C OPENBLAS_NUM_THREADS=1
for n in plane catalogue labelled_total cross114 tiles114 raw114; do
 c++ -std=c++17 -O3 -march=native "$n.cpp" -o "$n"
done
./plane 2>plane.log
./catalogue >catalogue.log
./labelled_total >labeled.log
python3 audit_census.py
./cross114 0 1016 edges114.dat >cross114.log 2>cross114.stats
./tiles114 >tiles114.log 2>&1
./raw114 >raw114.log 2>raw114.stats
python3 check.py
