#define main main_cross_unused
#include "cross114.cpp"
#undef main
using Tile=array<U,4>;
struct Cut{int ref,src,gi,j,ov,b[3];int tid[3][7];vector<int>opts[3];bool alive=true;};
map<Tile,int> idT;vector<int> dual;
Tile orit(const Tile&v,int rg,int cg){Tile out;for(int i=0;i<2;i++)for(int j=0;j<2;j++)out[2*i+j]=v[2*(i^rg)+(j^cg)];return out;}
Tile canon(Tile v){Tile best={~0ULL,~0ULL,~0ULL,~0ULL};for(int r=0;r<2;r++)for(int c=0;c<2;c++){auto w=orit(v,r,c);auto nn=norms.at(w[0]);for(auto ii:nn.gs){Tile a={(U)nn.id,act(w[1],gplane[ii]),act(w[2],gplane[ii]),act(w[3],gplane[ii])};best=min(best,a);}}return best;}
int name(Tile v){auto k=canon(v);auto p=idT.emplace(k,idT.size());return p.first->second;}
int main(){read();prepare();vector<Cut>E;Cut e;ifstream f("edges114.dat");while(f>>e.ref>>e.src>>e.gi>>e.j>>e.ov>>e.b[0]>>e.b[1]>>e.b[2]){P H;for(int i=0;i<33;i++)H[i]=cb[g[e.gi][S[e.src][i]]][cb[0][e.j]];auto r=sheets(S[e.ref]),s=sheets(H);for(int h=0;h<3;h++){e.opts[h].clear();for(int t=0;t<7;t++){int u=(t+1)%7;Tile v={r[h][t],r[h][u],s[h][t],s[h][u]};int id=name(v);swap(v[1],v[2]);int ii=name(v);dual.resize(idT.size(),-1);assert(dual[id]==-1||dual[id]==ii);dual[id]=ii;dual[ii]=id;e.tid[h][t]=id;}for(int a=0;a<128;a++)if(!(a&e.b[h])&&__builtin_popcount((unsigned)a)>=4)e.opts[h].push_back(a);assert(!e.opts[h].empty());}E.push_back(e);}cerr<<"start "<<E.size()<<" tiles="<<idT.size()<<endl;
 for(int iter=0;;iter++){vector<char>supported(idT.size());for(auto&e:E)if(e.alive)for(int h=0;h<3;h++)for(int a:e.opts[h])for(int t=0;t<7;t++)if((a>>t&1)&&(a>>((t+1)%7)&1))supported[e.tid[h][t]]=1;int n=0,nopt=0,changes=0;for(auto&e:E)if(e.alive){for(int h=0;h<3;h++){vector<int> vv;for(int a:e.opts[h]){bool ok=1;for(int t=0;t<7;t++)if((a>>t&1)&&(a>>((t+1)%7)&1)&&!supported[dual[e.tid[h][t]]])ok=0;if(ok)vv.push_back(a);else changes++;}e.opts[h].swap(vv);if(e.opts[h].empty())e.alive=false;}if(e.alive){n++;for(auto&v:e.opts)nopt+=v.size();}}
cerr<<iter<<" survive="<<n<<" patterns="<<nopt<<" removed="<<changes<<endl;if(!changes)break;}ofstream out("edges114_tile.dat");for(auto&e:E)if(e.alive){out<<e.ref<<' '<<e.src<<' '<<e.gi<<' '<<e.j<<' '<<e.ov;for(int i:e.b)out<<' '<<i;for(auto&v:e.opts){out<<' '<<v.size();for(int i:v)out<<' '<<i;}out<<'\n';}}
