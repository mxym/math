#include "space3.hpp"
using U=uint64_t;using g2=array<int,49>;using V=array<array<U,7>,3>;struct Pair{int a;U b;bool operator==(const Pair&o)const{return a==o.a&&b==o.b;}};struct HH{size_t operator()(Pair p)const{return (p.b*0x9e3779b97f4a7c15ULL)^(p.a*0xbf58476d1ce4e5b9ULL);}};
vector<g2>gplane;struct Nm{int id;vector<int>gs;};unordered_map<U,Nm>norms;unordered_set<Pair,HH> lit[4];unordered_map<U,vector<int>> orb;
U act(U v,const g2 &g){U b=0;while(v){b|=U(1)<<g[__builtin_ctzll(v)];v&=v-1;}return b;}
V sheets(P c){V x{};for(int v:c){auto t=coords[v];for(int j=0;j<3;j++)x[j][t[j]]|=1ULL<<(7*t[(j+1)%3]+t[(j+2)%3]);}V y=x;for(int h=0;h<3;h++)for(int j=0;j<7;j++){assert(!(x[h][j]&x[h][(j+1)%7]));y[h][j]|=x[h][(j+1)%7];}return y;}
Pair key(U a,U b){auto &g=norms.at(a);U v=~0ULL;for(int i:g.gs)v=min(v,act(b,gplane[i]));return {g.id,v};}
void prepare(){for(int sw:{0,1})for(int a:{1,6})for(int b:{1,6})for(int t=0;t<7;t++)for(int u=0;u<7;u++){g2 g;for(int j=0;j<49;j++)g[j]=7*((a*(sw?j%7:j/7)+t)%7)+(b*(sw?j/7:j%7)+u)%7;gplane.push_back(g);}
 ifstream pp("plane.dat");U v;int i=0;while(pp>>v){if(__builtin_popcountll(v)>=7){for(int j=0;j<(int)gplane.size();j++){U m=act(v,gplane[j]);auto &g=norms[m];g.id=i;
 // derive inverse plane map once, use it as normalization orientation
 if(!orb.count(j)){int inv=-1;for(int k=0;k<392;k++){bool ok=true;for(int l:{0,1,7})if(gplane[k][gplane[j][l]]!=l)ok=false;if(ok){inv=k;break;}}assert(inv>=0);orb[j]={inv};}
 g.gs.push_back(orb[j][0]);}}i++;}
 for(auto&c:S){auto y=sheets(c);for(auto &w:y)for(int h=1;h<=3;h++)for(int j=0;j<7;j++)for(int dir:{1,6})lit[h].insert(key(w[j],w[(j+dir*h)%7]));}cerr<<"norms "<<norms.size()<<" pair classes "<<lit[1].size()<<" "<<lit[2].size()<<" "<<lit[3].size()<<endl;}
int main(int ac,char**av){read();prepare();int fi0=ac>=2?atoi(av[1]):0,n=ac>=3?atoi(av[2]):8;ofstream edge;if(ac>=4)edge.open(av[3]);for(int fi=fi0;fi<min(int(S.size()),fi0+n);fi++){P F=S[fi];auto r=sheets(F);long long ct[34]{};int ma=0,np=0;
 for(int j0=0;j0<S.size();j0++){auto &P0=S[j0];for(int gi=0;gi<48;gi++){auto &gg=g[gi];P q;for(int i=0;i<33;i++)q[i]=gg[P0[i]];unsigned char a[343]{};for(int u:q)for(int v:F)a[cb[v][u]]++;
 for(int j=0;j<343;j++)if(a[j]>=15){np++;P H;for(int i=0;i<33;i++)H[i]=cb[q[i]][cb[0][j]];auto s=sheets(H);bool ok=true;int exc[3]={0,0,0};
 for(int h=0;h<3&&ok;h++){for(int t=0;t<7;t++)if(!lit[1].count(key(r[h][t],s[h][t]))){exc[h]|=1<<t;if(__builtin_popcount((unsigned)exc[h])>3){ok=false;break;}}}
 if(ok){ct[a[j]]++;ma=max(ma,33-a[j]);if(edge)edge<<fi<<" "<<j0<<" "<<gi<<" "<<j<<" "<<(int)a[j]<<" "<<exc[0]<<" "<<exc[1]<<" "<<exc[2]<<'\n';}
 }}}
 cout<<fi<<" before="<<np<<" maxdiff="<<ma<<" counts ";for(int i=15;i<=33;i++)cout<<ct[i]<<' ';cout<<endl;}}
