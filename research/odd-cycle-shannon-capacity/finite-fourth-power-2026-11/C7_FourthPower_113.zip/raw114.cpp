#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <tuple>
#include <unordered_set>
#include <vector>
#include <map>
#include <set>
using namespace std;using U=uint64_t;using T=array<int,3>;using Board=array<U,7>;using Three=array<Board,3>;
struct Two {U lo,hi;Two(U a,U b):lo(min(a,b)),hi(max(a,b)){} bool operator==(const Two&x) const {return lo==x.lo&&hi==x.hi;}};
struct Hash{size_t operator()(const Two&p)const {U x=p.lo^(p.hi+0x9e3779b97f4a7c15ULL+(p.lo<<6)+(p.lo>>2));x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;return x^(x>>27);}};
int md(int z){return(z%7+7)%7;}
Three slices(vector<T> x,bool band){Three v{};for(auto p:x)for(int i=0;i<3;i++){array<int,2>q{};int n=0;for(int j=0;j<3;j++)if(i!=j)q[n++]=p[j];v[i][p[i]]|=U(1)<<(7*q[0]+q[1]);}if(band){Three w=v;for(int h=0;h<3;h++)for(int r=0;r<7;r++){assert(!(v[h][r]&w[h][(r+1)%7]));v[h][r]|=w[h][(r+1)%7];}}return v;}
using Four=array<U,4>;using Grid=array<array<Four,7>,3>;struct Edge{Grid tile;array<int,3> bad;};
int main(int argc,char**argv){vector<Edge> staged;ifstream f("three33.dat");vector<vector<T>> src;U a;while(f>>a){vector<T>x;for(int k=0;k<7;k++){if(k)f>>a;for(int j=0;j<49;j++)if(a& (U(1)<<j))x.push_back({k,j/7,j%7});}assert(x.size()==33);src.push_back(x);}assert(src.size()==1016);
 unordered_set<Two,Hash> allowed;allowed.reserve(3000000);vector<array<int,49>> orbit;for(int tr=0;tr<49;tr++)for(int s:{1,-1})for(int t:{1,-1})for(int sw=0;sw<2;sw++) {array<int,49>g;for(int i=0;i<49;i++) {int u=i/7,v=i%7;if(sw)swap(u,v);g[i]=7*md(s*u+tr/7)+md(t*v+tr%7);}orbit.push_back(g);}
 vector<Three>bands;vector<Board> plane;for(auto x:src){Three bs=slices(x,true);bands.push_back(bs);plane.push_back(slices(x,false)[0]);
 for(auto seq:bs)for(auto &g:orbit){Board v{};for(int i=0;i<7;i++)for(U a=seq[i];a;a&=a-1)v[i]|=U(1)<<g[__builtin_ctzll(a)];for(int i=0;i<7;i++)allowed.emplace(v[i],v[(i+1)%7]);}}
 cerr<<"allowed labelled unordered pairs "<<allowed.size()<<endl;long long overlap=0,survive=0;int lim=argc>1?atoi(argv[1]):1016;
 for(int si=0;si<lim;si++){vector<Three>L;array<vector<U>,7>B;array<int,3>p{0,1,2};do{for(int mask=0;mask<8;mask++)for(int tr=0;tr<343;tr++){
 vector<T> Y=src[si];for(auto &x:Y){auto y=x;int k=tr;for(int i=0;i<3;i++,k/=7)x[i]=md(((mask>>i)&1?-1:1)*y[p[i]]+k%7);}auto b=slices(Y,false)[0];for(int j=0;j<7;j++)B[j].push_back(b[j]);L.push_back(slices(Y,true));
 }}while(next_permutation(p.begin(),p.end()));assert(L.size()==16464);
 vector<unsigned char> dots(16464);for(int fi=0;fi<1016;fi++){fill(dots.begin(),dots.end(),0);for(int h=0;h<7;h++){U b=plane[fi][h];auto &s=B[h];for(int j=0;j<16464;j++)dots[j]+=__builtin_popcountll(b&s[j]);}
 for(int j=0;j<16464;j++)if(dots[j]>=15){++overlap;bool ok=true;array<int,3>bad{};for(int d=0;d<3&&ok;d++){int c=0;for(int k=0;k<7;k++)if(!allowed.count(Two(bands[fi][d][k],L[j][d][k]))){bad[d]|=1<<k;if(++c>3){ok=false;break;}}}if(ok){survive++;Edge e{};e.bad=bad;for(int d=0;d<3;d++)for(int k=0;k<7;k++){int j1=(k+1)%7;e.tile[d][k]={bands[fi][d][k],bands[fi][d][j1],L[j][d][k],L[j][d][j1]};}staged.push_back(e);}}
 }if(si%50==0||si+1==lim)cout<<si+1<<" "<<overlap<<" "<<survive<<endl;}

 // No representatives of planar shape classes: compute all 392 simultaneous images
 // and all four common row/column reversals, minimizing the full quadruple.
 map<U,array<U,392>> image;auto images=[&](U a) -> const array<U,392>& {auto r=image.try_emplace(a);auto &im=r.first->second;if(r.second)for(int j=0;j<392;j++)for(U x=a;x;x&=x-1)im[j]|=U(1)<<orbit[j][__builtin_ctzll(x)];return im;};
 auto orbitkey=[&](const Four&f){auto &a=images(f[0]),&b=images(f[1]),&c=images(f[2]),&d=images(f[3]);Four m{~U(0),~U(0),~U(0),~U(0)};
 for(int j=0;j<392;j++){auto A=a[j],B=b[j],C=c[j],D=d[j];m=min(m,Four{A,B,C,D});m=min(m,Four{B,A,D,C});m=min(m,Four{C,D,A,B});m=min(m,Four{D,C,B,A});}return m;};
 set<Four> tab;for(auto&e:staged)for(int h=0;h<3;h++)for(int k=0;k<7;k++){int j=(k+1)%7;if(!(e.bad[h]&((1<<k)|(1<<j)))) tab.insert(orbitkey(e.tile[h][k]));}
 long long finalCount=0,weakCount=0;for(auto&e:staged){bool ok=1,weak=1;for(int h=0;h<3;h++){int allowedAdj=0;for(int k=0;k<7;k++){int j=(k+1)%7;if(e.bad[h]&((1<<k)|(1<<j)))continue;Four f=e.tile[h][k];swap(f[1],f[2]);if(tab.count(orbitkey(f)))allowedAdj|=1<<k;}
 weak=weak&&allowedAdj;
 bool has=false;for(int t=0;t<128;t++){if((t&e.bad[h])||__builtin_popcount((unsigned)t)<4)continue;const int adj=t&((t>>1)|((t&1)<<6));if(!(adj&~allowedAdj))has=true;}ok=ok&&has;
 }finalCount+=ok;weakCount+=weak;}
 cout<<"Complete "<<overlap<<" "<<survive<<" transpose-classes "<<tab.size()<<" weak "<<weakCount<<" strong "<<finalCount<<endl;if(lim==1016){assert(survive==11240 && finalCount==0);}}
