# Crossing extremal slabs in powers of the 7-cycle

Private exact-computation packet, 20 November 2026. In the fourth strong power of the 7-cycle, no 114-point independent set exists; in the fifth power, an independent set has at most 395 points. With the published lower constructions, the intervals are 108–113 and 367–395, respectively. These are finite-power results, not an upper bound on asymptotic Shannon capacity.

**Read note.pdf.** To regenerate the complete 3D classification, verify it and run the two independent 4D obstructions, extract in a writable directory then run:

    sha256sum -c SHA256SUMS
    sh replay.sh

Requires Python ≥3.10 with NumPy, and GCC-compatible 64-bit C++17 compiler on Linux/Unix, about 0.5 GB working memory and 30 MB working disk. There are no network or solver requirements, randomized decisions or timeouts. Use neither -DNDEBUG for C++ nor -O for Python; assertions must remain enabled. A full replay takes several minutes, depending on CPU. All orbit keys and numerical constraints are exact.

* plane.cpp/plane_geometry.hpp: recursively enumerate independent planar masks, recover all 980 ten-point masks and the three extremal plane classes.
* catalogue.cpp: all 33-point packings in three dimensions, up to coordinate permutations/reflections/translations. The output three33.dat is regenerated from scratch; the shipped three33_reference.dat only pins the expected replay.
* labelled_total.cpp: independent counts-only layer transfer with orbit weights, different pivot costs and no 3D canonicalization. audit_census.py checks each representative and independently canonicalizes coordinate lists to match its labelled count (16,672,544).
* cross114.cpp/space3.hpp: translation-difference counts and simultaneous planar normalization for first-pass candidates with overlap ≥15 and at most three failed crossings along each axis.
* tiles114.cpp: all available tiles and legal subsets of at least four good positions. Rows and columns may independently be reversed as wholes; never transpose within the equivalence, and never use independent isometries of the individual cells.
* raw114.cpp: separate, all-labelled pair/whole-tuple implementation; no use of plane.dat, cached plane normalizers, first-checker outputs or tile code. Generates 1,168,356 labelled unordered footprint pairs, exhausts all 30,365,208 high-overlap placements, retains 11,240 first-pass edges, records 3,351 available tile classes, with 58 weak survivors and zero full-subset survivors.
* check.py: verifies output counts from all stages, byte-compares the generated 3D catalogue and checks a 99-point product packing as a positive control (not the published 108-point lower bound).
