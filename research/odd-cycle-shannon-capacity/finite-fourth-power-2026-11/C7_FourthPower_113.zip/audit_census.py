from itertools import permutations,product,combinations
from collections import Counter
import numpy as np, re
S=[]
for line in open('three33.dat'):
 rows=list(map(int,line.split()));assert len(rows)==7
 w=sorted((i,j//7,j%7) for i,v in enumerate(rows) for j in range(49) if v>>j&1)
 assert len(w)==33 and all(any((a-b)%7 not in [0,1,6] for a,b in zip(x,y)) for x,y in combinations(w,2));S.append(np.array(w))
assert len(S)==1016
keys=set();tot=0;hs=Counter()
# Minimize the sorted coordinate list independently, no "maximal plane" anchoring:
# some chosen point translates to zero for every candidate minimum. Count equally minimal images.
powers=np.array([49,7,1]);pp=np.array(list(permutations(range(3))));ss=np.array(list(product([1,-1],repeat=3)))
def scan(w):
 a=(w[:,pp].transpose(1,0,2)[:,None,:,:]*ss[None,:,None,:]).reshape(48,33,3)
 v=((a[:,None,:,:]-a[:,:,None,:])%7)@powers;v.sort(axis=-1);v=v.reshape(-1,33)
 v=np.ascontiguousarray(v.astype('>u2'));z=v.view(np.dtype('V66')).ravel();idx=np.argsort(z);key=z[idx[0]].tobytes();cnt=sum(x.tobytes()==key for x in z[idx[:48]])
 assert 16464%cnt==0 and key not in keys;keys.add(key)
 return cnt
for w in S:
 st=scan(w);hs[st]+=1;tot+=16464//st
print('all distinct valid; group order=16464, stabilizers',dict(sorted(hs.items())),'labelled sum',tot,flush=True)
s=open('labeled.log').read()
assert s.count('labeled=')==20
if True:
 t=sum(map(int,re.findall(r'labeled=(\d+)',s)));print('independent layer transfer labelled sum',t);assert tot==t
assert hs==Counter({1:1011,2:1,3:3,6:1}) and tot==16672544
