#include "plane_geometry.hpp"
int64_t Scnt[]={1,49,980,10388,63553,229908,486668,576856,346381,81095,980};
int cb(int n,int k){int s=1;for(int i=1;i<=k;i++)s=s*(n-i+1)/i;return s;}
using Counts=unordered_map<U,unsigned long long>;unsigned long long steps=0;
Counts grow(Counts r,int k){Counts n;n.reserve(2*r.size()); for(auto [u,m]:r){if(pc(u)+k>=9){for(U v:ext(u,k))n[v]+=m;}else{vector<U>v;gen(safe(u),k,0,v);for(U w:v)n[w]+=m;}}steps+=n.size();return n;}
void process(A q,int caseid){
 double best=1e100;A plan{};int km=0;
 for(int j=0;j<7;j++)for(int h:{1,6}){A z{};for(int k=0;k<7;k++)z[k]=q[(j+k*h)%7];if(z[0]+z[1]!=10)continue;
 for(int i=2;i<=6;i++){double f=0,b=0;auto cost=[&](int a,int b){return max(0.1,log(double(Scnt[a+b])*cb(a+b,a)/Scnt[a]));};
 for(int t=2;t<=i;t++)f+=cost(z[t-1],z[t]);for(int t=6;t>=i;t--)b+=cost(z[(t+1)%7],z[t]);double sc=.75*max(f,b)+.20*f+.07*min(f,b)+.004*i;if(sc<best){best=sc;plan=z;km=i;}}}
 unsigned long long ans=0,ct=0;vector<U>total;map<U,double>exp;
 for(U P:big)for(U a=P;a;a=(a-1)&P){if(pc(a)!=plan[0])continue;
  U b=P^a;bool minimal=true;for(auto &g:G)if(act(P,g)==P && act(a,g)<a){minimal=false;break;}if(!minimal)continue;
  Counts left{{b,1}},right{{a,1}};for(int t=2;t<=km;t++)left=grow(move(left),plan[t]);for(int t=6;t>=km;t--)right=grow(move(right),plan[t]);unsigned long long n=0;for(auto [s,m]:left){auto it=right.find(s);if(it!=right.end())n+=m*it->second;}
  int stab=0;for(auto &gg:G)if(act(P,gg)==P&&act(a,gg)==a)++stab;assert(392%stab==0);ans+=n*(392/stab);++ct;
 }
 set<A>oq;for(int shift=0;shift<7;shift++)for(int d:{1,6}){A z;for(int j=0;j<7;j++)z[j]=q[(shift+d*j)%7];oq.insert(z);}cout<<caseid<<" orbit="<<oq.size()<<" labeled="<<oq.size()*ans<<" ";for(int x:plan)cout<<x;cout<<" k="<<km<<" representatives="<<ct<<" count="<<ans<<" steps="<<steps<<" cache="<<cache.size()<<endl;
}
int main(int ac,char**av){
 for(int j=0;j<49;j++)for(int x:{-1,0,1})for(int y:{-1,0,1})nb[j]|=1ULL<<(7*((j/7+x+7)%7)+(j%7+y+7)%7);
 for(int sw:{0,1})for(int a:{1,6})for(int b:{1,6})for(int p=0;p<7;p++)for(int q=0;q<7;q++){array<int,49>g;for(int j=0;j<49;j++){int u=sw?j%7:j/7,v=sw?j/7:j%7;g[j]=7*((a*u+p)%7)+(b*v+q)%7;}G.push_back(g);}
 vector<U>v;gen(all,10,0,v);set<U>s;for(U x:v){U mn=x;for(auto &g:G)mn=min(mn,act(x,g));s.insert(mn);}big={s.begin(),s.end()};
 set<A> marg;A q{};function<void(int,int)>go=[&](int i,int n){if(i==7){if(n||q[0]+q[6]>10)return;A m=q;for(int j=0;j<7;j++)for(int h:{1,6}){A t;for(int k=0;k<7;k++)t[k]=q[(j+k*h)%7];m=min(m,t);}marg.insert(m);return;}for(int a=0;a<=min(n,10);a++){if(i&&q[i-1]+a>10)continue;q[i]=a;go(i+1,n-a);}};go(0,33);int i=0;for(auto q:marg){if(ac<=1||atoi(av[1])==i)process(q,i);i++;}
}
