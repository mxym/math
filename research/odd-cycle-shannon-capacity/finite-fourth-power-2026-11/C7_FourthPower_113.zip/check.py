from itertools import combinations,product
from pathlib import Path
s=Path('cross114.log').read_text().splitlines();assert len(s)==1016
num=hits=0
for i,line in enumerate(s):
 r=line.split();assert int(r[0])==i;num+=int(r[1].split('=')[1]);hits+=sum(map(int,r[4:]))
assert num==30365208 and hits==11240
edges=Path('edges114.dat').read_text().splitlines();assert len(edges)==11240
for l in edges:
 fi,gi,p,t,k,a,b,c=map(int,l.split());assert 0<=fi<1016 and 0<=gi<1016 and 0<=p<48 and 0<=t<343 and 15<=k<=33 and all(0<=x<128 and x.bit_count()<=3 for x in [a,b,c])
assert '0 survive=0 patterns=0 removed=44075' in Path('tiles114.log').read_text()
assert not Path('edges114_tile.dat').stat().st_size
r=Path('raw114.log').read_text().splitlines()[-1].split()
assert r==['Complete','30365208','11240','transpose-classes','3351','weak','58','strong','0']
assert '1168356' in Path('raw114.stats').read_text()
assert Path('three33.dat').read_bytes()==Path('three33_reference.dat').read_bytes()
P=[(i,j//7,j%7) for i,b in enumerate(map(int,Path('three33.dat').read_text().splitlines()[0].split())) for j in range(49) if b>>j&1]
Z=[(t,)+p for t,p in product([0,2,4],P)]
assert len(Z)==99 and all(any((u-v)%7 not in (0,1,6) for u,v in zip(a,b)) for a,b in combinations(Z,2))
print('99-point positive packing verified. Complete: 30,365,208 high-overlap transformations; 11,240 preliminary candidates; zero surviving 4D edges in both exhaustive checks.')
