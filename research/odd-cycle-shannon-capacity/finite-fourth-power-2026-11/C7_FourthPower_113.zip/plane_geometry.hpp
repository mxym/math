#include <bits/stdc++.h>
using namespace std;using U=uint64_t;int pc(U x){return __builtin_popcountll(x);}const U all=(1ULL<<49)-1;array<U,49>nb;vector<array<int,49>>G;int N=33;using A=array<int,7>;vector<U> big;array<U,7>layers;set<A>yes;
U act(U u,const array<int,49>&g){U v=0;while(u){int j=__builtin_ctzll(u);u&=u-1;v|=1ULL<<g[j];}return v;}
U safe(U a){U b=all;while(a){b&=~nb[__builtin_ctzll(a)];a&=a-1;}return b;}
unordered_map<U,vector<U>>cache;long long nn=0;
void gen(U a,int k,U u,vector<U>&v){if(!k){v.push_back(u);return;}while(pc(a)>=k){int i=__builtin_ctzll(a);U b=1ULL<<i;a^=b;gen(a&~nb[i],k-1,u|b,v);}}
vector<U>&ext(U u,int k){U key=(u<<4)|k;auto it=cache.find(key);if(it!=cache.end())return it->second;auto &v=cache[key];gen(safe(u),k,0,v);return v;}
