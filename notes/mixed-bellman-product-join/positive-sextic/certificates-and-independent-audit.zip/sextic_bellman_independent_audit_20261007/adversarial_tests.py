#!/usr/bin/env python3
"""Read-only candidate checker tests, with corrupt fixtures isolated here."""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
import argparse, importlib.util, json, os, random, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'nonquartic_envelope_20261007'

def need(ok,msg):
    if not ok: raise ArithmeticError(msg)

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'adversarial_report.json');args=parser.parse_args()
    fin=module('finite_audit_source',SRC/'check_sextic_finite.py')
    tail=module('tail_audit_source',SRC/'sextic_tail_core.py')
    ind=module('sextic_independent',ROOT/'independent_check.py')
    rng=random.Random(20261007); interval_checks=0; log_checks=0
    for _ in range(500):
        a,b=sorted([F(rng.randrange(-100,101),rng.randrange(1,30)) for _ in range(2)])
        c,d=sorted([F(rng.randrange(-100,101),rng.randrange(1,30)) for _ in range(2)])
        v,w=tail.I(a,b),tail.I(c,d)
        for x in (a,(2*a+b)/3,(a+2*b)/3,b):
            for y in (c,(c+d)/2,d):
                for enclosure,value in ((v+w,x+y),(v-w,x-y),(v*w,x*y)):
                    need(enclosure.lo<=value<=enclosure.hi,'interval arithmetic exclusion');interval_checks+=1
                if not c<=0<=d:
                    enclosure=v/w;need(enclosure.lo<=x/y<=enclosure.hi,'interval division');interval_checks+=1
            for p in range(8):
                enclosure=v**p;need(enclosure.lo<=x**p<=enclosure.hi,'interval power');interval_checks+=1
        q=F(rng.randrange(1,10000),rng.randrange(1,10000))*F(2)**rng.randrange(-50,51)
        bounds=fin.log_bounds(q); tbound=tail.log_bounds(q); reference=ind.logarithm(q)
        # Thirty-term, 112-bit independent interval fits the wider supplied
        # twenty-term finite and twenty-eight-term decimal-rounding intervals.
        need(bounds[0]<=reference.a<=reference.b<=bounds[1],'finite logarithm enclosure')
        need(tbound.lo<=reference.a<=reference.b<=tbound.hi,'tail logarithm enclosure');log_checks+=2
    product_checks=0; coefficient_checks=0; parabola_checks=0
    for _ in range(1000):
        r,s=rng.randrange(1,10001),rng.randrange(1,10001); n=r+s
        h=F(2)+F(rng.randrange(10001),10000)*(r-1)
        j=F(2)+F(rng.randrange(10001),10000)*(s-1)
        H=F(n)/(F(r)/h+F(s)/j)
        for p in (2,4,6):
            if p==2:
                moment=h*h/(r+1)+j*j/(s+1)-(r*h+s*j)**2/(n*n*(n+1))
            else:
                moment=(F(1,(r+1)**(p-1))-F(r,n*(n+1)**(p-1)))*h**p
                moment+=(F(1,(s+1)**(p-1))-F(s,n*(n+1)**(p-1)))*j**p
            defect=-1+h**p/(r+1)**(p-1)+j**p/(s+1)**(p-1)-H**p/(n+1)**(p-1)
            need(defect>=moment-1,'power-mean reduction');product_checks+=1
        z=F(1,s); u=j/(s+1); a,b,c,a4,d4,a6,d6=tail.coefficients(r,z)
        need(a*h*h+b*h*u+c*u*u==h*h/(r+1)+j*j/(s+1)-(r*h+s*j)**2/(n*n*(n+1)),'quadratic normalized coefficient')
        for p,ap,dp in ((4,a4,d4),(6,a6,d6)):
            direct=(F(1,(r+1)**(p-1))-F(r,n*(n+1)**(p-1)))*h**p
            direct+=(F(1,(s+1)**(p-1))-F(s,n*(n+1)**(p-1)))*j**p
            need(ap*h**p+dp*u**p==direct,'power normalized coefficient')
        coefficient_checks+=3
        ga,gb=sorted([F(rng.randrange(-100,101),rng.randrange(1,30)) for _ in range(2)])
        m=F(rng.randrange(1,100),rng.randrange(1,30));lo=F(-rng.randrange(100),17);hi=F(rng.randrange(100),19)
        enclosure=tail.parabola_box(tail.I(ga,gb),m,lo,hi)
        for i in range(21):
            eta=lo+(hi-lo)*F(i,20)
            for slope in (ga,(ga+gb)/2,gb):
                need(slope*eta-tail.ALPHA*m*eta*eta<=enclosure,'scalar quadratic maximum');parabola_checks+=1
    base=json.loads((SRC/'sextic_finite_points.json').read_text())
    fixtures=[]
    def add(name,change):
        data=deepcopy(base);change(data);fixtures.append((name,data))
    add('wrong coefficient',lambda d:d['coefficients'][2].__setitem__(0,198))
    add('wrong T',lambda d:d.__setitem__('T',[4868,100000]))
    add('missing rectangle',lambda d:d['points'].pop())
    add('wrong ordered dimension',lambda d:d['points'][0].__setitem__(0,2))
    add('noninteger coordinate',lambda d:d['points'][0].__setitem__(2,2.0))
    add('out of box',lambda d:d['points'][0].__setitem__(2,0))
    add('invalid denominator',lambda d:d.__setitem__('denominator',0))
    at=next(i for i,row in enumerate(base['points']) if row[:2]==[25,25])
    add('mathematically inadequate tangent',lambda d:d['points'].__setitem__(at,[25,25,2*base['denominator'],2*base['denominator']]))
    rejected=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
        tmp=Path(tmp)
        for optimized in (False,True):
            flags=['-O'] if optimized else []
            for name,data in fixtures:
                path=tmp/'finite.json';path.write_text(json.dumps(data))
                result=subprocess.run([sys.executable,*flags,str(SRC/'check_sextic_finite.py'),str(path),'--quiet'],capture_output=True,text=True,env=env)
                need(result.returncode!=0 and 'ArithmeticError' in result.stderr,f'bad finite fixture accepted: {name}')
                rejected.append({'name':name,'optimized':optimized,'error':result.stderr.strip().splitlines()[-1]})
        # Tail parser reads a fixed relative filename. Isolate verbatim checker
        # copies and only tiny corrupted fixtures in the temporary directory.
        full=SRC/'sextic_tail_certificate.json'
        if full.exists():
            tbase=json.loads(full.read_text()); tbase['cells']=tbase['cells'][:1]
            for name in ('check_sextic_tail.py','sextic_tail_core.py'):
                (tmp/name).write_bytes((SRC/name).read_bytes())
            tail_fixtures=[]
            def ta(name,change):
                data=deepcopy(tbase);change(data);tail_fixtures.append((name,data))
            ta('tail wrong gamma',lambda d:d.__setitem__('gamma','198/100000'))
            ta('tail incomplete coverage',lambda d:None)
            ta('tail duplicate cell',lambda d:d['cells'].append(d['cells'][0]))
            ta('tail point out of box',lambda d:d['cells'][0].__setitem__(3,0))
            ta('tail negative depth',lambda d:d['cells'][0].__setitem__(2,-1))
            ta('tail noninteger coordinate',lambda d:d['cells'][0].__setitem__(4,0.0))
            for optimized in (False,True):
                flags=['-O'] if optimized else []
                for name,data in tail_fixtures:
                    (tmp/'sextic_tail_certificate.json').write_text(json.dumps(data))
                    result=subprocess.run([sys.executable,*flags,str(tmp/'check_sextic_tail.py')],capture_output=True,text=True,env=env)
                    need(result.returncode!=0 and 'RuntimeError' in result.stderr,f'bad tail fixture accepted: {name}')
                    rejected.append({'name':name,'optimized':optimized,'error':result.stderr.strip().splitlines()[-1]})
    result={'status':'PASS','exact_interval_sample_checks':interval_checks,'independent_log_checks':log_checks,
            'exact_product_reduction_checks':product_checks,'exact_normalized_coefficient_checks':coefficient_checks,
            'exact_scalar_quadratic_checks':parabola_checks,
            'corrupted_fixtures_rejected':rejected,'full_tail_available':full.exists()}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
