#!/usr/bin/env python3
"""Separately written sextic audit. Does not import the candidate's modules.

Modes: symbolic identities, finite supporting planes, complete tail cells.
SymPy is used only for symbolic polynomial identities. All numerical proof
decisions are standard-library integer/Fraction arithmetic; checks survive -O.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
from math import comb
import argparse, hashlib, json, time

A, B, G = F(431, 10000), F(9, 2500), F(197, 100000)
T = A+B+G
POWERS = ((2,A),(4,B),(6,G))
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent/'nonquartic_envelope_20261007'

def check(ok, message):
    if not ok:
        raise ArithmeticError(message)

class V:
    def __init__(self, a, b=None):
        self.a, self.b = F(a), F(a if b is None else b)
        check(self.a <= self.b, 'reversed interval')
    @staticmethod
    def v(x): return x if isinstance(x,V) else V(x)
    def __add__(self,x):
        x=self.v(x); return V(self.a+x.a,self.b+x.b)
    __radd__=__add__
    def __neg__(self): return V(-self.b,-self.a)
    def __sub__(self,x): return self+-self.v(x)
    def __rsub__(self,x): return self.v(x)+-self
    def __mul__(self,x):
        x=self.v(x); p=[self.a*x.a,self.a*x.b,self.b*x.a,self.b*x.b]
        return V(min(p),max(p))
    __rmul__=__mul__
    def __truediv__(self,x):
        x=self.v(x); check(x.a>0 or x.b<0,'zero denominator')
        return self*V(1/x.b,1/x.a)
    def __rtruediv__(self,x): return self.v(x)/self
    def __pow__(self,p):
        check(type(p) is int and p>=0,'unsupported power')
        if p==0: return V(1)
        q=[self.a**p,self.b**p]
        if p%2==0 and self.a<=0<=self.b: q.append(F(0))
        return V(min(q),max(q))

def rounding(v, bits=112):
    d=1<<bits
    return V(F((v.a.numerator*d)//v.a.denominator,d),
             F(-((-v.b.numerator*d)//v.b.denominator),d))

@lru_cache(maxsize=100000)
def unit_log(y):
    check(1<=y<=2,'unit log domain')
    w=(y-1)/(y+1); low=F(0); term=w
    for m in range(30):
        low += 2*term/(2*m+1)
        term *= w*w
    return rounding(V(low,low+2*term/(61*(1-w*w))))

@lru_cache(maxsize=100000)
def logarithm(x):
    x=F(x); check(x>0,'log domain')
    # Exact bit-length normalization, then at most one adjustment each way.
    k=x.numerator.bit_length()-x.denominator.bit_length()
    y=x/(F(2)**k)
    if y<1: k-=1; y*=2
    if y>=2: k+=1; y/=2
    check(1<=y<2,'binary reduction')
    return rounding(unit_log(y)+k*unit_log(F(2)))

@lru_cache(maxsize=400)
def log_g(r):
    return r*logarithm(F(r))-sum((logarithm(F(k)) for k in range(1,r+1)),V(0))

def finite():
    path=SOURCE/'sextic_finite_points.json'; data=json.loads(path.read_text())
    check(data['schema']==1 and data['dimension_max']==199,'finite schema')
    check(data['coefficients']==[[431,10000],[9,2500],[197,100000]] and data['T']==[4867,100000],'finite parameters')
    den=data['denominator']; check(type(den) is int and den>0,'finite denominator')
    rows=data['points']; check(len(rows)==19900,'finite count')
    worst=None; count=0
    for r in range(1,200):
        for s in range(r,200):
            row=rows[count]; check(type(row) is list and len(row)==4 and all(type(i) is int for i in row),'finite row type')
            check(row[:2]==[r,s],'finite coverage')
            h,j=F(row[2],den),F(row[3],den); check(2<=h<=r+1 and 2<=j<=s+1,'finite state')
            n=r+s; x=(s*h+r*j)/n; weighted=r*h+s*j
            penalty=F(0); dh,dj=F(s,n)/x,F(r,n)/x
            for p,c in POWERS:
                if p==2:
                    moment=h*h/(r+1)+j*j/(s+1)-weighted*weighted/(n*n*(n+1))
                    ph=2*h/(r+1)-2*r*weighted/(n*n*(n+1))
                    pj=2*j/(s+1)-2*s*weighted/(n*n*(n+1))
                else:
                    ah=F(1,(r+1)**(p-1))-F(r,n*(n+1)**(p-1))
                    aj=F(1,(s+1)**(p-1))-F(s,n*(n+1)**(p-1))
                    check(ah>0 and aj>0,'finite convexity')
                    moment=ah*h**p+aj*j**p; ph=p*ah*h**(p-1); pj=p*aj*j**(p-1)
                penalty+=c*moment; dh-=c*ph; dj-=c*pj
            # Generic support function of the translated rectangle.
            support=max(dh*(2-h),dh*(r+1-h))+max(dj*(2-j),dj*(s+1-j))
            ub=(log_g(r)+log_g(s)-log_g(n)+logarithm(x)).b-penalty+T+support
            check(ub<F(-1,1000000),f'finite inequality {r},{s}')
            if worst is None or ub>worst[0]: worst=(ub,row)
            count+=1
    return {'status':'PASS','count':count,'series_terms':30,'rounding_bits':112,
            'worst_upper':str(worst[0]),'worst_row':worst[1],
            'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def polynomial_mul(a,b):
    q=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): q[i+j]+=x*y
    return q

@lru_cache(maxsize=400)
def cancelled_polynomial(r,p):
    # Build P_p, then divide P_p-(1+z)^(p-1) by r*z as a polynomial.
    q=polynomial_mul([F(1),F(r)],[F(comb(p-1,k)*(r+1)**k) for k in range(p)])
    q=[q[k]-(F(comb(p-1,k)) if k<p else 0) for k in range(p+1)]
    check(q[0]==0 and all(c>0 for c in q[1:]),'cancelled numerator coefficients')
    return tuple(q)

def cancelled_coefficients(r,z,p):
    q=cancelled_polynomial(r,p)
    divisor=(1+r*z)*(1+(r+1)*z)**(p-1)
    a=F(1,(r+1)**(p-1))-r*z**p/divisor
    d=(1+z)*sum((q[k]*z**(k-1) for k in range(1,p+1)),V(0))/divisor
    return a,d

@lru_cache(maxsize=200)
def quadratic_polynomial(r):
    # Separate cancellation for the arithmetic-mean quadratic moment.
    coeff=polynomial_mul([F(1),F(2*r),F(r*r)],[F(1),F(r+1)])
    coeff[0]-=1; coeff[1]-=1
    return tuple(coeff)

def quadratic_coefficients(r,z):
    coeff=quadratic_polynomial(r)
    denominator=(1+r*z)**2*(1+(r+1)*z)
    a=F(1,r+1)-r*r*z**3/denominator
    b=-2*r*z*(1+z)/denominator
    c=(1+z)*sum((coeff[k]*z**(k-1) for k in range(1,4)),V(0))/denominator
    return a,b,c

def supremum_piece(g,m,lo,hi):
    check(m>0 and lo<=0<=hi,'concavity parameters')
    out=F(0)
    for slope,left,right in ((g.a,lo,F(0)),(g.b,F(0),hi)):
        vertex=slope/(2*A*m)
        candidates=[left,right]
        if left<=vertex<=right: candidates.append(vertex)
        out=max(out,*(slope*x-A*m*x*x for x in candidates))
    return out

def tail_cell(r,left,right,h,u):
    check(1<=r<=199 and 0<=left<right<=F(1,200),'tail dimension interval')
    check(2<=h<=r+1 and 0<=u<=1,'tail state')
    z=V(left,right); a,b,c=quadratic_coefficients(r,z)
    check(a.a>0,'quadratic first diagonal')
    mh=a.a/2; mu=c.a-max(b.a*b.a,b.b*b.b)/(2*a.a)
    check(mu>0,'quadratic Young bound')
    first=h+r*(1+z)*u; second=1+r*z
    check(first.a>0 and second.a>0,'tail log domains')
    penalty=A*(a*h*h+b*h*u+c*u*u)
    dh=1/first-A*(2*a*h+b*u)
    du=r*(1+z)/first-A*(b*h+2*c*u)
    for p,coefficient in ((4,B),(6,G)):
        ap,dp=cancelled_coefficients(r,z,p)
        check(ap.a>0 and dp.a>0,'tail positive power coefficients')
        penalty+=coefficient*(ap*h**p+dp*u**p)
        dh-=coefficient*p*ap*h**(p-1)
        du-=coefficient*p*dp*u**(p-1)
    val=(log_g(r)-r).b+logarithm(first.b).b-logarithm(second.a).a/2-penalty.a+T
    return val+supremum_piece(dh,mh,2-h,r+1-h)+supremum_piece(du,mu,-u,1-u)

def tail():
    path=SOURCE/'sextic_tail_certificate.json'; data=json.loads(path.read_text())
    check(data['schema']==1 and data['cutoff']==200 and data['point_denominator']==10**8,'tail schema')
    check((data['alpha'],data['beta'],data['gamma'])==(str(A),str(B),str(G)),'tail parameters')
    coverage={r:[] for r in range(1,200)}; worst=None; count=0; start=time.monotonic()
    for row in data['cells']:
        check(type(row) is list and len(row)==5 and all(type(x) is int for x in row),'tail row type')
        r,i,d,hn,un=row; check(r in coverage and 0<=d<=24 and 0<=i<2**d,'tail dyadic coordinates')
        left,right=F(i,200*2**d),F(i+1,200*2**d)
        bound=tail_cell(r,left,right,F(hn,10**8),F(un,10**8))
        check(bound<F(-1,10**10),f'tail inequality {row}')
        coverage[r].append((left,right))
        if worst is None or bound>worst[0]: worst=bound,row
        count+=1
        if count%10000==0: print(json.dumps({'cells':count,'elapsed_seconds':round(time.monotonic()-start,1)}),flush=True)
    for r,cells in coverage.items():
        end=F(0)
        for left,right in sorted(cells):
            check(left==end,f'tail coverage {r}'); end=right
        check(end==F(1,200),f'tail endpoint {r}')
    return {'status':'PASS','cells':count,'maximum_depth':max(row[2] for row in data['cells']),
            'series_terms':30,'rounding_bits':112,'worst_upper':str(worst[0]),'worst_row':worst[1],
            'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def symbolic():
    import sympy as S
    r,s,h,j,z,t,tau=S.symbols('r s h j z t tau',positive=True)
    n=r+s; g2=h*h/(r+1)+j*j/(s+1)-(r*h+s*j)**2/(n*n*(n+1))
    names=[]
    def identity(name,expr):
        check(S.factor(expr)==0,name); names.append(name)
    matrix=S.hessian(g2,(h,j))/2
    identity('quadratic determinant',matrix.det()-r*s*(3*n+2)/((r+1)*n*n*(s+1)*(n+1)))
    delta=4*r*s+3*n+2; x=(s*h+r*j)/n
    square=r*s*((s+1)*(3*r+s+2)*h-(r+1)*(r+3*s+2)*j)**2/((r+1)*n*n*(s+1)*(n+1)*delta)
    identity('quadratic constrained minimum square',g2-(3*n+2)/delta*x*x-square)
    denominator=(1+r*z)**2*(1+(r+1)*z)
    normalized=(F(1)*h*h/(r+1)-r*r*z**3/denominator*h*h
      -2*r*z*(1+z)/denominator*h*j
      +r*(1+z)*(3+(3*r+2)*z+r*(r+1)*z*z)/denominator*j*j)
    identity('quadratic normalized cancellation',g2.subs({s:1/z,j:(1+z)*j/z}, simultaneous=True)-normalized)
    for p in (4,6,8,10):
        P=(1+r*z)*(1+(r+1)*z)**(p-1)
        Sp=sum(((comb(p-1,k)*((r+1)**k-1)+r*comb(p-1,k-1)*(r+1)**(k-1))/r*z**(k-1)
          if k<p else (r+1)**(p-1)*z**(k-1)) for k in range(1,p+1))
        identity(f'generalized S_{p} polynomial quotient',P-(1+z)**(p-1)-r*z*Sp)
        coeff=S.Rational(1,1)/(s+1)**(p-1)-s/((r+s)*(r+s+1)**(p-1))
        identity(f'normalized large-state p={p} coefficient',
          coeff.subs(s,1/z)*((1+z)/z)**p-r*(1+z)*Sp/P)
    K2=(3*(1+t)+2*t*tau)/(4+3*(1+t)*tau+2*t*tau*tau)
    identity('large K2 normalization',((3*n+2)/delta*r).subs({r:1/tau,s:1/(t*tau)},simultaneous=True)-K2)
    identity('large K0-K2 subtraction',3*(1+t)/4-K2-tau*(9*(1+t)**2-8*t+6*t*(1+t)*tau)/(4*(4+3*(1+t)*tau+2*t*tau*tau)))
    P=1+4*t+6*t*t+4*t**3; Q=4+6*t+4*t*t+t**3
    identity('quartic auxiliary Q squared',Q*Q-16*(1+t)**3-(t**6+8*t**5+28*t**4+40*t**3+20*t*t))
    return {'status':'PASS','identities':names,'count':len(names)}

def large():
    # Polynomial computed symbolically, transformed separately to Bernstein.
    import sympy as S
    t=S.symbols('t'); sa,sb=S.Rational(A.numerator,A.denominator),S.Rational(B.numerator,B.denominator)
    dd=(9+S.Rational(1003,100)*t+S.Rational(903,100)*t*t)/16
    rr=S.Rational(413,250)+S.Rational(21,40)*t
    pol=S.Poly(S.Rational(7,50)*(1+t)**4-t*(1+t)**3/12
      +S.Rational(200,2401)*(1+t)**5-sa*sa/(4*sb*S.Rational(123,125))*dd*dd*rr**3,t)
    check(pol.degree()==7,'large degree')
    # Derive Bernstein coefficients by recursive coefficient elimination.
    residual=pol.as_expr(); coefficients=[]
    for i in range(8):
        lead=S.expand(residual).coeff(t,i)
        bi=lead/comb(7,i); coefficients.append(F(int(S.numer(bi)),int(S.denom(bi))))
        residual=S.expand(residual-bi*comb(7,i)*t**i*(1-t)**(7-i))
    check(residual==0 and min(coefficients)>0,'large Bernstein positivity')
    pi_lower=16*sum((F((-1)**m, (2*m+1)*5**(2*m+1)) for m in range(4)),F(0))-F(4,239)
    check(pi_lower>F(314159,100000),'Machin lower')
    limiting=logarithm(3*pi_lower*A)
    check(limiting.a>F(-901,1000),'large logarithmic margin')
    final=T-F(1,2)-limiting.a/2+F(7,10000)
    check(final<F(-13,100000),'large final strict margin')
    # Independent rate endpoint: 18-term upper series rather than 12 terms.
    x=1+T; term=F(1); total=F(1)
    for m in range(1,19): term*=x/m; total+=term
    upper=total+term*x/19/(1-x/20)
    check(upper<F(142693,50000),'rate endpoint')
    return {'status':'PASS','bernstein_coefficients':[str(q) for q in coefficients],
      'minimum_bernstein':str(min(coefficients)),'pi_lower':str(pi_lower),
      'log_3_pi_lower_alpha_lower':str(limiting.a),'large_final_upper':str(final),
      'exp_upper_18_terms':str(upper),'endpoint':'142693/50000'}

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('mode',choices=['finite','tail','symbolic','large']); parser.add_argument('--output',type=Path)
    args=parser.parse_args(); start=time.monotonic(); result=globals()[args.mode]()
    result['elapsed_seconds']=round(time.monotonic()-start,3)
    if args.output: args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__': main()
