# Positive-sextic independent audit

This directory contains an independent, unpublished audit of
`../nonquartic_envelope_20261007`. The source directory is read only. See
`AUDIT.md` for the mathematical assessment and `SIGNOFF.json` for final
completion status when available. This audit does not publish or change the
candidate and is not human peer review or proof-assistant formalization.

## Reproduce from the workspace root

The independent checker expects the candidate input directory as the sibling
named above. Only the symbolic and large modes require SymPy. Finite/tail and
adversarial arithmetic use the Python standard library.

```
python research_math/sextic_bellman_independent_audit_20261007/independent_check.py symbolic
python research_math/sextic_bellman_independent_audit_20261007/independent_check.py finite
python research_math/sextic_bellman_independent_audit_20261007/independent_check.py large
python research_math/sextic_bellman_independent_audit_20261007/independent_check.py tail
python research_math/sextic_bellman_independent_audit_20261007/adversarial_tests.py
```

Repeat with `python -O`. Optional `--output PATH` writes reports only to the
selected audit output location. For submitted source-checker replay, consult
the manuscript's documented command lines and explicitly send any output
report to this audit directory. Use `PYTHONDONTWRITEBYTECODE=1` to keep imported
source directories read only.

The provided reports distinguish submitted replay, independent reconstruction,
symbolic identities, integer coverage, inherited endpoint replay, sextic
necessity, and corrupt-certificate tests. Intermediate smoke-test reports are
not substitutes for completed full-tail reports.
