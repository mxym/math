# Independent audit of the positive sextic Bellman continuation

7 October 2026. Isolated, unpublished mathematical audit.

## Final verdict: PASS

The written algebra and analytic reductions pass. All 19,900 finite rectangles
and the all-large component pass both submitted-checker replay and separately
written exact verification, normally and with Python optimization. Complete
independent imbalanced-tail replay also passes normally and under -O on all
157,872 cells, with maximum dyadic depth eleven and exact no-gap/no-overlap
coverage for all 199 small dimensions. This closes the independent audit of
the global theorem. No mathematical correction is required.

Candidate parameters are alpha=431/10000, beta=9/2500, gamma=197/100000,
T=4867/100000. The proposed spectral ceiling is exp(1+T)<142693/50000.

## Audit scope and independence

The manuscript, provenance, finite/large/tail verifier source, supplied ancestor
proof and dependency record, and the pinned ancestor calculus and spectral
reduction were read. Candidate optimization and reported floating margins were
not used to accept any inequality. `independent_check.py` does not import any
candidate module. It recomputes finite planes generically for p=2,4,6, implements
separate interval arithmetic and 30-term rational logarithms with 112-bit
outward rounding, and builds tail coefficients by polynomial subtraction and
division rather than copying the candidate's explicit sixth-power polynomial.

The new symbolic identity checks use SymPy solely to reduce polynomial/rational
identities to zero. Numerical signs use exact integers and fractions. The
independent large checker transforms the polynomial to Bernstein form by
successive coefficient elimination and bounds the final exponential with
18 terms, instead of the candidate's 12-term endpoint calculation.

All audit artifacts are confined to this directory. No candidate mathematical
source or certificate was edited, and nothing was published. The pinned
ancestor paper and spectral reduction hashes match their dependency record:

- paper.md: 8b7ad76a8a4b96ff40d43e9f9c3e7f4fe494dbadcf82bbdc114f980971ffb430
- ASYMPTOTIC_SPECTRAL_REDUCTION.md:
  4e86069432d563910f3c58e75ef777d98e1c5ab088a45687b640e2a3f88e4b0e

## 1. State calculus, finite expressions, and affine scope

The inherited product and join identities are used with their exact original
normalization: Q=aR/g(d), H=1/a, D=d+1. In particular the gain factor for a
product is x=(s h+r j)/(r+s), whereas the arithmetic mean used to control the
harmonic output H' has numerator r h+s j. These two distinct weightings have
not been interchanged in the manuscript or the checkers.

The dimension restriction to invertible affine equivalences of full affine
hulls is essential and is explicitly present. The result covers the finite
point-generated product/join grammar. It does not silently cover rank-dropping
affine maps or arbitrary convex bodies. Point products are redundant. The point
has Phi=0 and Q=1, joins with a point are covered by Jensen, and the join of two
points starts the positive-dimensional grammar with H=2. Joins add H, while
products take the dimension-weighted mean of a and preserve a<=1/2. Together
with the inherited a>=1/(d+1), this proves 2<=H<=D for every relevant factor.

Structural induction is well-founded on finite expressions. Applying affine
invariance at any expression node does not change D,H,Q. No missing operation
or infinite-tree limit is needed for the invariant theorem.

## 2. Join and product closure signs

For p=2,4,6, the map (D,H) -> H^p/D^(p-1) is a convex perspective.
Thus Jensen gives sum H_i^p/D_i^(p-1) >= (sum H_i)^p/(sum D_i)^(p-1).
With positive coefficients, Phi is superadditive under joins, which is the
direction required to preserve log Q<=Phi.

The product potential increment is exactly sum c_p Delta_p, including the
constant -sum c_p=-T caused by D'-(D_A+D_B)=-1. The output H' is the
dimension-weighted harmonic mean of h,j. Its arithmetic-mean and p-power-mean
upper bounds yield Delta_p >= G_p-1. Consequently strict negativity of
log(C x)-alpha G2-beta G4-gamma G6+T proves product closure. All coefficients
A_p,B_p for p=4,6 are positive because n>r,s and
r(r+1)^(p-1)<n(n+1)^(p-1). No negative potential coefficient weakens the
direction of this reduction.

The exact G2 determinant was independently reduced to
rs(3n+2)/[(r+1)n^2(s+1)(n+1)]>0. Its positive first diagonal and determinant
establish positive definiteness. The logarithm is concave on the positive
quadrant and the positive even-power terms are convex. The complete f is
therefore strictly concave; tangent-plane certification covers continuous
states, including boundary points of the state boxes.

## 3. Finite rectangles

Coverage is precisely all pairs 1<=r<=s<=199, count 19,900. State points and
denominators are verified as exact integers/rationals. The support function is
computed independently as max(g_h(2-h),g_h(r+1-h)) plus its j analogue, which
is equivalent to the submitted endpoint sign rule. The complete real rectangle
is covered, rather than just the candidate point or a numerical mesh.

Both submitted replay and independent replay pass normally and under -O with
uniform upper margin below -1/1,000,000. The worst pair remains (25,25), at
h=j=137374081947/10^10. The independent exact upper fraction appears in
`independent_finite_report.json`; its decimal value is approximately
-0.0000064803879273 and is only a display aid. The finite certificate hash is
f1015d270d337af16de579c068ad6d66237fb0f5b8038c031f41fd6d2abbe4c7.

## 4. Imbalanced-tail algebra and continuous parameter domain

Let z=1/s, u=j/(s+1). The enlarged box h in [2,r+1], u in [0,1] contains every
realizable state for every integer s>=200. The compact z interval [0,1/200]
also contains z=0 solely as an auxiliary limiting parameter. At z=0 the
normalized quadratic coefficients are a=1/(r+1), b=0, c=3r, so there is no
singularity or failure of strict state concavity at that endpoint.

Independent symbolic reduction verifies the normalized G2 identity. For the
even powers, polynomial division gives

S_p=[(1+r z)(1+(r+1)z)^(p-1)-(1+z)^(p-1)]/(r z).

The numerator has zero constant term and positive subsequent coefficients.
The checker formula for every coefficient matches that quotient, and the
large-state penalty really becomes r(1+z)S_p/P_p times u^p. This is crucial:
naively interval-evaluating the uncancelled expression at z=0 would not be a
valid tail proof. Exact identity tests pass for p=4,6,8,10, including the p=6
term actually used in this continuation.

The inherited factorial ratio bound also checks out. For
v_m=m!e^m/(m^m sqrt m), its ratio has logarithm
1-(m+1/2)log(1+1/m)<0, by the differentiated inequality
log t>2(t-1)/(t+1). Thus C<=g(r)e^-r sqrt(1+r z). Substitution into x gives
the exact logarithmic upper function displayed in the manuscript. Both
logarithm arguments stay positive on the enlarged box, including u=0.

For a cell, let a_-,c_- be coefficient lower endpoints and b_* the largest
absolute b endpoint. Young's inequality yields

a eta_h^2+b eta_h eta_u+c eta_u^2
>= (a_-/2) eta_h^2+[c_- - b_*^2/(2a_-)] eta_u^2.

Positive lower curvatures therefore give a uniform bound on the quadratic
Taylor remainder. The logarithm, quartic, and sextic remainder terms all have
the favorable concave sign. The interval gradient treatment is sound: a
negative displacement uses the lower slope endpoint and a positive
displacement the upper endpoint. Each scalar quadratic is maximized at its
clipped vertex or interval endpoint, with zero included. No gradient interval
is treated as a point gradient. Division checks exclude zero denominators.

The initial 101-cell smoke test was followed by complete separately written
replay on all 157,872 cells, normally and under -O. Both verify every upper
bound is strictly below -1/10^10 and verify exact complete coverage. An
additional integer-only dyadic endpoint audit confirms coverage and point
membership without using the interval evaluator. Maximum depth is eleven.
The worst cell is [170,631,10,3654408533,15653202], with exact upper fraction
in `independent_tail_report.json` and decimal rendering approximately
-1.9673152903e-9. Its certificate SHA-256 is
73f04d318c8dba38cabef5582892a597f6bb5ae704aca178147b341e66b61b1a.
Normal and optimized proof data are identical, excluding elapsed time.

## 5. All-large analytic component

The nonnegative-square formula proving G2>=k B^2 was independently reduced to
zero, as were the t,tau normalization and K0-K2 subtraction. For
tau<=1/200, bounding its positive numerator and denominator gives the displayed
tau d(t) correction with the correct coefficients 1003/100 and 903/100.

The quartic derivative lower bounds -3 and -3t^4 are immediate after
differentiation. The a0>=15/16 and b0>=15t^4/16 bounds have the correct chord
direction. Hölder's simplification produces tau K4 q^2 with no lost (1+t)
factor. The inequalities for P,Q, the rational cube-root estimates, and
concavity of (1+t)^(5/6) give exactly R(t). Since tau<=1/200, the retained
coefficient is at least 123/125.

Robbins' bounds give the stated sigma correction with negative factor terms.
The replacement of each denominator by 12+1/200 produces the correct upper
bound -200(1+t)/2401. Tangency at q0 cancels the limiting alpha K0 q term,
and maximizing the remaining concave quadratic produces the stated E(t).
The omitted sextic term is favorable because G6>0, while its constant gamma
contribution is retained in T. This deliberate omission does not turn the
whole proof back into the obstructed quadratic/quartic potential family.

All eight independently computed degree-seven Bernstein coefficients are
strictly positive and match the submitted exact report. This covers every
real t in [0,1], including the auxiliary t=0 limit. Machin's alternating-series
bound gives pi>314159/100000. The submitted exponential lower comparison and
the independent direct rational-log comparison both imply the required
limiting margin. The submitted final upper product bound is strictly below
-13/100000. No state box is required in this component; all h,j>0 are covered.

The candidate's 12-term exponential remainder and the independent 18-term
remainder both prove exp(1+T)<142693/50000. Every omitted-term ratio is bounded
by the displayed geometric ratio, with denominator strictly positive.

## 6. Exact logarithms, implementation, and adversarial checks

The atanh expansion and remainder have the correct exponent, denominator,
and factor two. Binary reduction correctly reverses log2 endpoints for a
negative exponent. Fraction outward rounding uses floor for lower endpoints
and ceiling for upper endpoints, including negative values. The tail interval
power routine handles even powers of intervals straddling zero correctly,
though normalized z powers only need nonnegative intervals. Both submitted
checkers use explicit require calls, so optimization cannot remove checks.

`adversarial_tests.py` checks 36,892 exact sampled interval-operation values,
1,000 candidate logarithm intervals against narrower independent enclosures,
3,000 exact power-mean reductions, 3,000 exact normalized coefficient values,
and 63,000 exact scalar quadratic values. All pass normally and under -O.
Eight corrupt finite fixtures and six corrupt tail fixtures are each rejected
normally and under -O, for 28 rejection cases. These include wrong constants,
missing/wrong dimension coverage, malformed coordinates, box violations,
invalid denominator/depth, duplicate cells, and a genuinely inadequate tangent
at (25,25). Corruption fixtures are isolated copies.

The separate necessity test also passes: removing the sextic coefficient, or
discarding its penalty while retaining T, fails at the actual simplex-product
state r=s=5,h=j=6 by exact margin exceeding 1/100. This demonstrates that the
added penalty has substantive mathematical content; it is not an extremal
lower construction.
The later illustrative coefficient in the manuscript is also correct:
Delta_6=2*6^6/6^5-6^6/11^5-1=1724905/161051 at this state.

## 7. Exhaustion, spectral conclusion, and comparison claims

After assuming r<=s by factor symmetry, the three regions are exhaustive:
s<200; r<200<=s; and 200<=r<=s. No dimension boundary is omitted. Each region
controls all states needed by the induction, with the tail covering all real
z in a larger interval than the discrete dimension parameters require.

The pinned spectral reduction was read, not merely cited. The upper direction
uses a>=1/(d+1), Q<=lambda_*^(d+1), and g(d)^(1/d)->e. The lower direction
joins repeated copies of a fixed body with at most d auxiliary point-generated
simplex dimensions; Q of the filler is one. This proves the all-dimensional
identity e sup Q^(1/(d+1)) without attainment or an infinite expression.
The proposed invariant establishes the finiteness hypothesis. Although every
individual positive-dimensional state has log Q/D<T, a uniform strict gap
from T has not been proved and is not needed: the valid conclusion is
Gamma_C<=exp(1+T), followed by the independently strict decimal endpoint.

The lower endpoint remains inherited. The pinned ancestor's exact checker
was replayed normally and under -O with all four corrupt-certificate controls;
it confirms 2.8534<Lambda<2.8535, finite closure, and the direct geometric
checks. There is no newly discovered lower construction in this continuation.

The comparisons are exact: T is lower than 39/800 by 1/12500 and lower than
the prior local quadratic/quartic obstruction 3046/62500 by 33/500000.
The latter is a method restriction, not a lower bound on Gamma_C. The positive
sextic potential belongs to a different family. The manuscript also correctly
avoids pointwise domination: old-minus-new divided by D is
(1-x)(8+13x-197x^2)/100000 with x=(H/D)^2 and changes sign on the feasible
normalized state interval.

The completed product certificates, join closure, and finite-expression
induction prove the candidate inequality for every K in the specified class.
The inherited spectral identity and the exact exponential endpoint then give

2.8534 < Gamma_C <= exp(104867/100000) < 142693/50000 = 2.85386.

The independent signoff is the logical verification of this result at the
identified parameters and certificate hashes. Both parent-run submitted tail
checker replays are now complete and PASS; their normal and optimized reports
are byte-identical. All submitted and independent arithmetic gates are closed.
The supplementary exact sample checks total 106,892. Completion of any later
release workflow is outside this unpublished mathematical audit.

## Limitations

This is model-conducted mathematical audit and exact arithmetic verification,
not proof-assistant formalization or human peer review. Analytic Robbins,
Machin, Jensen/Hölder, elementary calculus, and Stirling inputs remain ordinary
mathematical dependencies, with their uses inspected here. There is no current
remote-head or publication-priority claim. No optimum within the sextic family
or within the recursive class is identified. Nothing was published.
