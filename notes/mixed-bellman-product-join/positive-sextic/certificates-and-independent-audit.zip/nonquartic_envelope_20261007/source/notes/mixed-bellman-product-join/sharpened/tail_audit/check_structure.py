#!/usr/bin/env python3
"""Independent symbolic identities and integer-only tail coverage checks.

Does not import the submitted interval verifier or generator.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json


def require(value, message):
    if not value:
        raise ArithmeticError(message)


class P:
    """Sparse bivariate polynomial over the integers."""
    def __init__(self, coefficients):
        if isinstance(coefficients, int):
            coefficients = {(0, 0): coefficients}
        self.c = {k: v for k, v in coefficients.items() if v}

    @staticmethod
    def cast(x):
        return x if isinstance(x, P) else P(x)

    def __add__(self, other):
        other = self.cast(other)
        result = self.c.copy()
        for key, value in other.c.items():
            result[key] = result.get(key, 0)+value
        return P(result)

    __radd__ = __add__

    def __neg__(self):
        return P({key: -value for key, value in self.c.items()})

    def __sub__(self, other):
        return self+-self.cast(other)

    def __rsub__(self, other):
        return self.cast(other)+-self

    def __mul__(self, other):
        other = self.cast(other)
        result = {}
        for (a, b), v in self.c.items():
            for (c, d), w in other.c.items():
                key = (a+c, b+d)
                result[key] = result.get(key, 0)+v*w
        return P(result)

    __rmul__ = __mul__

    def __pow__(self, n):
        require(isinstance(n, int) and n >= 0, "invalid polynomial power")
        result = P(1)
        for _ in range(n):
            result = result*self
        return result


X = P({(1, 0): 1})
Y = P({(0, 1): 1})
n = X+Y
identity = n**2*(n+1)-X**2*(X+1)-Y**2*(Y+1)-X*Y*(3*n+2)
require(not identity.c, "positive definite quadratic identity")

r, z = X, Y
p2 = (1+r*z)**2*(1+(r+1)*z)
s2 = 3+(3*r+2)*z+r*(r+1)*z**2
require(not (p2-(1+z)-r*z*s2).c, "quadratic cancellation identity")
p4 = (1+r*z)*(1+(r+1)*z)**3
s4 = 4+(6*r+9)*z+(4*r*r+9*r+6)*z**2+(r+1)**3*z**3
require(not (p4-(1+z)**3-r*z*s4).c, "quartic cancellation identity")
require(F(861, 20000)+F(57, 10000) == F(39, 800), "constant sum")

root = Path(__file__).resolve().parent.parent
path = root/"mixed_tail_certificate.json"
raw = path.read_bytes()
certificate = json.loads(raw)
require(certificate["schema"] == 1, "certificate schema")
require(certificate["alpha"] == "861/20000" and certificate["beta"] == "57/10000",
        "certificate coefficients")
require(certificate["cutoff"] == 200 and certificate["point_denominator"] == 10**8,
        "certificate scales")
rows = certificate["cells"]
require(rows, "empty certificate")
require(all(type(row) is list and len(row) == 5 and
            all(type(v) is int for v in row) for row in rows), "integer rows")
depth = max(row[2] for row in rows)
require(0 <= depth <= 24, "depth range")
scale = 2**depth
by_r = {r: [] for r in range(1, 200)}
for r, index, cell_depth, hn, jn in rows:
    require(r in by_r and 0 <= cell_depth <= depth and 0 <= index < 2**cell_depth,
            "cell coordinates")
    require(2*10**8 <= hn <= (r+1)*10**8 and 0 <= jn <= 10**8,
            "supporting point rectangle")
    unit = 2**(depth-cell_depth)
    by_r[r].append((index*unit, (index+1)*unit))
for r, intervals in by_r.items():
    cursor = 0
    for lo, hi in sorted(intervals):
        require(lo == cursor, f"coverage gap or overlap at dimension {r}")
        cursor = hi
    require(cursor == scale, f"incomplete dimension {r}")

print(json.dumps({
    "status": "PASS",
    "symbolic_identities": 3,
    "arithmetic": "integer sparse polynomials and dyadic endpoint integers",
    "cells": len(rows),
    "maximum_depth": depth,
    "covered_r": [1, 199],
    "covered_z": "[0,1/200]",
    "certificate_sha256": hashlib.sha256(raw).hexdigest(),
    "supporting_bound_replay": "separate normal and optimized main-checker runs"
}, indent=2))
