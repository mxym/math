# Independent audit of the mixed quadratic/quartic obstruction

This audit concerns the local product supersolution mechanism for

\[
P(D,H)=TD-\alpha H^2/D-\beta H^4/D^3,
\qquad \alpha,\beta\ge0,\quad T=\alpha+\beta.
\]

It does not claim that the resulting necessary conditions determine the best
global invariant or the extremal rate of the point-generated class. Only files
in this audit directory were created or changed. The publication and prior
certificates were read for definitions and were not edited.

## Exact product condition

For factor dimensions \(r,s\), put \(n=r+s\), \(h=H_1\), \(j=H_2\), and

\[
C=\frac{g(r)g(s)}{g(n)},\quad
x=\frac{rj+sh}{n},\quad
H'=\frac{nhj}{rj+sh},\qquad g(k)=k^k/k!.
\]

The exact gain is \(Q'=Q_1Q_2Cx\). Since the output has \(D'=n+1\), whereas
the two input dimensions add to \(n+2\), the required local closure inequality is

\[
\log(Cx)\le \alpha\Delta_2+\beta\Delta_4,
\quad
\Delta_p=-1+\frac{h^p}{(r+1)^{p-1}}+
\frac{j^p}{(s+1)^{p-1}}-
\frac{(H')^p}{(n+1)^{p-1}}.
\tag{1}
\]

This follows by replacing each input's \(\log Q_i\) by \(P(D_i,H_i)\).
Consequently it deliberately discards whatever slack the inputs may have.

## Balanced limiting calculation

Set \(r=s=m\) and \(h=j=\sqrt{zm}\), with fixed \(z>0\). These values lie in
\([2,m+1]^2\) once \(m\) is sufficiently large. Then \(H'=h\), \(x=h\), and
ordinary Stirling asymptotics give

\[
\frac{g(m)^2}{g(2m)}\sqrt m\longrightarrow\pi^{-1/2}.
\]

In fact \(g(m)\sim e^m/\sqrt{2\pi m}\), so the denominator is
\(g(2m)\sim e^{2m}/\sqrt{4\pi m}\). Hence

\[
\log(Cx)\longrightarrow \frac12\log(z/\pi),
\]

\[
\Delta_2=-1+zm\left(\frac2{m+1}-\frac1{2m+1}\right)
\longrightarrow -1+\frac32z,
\]

\[
\Delta_4=-1+z^2m^2\left(\frac2{(m+1)^3}-\frac1{(2m+1)^3}\right)
\longrightarrow -1.
\]

Therefore (1), for every real state in every product rectangle, necessarily
implies

\[
\frac12\log(z/\pi)-\frac32\alpha z+T\le0
\quad\text{for every }z>0.
\tag{2}
\]

If \(\alpha=0\), the left side tends to infinity as \(z\to\infty\), so
\(\alpha>0\). The unique maximum in (2) occurs at \(z=1/(3\alpha)\) and equals

\[
T-\frac12-\frac12\log(3\pi\alpha).
\]

The necessary condition is exactly

\[
\boxed{3\pi\alpha\exp(1-2T)\ge1},
\qquad
\alpha\ge a(T):=\frac{\exp(2T-1)}{3\pi}.
\tag{3}
\]

No quartic term survives this scaling limit, except through its constant
contribution \(\beta\) within \(T\).

## Realizability and the limitation of the obstruction

The exact states \(H=\sqrt{zm}\) need not be realizable for each fixed integer
dimension. Indeed, induction using the rational product and join formulas shows
that every state generated from a point has rational \(H\). This does not prevent
rigorous asymptotic realization of every positive \(z\).

Let \(I\) be a segment. It has \((D,H,Q)=(2,2,1)\). Its \(m\)-fold Cartesian
power \(I^m\) has \(D=m+1\), \(H=2\), and

\[
Q(I^m)=\frac{2^{m-1}}{g(m)}.
\tag{4}
\]

The last equality follows by telescoping the product gains; each product of
factors with \(H=2\) has \(x=2\). For fixed \(z>0\), put

\[
k_m=\left\lfloor\frac{z(m+1)}4\right\rfloor,
\qquad K_m=\underbrace{I^m*\cdots*I^m}_{k_m\text{ copies}}.
\]

For all sufficiently large \(m\), this is a valid body in the actual class, with

\[
D_m=k_m(m+1),\quad r_m=D_m-1,\quad H_m=2k_m,
\quad
\frac{H_m^2}{r_m}
=\frac{4k_m^2}{k_m(m+1)-1}\longrightarrow z.
\tag{5}
\]

Taking equal factors \(K_m\times K_m\) gives exactly the same limits in (2).
Thus (3) is necessary even if local closure is required only at actual input
\((D,H)\) states, while still replacing their input \(\log Q\) values by the
potential. Continuous-state relaxation is not essential to the balanced
limiting obstruction.

However, these bodies do not come close to saturating the candidate invariant.
By (4) and join multiplicativity,

\[
\frac{\log Q(K_m)}{D_m}
=\frac{(m-1)\log2-\log g(m)}{m+1}
\longrightarrow \log2-1<0,
\]

whereas \(P(D_m,H_m)/D_m\to T\). The discarded input slack is therefore
asymptotically \((T+1-\log2)D_m\), which is extensive and positive for \(T\ge0\).
Failure of (3) cannot by itself refute a direct global assertion
\(\log Q(K)\le P(D,H)\) on the class. It refutes this local inductive
supersolution mechanism. Nor does (3) lower-bound the actual class's extremal
growth rate.

## The exact simplex product condition

The simplex \(T_5\) is the join of six points. It has \((D,H,Q)=(6,6,1)\), and
its potential is zero for every \(\alpha,\beta\). For
\(T_5\times T_5\), the output has \((D,H)=(11,6)\), and

\[
Q=6\frac{g(5)^2}{g(10)}=\frac{189}{128},
\quad \Delta_2=\frac{85}{11},\quad
\Delta_4=\frac{13345}{1331}.
\]

Consequently

\[
c:=\log\frac{189}{128}\le A\alpha+B\beta,
\quad A=\frac{85}{11},\quad B=\frac{13345}{1331}.
\tag{6}
\]

Unlike (3), condition (6) is necessary for a directly asserted global invariant:
it evaluates that invariant on one actual body, and there is no slack in the two
simplex inputs.

## Optimization of only these two necessary conditions

Since \(B>A\), for fixed \(T\) the largest right side of (6) under
\(\alpha\ge a(T)\), \(\beta=T-\alpha\ge0\), occurs at \(\alpha=a(T)\), provided
\(a(T)\le T\). The two conditions imply

\[
F(T):=BT-(B-A)\frac{e^{2T-1}}{3\pi}-c\ge0.
\tag{7}
\]

Here

\[
F'(T)=B-2(B-A)a(T),\qquad
F''(T)=-4(B-A)a(T)<0.
\]

Thus \(F\) is strictly concave. It starts negative at zero, is positive at
\(T=.049\), and tends to minus infinity. There are two positive roots, and the
minimum nonnegative \(T\) satisfying (7) is its first root \(T_*\). The supplied
checker verifies \(F'>9.82834\) on \([0,.049]\), so the enclosed root is
unambiguously the first root. It also verifies \(a(T_*)<T_*\), so the
nonnegative coefficient requirement is compatible with the two-condition
minimum.

The independently reproduced values are

\[
T_*=0.04873609459550649225\ldots,
\quad e^{1+T_*}=2.854041598896782102\ldots,
\]

\[
\alpha_*=0.04302947274825509154\ldots,
\quad \beta_*=0.00570662184725140071\ldots.
\]

Using only rational arithmetic, Machin bounds for \(\pi\), a positive Taylor
series with geometric remainder for the exponential, and the atanh series for
the logarithm, `check_audit.py` certifies

\[
0.0487360945955<T_*<0.0487360945956,
\]

\[
2.854041598896763<e^{1+T_*}<2.854041598897049.
\]

## The two-condition floor is not the full supersolution optimum

There is a concrete reason not to call \(T_*\) a sharp restricted-family
optimum. At its forced coefficient pair \((\alpha_*,\beta_*)\), the continuous
rectangle for \((r,s)=(5,5)\) fails local closure just inside its simplex corner.
For equal states \(h=j\), its residual is

\[
R(h)=\log\left(\frac{189h}{768}\right)+T_*
-\alpha_*\left(\frac13-\frac1{11}\right)h^2
-\beta_*\left(\frac1{108}-\frac1{1331}\right)h^4.
\]

The corner \(h=6\) has \(R(6)=0\), but \(R'(6)\simeq-0.00045858\). The exact
checker certifies \(R(599/100)>10^{-6}\). This rational state lies in the
continuous rectangle; the audit makes no assertion that it is an actual
dimension-five generated body.

Therefore \(T_*\) is a necessary floor and even the minimizing pair of the two
necessary conditions fails full continuous-box closure. Full feasibility, or a
sharp infimum for this mechanism, requires additional constraints. Nothing here
proves global optimality of a mixed invariant, of a broader potential family,
or of the \(T_5\) orbit in the point-generated class.

## A slightly stronger rational-state corollary

The requested third test, \(r=s=5\) and \(h=j=29967/5000\), sharpens the
continuous-box obstruction. Define

\[
A_h=\frac8{33}h^2-1=\frac{264965363}{34375000},
\qquad
B_h=\left(\frac1{108}-\frac1{1331}\right)h^4-1
=\frac{33201330174116157829}{3327500000000000000},
\]

\[
K_h=B_h-A_h>0,
\qquad L_h=\log(189h/768).
\]

Combining this state's local condition with the balanced condition gives

\[
F_h(T):=B_hT-K_h\frac{e^{2T-1}}{3\pi}-L_h\ge0.
\]

For \(0\le T\le1/10\), \(a(T)<1/9\), and therefore
\(F_h'(T)>B_h-2K_h/9>0\). The exact checker verifies

\[
F_h(609203/12500000)<-8.7900658\cdot10^{-8}<0,
\]

\[
e^{1+609203/12500000}>1427021/500000.
\]

It follows that every full continuous-box supersolution has

\[
\boxed{T>609203/12500000=0.04873624,
\qquad e^{1+T}>1427021/500000=2.854042.}
\]

The first root of this one-state-plus-balanced condition is enclosed by
\(0.0487362489854\) and \(0.0487362489856\); its associated exponential is
between \(2.854042039531994\) and \(2.854042039532566\). This is a necessary
condition for continuous rectangles. The audit does not claim that this exact
interior dimension-five state is generated by the allowed operations, and does
not label this root as the full mechanism's optimum.

## Replay

Both commands passed, and checks remain active under optimized Python:

```
python check_audit.py
python -O check_audit.py
```

`audit_report.json` records the checked intervals and the interior-state witness.
This is an independent mathematical and rational-arithmetic audit, not a formal
proof-assistant certificate.
