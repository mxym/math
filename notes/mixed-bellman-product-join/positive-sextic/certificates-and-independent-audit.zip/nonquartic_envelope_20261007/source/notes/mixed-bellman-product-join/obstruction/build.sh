#!/usr/bin/env bash
set -euo pipefail
task_obstruction_dir="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$task_obstruction_dir/build"
cd "$task_obstruction_dir"
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build obstruction.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build obstruction.tex
cp build/obstruction.pdf obstruction.pdf
