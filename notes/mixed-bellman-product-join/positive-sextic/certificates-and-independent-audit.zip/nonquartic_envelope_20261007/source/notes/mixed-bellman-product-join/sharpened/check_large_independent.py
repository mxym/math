#!/usr/bin/env python3
"""Independent exact audit of the retained-quartic polynomial certificate.

This reconstructs power coefficients from the Bernstein representation and
checks the claimed polynomial by eight rational values. No symbolic algebra,
floating point, source-checker import, or optimization package is used.
"""
import argparse
from fractions import Fraction as F
import json
from math import comb, factorial
from pathlib import Path


def require(ok, message):
    if not ok:
        raise ArithmeticError(message)


def evaluate(coefficients, t):
    value = F(0)
    for coefficient in reversed(coefficients):
        value = value*t+coefficient
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', nargs='?', type=Path,
                        default=Path(__file__).with_name('large_replay.json'))
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    a, b, total = F(report['alpha']), F(report['beta']), F(report['T'])
    require((a,b,total) == (F(861,20000),F(57,10000),F(39,800)), 'parameter mismatch')
    require(a+b == total, 'parameter sum mismatch')
    power = list(map(F,report['power_coefficients']))
    bernstein = list(map(F,report['bernstein_coefficients']))
    require(len(power) == len(bernstein) == 8, 'wrong polynomial degree')
    require(all(c > F(1,200) for c in bernstein), 'Bernstein coefficient positivity failed')
    reconstructed = [F(0)]*8
    for i, coefficient in enumerate(bernstein):
        for j in range(8-i):
            reconstructed[i+j] += coefficient*comb(7,i)*comb(7-i,j)*(-1)**j
    require(reconstructed == power, 'Bernstein-to-power reconstruction failed')
    # Both sides have degree at most seven. Eight distinct exact values prove
    # their polynomial identity without duplicating the source coefficient code.
    scale = a*a/(4*b*F(123,125))
    for i in range(8):
        t = F(i,7)
        d = (9+F(1003,100)*t+F(903,100)*t*t)/16
        denominator = F(413,250)+F(21,40)*t
        target = ((1+t)**4/25-t*(1+t)**3/12+F(200,2401)*(1+t)**5
                  -scale*d*d*denominator**3)
        require(evaluate(power,t) == target, 'polynomial identity failed at '+str(t))
    require(F(511,500)**3 > F(16,15), 'P cube-root bound failed')
    require(F(63,100)**3 > F(1,4), 'Q cube-root bound failed')
    pi_lower = 16*(F(1,5)-F(1,5)**3/3+F(1,5)**5/5-F(1,5)**7/7)-F(4,239)
    require(pi_lower > F(314159,100000), 'Machin lower bound failed')
    x = F(9021,10000)
    exp_lower = sum((x**j/factorial(j) for j in range(11)), F(0))
    require(3*F(314159,100000)*a*exp_lower > 1, 'limiting logarithmic margin failed')
    require(total-F(1,2)+F(9021,20000)+F(1,5000) == 0, 'final exact cancellation failed')
    x = 1+total
    exp_upper = sum((x**j/factorial(j) for j in range(13)),F(0))
    exp_upper += x**13/factorial(13)/(1-x/14)
    require(exp_upper == F(report['exp_upper']), 'exponential upper report mismatch')
    require(exp_upper < F(28541,10000), '2.8541 endpoint failed')
    result = {'status':'PASS','component':'products with both factor dimensions at least 200',
              'independent_polynomial_identity_points':8,'independent_Bernstein_reconstruction':True,
              'minimum_Bernstein_coefficient':str(min(bernstein)),
              'strict_Bernstein_threshold':'1/200','parameters':[str(a),str(b),str(total)],
              'conditional_rate_endpoint':'exp(1+39/800)<2.8541; full class requires other product cases'}
    if args.output:
        args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
