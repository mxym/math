# A sharp two-test obstruction for the positive quadratic/quartic Bellman ansatz

This is a structural restriction on a particular **local product supersolution
method**. It is not a lower bound for the optimal product/join-class projection
rate, and it is not an obstruction to a global invariant proved using additional
information about its inputs' slack.

## 1. Hypotheses and conclusion

Retain the exact product/join notation
\[
 g(d)=d^d/d!,\qquad D=d+1,\qquad H=1/a,\qquad
 Q=aR/g(d).
\]
The formal point has \(D=H=Q=1\). Every positive-dimensional member of the
point-generated product/join class has \(2\le H\le d+1\).
Here that class starts from a point, applies joins and Cartesian products in
independent affine coordinate spaces, and permits invertible affine maps of
each body's full affine hull. Every such map preserves dimension. No
rank-decreasing projection or collapsed affine image is an allowed operation.

Fix constants \(\alpha,\beta\ge0\), put \(T=\alpha+\beta\), and define
\[
 P(d,H)=T(d+1)-\alpha\frac{H^2}{d+1}
                    -\beta\frac{H^4}{(d+1)^3}.
\]
We assume **local product closure**: for every pair of positive integers
\(r,s\), every \(2\le H\le r+1\), and every \(2\le J\le s+1\),
\[
 P(r,H)+P(s,J)+\log\left[
  \frac{g(r)g(s)}{g(r+s)}\frac{rJ+sH}{r+s}\right]
 \le P(r+s,H'),
 \tag{1.1}
\]
where
\[
 H'=\frac{(r+s)HJ}{rJ+sH}.
\]
This is the exact algebraic condition ensuring that two inputs satisfying
\(\log Q\le P\) produce another such input by a Cartesian product, without
using any additional information about the input deficits.

### Theorem 1.1. Obstruction

Every locally product-closed ansatz above satisfies
\[
 \boxed{T>\frac{3046}{62500}=0.048736,}
\]
and hence
\[
 \boxed{e^{1+T}>\frac{71351}{25000}=2.85404>2.8535.}
\]
In particular this ansatz, with this local proof mechanism, cannot certify an
upper projection growth rate as small as \(2.8535\) merely through its nominal
spectral ceiling \(e^T\).

The same conclusions hold if local closure is assumed only for pairs of
states arising from actual class members. Section 3 gives class-realizable
test sequences sufficient for the argument.

The exact optimum imposed by the two necessary test families used below is
the first positive root \(\rho\) of
\[
 \boxed{
 F(t)=\frac{13345}{1331}t
      -\frac{3060}{1331}\frac{e^{2t-1}}{3\pi}
      -\log\frac{189}{128}=0.}
 \tag{1.2}
\]
Its certified enclosure is
\[
 0.0487360945<\rho<0.0487360947,
\]
\[
 2.8540415986<e^{1+\rho}<2.8540415992.
\]
These two tests do not establish that this endpoint is attainable by an ansatz
closed under **all** product states. Other states could force a larger value.

### Corollary 1.2. A slightly stronger continuous-state obstruction

Under the full continuous-rectangle hypothesis (1.1), one has
\[
 \boxed{T>\frac{609203}{12500000}=0.04873624,\qquad
        e^{1+T}>\frac{1427021}{500000}=2.854042.}
\]
This additional sharpening uses \(r=s=5\), \(H=J=29967/5000\). It does
not assert that this auxiliary state is realized by a member of the recursive
class. The weaker Theorem 1.1 applies even to local closure restricted to
class-realizable states.

## 2. The exact \(T_5\times T_5\) constraint

Writing \(n=r+s\), local closure (1.1) is equivalent to
\[
 \log\left[\frac{g(r)g(s)}{g(n)}\frac{rJ+sH}{n}\right]
 \le\alpha(G_2-1)+\beta(G_4-1),
 \tag{2.1}
\]
where
\[
 G_p=\frac{H^p}{(r+1)^{p-1}}+
      \frac{J^p}{(s+1)^{p-1}}-
      \frac{(H')^p}{(n+1)^{p-1}}.
\]
Take \(r=s=5\) and \(H=J=6\). These are the exact states of two
five-dimensional simplices. Their product has \(H'=6\), and exact rational
calculation gives
\[
 \frac{g(5)^2}{g(10)}6=\frac{189}{128},
\]
\[
 G_2-1=\frac{85}{11},\qquad
 G_4-1=\frac{13345}{1331}.
\]
Consequently
\[
 \boxed{\log\frac{189}{128}\le
       \frac{85}{11}\alpha+\frac{13345}{1331}\beta.}
 \tag{2.2}
\]
This constraint is necessary even for a directly asserted global invariant:
the simplex inputs have \(Q=1\) and \(P=0\), so there is no input slack in
this particular product.

## 3. The balanced large-dimensional constraint

Set \(r=s=m\), \(H=J=\sqrt{zm}\), where \(z>0\) is fixed and \(m\)
tends to infinity. These states lie in the required boxes for every
sufficiently large \(m\). Then \(H'=H\),
\[
 \frac{g(m)^2}{g(2m)}
 =\frac{\binom{2m}{m}}{4^m}\sim\frac1{\sqrt{\pi m}},
\]
and
\[
 G_2=zm\left(\frac2{m+1}-\frac1{2m+1}\right)
       \longrightarrow\frac32z,
\]
\[
 G_4=z^2m^2\left(\frac2{(m+1)^3}-\frac1{(2m+1)^3}\right)
       \longrightarrow0.
\]
Taking the limit in (2.1) yields, for every \(z>0\),
\[
 \frac12\log\frac z\pi\le\frac32\alpha z-T.
 \tag{3.1}
\]
If \(\alpha=0\), the left side is unbounded above as \(z\to\infty\),
contradicting (3.1). Thus \(\alpha>0\). The maximum over \(z>0\) of
\[
 \frac12\log\frac z\pi-\frac32\alpha z
\]
occurs at \(z=1/(3\alpha)\), with value
\(\tfrac12\log(1/(3\pi\alpha))-\tfrac12\). Therefore (3.1) is
equivalent to
\[
 \boxed{3\pi\alpha e^{1-2T}\ge1,\qquad
        \alpha\ge\frac{e^{2T-1}}{3\pi}.}
 \tag{3.2}
\]

### These asymptotic auxiliary states can be realized in the recursive class

The preceding derivation only requires the continuous-state boxes. It also
works if local closure is required solely for pairs of states realized by
actual class members.

Let \(C_m=I^m\) be an \(m\)-dimensional cube. The exact product calculus
gives \(H(C_m)=2\). For fixed \(z>0\), put
\[
 k_m=\left\lfloor\frac{z(m+1)}4\right\rfloor,\qquad
 K_m=C_m^{*k_m}.
\]
For all sufficiently large \(m\), \(k_m\ge1\), and the join identities give
\[
 D(K_m)=k_m(m+1),\qquad H(K_m)=2k_m.
\]
Writing \(d_m=D(K_m)-1\), we have \(d_m\to\infty\) and
\[
 \frac{H(K_m)^2}{d_m}
 =\frac{4k_m^2}{k_m(m+1)-1}\longrightarrow z.
\]
Apply local closure to \(K_m\times K_m\). The same balanced limiting
calculation proves (3.2), with no need for exact square-root states to be
realizable.

This realization does **not** make (3.2) necessary for a global invariant
proved without local closure. Such cube-join inputs can have substantial
deficit \(P-\log Q\). A proof retaining that deficit could pass a product
even when (1.1) fails.

The deficit here is explicitly extensive. For the cube,
\(Q(C_m)=2^{m-1}/g(m)\), so the self-join identity gives
\[
 \frac{\log Q(K_m)}{D(K_m)}
 =\frac{(m-1)\log2-\log g(m)}{m+1}
 \longrightarrow\log2-1.
\]
On the other hand,
\[
 \frac{P(d_m,H(K_m))}{D(K_m)}
 =T-\alpha\left(\frac2{m+1}\right)^2
    -\beta\left(\frac2{m+1}\right)^4\longrightarrow T.
\]
Thus
\[
 \frac{P(d_m,H(K_m))-\log Q(K_m)}{D(K_m)}
 \longrightarrow T+1-\log2>0.
\]
This quantifies why the local obstruction cannot be promoted to an
obstruction for every possible proof of the same global inequality.

## 4. Optimize the two necessary constraints

Put
\[
 A=85/11,\quad B=13345/1331,\quad C=B-A=3060/1331,
 \quad L=\log(189/128).
\]
Since \(\beta=T-\alpha\), (2.2) becomes
\[
 L\le BT-C\alpha.
\]
Combining this with (3.2) gives the necessary scalar inequality
\[
 \boxed{F(T):=BT-C\frac{e^{2T-1}}{3\pi}-L\ge0.}
 \tag{4.1}
\]
On \(0\le t\le1/10\), \(e^{2t-1}<1\) and \(\pi>3\). Thus
\[
 F'(t)=B-2C\frac{e^{2t-1}}{3\pi}
       > B-\frac{2C}{9}>0.
\]
Also \(F(0)<0\). The exact checker certifies \(F(1/10)>0\), so there is
a unique root \(\rho\) in this interval. Every feasible \(T\le1/10\)
satisfies \(T\ge\rho\); values above \(1/10\) already exceed \(\rho\).

The exact comparisons
\[
 F(3046/62500)<0,
\]
\[
 e^{1+3046/62500}>71351/25000
\]
prove Theorem 1.1. The sharper root and growth enclosures stated above follow
from the same interval routines.

At \(T=\rho\), choose
\[
 \alpha_*=\frac{e^{2\rho-1}}{3\pi},\qquad
 \beta_*=\rho-\alpha_*.
\]
Both necessary constraints become equalities. The checker encloses these
coefficients and verifies \(\alpha_*,\beta_*>0\). Thus \(\rho\) is the
**exact minimum allowed by these two necessary test families**. Numerically,
only for orientation,
\[
 \alpha_*\approx0.0430294727483,\qquad
 \beta_*\approx0.0057066218473.
\]
No all-state sufficiency claim is made for this coefficient pair.

Indeed that pair fails a nearby continuous state. At \(r=s=5\) and
\(H=J=h=599/100\), put
\[
 A_h=\frac8{33}h^2-1,\qquad
 B_h=\frac{1223}{143748}h^4-1.
\]
The exact checker, using the narrow root and coefficient intervals, proves
\[
 \log\left(\frac{63h}{256}\right)-\alpha_*A_h-\beta_*B_h>10^{-6}.
\]
Thus the two-test optimal coefficient pair is not a full continuous-box
supersolution. This state is not claimed to be class-realizable.

For Corollary 1.2, take instead \(h=29967/5000\) and define \(A_h,B_h\)
by the same formulas. Condition (2.1) and (3.2) yield
\[
 F_h(T):=B_hT-(B_h-A_h)\frac{e^{2T-1}}{3\pi}
                  -\log\left(\frac{63h}{256}\right)\ge0.
\]
Here \(B_h-A_h>0\), and on \([0,1/10]\),
\[
 F_h'(t)>B_h-\frac{2(B_h-A_h)}9>0.
\]
Exact rational interval arithmetic certifies
\[
 F_h(609203/12500000)<0,
 \qquad
 e^{1+609203/12500000}>1427021/500000.
\]
These comparisons prove the stronger continuous-state obstruction without
asserting feasibility of any endpoint coefficient pair.

## 5. Standalone exact evidence

Run

```text
python check_obstruction.py
python -O check_obstruction.py
```

The checker uses only the Python standard library. Every proof decision uses
integers and `Fraction`, including independent verification of the \(T_5\)
coefficients, signs of the root endpoints, positivity of the two-test optimal
coefficients, and all growth comparisons.

For \(0\le x\le2\), the exponential bounds use the positive Taylor sum
through degree fifty. The remaining tail is bounded above by its first term
times \((1-x/52)^{-1}\). Negative exponents use reciprocal intervals.
The logarithm uses thirty-five terms of
\[
 \log x=2\sum_{k\ge0}\frac{w^{2k+1}}{2k+1},
 \qquad w=\frac{x-1}{x+1},
\]
with the upper tail \(2w^{71}/[71(1-w^2)]\).
The interval for \(\pi\) uses Machin's identity
\[
 \pi=16\arctan(1/5)-4\arctan(1/239)
\]
and alternating rational series. The identity follows by applying the tangent
double-angle formula twice: \(\tan(4\arctan(1/5))=120/119\), then
\(\tan(4\arctan(1/5)-\arctan(1/239))=1\); that angle lies in
\((0,\pi/2)\), so equals \(\pi/4\).

The central-binomial asymptotic in Section 3 is a standard consequence of
Stirling's formula. It can equivalently be proved using the explicit Robbins
factorial bounds already used for the certified upper construction.

## 6. What a sharper proof must change

To obtain a nominal ceiling \(e^{1+T}\) at or below \(2.8535\), one must leave
at least one hypothesis of this obstruction. A proof could instead change
the potential profile, introduce additional state information, or carry a
rigorously quantified input deficit through products. Additional control of
the attained states could also sharpen what follows from a global invariant.
The result does not preclude any of those routes and does not determine
\(\Gamma_{\mathcal C}\).
