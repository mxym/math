# Retaining the quartic term: a uniform cutoff of two hundred

Fix the exact rational parameters

α=861/20000, β=57/10000, T=α+β=39/800.

The following is a rigorous large-factor component for the proposed sharper mixed Bellman bound. It does not by itself certify the entire product/join class: the finite and small-factor product cases remain to be checked at these new parameters.

**Lemma.** Let r,s≥200 be integers, n=r+s, and h,j>0. Put

C=g(r)g(s)/g(n), g(d)=d^d/d!,

B=(s h+r j)/n,

G₂=h²/(r+1)+j²/(s+1)−(r h+s j)²/[n²(n+1)],

A=1/(r+1)³−r/[n(n+1)³],

J=1/(s+1)³−s/[n(n+1)³],

G₄=A h⁴+J j⁴.

Then

log(CB)−αG₂−βG₄+T<0.

In particular, the actual harmonic-mean product defect is strictly controlled: harmonic≤arithmetic gives the G₂ lower bound, and harmonic≤fourth-power mean gives the G₄ lower bound. No auxiliary-state box restrictions are needed in this lemma.

## 1. Normalize the two dimensions

Assume r≤s, and write

t=r/s∈(0,1], τ=1/r≤1/200, q=B²/r>0.

The exact quadratic minimum is

G₂≥kB², k=(3n+2)/(4rs+3n+2).

For completeness, putting Δ=4rs+3n+2, its nonnegative-square identity is

G₂−kB²=

rs·[(s+1)(3r+s+2)h−(r+1)(r+3s+2)j]²

/[(r+1)n²(s+1)(n+1)Δ].

Thus G₂≥K₂(t,τ)q, where

K₂(t,τ)=[3(1+t)+2tτ]/[4+3(1+t)τ+2tτ²].

Put K₀(t)=3(1+t)/4. Direct subtraction gives

0≤K₀−K₂

=τ[9(1+t)²−8t+6t(1+t)τ]/[4(4+3(1+t)τ+2tτ²)]

≤τ d(t),

where

d(t)=[9+(1003/100)t+(903/100)t²]/16.

## 2. A rational lower bound for the quartic coefficient

Write γ=t/(1+t). Multiplying the diagonal quartic coefficients by r³ gives

a(t,τ)=(1+τ)^(−3)−γ⁴(1+γτ)^(−3),

b(t,τ)=t³[(1+tτ)^(−3)−(1+t)^(−4)(1+γτ)^(−3)].

Let a₀=a(t,0) and b₀=b(t,0). Since γ≤1/2, a₀≥15/16. Also ∂a/∂τ≥−3, whence

a(t,τ)≥a₀−3τ≥(1−16τ/5)a₀.

Likewise ∂b/∂τ≥−3t⁴. The concave function 1−(1+t)^(−4) lies above its chord on[0,1], so

1−(1+t)^(−4)≥15t/16.

Therefore b₀≥15t⁴/16 and

b(t,τ)≥(1−16τ/5)b₀.

For positive coefficients a₀,b₀ and the linear constraint h+t j=(1+t)B, Hölder gives

(h+t j)⁴≤(a₀h⁴+b₀j⁴)[a₀^(−1/3)+t^(4/3)b₀^(−1/3)]³.

Indeed this is the finite-dimensional Hölder inequality with exponents4 and4/3, applied to the two pairs (a₀^(1/4)h,b₀^(1/4)j) and(a₀^(−1/4),t b₀^(−1/4)). We have a₀=P(t)/(1+t)⁴ and b₀=t⁴Q(t)/(1+t)⁴, so the denominator simplifies exactly. It follows that

G₄≥τ(1−16τ/5)K₄(t)q²,

where

K₄(t)=[P(t)^(−1/3)+Q(t)^(−1/3)]^(−3),

P(t)=1+4t+6t²+4t³,

Q(t)=4+6t+4t²+t³.

This also has a continuous positive limit at t=0.

We now replace the cube roots by rational bounds. First,

P(t)=(1+t)⁴−t⁴≥(15/16)(1+t)⁴.

Second,

Q(t)²−16(1+t)³=t⁶+8t⁵+28t⁴+40t³+20t²≥0.

The exact rational comparisons

(511/500)³>16/15, (63/100)³>1/4

therefore imply

P(t)^(−1/3)+Q(t)^(−1/3)

≤(1+t)^(−4/3)[511/500+(63/100)(1+t)^(5/6)].

Concavity gives (1+t)^(5/6)≤1+5t/6. Hence

K₄(t)≥R(t):=(1+t)⁴/[413/250+(21/40)t]³.

As 1−16τ/5≥123/125, we have the entirely rational bound

G₄≥τ(123/125)R(t)q².

## 3. Keep the first factorial correction

Robbins' bounds give

C²< [n/(2πrs)]exp(σ),

σ=τ[t/(6(1+t))−2/(12+τ)−2t/(12+tτ)].

Thus

log(CB)<(1/2)log q+(1/2)log[(1+t)/(2π)]+σ/2.

For τ≤1/200,

σ/2≤τ[t/(12(1+t))−200(1+t)/2401].

This correction is essential to avoid the much larger cutoff obtained by discarding the quartic term and all factorial corrections.

## 4. A global tangent bound in q

Set q₀=1/[2αK₀(t)]=2/[3α(1+t)]. The tangent inequality

log q≤log q₀+q/q₀−1

gives

log(CB)−αG₂−βG₄+T

< F∞+σ/2+α(K₀−K₂)q−βτ(123/125)R(t)q²,

where

F∞=T−1/2−(1/2)log(3πα).

Maximizing the remaining concave quadratic in q and using K₀−K₂≤τd(t), we obtain

log(CB)−αG₂−βG₄+T < F∞+τ E(t),

E(t)=t/[12(1+t)]−200(1+t)/2401

+α²d(t)²/[4β(123/125)R(t)].

## 5. Eight exact coefficients certify every factor ratio

The inequality E(t)<1/25 for every0≤t≤1 is equivalent to positivity of the degree-seven polynomial

F(t)=(1+t)⁴/25−t(1+t)³/12+200(1+t)⁵/2401

−[α²/(4β(123/125))]d(t)²[413/250+(21/40)t]³.

The standalone checker constructs this polynomial with Fraction arithmetic. It converts the power coefficients c₀,…,c₇ to Bernstein coefficients

bᵢ=Σ_{k=0}^i c_k·binom(i,k)/binom(7,k).

It verifies all eight exact rational inequalities bᵢ>1/200. Since the Bernstein basis functions binom(7,i)t^i(1−t)^(7−i) are nonnegative and sum to one, this proves F(t)>1/200 and therefore E(t)<1/25 throughout[0,1]. The complete rational coefficient list is written to `retained_quartic_exact_report.json`.

Consequently the product violation is less than F∞+1/5000.

Finally, exact arithmetic certifies

3·(314159/100000)·α·Σ_{j=0}^{10}(9021/10000)^j/j!>1,

and the Machin alternating-series bound gives π>314159/100000. Hence

log(3πα)>−9021/10000,

so

F∞+1/5000

<T−1/2+9021/20000+1/5000=0.

This completes the proof for all r,s≥200.

The same checker verifies exp(1+T)<28541/10000=2.8541 by a rational positive Taylor sum with a geometric remainder. This endpoint becomes a class-wide theorem only after the other product cases and the invariant induction are completed at the new parameters.
