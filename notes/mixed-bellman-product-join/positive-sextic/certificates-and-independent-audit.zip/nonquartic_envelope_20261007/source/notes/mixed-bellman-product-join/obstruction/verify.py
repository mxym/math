#!/usr/bin/env python3
"""Offline replay of the local-closure obstruction and its independent audit."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    root = Path(__file__).resolve().parent
    rows = json.loads((root / 'MANIFEST.json').read_text())['files']
    seen = set()
    for row in rows:
        name = row['path']
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in seen,
                'Invalid manifest path: ' + name)
        seen.add(name)
        local = root / name
        require(local.is_file() and local.stat().st_size == row['bytes'], 'Missing file or length mismatch: ' + name)
        require(hashlib.sha256(local.read_bytes()).hexdigest() == row['sha256'], 'Hash mismatch: ' + name)
    environment = dict(os.environ)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    outputs = {}
    with tempfile.TemporaryDirectory(prefix='math005-obstruction-replay-') as directory:
        for mode in ('ordinary', 'optimized'):
            python = [sys.executable] + (['-O'] if mode == 'optimized' else [])
            outputs[mode] = []
            for checker, reference in [('check_obstruction.py', 'result.json'),
                                       ('audit/check_audit.py', 'audit/audit_report.json')]:
                result = subprocess.run(python + [str(root / checker)], cwd=directory,
                                        env=environment, text=True, capture_output=True)
                require(result.returncode == 0, checker + ' failed:\n' + result.stdout + result.stderr)
                data = json.loads(result.stdout)
                require(data == json.loads((root / reference).read_text()), 'Replay mismatch: ' + reference)
                outputs[mode].append(data)
    require(outputs['ordinary'] == outputs['optimized'], 'Ordinary and optimized reports differ.')
    print(json.dumps({'status': 'PASS', 'manifest_files': len(rows),
                      'both_checkers_and_python_modes_pass': True,
                      'scope': 'local product supersolutions, not the actual class optimum',
                      'realizable_state_local_method_floor': 'strictly greater than 2.85404',
                      'continuous_rectangle_local_method_floor': 'strictly greater than 2.854042',
                      'network_or_checkout_required': False}, indent=2))


if __name__ == '__main__':
    main()
