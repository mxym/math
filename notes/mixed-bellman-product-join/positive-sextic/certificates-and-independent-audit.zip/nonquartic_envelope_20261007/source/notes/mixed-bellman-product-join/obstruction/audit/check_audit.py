#!/usr/bin/env python3
"""Independent rational replay of the mixed-potential necessary-condition floor.

No floating arithmetic is used for any checked inequality. This checker certifies
the root enclosure and constants; the limiting and realizability arguments are
given in audit.md.
"""
from fractions import Fraction as F
from math import factorial
import json


def require(value, message):
    if not value:
        raise ArithmeticError(message)


def atan_unit_reciprocal(q, n=80):
    x = F(1, q)
    total = sum(((-1)**k * x**(2*k+1) / (2*k+1)
                 for k in range(n)), F(0))
    endpoint = total + (-1)**n * x**(2*n+1)/(2*n+1)
    return min(total, endpoint), max(total, endpoint)


def exp_point(x, n=160):
    if x < 0:
        lo, hi = exp_point(-x, n)
        return 1/hi, 1/lo
    term = F(1)
    total = term
    for j in range(1, n+1):
        term = term*x/j
        total += term
    first_omitted = term*x/(n+1)
    ratio = x/(n+2)
    require(ratio < 1, "exponential tail ratio")
    return total, total + first_omitted/(1-ratio)


def log_point(x, n=80):
    require(x >= 1, "logarithm routine requires x >= 1")
    t = (x-1)/(x+1)
    total = 2*sum((t**(2*k+1)/(2*k+1) for k in range(n)), F(0))
    tail = 2*t**(2*n+1)/((2*n+1)*(1-t*t))
    return total, total+tail


atan5 = atan_unit_reciprocal(5)
atan239 = atan_unit_reciprocal(239)
pi_lo = 16*atan5[0]-4*atan239[1]
pi_hi = 16*atan5[1]-4*atan239[0]
log_lo, log_hi = log_point(F(189, 128))
A = F(85, 11)
B = F(13345, 1331)
K = B-A


def alpha_interval(t):
    elo, ehi = exp_point(2*t-1)
    return elo/(3*pi_hi), ehi/(3*pi_lo)


def f_interval(t):
    alo, ahi = alpha_interval(t)
    return B*t-K*ahi-log_hi, B*t-K*alo-log_lo


def decimal_interval(lo, hi, digits=15):
    unit = 10**digits
    lower = (lo.numerator*unit)//lo.denominator
    upper = -((-hi.numerator*unit)//hi.denominator)
    def render(i):
        s = str(abs(i)).rjust(digits+1, "0")
        return ("-" if i < 0 else "") + s[:-digits]+"."+s[-digits:]
    return [render(lower), render(upper)]


def g(m):
    return F(m**m, factorial(m))


# Exact T_5 x T_5 product data and potential increments.
require(6*g(5)**2/g(10) == F(189, 128), "T5 gain")
require(-1+2*F(6**2, 6)-F(6**2, 11) == A, "T5 quadratic increment")
require(-1+2*F(6**4, 6**3)-F(6**4, 11**3) == B,
        "T5 quartic increment")

root_lo = F("0.0487360945955")
root_hi = F("0.0487360945956")
require(f_interval(root_lo)[1] < 0, "lower root endpoint sign")
require(f_interval(root_hi)[0] > 0, "upper root endpoint sign")
require(f_interval(F(0))[1] < 0, "F(0) sign")
require(f_interval(F("0.049"))[0] > 0, "F(.049) sign")

# F'(t)=B-2K alpha_min(t). Monotonicity of alpha_min bounds F'
# from below on [0,.049]. This makes the enclosed root the first one.
derivative_lo = B-2*K*alpha_interval(F("0.049"))[1]
require(derivative_lo > 0, "F increasing up to .049")

alpha_lo = alpha_interval(root_lo)[0]
alpha_hi = alpha_interval(root_hi)[1]
require(alpha_hi < root_lo, "nonnegative beta at combined equality")
beta_lo = root_lo-alpha_hi
beta_hi = root_hi-alpha_lo
rate_lo = exp_point(1+root_lo)[0]
rate_hi = exp_point(1+root_hi)[1]
require(F("2.8540415988967") < rate_lo, "rate lower decimal")
require(rate_hi < F("2.8540415988971"), "rate upper decimal")

# The pair minimizing only the two necessary inequalities is not feasible for
# full continuous-rectangle closure. A rational interior diagonal state gives
# a positive exact residual throughout the certified parameter enclosure.
h = F(599, 100)
q = F(1, 3)-F(1, 11)
v = F(1, 108)-F(1, 1331)
log_gain_lo, log_gain_hi = log_point(F(189, 128)*h/6)
t_coefficient = 1-v*h**4
alpha_coefficient = v*h**4-q*h**2
require(t_coefficient < 0 and alpha_coefficient > 0,
        "interior witness interval signs")
witness_lo = log_gain_lo+t_coefficient*root_hi+alpha_coefficient*alpha_lo
witness_hi = log_gain_hi+t_coefficient*root_lo+alpha_coefficient*alpha_hi
require(witness_lo > F(1, 10**6), "interior continuous-state failure")

# Requested sharper rational continuous-state corollary. It uses the same
# balanced asymptotic condition, and a single h=j=29967/5000 test at r=s=5.
sharper_h = F(29967, 5000)
sharper_A = q*sharper_h**2-1
sharper_B = v*sharper_h**4-1
sharper_K = sharper_B-sharper_A
sharper_log_lo, sharper_log_hi = log_point(F(189, 128)*sharper_h/6)
require(sharper_K > 0, "sharper coefficient sign")


def sharper_f_interval(t):
    alo, ahi = alpha_interval(t)
    return (sharper_B*t-sharper_K*ahi-sharper_log_hi,
            sharper_B*t-sharper_K*alo-sharper_log_lo)


sharper_threshold = F("0.04873624")
require(pi_lo > 3, "pi lower bound for sharper monotonicity")
require(sharper_B-2*sharper_K/9 > 0, "sharper monotonicity on [0,.1]")
require(sharper_f_interval(sharper_threshold)[1] < 0,
        "sharper rational T threshold")
requested_rate = F(1427021, 500000)
require(exp_point(1+sharper_threshold)[0] > requested_rate,
        "requested sharper rational rate threshold")
sharper_root_lo = F("0.0487362489854")
sharper_root_hi = F("0.0487362489856")
require(sharper_f_interval(sharper_root_lo)[1] < 0,
        "sharper root lower endpoint")
require(sharper_f_interval(sharper_root_hi)[0] > 0,
        "sharper root upper endpoint")

report = {
    "status": "passed",
    "interpretation": "necessary floor for mixed quadratic/quartic local product closure",
    "root_interval": [str(root_lo), str(root_hi)],
    "root_decimal": decimal_interval(root_lo, root_hi),
    "rate_interval_decimal": decimal_interval(rate_lo, rate_hi),
    "alpha_at_combined_equality_decimal": decimal_interval(alpha_lo, alpha_hi),
    "beta_at_combined_equality_decimal": decimal_interval(beta_lo, beta_hi),
    "Fprime_lower_on_0_to_0.049_decimal": decimal_interval(derivative_lo, derivative_lo),
    "pi_interval_decimal": decimal_interval(pi_lo, pi_hi),
    "log189over128_interval_decimal": decimal_interval(log_lo, log_hi),
    "interior_state": {"r": 5, "s": 5, "h": "599/100", "j": "599/100"},
    "interior_state_residual_decimal": decimal_interval(witness_lo, witness_hi),
    "sharper_continuous_state": {
        "r": 5, "s": 5, "h": str(sharper_h), "j": str(sharper_h),
        "A_h": str(sharper_A), "B_h": str(sharper_B),
        "strict_T_threshold": str(sharper_threshold),
        "strict_T_threshold_decimal": "0.04873624",
        "strict_rate_threshold": str(requested_rate),
        "strict_rate_threshold_decimal": "2.854042",
        "F_h_at_threshold_interval_decimal": decimal_interval(
            *sharper_f_interval(sharper_threshold)),
        "root_interval_decimal": decimal_interval(sharper_root_lo, sharper_root_hi),
        "root_rate_interval_decimal": decimal_interval(
            exp_point(1+sharper_root_lo)[0], exp_point(1+sharper_root_hi)[1]),
        "scope": "continuous product rectangles; exact h not claimed reachable"
    },
    "limitations": [
        "does not certify full all-state closure at the minimizing parameters",
        "does not disprove a direct global invariant below this floor",
        "does not determine the point-generated class extremal rate"
    ]
}
print(json.dumps(report, indent=2))
