# An exact obstruction for the local quadratic/quartic method

[English proof PDF](obstruction.pdf), [LaTeX source](obstruction.tex), and [Markdown proof](OBSTRUCTION.md) establish a method restriction:

- If the positive quadratic/quartic potential is locally product-closed even just on actual recursive-class states, its nominal growth ceiling is greater than **2.85404**.
- If closure is required on every continuous state rectangle, the ceiling is greater than **2.854042**.

Neither statement is a lower bound for the actual optimal projection-body growth rate. Cube-join test inputs have an extensive deficit in this potential; retaining that deficit or changing the potential could bypass the obstruction. The two-test root is only the minimum allowed by those two tests, and its coefficient pair fails full continuous-box closure, as independently certified.

The class permits invertible affine maps on affine hulls. Rank-dropping maps are excluded. The abstract local product condition and every analytic hypothesis are written explicitly in the proof. The geometric interpretation uses the exact calculus in [entry 005 v2](https://github.com/mxym/math/blob/3360e7191cf564a46d09edcbfbd107c9178bd98f/preprints/005-simplex-product-optimum/v2/paper.md) and its [spectral supplement](https://github.com/mxym/math/blob/3360e7191cf564a46d09edcbfbd107c9178bd98f/preprints/005-simplex-product-optimum/v2/ASYMPTOTIC_SPECTRAL_REDUCTION.md). No external file or network is needed for exact replay.

Run `python3 verify.py` from this folder or by its actual path from any other directory. It checks all delivery hashes and runs both independent standard-library checkers normally and with `python -O`. Reports must match the supplied reports and agree between modes. Audit details are in `audit/AUDIT.md` and `audit/audit.md`. This is model mathematical review and exact arithmetic, not human peer review or proof-assistant formalization.

Build the PDF with `bash build.sh`. The supplied LaTeX does not require Pandoc. A standard TeX installation needs article, amsmath, amssymb, iftex, fontenc, inputenc, textcomp, lmodern, geometry, xcolor/color, fancyvrb, bookmark/hyperref and URL support. Verify the delivered files before rebuilding; PDF metadata and TeX versions can change the built bytes.

The sibling [sharper theorem](../sharpened/paper.pdf) proves a genuine class-wide upper bound below 2.8541. The two different meanings of the upper theorem and the method obstruction are kept separate. No publication or push was performed.
