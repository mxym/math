# Independent audit: retained quartic large-dimension lemma

**Component outcome: PASS.** The proof `retained_quartic_large.md` and exact checker were independently read in full. No material mathematical gap was found. The audited parameters are

\[
\alpha=861/20000,\qquad \beta=57/10000,\qquad
T=\alpha+\beta=39/800.
\]

The conclusion audited here is strict product closure for **both factor dimensions at least 200**, for all positive real auxiliary states. It is not by itself a class-wide rate theorem. The finite and small-factor certificates must also pass at these parameters before claiming the full mixed invariant or a new class ceiling.

## General quartic Hölder reduction

Assume \(r\le s\), put \(t=r/s\in(0,1]\), \(\tau=1/r\le1/200\), and \(q=B^2/r\). The diagonal quartic coefficients scaled by \(r^3\) are exactly

\[
a=(1+\tau)^{-3}-\gamma^4(1+\gamma\tau)^{-3},
\qquad \gamma=t/(1+t),
\]

\[
b=t^3\big[(1+t\tau)^{-3}-(1+t)^{-4}(1+\gamma\tau)^{-3}\big].
\]

The derivative bounds \(\partial_\tau a\ge-3\) and \(\partial_\tau b\ge-3t^4\) are valid: the first differentiated terms are bounded below by these values, while the second differentiated terms are nonnegative. Since \(a_0\ge15/16\) and the concave function \(1-(1+t)^{-4}\) lies above its chord \(15t/16\), \(b_0\ge15t^4/16\). Therefore both scaled coefficients satisfy

\[
a\ge(1-16\tau/5)a_0,
\qquad b\ge(1-16\tau/5)b_0.
\]

The shared factor remains positive and is at least \(123/125\). These inequalities are uniform; they do not select or sample auxiliary states.

For the constraint \(h+t j=(1+t)B\), two-term Hölder gives

\[
(h+t j)^4\le
(a_0h^4+b_0j^4)
\big(a_0^{-1/3}+t^{4/3}b_0^{-1/3}\big)^3.
\]

Writing

\[
a_0=P(t)/(1+t)^4,
\qquad b_0=t^4Q(t)/(1+t)^4,
\]

where \(P=1+4t+6t^2+4t^3\), \(Q=4+6t+4t^2+t^3\), cancels all powers of \(1+t\) and \(t\) correctly. This yields

\[
G_4\ge \tau(1-16\tau/5)
\big(P^{-1/3}+Q^{-1/3}\big)^{-3}q^2.
\]

The fixed-constraint Hölder coefficient and its direction were derived independently. The coefficient formula has a continuous positive extension at \(t=0\); the underlying integer dimensions always have \(t>0\), so no zero coefficient was divided by at a finite state.

## Rational uniform estimate

The two polynomial inequalities used to remove radicals are valid throughout \([0,1]\):

\[
P\ge(15/16)(1+t)^4,
\]

\[
Q^2-16(1+t)^3=t^6+8t^5+28t^4+40t^3+20t^2\ge0.
\]

The rational cube bounds \((511/500)^3>16/15\) and \((63/100)^3>1/4\), followed by the concavity bound \((1+t)^{5/6}\le1+5t/6\), yield exactly

\[
K_4(t)\ge R(t)
=\frac{(1+t)^4}{(413/250+(21/40)t)^3}.
\]

Thus \(G_4\ge\tau(123/125)R(t)q^2\). No inequality direction is reversed when taking inverse cube powers.

The exact quadratic coefficient is

\[
K_2=\frac{3(1+t)+2t\tau}{4+3(1+t)\tau+2t\tau^2},
\qquad K_0=3(1+t)/4.
\]

Its subtraction formula and the upper bound \(0\le K_0-K_2\le\tau d(t)\), with

\[
d(t)=\big[9+(1003/100)t+(903/100)t^2\big]/16,
\]

are correct. The positive denominator is bounded below by 16 and \(6\tau\le3/100\), giving precisely the displayed coefficients.

## Factorial correction and tangent maximization

The Robbins factorial remainder gives the stated exponent

\[
\sigma=\tau\left[\frac{t}{6(1+t)}-
\frac2{12+\tau}-\frac{2t}{12+t\tau}\right].
\]

For \(0<\tau\le1/200\), both reciprocal denominators yield the bound

\[
\sigma/2\le\tau\left[\frac{t}{12(1+t)}-
\frac{200(1+t)}{2401}\right].
\]

The scaled logarithm \(\log(CB)<\tfrac12\log q+
\tfrac12\log((1+t)/(2\pi))+\sigma/2\) has the correct normalization. Using the global tangent to \(\log q\) at \(q_0=1/(2\alpha K_0)\) cancels the term \(\alpha K_0q\) and produces the dimension-ratio independent constant

\[
F_\infty=T-1/2-\tfrac12\log(3\pi\alpha).
\]

The remaining concave quadratic is bounded by its unrestricted maximum. This gives the exact correction

\[
E(t)=\frac{t}{12(1+t)}-\frac{200(1+t)}{2401}
+\frac{\alpha^2d(t)^2}{4\beta(123/125)R(t)}.
\]

Its denominator and factor four are correct. Restricting to positive \(q\) cannot increase that unrestricted maximum.

## Degree-seven exact certificate

Multiplying \(1/25-E(t)\) by \((1+t)^4>0\) gives the stated degree-seven polynomial exactly. The power-to-Bernstein conversion

\[
b_i=\sum_{k\le i}c_k\binom{i}{k}/\binom7k
\]

is correct. All eight exact coefficients exceed \(1/200\), so their Bernstein convex combination proves positivity on the entire closed interval, including both endpoints.

The independently written `check_large_independent.py` does not import the source checker. It reconstructs the power coefficients from the Bernstein representation by binomial expansion, then checks the claimed degree-seven polynomial at eight distinct rational points. Both polynomials have degree at most seven, so these exact equalities prove their identity. It independently checks the cube bounds, Machin lower bound, positive exponential lower sum, exact limiting cancellation, and the rational exponential upper report.

The minimum Bernstein coefficient is exactly

\[
1275042355731987/233569280000000000>1/200.
\]

Consequently the large-factor violation is strictly below \(F_\infty+1/5000\). The certified comparison

\[
3(314159/100000)\alpha
\sum_{j=0}^{10}(9021/10000)^j/j!>1
\]

and the Machin bound \(\pi>314159/100000\) imply
\(\log(3\pi\alpha)>-9021/10000\). Finally

\[
T-1/2+9021/20000+1/5000=0.
\]

The strict conclusion follows. The exact upper comparison
\(e^{1+39/800}<28541/10000\) is also correct, but remains a conditional class-wide endpoint until the other product regions are certified.

## Evidence

`large_replay.json` and `large_replay_optimized.json` reproduce the proof author's exact checker. `large_independent_report.json` and its optimized counterpart reproduce the independent coefficient audit. Both pairs are byte-identical. All verification decisions use Python's standard library, integers and `Fraction`, with explicit exceptions retained under optimization.

No owner proof or certificate file was modified. This is an independent model audit, not external peer review or proof-assistant formalization.
