# A sharper certified mixed Bellman envelope

The complete English proof is in [paper.pdf](paper.pdf), with editable [LaTeX](paper.tex) and [Markdown](proof.md). For the class generated from a point by finite products, joins, and invertible affine maps on affine hulls, it proves
\[
\log Q\le\frac{39}{800}D-\frac{861}{20000}\frac{H^2}{D}
-\frac{57}{10000}\frac{H^4}{D^3},\qquad
2.8534<\Gamma_{\mathcal C}\le e^{839/800}<2.8541.
\]
Rank-dropping maps are excluded. The lower construction is inherited and unchanged; the optimum remains undetermined.

The exact proof covers 19,900 finite dimension rectangles, 82,995 intervals in the imbalanced tails, and all products whose factor dimensions are both at least 200. The large-factor proof retains the quartic term and the first factorial correction; eight positive rational Bernstein coefficients certify every factor ratio. All cases use the same rational parameters.

Run `python3 verify.py` from this folder, or invoke its actual path from any other working directory. Python 3.10 or newer and its standard library suffice. The verifier checks the delivery manifest and replays the finite, tail, large-factor, and independent polynomial checkers normally and under `python -O`. It compares the exact outputs with the supplied reports and between modes. No network connection, repository checkout, SciPy, or prior source file is required.

Direct checks are also available from this folder:

```sh
python3 check_finite.py mixed_finite_points.json --quiet
python3 check_mixed_tail.py
python3 check_retained_quartic_large.py
python3 check_large_independent.py
```

All acceptance decisions use integers, fractions and proved rational logarithm bounds. The rational points are authoritative proof inputs; numerical optimization only proposed them. No convergence assumption or sampled-state extrapolation enters the proof. Optional discovery programs are excluded from this clean exact-proof delivery.

`DEPENDENCIES.md` states all imported hypotheses and pinned public sources; `SOURCE_MAP.json` records the mathematical origin and current file roles. `COMBINED_AUDIT.md`, `LARGE_AUDIT.md`, and `tail_audit/AUDIT.md` document the new-parameter model audits. The parent's independent reimplementation audited the earlier, weaker coefficients, not this sharpening. No external human review or proof-assistant formalization is asserted.

Build the PDF with `bash build.sh`. It runs `pdflatex` twice without shell escape or network access. Verify the delivered bundle before rebuilding: PDF metadata and TeX versions may change the resulting bytes, so a rebuilt PDF need not match the delivery manifest.

The accompanying [obstruction proof](../obstruction/obstruction.pdf) proves that the positive quadratic/quartic **local product-closure method** has nominal growth ceiling greater than 2.85404, or greater than 2.854042 when required on the full continuous state rectangles. These are method restrictions, not lower bounds for the actual optimal class rate. The [subquadratic-profile lemma](method_lemma.md) gives a possible route beyond that restriction; it contains no new certified global rate.

The closing public head is `dd5c29fc50c3e0694591260f60f3030d551d304d`. Its latest 005 README was reread; all pinned mathematical inputs are byte unchanged, and the mixed-envelope note is absent at that head. `HEAD_RECONCILIATION.json` records the file comparisons. This is a completed-work check, not a priority claim.

The bundle is additive under `notes/mixed-bellman-product-join/sharpened/` and `notes/mixed-bellman-product-join/obstruction/`. It also includes the unchanged earlier mixed-envelope PDF at `../paper.pdf` for the manuscript's comparison link. No numbered 005 version or shared catalogue file is changed. The immutable original candidate and earlier clean publication ZIP are preserved byte for byte. No publication or push was performed.

中文状态：已严格认证全 product/join 类新上界 \(\Gamma_{\mathcal C}\le e^{839/800}<2.8541\)。原候选与先前出版包未变；未改善下界、未确定真实最优值、未推送或发布。
