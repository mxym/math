# Exact finite certificate for the sharper quadratic/quartic parameters

This is the finite component of a sharper candidate envelope. It does not edit or supersede the immutable original publication package. Global conclusions require the separately proved imbalanced and large-factor tails.

Set
\[
\alpha=\frac{861}{20000},\qquad
\beta=\frac{57}{10000},\qquad
T=\alpha+\beta=\frac{39}{800}.
\]
For every pair \(1\le r\le s\le199\), let \(n=r+s\), \(C=g(r)g(s)/g(n)\), and
\[
x=(sh+rj)/n,\qquad v=rh+sj,
\]
\[
G_2=\frac{h^2}{r+1}+\frac{j^2}{s+1}-\frac{v^2}{n^2(n+1)},
\]
\[
A_4=\frac1{(r+1)^3}-\frac r{n(n+1)^3},\qquad
B_4=\frac1{(s+1)^3}-\frac s{n(n+1)^3},\qquad
G_4=A_4h^4+B_4j^4.
\]

## Finite proposition

For every real state \((h,j)\in[2,r+1]\times[2,s+1]\) in all 19,900 rectangles,
\[
\boxed{f_{r,s}(h,j):=\log(Cx)-\alpha G_2-\beta G_4+T<-10^{-6}<0.}
\]

**Proof.** Both quartic coefficients are positive. The quadratic form is positive definite: weighted Cauchy gives
\[
(rh+sj)^2\le\bigl(r^2(r+1)+s^2(s+1)\bigr)
\left(\frac{h^2}{r+1}+\frac{j^2}{s+1}\right),
\]
and
\[
n^2(n+1)-r^2(r+1)-s^2(s+1)=rs(3n+2)>0.
\]
Consequently \(f_{r,s}\) is strictly concave throughout the positive quadrant.

At a rational point \(p=(h_0,j_0)\) inside the rectangle, its exact rational derivatives are
\[
g_h=\frac{s}{nx}-\alpha\left(\frac{2h}{r+1}-\frac{2rv}{n^2(n+1)}\right)-4\beta A_4h^3,
\]
\[
g_j=\frac{r}{nx}-\alpha\left(\frac{2j}{s+1}-\frac{2sv}{n^2(n+1)}\right)-4\beta B_4j^3.
\]
Concavity bounds the entire rectangle by
\[
f_{r,s}(h,j)\le f_{r,s}(p)+g_h(h-h_0)+g_j(j-j_0).
\]
The exact maximum of this affine correction is
\[
S_p=g_h(e_r(g_h)-h_0)+g_j(e_s(g_j)-j_0),
\quad e_d(g)=\begin{cases}d+1,&g\ge0,\\2,&g<0.\end{cases}
\]
This is valid for the degenerate interval at dimension one as well.

The certificate `mixed_finite_points.json` contains exactly one rational point for each pair, with common denominator \(10^9\). The verifier checks its mathematical constants, complete ordered coverage, integer coordinate types, and membership of every point in its rectangle. It independently recomputes the value and derivatives and proves
\[
\overline{f_{r,s}(p)}+S_p<-10^{-6}
\]
for every rectangle. Its strict comparison is an integer/Fraction proof decision. No condition of numerical optimality or convergence is imposed on the proposed point.

Only the logarithms need interval arithmetic. For a positive rational input, write \(x=2^k y\), \(1\le y\le2\), and \(w=(y-1)/(y+1)\). For \(N=20\),
\[
\log y=2\sum_{m=0}^{N-1}\frac{w^{2m+1}}{2m+1}+E_N,
\qquad
0\le E_N\le\frac{2w^{2N+1}}{(2N+1)(1-w^2)}.
\]
The same formula at \(w=1/3\) bounds \(\log2\). Negative integer multiples swap the interval endpoints. Each proved interval is rounded outward by exact integer floor and ceiling to denominator \(2^{96}\). The checker caches integer logarithms through 398 and sums them to enclose factorial logarithms in the exact identity
\[
\log C=r\log r+s\log s-n\log n+\log(n!)-\log(r!)-\log(s!).
\]
All other operations are exact fractions, and outward rounding preserves every enclosure. This proves the finite proposition. \(\square\)

## Reproduction and evidence

The ordinary and optimized checkers are:

```sh
python3 check_finite.py mixed_finite_points.json --quiet --report finite_report.json
python3 -O check_finite.py mixed_finite_points.json --quiet --report finite_report_optimized.json
```

Both use only Python's standard library and arbitrary-precision integer/Fraction arithmetic. All correctness checks are explicit exceptions, which remain active under optimization. The generator imports SciPy only to propose rational points; the independent verifier imports neither SciPy nor the generator.

The greatest tangent upper bound occurs at \((r,s)=(5,5)\), with
\[
p=\left(\frac{5993253354}{10^9},\frac{5993253354}{10^9}\right).
\]
Its exact rational value, two gradients, and support correction are recorded in `finite_report.json`. The approximate value \(-0.0000906427\) indicates its scale and is not used in any proof decision.

## Relationship to the full invariant

The proposed homogeneous potential is
\[
\Phi(D,H)=TD-\alpha H^2/D-\beta H^4/D^3.
\]
Weighted Jensen proves join closure, and the formal point has zero potential. For a product, weighted harmonic mean is at most arithmetic and fourth-power mean, giving the conservative gains \(G_2,G_4\) above. Thus strict negativity of \(f\) proves product closure on this complete finite region. The state box is valid for the point-generated class under invertible affine maps between affine hulls; arbitrary rank-decreasing affine images are not included.

The other dimension regions must be certified separately. Once those regions are complete, the potential would give the all-dimensional ceiling \(e^{1+T}=e^{839/800}\); this finite note alone makes no such global assertion.
