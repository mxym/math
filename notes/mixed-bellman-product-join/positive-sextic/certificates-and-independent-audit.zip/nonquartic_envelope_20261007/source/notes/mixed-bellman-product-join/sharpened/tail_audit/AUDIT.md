# Independent audit of the sharper imbalanced-tail certificate

**Result: passed.** Analytic review, independent symbolic and coverage checks,
and complete normal and optimized rational replays all passed. No remaining
blockers were identified within the tail component's scope.

The reviewed constants are
\(\alpha=861/20000\), \(\beta=57/10000\), and
\(T=\alpha+\beta=39/800\). The claimed scope is every integer pair
\(1\le r<200\), \(s\ge200\), and every continuous state in
\([2,r+1]\times[2,s+1]\). This component proves only that product range.
Finite and large-dimension components with the same constants must be checked
separately before claiming the complete invariant.

## Mathematical review

The exact violation is correctly bounded above by the arithmetic-mean
quadratic and fourth-power-mean quartic relaxation. The quadratic form is
positive definite because
\[
(r+s)^2(r+s+1)-r^2(r+1)-s^2(s+1)=rs(3(r+s)+2)>0.
\]
Both quartic coefficients are positive, so the subtracted quartic term is
concave and has the required supporting-plane upper bound.

The factorial-ratio estimate follows from the stated Robbins bounds. In
particular, for \(n=r+s\ge s+1\),
\[
\delta_n<1/(12n)\le1/(12s+12)<1/(12s+1)<\delta_s,
\]
which justifies the sign of the correction used to bound \(C\). The normalized
logarithmic expression and all five rational cancellation coefficients match
direct substitution of \(s=1/z\), \(J=(s+1)j\).

The strong quadratic supporting correction is valid uniformly on each interval.
For any displacements \(u,v\), Young's inequality gives
\[
|buv|\le (a_-/2)u^2+\frac{b^2}{2a_-}v^2,
\]
and hence
\[
au^2+buv+cv^2\ge (a_-/2)u^2+
\left(c_--\frac{\max(b_-^2,b_+^2)}{2a_-}\right)v^2.
\]
The checker requires both displayed curvature lower bounds to be positive.
There is no missing factor of two: the exact quadratic expansion contributes
\(-\alpha q_2(u,v)\), and each one-dimensional correction is maximized at
\(g/(2\alpha m)\), clipped to the allowed displacement interval.

For a negative displacement the larger linear term uses the lower gradient
endpoint, and for a positive displacement it uses the upper gradient endpoint.
`parabola_box` takes the maximum of these two half-interval maxima before the
two coordinate maxima are added. The supporting value and both gradient
formulas are enclosed with the correct signs.

## Implementation and completeness

`mixed_tail_core.py` differs from the previously audited
immutable candidate `mixed_tail_core.py` only in its two parameter lines. Its interval
arithmetic, denominator checks, logarithmic series remainder, power-of-two
range reduction, and integer outward rounding preserve their enclosures.

The main checker checks strict integer coordinate types, bounded dyadic
indices, supporting-point membership, every exact negative supporting bound,
and endpoint-by-endpoint coverage for every dimension from 1 through 199.
Duplicate intervals, gaps, and overlaps fail its coverage test. The final
worst-bound check implies a uniform margin below \(-10^{-10}\), and it occurs
before the printed `PASS`. These checks remain active under optimized Python.

The independent `check_structure.py` does not import the submitted core or
generator. It proves three symbolic polynomial identities and validates
coverage using integer endpoints on a common dyadic scale. Both normal and
optimized runs passed, reporting 82,995 cells and maximum depth 10.

The merged certificate SHA-256 is

```
ad56c8f4b31e91d341d51ddf0d593c4da58b118d049ee1644384a807ec9de329
```

The source snapshot reviewed has hashes:

```
153858ca279d3ec164714997fda4bb9754471fea0d9247635f65e98db958fced  TAIL_PROOF.md
00871198e2d9c7c58b4eb287c374c180258903a52afcbe54e0f9a39247a62b4c  mixed_tail_core.py
2d2117656fadc8a2d621ec00ab7890c734aab98d39f4522fea18d3c40e502a58  check_mixed_tail.py
```

## Replay record

The two independent complete replays were launched with bytecode writing
disabled, and their outputs are saved only in this audit directory:

```
PYTHONDONTWRITEBYTECODE=1 python ../check_mixed_tail.py > result_normal.json
PYTHONDONTWRITEBYTECODE=1 python -O ../check_mixed_tail.py > result_optimized.json
```

Both processes exited successfully. Their saved reports are byte-identical and
report `PASS`, 82,995 cells, maximum depth 10, and the uniform certified upper
margin `-1/10000000000`. The worst supporting cell is
`[70, 101, 7, 2365127134, 18946456]`. The replay hash matches the independent
coverage report and the final certificate bytes. The executable hashes above
were unchanged at replay completion and at the subsequent documentation review.

The independent structure reports are `structure_result.json` and
`structure_result_optimized.json`. No publication, prior proof, original
certificate, or file outside this audit directory was changed by this reviewer.

## Documentation snapshot refresh

After the complete replays, `TAIL_PROOF.md` appended the already verified cell
count, depth, margin, report identity, and certificate hash. It also clarified
that bare verifier commands run from the component directory; a full script
path works from another working directory because certificate lookup is
relative to the checker. These documentation changes, and the matching wording
in `REPRODUCTION.md`, were reviewed and are accurate. The reviewed proof hash
above was refreshed to `153858ca279d3ec164714997fda4bb9754471fea0d9247635f65e98db958fced`.
No mathematical argument, executable, or certificate changed, so the completed
normal and optimized replay evidence remains applicable; no replay was repeated.
