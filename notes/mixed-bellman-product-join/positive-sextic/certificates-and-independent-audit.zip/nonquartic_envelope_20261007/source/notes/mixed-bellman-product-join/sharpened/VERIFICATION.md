# Standalone exact verification and build

The default command is `python3 verify.py`. It resolves all inputs beside its own script, checks `MANIFEST.json`, and runs every required checker from an unrelated temporary working directory with bytecode writing disabled. Supplied certificates and reports are never overwritten. Temporary reports are removed on completion.

The finite checker certifies all 19,900 rectangles, with uniform upper bound below `-1/1000000`. The tail checker certifies all 82,995 cells, depth at most ten, with uniform upper bound below `-1/10000000000`, and exact gap-free, overlap-free coverage for every small dimension. The large-factor checker certifies the degree-seven polynomial, radical bounds, factorial-margin constants and `exp(839/800)<28541/10000`. The separate polynomial checker imports none of its author's checker code and reconstructs the claimed polynomial independently.

Each checker is run normally and with optimization enabled. Reports must match the supplied exact reports and be byte-identical between these modes. Timing floats, if any, do not enter a proof comparison or the final exact reports. All acceptance tests are explicit exceptions, so `python -O` removes none of them.

For an optional summary outside the package:

```sh
python3 verify.py --report /path/to/replay-summary.json
```

Assembly integrity alone can be checked with `--integrity-only`; its report explicitly states that mathematics was not replayed. A full verification of this large tail may take several minutes. Independent component replay reports and the written analytic reductions are included.

`tail_audit/check_structure.py` is an optional symbolic and coverage cross-check requiring SymPy. It does not import the certificate core. SymPy is not required by the main exact verifier or the proof's authoritative arithmetic checkers.

Build `paper.pdf` with `bash build.sh`, using a TeX installation with the packages listed in `DEPENDENCIES.md`. The build is independent of the mathematical replay. Verify the as-delivered files before rebuilding; changes in TeX versions or PDF metadata may change PDF bytes. No byte-identical PDF build is claimed.

The inherited lower endpoint is documented in `DEPENDENCIES.md`. Its historical exact replay is retained; the main verifier does not rerun or download the upstream lower certificate. The method-obstruction package has its own verifier in the sibling `obstruction/` folder.
