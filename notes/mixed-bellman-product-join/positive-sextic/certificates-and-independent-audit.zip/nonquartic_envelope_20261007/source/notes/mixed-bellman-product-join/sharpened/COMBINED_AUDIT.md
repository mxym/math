# Combined audit of the sharper mixed envelope

**Result: PASS.** The assembled English proof and its three exact components
are consistent at
\[
\alpha=861/20000,\qquad\beta=57/10000,\qquad
T=\alpha+\beta=39/800.
\]
They prove the claimed invariant, and hence
\(\Gamma_{\mathcal C}\le e^{839/800}<2.8541\), for the point-generated
product/join class closed under **invertible affine maps on affine hulls**.
There is no remaining mathematical blocker identified by this audit.
Rank-dropping maps, the unrestricted class of convex bodies, and optimality of
the known lower orbit are outside the theorem.

This is a separate collaborating-model audit of the sharper coefficients.
The parent's adversarial reimplementation of the earlier mixed envelope is
not evidence for replaying these new certificates, and is not presented as
such. The checks below do not constitute human peer review or a proof-assistant
formalization.

## The global argument

The imported exact calculus has positive-dimensional state bounds
\(2\le H\le D=d+1\), the point state \((D,H,Q)=(1,1,1)\), additive \(D,H\)
and multiplicative \(Q\) for joins, and the stated harmonic-mean product
formula. These are the same hypotheses and normalization as the pinned entry
005 calculus and spectral supplement. The enlarged finite state boxes are
valid for this class because products average the input \(a=1/H\) with
dimension weights and joins add \(H\). Intermediate affine equivalences
preserve the invariant. Products with points are redundant and need no
positive-dimension product inequality.

The potential
\[
\Phi(D,H)=TD-\alpha H^2/D-\beta H^4/D^3
\]
vanishes at the point. Weighted Jensen proves its superadditivity under
joining. For a product, the output minus input potential is exactly
\(\alpha\Delta_2+\beta\Delta_4\); the subtraction of one dimension contributes
\(-T\). Thus the sign of the \(+T\) in the concave product defect is correct.
The harmonic/arithmetic and harmonic/fourth-power mean comparisons give
\(\Delta_2\ge G_2-1\) and \(\Delta_4\ge G_4-1\) in the required direction.

The diagonal quartic coefficients are strictly positive. The quadratic
matrix has a positive first diagonal entry and determinant
\[
\frac{rs(3(r+s)+2)}{(r+1)(r+s)^2(s+1)(r+s+1)}>0.
\]
Consequently the supporting planes used in the finite component are global
upper bounds on every real state in the box. Strict concavity is not inferred
from numerical optimization. The stronger supporting quadratic in the tail
component has the correct factor: expansion of the quadratic term contributes
\(-\alpha q_2(\eta)\), and its scalar maximum has vertex
\(g/(2\alpha m)\).

After using symmetry to assume \(r\le s\), the three regions are exhaustive
and disjoint:

| Region | Exact component | Coverage and conclusion |
| --- | --- | --- |
| \(1\le r\le s\le199\) | Finite supporting planes | All 19,900 rectangles; every upper bound is below \(-10^{-6}\). |
| \(1\le r<200\le s\) | Imbalanced interval tail | All 199 smaller dimensions and all real \(z=1/s\in[0,1/200]\); 82,995 cells, maximum depth 10, every upper bound below \(-10^{-10}\). |
| \(r,s\ge200\) | Retained quartic lemma | Analytic inequality for every positive real \(h,j\), with uniform exact polynomial certification for every factor ratio. |

Structural induction therefore proves the invariant for every finite
construction expression. No limiting or infinite construction is required
for this induction.

## New finite certificate review and replay

The certificate contains exactly the ordered pairs \(1\le r\le s\le199\).
Its parameter arrays, common point denominator, point membership, and all
integer coordinate checks agree with the English proof. Each exact gradient
has its box-linear maximum at the endpoint chosen by its sign.

The eight mathematical helper functions in `check_finite.py` are identical
as Python abstract syntax trees to their previously audited versions:
`require`, `rat`, `atanh_log_bounds`, `outward_round`, `log_bounds`,
`add_intervals`, `scale_interval`, and `tangent`. The new source changes only
the parameter declarations, certificate parameter guard, and claimed uniform
margin. The new rational points are accepted only after recomputing their
inequalities; no earlier-parameter decision is reused.

This reviewer independently replayed every rectangle in both normal and
optimized Python. `finite_replay.json` and
`finite_replay_optimized.json` are byte-identical to one another and to the
supplied `finite_report.json`. Both runs exited successfully. The worst
rectangle is \((5,5)\), with both coordinates
\(2996626677/500000000\). Its certified upper endpoint is
\[
\frac{-195724544700769594069376846520017938592416510821856716349135553}
{2159297085744910028211486720000000000000000000000000000000000000000}
<-\frac1{1000000}.
\]
All acceptance checks use explicit exceptions and remain active under `-O`.

## Tail integration and separate complete replay

The normalized cancellation coefficients, dimension-only factorial bound,
strong concavity correction, interval gradient signs, and clipped scalar
maxima were reviewed. The elementary monotonicity proof in the assembled
English text also proves the same bound
\(C\le g(r)e^{-r}\sqrt{1+rz}\) used by the checker. In particular no
unproved sign of a Stirling error is needed for that tail bound.

All nine mathematical functions of `mixed_tail_core.py` are identical as
abstract syntax trees to the earlier audited tail core; only the two parameter
lines change. Positivity and curvature lower bounds are recomputed with the
new parameters for every cell. The 28-term logarithm enclosure, sign handling
for integer multiples of \(\log2\), and outward rounding preserve their
enclosures. The algebraic endpoint \(z=0\) is regular and is used for interval
coverage only.

The separate tail reviewer completed both normal and optimized supporting
bound replays for these new coefficients, and independently checked three
symbolic cancellation identities and complete coverage on a common integer
dyadic scale. Its `tail_audit/AUDIT.md` and corresponding reports describe
that review. This combined reviewer inspected those completed reports,
confirmed they are byte-identical to one another and to the supplied tail
report, and independently ran the lightweight symbolic/coverage checker.
The long supporting-bound replay was not duplicated here. No gap, overlap,
missing smaller dimension, malformed point, or parameter mismatch was found.

## Large-dimension analytic and exact audit

`LARGE_AUDIT.md` records this reviewer's separate adversarial audit of the
retained-quartic lemma. Its quadratic square identity, derivative bounds for
the two scaled quartic coefficients, and two-term Hölder minimization are
valid. The lower bound for the quartic coefficient is uniform for
\(0<t\le1\) and \(0<\tau\le1/200\). The rational cube-root estimates and the
concave chord bound have the correct directions.

Retaining the first Robbins correction, then applying the logarithm tangent
at \(q_0=1/(2\alpha K_0)\), gives the displayed upper defect
\(F_\infty+\tau E(t)\). The residual maximization in \(q\) is a concave
quadratic with a positive quadratic penalty. Its degree-seven polynomial
certificate is strictly positive throughout \([0,1]\): all eight Bernstein
coefficients exceed \(1/200\). The smallest is exactly
\[
\frac{1275042355731987}{233569280000000000}>\frac1{200}.
\]

Normal and optimized owner-checker replays are byte-identical. This reviewer
also independently reconstructed the polynomial from its Bernstein
coefficients, checked its identity at eight rational points, and verified
the rational root estimates, Machin lower bound for \(\pi\), exponential
comparisons, and exact final cancellation. The corresponding independent
normal and optimized reports are byte-identical. Thus the large component
does not rely on the small-dimensional certificates or on a floating
approximation to the limiting margin.

## Spectral conclusion and comparison

The proof uses the existing join-closed spectral identity
\(\Gamma_{\mathcal C}=e\sup_K Q(K)^{1/D}\) after establishing a finite upper
bound. Since \(H>0\), the new invariant implies
\(\log Q/D<T\) for each finite state, and hence only the non-strict
supremum bound \(\sup Q^{1/D}\le e^T\), exactly as stated. It makes no
finite-attainment inference.

The spectral exponent is \(1+T=839/800\). The positive Taylor sum with a
geometric remainder certifies
\(e^{839/800}<28541/10000\). The actual public quadratic ceiling is larger
by the rigorous comparison
\[
\frac{11}{85}\log\frac{189}{128}
>\frac{1342}{26945}>\frac{39}{800},\qquad
\frac{1342}{26945}-\frac{39}{800}
=\frac{4549}{4311200}>0.
\]
The pointwise comparison with the earlier audited mixed envelope is also
correct:
\[
\Phi_{\rm old}-\Phi_{\rm sharp}
=\frac D{20000}(1-(H/D)^2)(5-4(H/D)^2)\ge0.
\]
The inherited lower endpoint \(2.8534\) is kept separate from the new upper
proof. Its historical replay is not a new lower construction. The literature
and scope paragraphs avoid claiming an unrestricted optimum, first discovery
of Bellman methodology, or complete exclusion of unavailable prior texts.

## Snapshot and evidence

`combined_consistency_report.json` records the source/certificate hashes,
parameter arithmetic, report identities, and byte equality of the published
component copies to the reviewed component sources. The reviewed English
proof snapshot has SHA-256

```
e7b65feeeb79d79663cba5b1049ccc7d8dcf046188a1972922d48f0514003d14
```

The two unchanged new certificate hashes are

```
fc221dd788709b24033ae5656e3001c34ef1d107533373325428f1704212385e  mixed_finite_points.json
ad56c8f4b31e91d341d51ddf0d593c4da58b118d049ee1644384a807ec9de329  mixed_tail_certificate.json
```

The proof copy's documentation snapshot is distinguished from its immutable
arithmetic certificates. Later editorial changes require a documentation
review/hash refresh, and do not by themselves require replaying unchanged
arithmetic. Reproduction commands from the supplied component bundle are:

```sh
python3 check_finite.py mixed_finite_points.json --quiet
python3 -O check_finite.py mixed_finite_points.json --quiet
python3 check_mixed_tail.py
python3 -O check_mixed_tail.py
python3 check_retained_quartic_large.py
python3 -O check_retained_quartic_large.py
python3 check_large_independent.py
python3 -O check_large_independent.py
```

The independent source consistency and analytic review found no parameter
drift, coverage mismatch, reversed inequality, missing base case, or circular
use of the final rate bound. No proof, component executable, or certificate
was modified by this reviewer during this combined audit.
