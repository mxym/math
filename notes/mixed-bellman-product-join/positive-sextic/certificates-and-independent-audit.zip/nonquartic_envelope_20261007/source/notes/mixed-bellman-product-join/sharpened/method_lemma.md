# Subquadratic homogeneous potentials: an analytic method lemma

This is a rigorous structural lemma for possible future product/join envelopes. It does not prove a new global upper constant. The new upper theorem does not depend on this optional method lemma.

## 1. A convex product relaxation for every real exponent between one and two

Let \(r,s\ge1\), \(n=r+s\), and \(1<p\le2\). For \(h,j>0\), define
\[
U_p(h,j)=\frac{h^p}{(r+1)^{p-1}}+
\frac{j^p}{(s+1)^{p-1}}-
\frac{(rh+sj)^p}{n^p(n+1)^{p-1}}.
\]
Then \(U_p\) is strictly convex on the positive quadrant. At \(p=1\), its continuous algebraic counterpart is the linear function
\[
U_1(h,j)=h+j-(rh+sj)/n=(sh+rj)/n.
\]

**Proof.** For \(1<p\le2\), divide the Hessian by the positive factor \(p(p-1)\). Its diagonal part is
\[
M=\operatorname{diag}\left(\frac{h^{p-2}}{(r+1)^{p-1}},
\frac{j^{p-2}}{(s+1)^{p-1}}\right),
\]
and the subtracted rank-one part is
\[
\lambda vv^{\mathsf T},\quad v=(r,s),\quad
\lambda=\frac{(rh+sj)^{p-2}}{n^p(n+1)^{p-1}}.
\]
A diagonal-positive matrix \(M-\lambda vv^{\mathsf T}\) is positive definite if \(\lambda v^{\mathsf T}M^{-1}v<1\), by Cauchy's inequality in the \(M\)-inner product.

Put \(q=2-p\in[0,1)\), \(x=rh\), and \(y=sj\). Hölder's inequality gives
\[
 r^p(r+1)^{p-1}x^q+s^p(s+1)^{p-1}y^q
\le(x+y)^q
\left[r^{p/(p-1)}(r+1)+s^{p/(p-1)}(s+1)\right]^{p-1}.
\]
For \(q=0\), this is the equality of the two constant sums. Consequently
\[
\lambda v^{\mathsf T}M^{-1}v\le
\frac{\left[r^{p/(p-1)}(r+1)+s^{p/(p-1)}(s+1)\right]^{p-1}}
{n^p(n+1)^{p-1}}<1.
\]
The strict inequality follows because \(k=p/(p-1)>1\) and
\[
r^k(r+1)+s^k(s+1)<(r^k+s^k)(n+1)<n^k(n+1).
\]
Thus the Hessian is positive definite. The \(p=1\) identity is direct. \(\square\)

Let \(H'=n/(r/h+s/j)\). Since \(H'\le(rh+sj)/n\), the actual gain in the \(p\)-perspective satisfies
\[
\frac{h^p}{(r+1)^{p-1}}+\frac{j^p}{(s+1)^{p-1}}
-\frac{(H')^p}{(n+1)^{p-1}}\ge U_p(h,j).
\]
Thus a nonnegative coefficient of a subquadratic exponent \(1<p<2\) can be added to a concave product violation while retaining the supporting-plane certificate method. For \(p=1\), this is exactly the tractable lower bound \(h+j-H'\ge(sh+rj)/n\).

For a profile
\[
f(t)=T-\sum_i c_i t^{p_i},\qquad c_i\ge0,\quad p_i\ge1,\quad T=\sum_i c_i,
\]
weighted Jensen proves join closure of \(D f(H/D)\), and the point has zero potential. The lemma supplies a strictly convex arithmetic-mean relaxation for every \(p_i\in(1,2]\). For higher exponents the established diagonal power-mean relaxation remains convex. Complete product closure in every dimension still requires a separate certified inequality.

## 2. Why a subquadratic term bypasses the balanced curvature test

For a balanced product of equal dimensions \(d\), at equal states \(h=j\), the \(p\)-gain is exactly
\[
-1+h^p\left(\frac2{(d+1)^{p-1}}-\frac1{(2d+1)^{p-1}}\right).
\]
At \(h=t\sqrt d\), its positive part is asymptotic to
\[
(2-2^{1-p})t^p d^{1-p/2}.
\]
It diverges for every \(1\le p<2\). Therefore a positive coefficient of such a term removes the finite quadratic-curvature necessary condition arising when the profile has zero initial slope and leading quadratic order. This statement concerns the balanced local closure test; it does not establish closure at other states or prove a global invariant. The accompanying [obstruction note](../obstruction/OBSTRUCTION.md) gives the precise necessary conditions and reachable joined-cube examples.

## 3. A regular compact tail formula for the exponent three halves

The case \(p=3/2\) admits exact square-root interval evaluation. In the imbalanced tail, put \(z=1/s\), \(j=(s+1)u\), and \(0\le z\le1/200\). Let
\[
R=(1+rz)^3(1+(r+1)z),\quad L=u(1+z)+rh z^2,
\]
\[
A=(1+z)u^{3/2},\qquad B=L^{3/2}/\sqrt R.
\]
For \(z>0\),
\[
U_{3/2}=\frac{h^{3/2}}{\sqrt{r+1}}+\frac{A-B}{z}.
\]
At a supporting point with \(u>0\), the following exact rationalization removes the apparent singularity:
\[
U_{3/2}=\frac{h^{3/2}}{\sqrt{r+1}}+\frac{Q}{R(A+B)},
\]
where the polynomial
\[
\begin{aligned}
Q={}&u^3(1+z)^2\left[4r+(6r^2+3r)z+(4r^3+3r^2)z^2+r^3(r+1)z^3\right]\\
&-3rh u^2(1+z)^2z-3r^2h^2u(1+z)z^3-r^3h^3z^5
\end{aligned}
\]
is obtained from \(((1+z)^2u^3R-L^3)/z\). The identity follows by multiplying numerator and denominator by \(A+B\). Its denominator is strictly positive at \(u>0\) throughout the closed interval. The extension at zero is
\[
U_{3/2}(z=0)=\frac{h^{3/2}}{\sqrt{r+1}}+2r u^{3/2}.
\]
This provides a regular algebraic function for interval supporting-point evaluations and their state derivatives. It is a method lemma, not a tail certificate.

For a nonnegative rational \(a/b\), an integer-only square-root enclosure at denominator \(M\) is obtained by
\[
k=\operatorname{isqrt}\left(\left\lfloor aM^2/b\right\rfloor\right),\qquad
k/M\le\sqrt{a/b}<(k+1)/M.
\]
When \(bk^2=aM^2\), the root is exact and the two endpoints can coincide. Thus no floating-point decision is needed for a future three-halves certificate.

## 4. Remaining proof obligation

These lemmas make additional potential profiles compatible with supporting-plane certification. They do not supply an all-dimensional product inequality or a certified numerical rate. Any extension must separately prove finite, imbalanced-tail, and large-factor closure; the present exact upper theorem uses only the certified quadratic/quartic profile.
