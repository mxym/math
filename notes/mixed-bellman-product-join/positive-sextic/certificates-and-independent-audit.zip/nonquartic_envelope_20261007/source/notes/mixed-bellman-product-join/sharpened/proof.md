# A sharper certified mixed quadratic/quartic envelope for projection-body growth

**Research continuation of entry 005. Complete English proof, 7 October 2026.**

The public repository was initially read at `8ad38152eac75993659c1f128a382bbc1a19ceab` and rechecked during the work through `3360e7191cf564a46d09edcbfbd107c9178bd98f`. Its v5 balanced-recursion classification and its newly published quadratic Bellman bound are completed prior work. The mixed-potential discovery mentioned in that supplement is also acknowledged. The contribution below is exact certification of a strictly smaller upper ceiling over every finite product/join tree. It is not a new lower construction or an unrestricted extremal theorem.

The new finite certificate, imbalanced-tail certificate, and retained-quartic large-factor proof have passed exact replay and separate model-conducted mathematical audits. The parent adversarial reimplementation audited the earlier coefficients; it is not asserted to have audited this sharpening. Ordinary and optimized Python checks remain active and pass. This is model-assisted research and exact arithmetic verification, not human peer review or proof-assistant formalization.

## The theorem and its hypotheses

Let \(\mathcal C\) be the class generated from a formal zero-dimensional point by finitely many joins, Cartesian products, and invertible affine maps on affine hulls. Thus affine images here mean affine equivalences; rank-dropping maps are outside this class. A product with a point is redundant. For a positive-dimensional convex body in this class, put
\[
d=\dim K,\qquad D=d+1,\qquad H=\frac1{a(K)},\qquad
g(d)=\frac{d^d}{d!},\qquad
Q=\frac{a(K)R(K)}{g(d)},\qquad
R(K)=\frac{|\Pi K|}{|K|^{d-1}}.
\]
The projection-body normalization, the invariant \(a\), and the exact calculus are those of entry 005 v2. For a point set \((D,H,Q)=(1,1,1)\). Define
\[
\alpha=\frac{861}{20000},\qquad
\beta=\frac{57}{10000},\qquad
T=\alpha+\beta=\frac{39}{800}.
\]
The sharper inequality is
\[
\boxed{\log Q(K)\le
\alpha\left(D-\frac{H^2}{D}\right)
+\beta\left(D-\frac{H^4}{D^3}\right).}
\tag{1}
\]
Consequently the optimal asymptotic rate of the entire class satisfies
\[
\boxed{2.8534<\Gamma_{\mathcal C}\le e^{839/800}<2.8541.}
\tag{2}
\]
Here \(\Gamma_{\mathcal C}=\lim_{d\to\infty}\sup_{K\in\mathcal C_d}R(K)^{1/d}\). Its existence and its equality to \(e\sup Q(K)^{1/(d+1)}\) are the spectral reduction already proved in entry 005. The lower endpoint is the already certified self-similar family, not a new lower-bound claim.

All proof decisions in the certificates below use integers, fractions, and rational logarithm intervals. Floating optimization is used only to propose rational supporting points. Acceptance of such a point is governed entirely by the exact inequalities below.

## 1. Structural induction and join closure

The exact v2 calculus is
\[
(D,H,Q)(A*B)=(D_A+D_B,H_A+H_B,Q_AQ_B).
\tag{3}
\]
For a product of positive-dimensional factors, let \(r=\dim A\), \(s=\dim B\), \(n=r+s\), \(h=H_A\), and \(j=H_B\). Then
\[
H'=\frac{n}{r/h+s/j},\qquad
D'=n+1,\qquad
Q'=Q_AQ_B Cx,
\tag{4}
\]
where
\[
C=\frac{g(r)g(s)}{g(n)},\qquad
x=\frac{sh+rj}{n}.
\tag{5}
\]
Every positive-dimensional state in \(\mathcal C\) obeys
\[
2\le H\le d+1.
\tag{6}
\]
The upper bound follows from the inherited inequality \(a\ge1/(d+1)\). For the lower bound, the first positive-dimensional body is the join of two points, with \(H=2\). Joins add \(H\); products make \(a\) a dimension-weighted arithmetic mean, and therefore preserve \(a\le1/2\). This argument concerns this class, and does not assume symmetry of all its bodies.

For \(p\ge1\), Hölder's inequality gives
\[
\frac{(H_1+H_2)^p}{(D_1+D_2)^{p-1}}
\le \frac{H_1^p}{D_1^{p-1}}+\frac{H_2^p}{D_2^{p-1}}.
\tag{7}
\]
For instance this is Jensen applied to \(u\mapsto u^p\), with weights \(D_i/(D_1+D_2)\). Applying (7) with \(p=2,4\) proves that (1) is preserved by joins. The point has equality. It remains to prove product closure.

## 2. A strictly concave product supersolution

Define
\[
\Delta_p=-1+\frac{h^p}{(r+1)^{p-1}}+
\frac{j^p}{(s+1)^{p-1}}-\frac{(H')^p}{(n+1)^{p-1}}.
\]
The difference between the product's potential in (1) and the sum of the two input potentials is \(\alpha\Delta_2+\beta\Delta_4\). Therefore product closure follows from
\[
\log(Cx)\le\alpha\Delta_2+\beta\Delta_4.
\tag{8}
\]
Weighted harmonic mean is at most weighted arithmetic mean and at most weighted fourth-power mean. Thus (8) follows from strict negativity of
\[
f_{r,s}(h,j)=\log(Cx)-\alpha G_2(h,j)-\beta G_4(h,j)+T,
\tag{9}
\]
where
\[
G_2=\frac{h^2}{r+1}+\frac{j^2}{s+1}
-\frac{(rh+sj)^2}{n^2(n+1)},
\tag{10}
\]
\[
G_4=A_4h^4+B_4j^4,
\quad A_4=\frac1{(r+1)^3}-\frac r{n(n+1)^3},
\quad B_4=\frac1{(s+1)^3}-\frac s{n(n+1)^3}.
\tag{11}
\]
Both quartic coefficients are positive. For example \(r(r+1)^3<n(n+1)^3\).

The quadratic form \(G_2\) is positive definite. Its first diagonal coefficient is positive, and its determinant is
\[
\frac{rs(3n+2)}{(r+1)n^2(s+1)(n+1)}>0.
\tag{12}
\]
Hence \(f_{r,s}\) is strictly concave throughout the positive quadrant: its logarithm is concave, and G₂ and G₄ are convex. In particular every supporting plane gives a global upper bound on its entire state rectangle. No untested sampling of states is used below.

By symmetry assume \(r\le s\). We prove (9) is negative in three exhaustive ranges: both dimensions below 200; \(r<200\le s\); and both dimensions at least 200.

## 3. Both dimensions large: retaining the quartic term

Fix the exact rational parameters

α=861/20000, β=57/10000, T=α+β=39/800.

This section proves the large-factor component. Sections 4–5 supply the complementary finite and small-factor certificates at exactly the same parameters.

**Lemma.** Let r,s≥200 be integers, n=r+s, and h,j>0. Put

C=g(r)g(s)/g(n), g(d)=d^d/d!,

B=(s h+r j)/n,

G₂=h²/(r+1)+j²/(s+1)−(r h+s j)²/[n²(n+1)],

A=1/(r+1)³−r/[n(n+1)³],

J=1/(s+1)³−s/[n(n+1)³],

G₄=A h⁴+J j⁴.

Then

log(CB)−αG₂−βG₄+T<0.

In particular, the actual harmonic-mean product defect is strictly controlled: harmonic≤arithmetic gives the G₂ lower bound, and harmonic≤fourth-power mean gives the G₄ lower bound. No auxiliary-state box restrictions are needed in this lemma.

## 1. Normalize the two dimensions

Assume r≤s, and write

t=r/s∈(0,1], τ=1/r≤1/200, q=B²/r>0.

The exact quadratic minimum is

G₂≥kB², k=(3n+2)/(4rs+3n+2).

For completeness, putting Δ=4rs+3n+2, its nonnegative-square identity is

G₂−kB²=

rs·[(s+1)(3r+s+2)h−(r+1)(r+3s+2)j]²

/[(r+1)n²(s+1)(n+1)Δ].

Thus G₂≥K₂(t,τ)q, where

K₂(t,τ)=[3(1+t)+2tτ]/[4+3(1+t)τ+2tτ²].

Put K₀(t)=3(1+t)/4. Direct subtraction gives

0≤K₀−K₂

=τ[9(1+t)²−8t+6t(1+t)τ]/[4(4+3(1+t)τ+2tτ²)]

≤τ d(t),

where

d(t)=[9+(1003/100)t+(903/100)t²]/16.

## 2. A rational lower bound for the quartic coefficient

Write γ=t/(1+t). Multiplying the diagonal quartic coefficients by r³ gives

a(t,τ)=(1+τ)^(−3)−γ⁴(1+γτ)^(−3),

b(t,τ)=t³[(1+tτ)^(−3)−(1+t)^(−4)(1+γτ)^(−3)].

Let a₀=a(t,0) and b₀=b(t,0). Since γ≤1/2, a₀≥15/16. Also ∂a/∂τ≥−3, whence

a(t,τ)≥a₀−3τ≥(1−16τ/5)a₀.

Likewise ∂b/∂τ≥−3t⁴. The concave function 1−(1+t)^(−4) lies above its chord on[0,1], so

1−(1+t)^(−4)≥15t/16.

Therefore b₀≥15t⁴/16 and

b(t,τ)≥(1−16τ/5)b₀.

For positive coefficients a₀,b₀ and the linear constraint h+t j=(1+t)B, Hölder gives

(h+t j)⁴≤(a₀h⁴+b₀j⁴)[a₀^(−1/3)+t^(4/3)b₀^(−1/3)]³.

Indeed this is the finite-dimensional Hölder inequality with exponents4 and4/3, applied to the two pairs (a₀^(1/4)h,b₀^(1/4)j) and(a₀^(−1/4),t b₀^(−1/4)). We have a₀=P(t)/(1+t)⁴ and b₀=t⁴Q(t)/(1+t)⁴, so the denominator simplifies exactly. It follows that

G₄≥τ(1−16τ/5)K₄(t)q²,

where

K₄(t)=[P(t)^(−1/3)+Q(t)^(−1/3)]^(−3),

P(t)=1+4t+6t²+4t³,

Q(t)=4+6t+4t²+t³.

This also has a continuous positive limit at t=0.

We now replace the cube roots by rational bounds. First,

P(t)=(1+t)⁴−t⁴≥(15/16)(1+t)⁴.

Second,

Q(t)²−16(1+t)³=t⁶+8t⁵+28t⁴+40t³+20t²≥0.

The exact rational comparisons

(511/500)³>16/15, (63/100)³>1/4

therefore imply

P(t)^(−1/3)+Q(t)^(−1/3)

≤(1+t)^(−4/3)[511/500+(63/100)(1+t)^(5/6)].

Concavity gives (1+t)^(5/6)≤1+5t/6. Hence

K₄(t)≥R(t):=(1+t)⁴/[413/250+(21/40)t]³.

As 1−16τ/5≥123/125, we have the entirely rational bound

G₄≥τ(123/125)R(t)q².

## 3. Keep the first factorial correction

Robbins' bounds give

C²< [n/(2πrs)]exp(σ),

σ=τ[t/(6(1+t))−2/(12+τ)−2t/(12+tτ)].

Thus

log(CB)<(1/2)log q+(1/2)log[(1+t)/(2π)]+σ/2.

For τ≤1/200,

σ/2≤τ[t/(12(1+t))−200(1+t)/2401].

This correction is essential to avoid the much larger cutoff obtained by discarding the quartic term and all factorial corrections.

## 4. A global tangent bound in q

Set q₀=1/[2αK₀(t)]=2/[3α(1+t)]. The tangent inequality

log q≤log q₀+q/q₀−1

gives

log(CB)−αG₂−βG₄+T

< F∞+σ/2+α(K₀−K₂)q−βτ(123/125)R(t)q²,

where

F∞=T−1/2−(1/2)log(3πα).

Maximizing the remaining concave quadratic in q and using K₀−K₂≤τd(t), we obtain

log(CB)−αG₂−βG₄+T < F∞+τ E(t),

E(t)=t/[12(1+t)]−200(1+t)/2401

+α²d(t)²/[4β(123/125)R(t)].

## 5. Eight exact coefficients certify every factor ratio

The inequality E(t)<1/25 for every0≤t≤1 is equivalent to positivity of the degree-seven polynomial

F(t)=(1+t)⁴/25−t(1+t)³/12+200(1+t)⁵/2401

−[α²/(4β(123/125))]d(t)²[413/250+(21/40)t]³.

The standalone checker constructs this polynomial with Fraction arithmetic. It converts the power coefficients c₀,…,c₇ to Bernstein coefficients

bᵢ=Σ_{k=0}^i c_k·binom(i,k)/binom(7,k).

It verifies all eight exact rational inequalities bᵢ>1/200. Since the Bernstein basis functions binom(7,i)t^i(1−t)^(7−i) are nonnegative and sum to one, this proves F(t)>1/200 and therefore E(t)<1/25 throughout[0,1]. The complete rational coefficient list is written to `retained_quartic_exact_report.json`.

Consequently the product violation is less than F∞+1/5000.

Finally, exact arithmetic certifies

3·(314159/100000)·α·Σ_{j=0}^{10}(9021/10000)^j/j!>1,

and the Machin alternating-series bound gives π>314159/100000. Hence

log(3πα)>−9021/10000,

so

F∞+1/5000

<T−1/2+9021/20000+1/5000=0.

This completes the proof for all r,s≥200.

The same checker verifies exp(1+T)<28541/10000=2.8541 by a rational positive Taylor sum with a geometric remainder. Sections 4–6 complete the complementary product cases and the invariant induction, making this endpoint class-wide.


## 4. Both dimensions below 200: exact supporting planes

There are 19,900 pairs \(1\le r\le s\le199\). `mixed_finite_points.json` supplies one rational point \(p=(h_0,j_0)\) in each rectangle
\[
\mathcal B_{r,s}=[2,r+1]\times[2,s+1].
\]
For every such pair, `check_finite.py` recomputes \(G_2,G_4\) and the gradient of (9) exactly, encloses its one logarithm rationally, and proves
\[
f_{r,s}(p)+
\max_{(h,j)\in\mathcal B_{r,s}}
\nabla f_{r,s}(p)\cdot((h,j)-p)<0.
\tag{18}
\]
The maximum in (18) is the sum of two elementary endpoint choices: use the upper coordinate bound when the corresponding gradient is nonnegative, and the lower bound otherwise. Concavity gives \(f_{r,s}(h,j)\) at most (18) for every real state in the rectangle.

The certificate checks ordered coverage of every dimension pair, and checks that every point lies inside its rectangle. Its largest upper bound occurs at \((r,s)=(5,5)\), with
\[
p=\left(\frac{5993253354}{10^9},\frac{5993253354}{10^9}\right),
\]
and is strictly less than \(-1/1000000\). The exact rational value appears in `finite_report.json`. This proves every finite rectangle, not merely its proposed point.

## 5. One small factor and an arbitrarily large factor

Fix \(1\le r<200\) and let \(s\ge200\). Set
\[
z=1/s\in(0,1/200],\qquad h=H_A,\qquad
u=H_B/(s+1)\in[0,1].
\]
The enlarged rectangle \([2,r+1]\times[0,1]\) contains every actual state. Write
\[
P_2=(1+rz)^2(1+(r+1)z),
\quad S_2=3+(3r+2)z+r(r+1)z^2,
\]
\[
P_4=(1+rz)(1+(r+1)z)^3,
\quad S_4=4+(6r+9)z+(4r^2+9r+6)z^2+(r+1)^3z^3.
\]
Exact cancellation of the apparent singularity at \(z=0\) gives
\[
G_2=a h^2+bhu+c u^2,
\quad a=\frac1{r+1}-\frac{r^2z^3}{P_2},
\quad b=-\frac{2rz(1+z)}{P_2},
\quad c=\frac{r(1+z)S_2}{P_2},
\tag{19}
\]
\[
G_4=a_4h^4+d_4u^4,
\quad a_4=\frac1{(r+1)^3}-\frac{rz^4}{P_4},
\quad d_4=\frac{r(1+z)S_4}{P_4}.
\tag{20}
\]
These are regular throughout the closed interval \([0,1/200]\).

The factorial ratio has the useful upper bound
\[
C\le g(r)e^{-r}\sqrt{1+rz}.
\tag{21}
\]
To prove it, define \(v_m=m!e^m/(m^m\sqrt m)\). Then
\[
\log(v_{m+1}/v_m)=1-(m+1/2)\log(1+1/m)<0,
\]
using \(\log t>2(t-1)/(t+1)\) for \(t>1\), whose derivative proof is elementary. Exact substitution gives
\(C=g(r)e^{-r}(v_{r+s}/v_s)\sqrt{(r+s)/s}\), proving (21).

Consequently (9), after normalization, is bounded above by the strictly concave function
\[
F_{r,z}(h,u)=\log g(r)-r+
\log(h+r(1+z)u)-\tfrac12\log(1+rz)
-\alpha G_2-\beta G_4+T.
\tag{22}
\]
Its state gradient is the same as that of the actual normalized function (9). The added constant in (21) depends only on dimensions.

The tail certificate partitions \([0,1/200]\) into finitely many rational dyadic intervals, separately for each of the 199 values of \(r\). On each cell it supplies a rational point \(p=(h_0,u_0)\). Standard rational interval arithmetic encloses (19)–(22) and the two state derivatives on the entire cell. All divisions are checked to have denominators separated from zero.

For additional strength, let \(a_-\) and \(c_-\) be the lower interval endpoints for \(a,c\), and \(b_*^2\) the larger squared endpoint for \(b\). The checker verifies
\[
m_h=a_-/2>0,\qquad
m_u=c_- -b_*^2/(2a_-)>0.
\]
Young's inequality then gives, uniformly in the whole cell,
\[
a\eta_h^2+b\eta_h\eta_u+c\eta_u^2
\ge m_h\eta_h^2+m_u\eta_u^2.
\tag{23}
\]
The logarithm and quartic terms are concave with favorable Taylor remainders. Hence
\[
F_{r,z}(p+\eta)
\le F_{r,z}(p)+\nabla F_{r,z}(p)\cdot\eta
-\alpha(m_h\eta_h^2+m_u\eta_u^2).
\tag{24}
\]
Each separated scalar maximum on the coordinate displacement interval is exact: maximize \(g\eta-\alpha m\eta^2\) at its clipped vertex \(g/(2\alpha m)\). When the gradient is an interval, use its lower endpoint on negative displacements and its upper endpoint on positive displacements. This encloses every possible gradient, rather than using a point approximation to it.

`check_mixed_tail.py` recomputes these upper bounds on all 82,995 cells, of dyadic depth at most ten, and verifies that every bound is less than \(-1/10^{10}\). It also verifies exact coverage, with no gap or overlap, of \([0,1/200]\) for every \(r\). Thus the certificate covers all real \(z\) in that interval and therefore every integer \(s\ge200\). The endpoint \(z=0\) is used only as a regular limiting parameter; it does not assert existence of an infinite-dimensional body.

## 6. Exact logarithms, completion, and the rate

For a positive rational argument, power-of-two reduction writes \(x=2^k y\), \(1\le y\le2\). With \(w=(y-1)/(y+1)\in[0,1/3]\),
\[
\log y=2\sum_{m=0}^{N-1}\frac{w^{2m+1}}{2m+1}+E_N,
\quad 0\le E_N\le
\frac{2w^{2N+1}}{(2N+1)(1-w^2)}.
\tag{25}
\]
The same expansion encloses \(\log2\). Both checkers preserve the correct endpoints when multiplying by a negative integer \(k\). Their optional rational outward rounding enlarges intervals and therefore preserves correctness. Every check remains active under `python -O`.

Sections 3–5 exhaust all positive integer dimension splits. They prove (8), so products preserve (1). Joins preserve (1) by (7), and the point satisfies it. Structural induction over finite expressions and affine invariance complete the theorem.

Dividing (1) by \(D\) gives
\[
\log\lambda(K)\le
T-\alpha(H/D)^2-\beta(H/D)^4<T.
\]
Taking the all-dimensional supremum and applying the inherited spectral identity gives \(\Gamma_{\mathcal C}\le e^{1+T}\). With \(x=839/800\), the positive exponential series gives
\[
e^x<\sum_{m=0}^{12}\frac{x^m}{m!}+
\frac{x^{13}/13!}{1-x/14}<\frac{28541}{10000}=2.8541.
\]
Every subsequent ratio after the first omitted term is at most \(x/14<1\), proving the tail bound. The last rational comparison is replayed by the large-dimension checker. The v2 exact checker was also rerun successfully, preserving the strict lower endpoint \(2.8534\).

## Scope and comparison

The current public quadratic Bellman theorem gives the ceiling \(e^{1+\alpha_*}\), where \(\alpha_*=(11/85)\log(189/128)\), and reports \(\Gamma_{\mathcal C}<2.8589\). The strict improvement here compares the actual constants, not just their rounded decimals:
\[
\alpha_*>\frac{11}{85}\frac{2(189-128)}{189+128}
=\frac{1342}{26945}>\frac{39}{800}=T.
\]
The logarithm bound is the one proved in Section 5, and the final rational gap is \(4549/4311200>0\). Therefore \(e^{1+T}<e^{1+\alpha_*}\). The numerical mixed-potential direction was already recorded in that public supplement. This report claims exact certification of the displayed parameters, not discovery of the Bellman method or of the numerical direction.

The optimum and the known lower orbit remain distinct: no proof here identifies their values, and no finite spectral improvement is advertised as an improvement of the actual limiting rate. The theorem is confined to \(\mathcal C\). For unrestricted convex bodies, the classical Zhang–Blaschke–Santaló bound recorded in Saroglou's 2015 primary text gives asymptotic upper root \(\pi e/2\), sharper than the older Lutwak–Yang–Zhang root \(e^{3/2}\). The focused primary comparison and its limitations, including unavailable Saroglou 2011 full text, are in `literature.md`. No priority or unrestricted optimality claim is made.

All work is in a separate temporary math directory. The saved old project was neither inspected nor resumed. No publication or push was performed.


## Pointwise comparison with the prior audited mixed envelope

For t=H/D in [0,1], direct subtraction gives
\[
\Phi_{\rm old}-\Phi_{\rm sharp}=\frac D{20000}(1-t^2)(5-4t^2)\ge0.
\]
The prior coefficients were alpha=87/2000, beta=11/2000, T=49/1000. Thus the new envelope is pointwise stronger, with strict improvement whenever H<D. Its nominal spectral exponent improves by exactly 1/4000. The companion obstruction proof explains why local positive quadratic/quartic supersolutions cannot reach a nominal growth ceiling as small as 2.8535; it does not give a lower bound on the actual class optimum.
