#!/usr/bin/env python3
"""Verify the delivered files and replay every exact upper-bound component."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def integrity(root):
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    seen = set()
    for row in manifest['files']:
        name = row['path']
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in seen,
                'Invalid or duplicate manifest path: ' + name)
        seen.add(name)
        local = root / name
        require(local.is_file() and local.stat().st_size == row['bytes'],
                'Missing file or byte-count mismatch: ' + name)
        require(hashlib.sha256(local.read_bytes()).hexdigest() == row['sha256'],
                'File hash mismatch: ' + name)
    origin = json.loads((root / 'MATH_ORIGIN.json').read_text())
    require(origin['parameters'] == {'alpha': '861/20000', 'beta': '57/10000', 'T': '39/800'},
            'Unexpected theorem parameters.')
    for name, digest in origin['certificate_sha256'].items():
        require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
                'Certificate origin mismatch: ' + name)
    print('PASS: complete delivery manifest and exact certificate origins.', flush=True)
    return len(seen)


def run(root, directory, mode, checker, arguments):
    environment = dict(os.environ)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    python = [sys.executable] + (['-O'] if mode == 'optimized' else [])
    result = subprocess.run(python + [str(root / checker)] + arguments, cwd=directory,
                            env=environment, text=True, capture_output=True)
    require(result.returncode == 0, checker + ' failed:\n' + result.stdout + result.stderr)
    return json.loads(result.stdout)


def replay(root):
    reports = {}
    with tempfile.TemporaryDirectory(prefix='sharper-math005-replay-') as directory:
        for mode in ('ordinary', 'optimized'):
            reports[mode] = {}
            commands = [
                ('finite', 'check_finite.py', [str(root / 'mixed_finite_points.json'), '--quiet'], 'finite_report.json'),
                ('tail', 'check_mixed_tail.py', [], 'mixed_tail_report.json'),
                ('large', 'check_retained_quartic_large.py', [], 'retained_quartic_exact_report.json'),
                ('independent_large', 'check_large_independent.py', [], 'large_independent_report.json'),
            ]
            for label, checker, arguments, reference in commands:
                data = run(root, directory, mode, checker, arguments)
                require(data == json.loads((root / reference).read_text()),
                        'Exact replay differs from delivered report: ' + reference)
                reports[mode][label] = data
                print('PASS: ' + label + ' exact replay (' + mode + ').', flush=True)
    require(reports['ordinary'] == reports['optimized'], 'Python modes produced different exact reports.')
    print('PASS: all ordinary and optimized exact reports agree.', flush=True)
    return {'finite_rectangles': reports['ordinary']['finite']['rectangles'],
            'finite_uniform_margin': reports['ordinary']['finite']['uniform_upper_margin'],
            'tail_cells': reports['ordinary']['tail']['cells'],
            'tail_maximum_depth': reports['ordinary']['tail']['maximum_depth'],
            'tail_uniform_margin': reports['ordinary']['tail']['uniform_certified_upper_margin'],
            'large_factor_minimum_dimension': 200,
            'independent_large_polynomial_reconstruction': 'PASS',
            'ordinary_optimized_reports_agree': True,
            'supplied_reports_match': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--integrity-only', action='store_true')
    parser.add_argument('--report', type=Path, help='Optional summary output outside delivered inputs.')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    files = integrity(root)
    mathematics = {} if args.integrity_only else replay(root)
    report = {'status': 'PASS', 'manifest_files': files,
              'mathematics_replayed': not args.integrity_only, 'replay': mathematics,
              'scope': 'Point-generated products and joins; invertible affine maps on affine hulls.',
              'upper_conclusion': 'Gamma_C <= exp(839/800) < 2.8541' if mathematics else None,
              'inherited_lower_replayed_here': False, 'network_or_checkout_required': False}
    if args.report:
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
