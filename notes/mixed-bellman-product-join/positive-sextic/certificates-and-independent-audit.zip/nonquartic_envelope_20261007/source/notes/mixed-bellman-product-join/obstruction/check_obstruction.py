#!/usr/bin/env python3
"""Exact rational evidence for the quadratic/quartic local-closure obstruction.

Standard library only. All proof decisions use integer/Fraction arithmetic.
Numerical optimization, decimal transcendental functions, and floating point
are unnecessary. Run normally or with python -O.
"""
from fractions import Fraction as F
from math import factorial
from dataclasses import dataclass
import json


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


@dataclass(frozen=True)
class Interval:
    lower: F
    upper: F

    def __post_init__(self):
        check(self.lower <= self.upper, "inverted interval")

    @staticmethod
    def point(x):
        return Interval(F(x), F(x))

    def __add__(self, other):
        if not isinstance(other, Interval):
            other = Interval.point(other)
        return Interval(self.lower+other.lower, self.upper+other.upper)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.upper, -self.lower)

    def __sub__(self, other):
        return self+-other if isinstance(other, Interval) else self+Interval.point(-other)

    def __rsub__(self, other):
        return Interval.point(other)+-self

    def __mul__(self, other):
        if not isinstance(other, Interval):
            other = Interval.point(other)
        endpoints = [self.lower*other.lower, self.lower*other.upper,
                     self.upper*other.lower, self.upper*other.upper]
        return Interval(min(endpoints), max(endpoints))

    __rmul__ = __mul__

    def reciprocal(self):
        check(self.lower > 0, "reciprocal interval must be positive")
        return Interval(1/self.upper, 1/self.lower)

    def __truediv__(self, other):
        if not isinstance(other, Interval):
            other = Interval.point(other)
        return self*other.reciprocal()

    def __rtruediv__(self, other):
        return Interval.point(other)*self.reciprocal()


def exp_bounds(x, terms=50):
    """Taylor series with a geometric majorant of the positive tail."""
    x = F(x)
    if x < 0:
        return exp_bounds(-x, terms).reciprocal()
    check(x <= 2, "exponential argument outside certified range")
    partial = sum((x**k/F(factorial(k)) for k in range(terms+1)), F(0))
    first_omitted = x**(terms+1)/factorial(terms+1)
    tail = first_omitted/(1-x/F(terms+2))
    return Interval(partial, partial+tail)


def log_bounds(x, terms=35):
    """Atanh series, used only for 1<=x<=2."""
    x = F(x)
    check(1 <= x <= 2, "logarithm argument outside certified range")
    z = (x-1)/(x+1)
    partial = 2*sum((z**(2*k+1)/F(2*k+1) for k in range(terms)), F(0))
    tail = 2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
    return Interval(partial, partial+tail)


def atan_bounds(x, terms=30):
    x = F(x)
    check(0 < x < 1, "arctangent argument outside alternating-series range")
    partial = sum(((-1)**k*x**(2*k+1)/F(2*k+1) for k in range(terms)), F(0))
    next_term = (-1)**terms*x**(2*terms+1)/F(2*terms+1)
    return Interval(min(partial, partial+next_term), max(partial, partial+next_term))


PI = 16*atan_bounds(F(1, 5))-4*atan_bounds(F(1, 239))
LOG_M = log_bounds(F(189, 128))
A = F(85, 11)
B = F(13345, 1331)
C = B-A


def a_of_t(t):
    return exp_bounds(2*t-1)/(3*PI)


def constraint_function(t):
    return B*t-C*a_of_t(t)-LOG_M


def main():
    # Verify the exact simplex-product coefficients independently.
    g5 = F(5**5, factorial(5))
    g10 = F(10**10, factorial(10))
    check(g5*g5/g10*6 == F(189, 128), "T5 product gain")
    check(2*F(6**2, 6)-F(6**2, 11)-1 == A, "quadratic T5 increment")
    check(2*F(6**4, 6**3)-F(6**4, 11**3)-1 == B, "quartic T5 increment")
    check(C == F(3060, 1331), "coefficient difference")

    # The written proof shows F'>B-2C/9>0 on 0<=t<=1/10.
    check(PI.lower > 3, "elementary pi endpoint")
    check(B-2*C/9 > 0, "monotonicity endpoint")
    check(constraint_function(F(0)).upper < 0, "left root endpoint")
    check(constraint_function(F(1, 10)).lower > 0, "right root endpoint")

    conservative = F(3046, 62500)  # .048736
    check(constraint_function(conservative).upper < 0, "strict obstruction threshold")
    advertised_growth = F(71351, 25000)  # 2.85404
    check(exp_bounds(1+conservative).lower > advertised_growth, "growth obstruction endpoint")
    check(advertised_growth > F(5707, 2000), "strict separation from 2.8535")

    root_lower = F(487360945, 10**10)
    root_upper = F(487360947, 10**10)
    check(constraint_function(root_lower).upper < 0, "narrow lower root endpoint")
    check(constraint_function(root_upper).lower > 0, "narrow upper root endpoint")
    growth_lower = F(28540415986, 10**10)
    growth_upper = F(28540415992, 10**10)
    check(exp_bounds(1+root_lower).lower > growth_lower, "narrow lower growth endpoint")
    check(exp_bounds(1+root_upper).upper < growth_upper, "narrow upper growth endpoint")

    # At the first root, alpha=a(t), beta=t-a(t) are both strictly positive.
    alpha_lower = a_of_t(root_lower).lower
    alpha_upper = a_of_t(root_upper).upper
    beta_lower = root_lower-alpha_upper
    beta_upper = root_upper-alpha_lower
    check(alpha_lower > 0 and beta_lower > 0, "two-test optimum has nonnegative coefficients")
    check(alpha_upper-alpha_lower < F(1, 10**9), "alpha interval width")
    check(beta_upper-beta_lower < F(1, 10**9), "beta interval width")

    # The two-test optimum is not a full continuous-box supersolution.
    # This extra test state is not claimed to be realized by a class body.
    h = F(599, 100)
    ah = F(8, 33)*h*h-1
    bh = F(1223, 143748)*h**4-1
    violation = (log_bounds(F(63, 256)*h)
                 -Interval(beta_lower, beta_upper)*bh
                 -Interval(alpha_lower, alpha_upper)*ah)
    check(violation.lower > F(1, 10**6), "two-test coefficient pair violates an interior box state")

    # A nearby rational state gives a slightly stronger obstruction if closure
    # is required on the complete continuous rectangle. Its realizability as
    # a recursive body is not assumed or claimed.
    h_sharp = F(29967, 5000)
    a_sharp = F(8, 33)*h_sharp*h_sharp-1
    b_sharp = F(1223, 143748)*h_sharp**4-1
    c_sharp = b_sharp-a_sharp
    check(c_sharp > 0 and b_sharp-2*c_sharp/9 > 0, "sharpened constraint monotonicity")
    t_sharp = F(609203, 12500000)
    f_sharp = b_sharp*t_sharp-c_sharp*a_of_t(t_sharp)-log_bounds(F(63, 256)*h_sharp)
    check(f_sharp.upper < 0, "sharper continuous-state obstruction threshold")
    sharp_growth = F(1427021, 500000)
    check(exp_bounds(1+t_sharp).lower > sharp_growth, "sharper growth endpoint")

    print(json.dumps({
        "status": "PASS",
        "scope": "necessary obstruction for local product closure of the positive 2/4 ansatz",
        "strict_lower_bound_for_T": str(conservative),
        "strict_lower_bound_for_growth": str(advertised_growth),
        "first_root_interval": [str(root_lower), str(root_upper)],
        "first_root_growth_interval": [str(growth_lower), str(growth_upper)],
        "coefficient_alpha_interval_width_below": "1/1000000000",
        "coefficient_beta_interval_width_below": "1/1000000000",
        "two_test_optimum_continuous_box_violation": {
            "r": 5, "s": 5, "H_and_J": "599/100",
            "strict_positive_residual_lower_bound": "1/1000000",
            "state_class_realizability_claim": False,
        },
        "stronger_continuous_rectangle_obstruction": {
            "H_and_J": str(h_sharp),
            "strict_lower_bound_for_T": str(t_sharp),
            "strict_lower_bound_for_growth": str(sharp_growth),
            "state_class_realizability_claim": False,
        },
        "actual_class_optimality_claim": False,
        "global_invariant_without_local_closure_obstruction_claim": False,
    }, indent=2))


if __name__ == "__main__":
    main()
