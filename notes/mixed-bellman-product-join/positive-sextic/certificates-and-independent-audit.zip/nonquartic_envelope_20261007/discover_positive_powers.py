import numpy as np, math, json
from scipy.optimize import minimize, linprog
from scipy.special import gammaln
P=np.array([2,4,6,8,10],dtype=float)
DIM=list(range(1,41))+[50,75,100,150,200,300,500,1000,5000,10000,100000]
PAIRS=[(r,s) for i,r in enumerate(DIM) for s in DIM[i:]]
def data(r,s,h,j):
 n=r+s;x=(s*h+r*j)/n
 Clog=r*math.log(r)+s*math.log(s)-n*math.log(n)-gammaln(r+1)-gammaln(s+1)+gammaln(n+1)
 G=np.zeros(len(P));G[0]=h*h/(r+1)+j*j/(s+1)-(r*h+s*j)**2/(n*n*(n+1))
 for k,p in enumerate(P[1:],1):
  G[k]=(h/(r+1))**p*(r+1)+(j/(s+1))**p*(s+1)-r/n*(h/(n+1))**p*(n+1)-s/n*(j/(n+1))**p*(n+1)
 return G-1,Clog+math.log(x)
def maxi(r,s,a):
 n=r+s;A=r+1;B=s+1
 Clog=r*math.log(r)+s*math.log(s)-n*math.log(n)-gammaln(r+1)-gammaln(s+1)+gammaln(n+1)
 def fun(v):
  h,j=v*np.array([A,B]); x=(s*h+r*j)/n
  G=np.zeros(len(P)); gh=np.zeros(len(P));gj=np.zeros(len(P))
  ar=(r*h+s*j)/n
  G[0]=h*h/A+j*j/B-ar*ar/(n+1)
  gh[0]=2*h/A-2*r*ar/(n*(n+1));gj[0]=2*j/B-2*s*ar/(n*(n+1))
  for k,p in enumerate(P[1:],1):
   ca=A**(1-p)-r/n*(n+1)**(1-p);cb=B**(1-p)-s/n*(n+1)**(1-p)
   G[k]=ca*h**p+cb*j**p;gh[k]=p*ca*h**(p-1);gj[k]=p*cb*j**(p-1)
  f=Clog+math.log(x)-a@(G-1)
  grad=np.array([s/(n*x)-a@gh,r/(n*x)-a@gj])*np.array([A,B])
  return -f,-grad
 init=np.minimum(1,np.array([math.sqrt(r/(3*a[0]))/A,math.sqrt(s/(3*a[0]))/B]))
 init=np.maximum(init,[2/A,2/B])
 sol=minimize(fun,init,jac=True,bounds=[(2/A,1),(2/B,1)],method='L-BFGS-B', options={'ftol':1e-13,'gtol':1e-10,'maxiter':200})
 h,j=sol.x*np.array([A,B]);return -sol.fun,h,j
constraints=[]
for r,s in PAIRS:
 for h,j in [(r+1,s+1),(2,2)]:
  g,L=data(r,s,h,j);constraints.append((g,L,r,s,h,j))
amin=float(__import__('sys').argv[1]) if len(__import__('sys').argv)>1 else .04305
for turn in range(12):
 M=np.array([q[0] for q in constraints]);b=np.array([q[1] for q in constraints])
 lp=linprog(np.ones(len(P)),A_ub=-M,b_ub=-b,bounds=[(amin,None)]+[(0,None)]*(len(P)-1),method='highs')
 if not lp.success: raise RuntimeError(lp.message)
 a=lp.x;T=sum(a)
 worst=[]
 for r,s in PAIRS:
  f,h,j=maxi(r,s,a)
  if f>1e-10:
   g,L=data(r,s,h,j);constraints.append((g,L,r,s,h,j))
  worst.append((f,r,s,h,j))
 worst.sort(reverse=True)
 print(turn,a.tolist(),T,math.exp(1+T),'violators',sum(q[0]>1e-10 for q in worst),'top',worst[:6],flush=True)
 if worst[0][0]<2e-8:break
json.dump({'powers':P.tolist(),'coefficients':a.tolist(),'T':T,'worst':worst[:30],'constraints':len(constraints),'alpha_min':amin,'numerical_only':True},open(f'discovery_{amin}.json','w'),indent=2)
