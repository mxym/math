# Positive sextic Bellman continuation (unpublished)

Certified theorem (see STATUS.md for independent audit status):

log Q <= (431/10000)(D-H^2/D)
       + (9/2500)(D-H^4/D^3)
       + (197/100000)(D-H^6/D^5).

Its nominal ceiling is exp(1+4867/100000)<2.85386. This is a richer homogeneous potential than the preceding quadratic/quartic family. It gives no new lower construction and does not identify the true optimum.

Read STATUS.md before citing the theorem. PROOF.md gives the full mathematical reduction. SOURCE_PROVENANCE.md records every inherited component.

Proof replay (Python standard library only; verify.py runs the four components in sequence and records checksums):

python verify.py
python -O verify.py --output complete_replay_report_optimized.json

Or run components separately:

python check_sextic_finite.py sextic_finite_points.json --report sextic_finite_report.json
python check_sextic_tail.py
python check_sextic_large.py --output sextic_large_report.json
python check_negative_controls.py

Run each again with python -O; the proof checks are not Python assertions and stay active. All components pass ordinary and optimized exact replay with identical submitted reports. A separate independent implementation also passes every finite rectangle and tail cell in both modes, all-large constants and structural identities; no mathematical correction is required. See the sibling audit directory for its complete scope and evidence.

SciPy/NumPy are needed only to regenerate discovery points using discover_positive_powers.py, generate_finite.py and generate_tail.py. Such output is not evidence until the corresponding exact replay accepts it. The supplied source/ archive extraction is preserved unchanged. Nothing was published or pushed.
