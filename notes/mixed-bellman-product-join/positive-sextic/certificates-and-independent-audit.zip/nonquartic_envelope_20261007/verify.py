#!/usr/bin/env python3
"""Run the complete exact certificate; no discovery or SciPy dependency."""
import argparse,subprocess,sys,json,hashlib,time
from pathlib import Path

def require(ok,msg):
 if not ok:raise ArithmeticError(msg)

def run(args,out):
 r=subprocess.run([sys.executable,*(["-O"] if sys.flags.optimize else []),*args],text=True,capture_output=True)
 Path(out).write_text(r.stdout)
 if r.returncode:
  raise RuntimeError(f'failed {args}: {r.stderr}')
 return json.loads(r.stdout[r.stdout.index('{'):]) if args[0]!='check_sextic_finite.py' else None

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default='complete_replay_report.json');args=p.parse_args()
    start=time.monotonic()
    run(['check_sextic_finite.py','sextic_finite_points.json','--report','sextic_finite_report.json','--quiet'],'sextic_finite_replay.log')
    run(['check_sextic_tail.py'],'sextic_tail_replay.json')
    run(['check_sextic_large.py','--output','sextic_large_report.json'],'sextic_large_replay.log')
    run(['check_negative_controls.py'],'negative_controls.json')
    required=['check_sextic_finite.py','check_sextic_tail.py','sextic_tail_core.py','check_sextic_large.py','check_negative_controls.py','sextic_finite_points.json','sextic_tail_certificate.json','PROOF.md','SOURCE_PROVENANCE.md']
    files={x:hashlib.sha256(Path(x).read_bytes()).hexdigest() for x in required}
    report={'status':'PASS','claim':'positive sextic local closure in every dimension; full induction and spectral reduction in PROOF.md','alpha':'431/10000','beta':'9/2500','gamma':'197/100000','T':'4867/100000','nominal_rate_upper':'exp(104867/100000)<142693/50000','finite_rectangles':19900,'tail_cells':len(json.loads(Path('sextic_tail_certificate.json').read_text())['cells']),'all_large_minimum_dimension':200,'elapsed_seconds':round(time.monotonic()-start,2),'sha256':files}
    Path(args.output).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
