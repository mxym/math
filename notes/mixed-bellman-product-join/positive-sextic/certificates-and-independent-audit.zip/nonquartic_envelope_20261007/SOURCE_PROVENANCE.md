# Source provenance

The full supplied sharpening archive was extracted without modification into source/:

../mixed_sharpened_received/005-mixed-bellman-sharpening-proof-and-certificates.zip

Relevant inherited sources read:
- source/notes/mixed-bellman-product-join/sharpened/proof.md (corresponding paper.tex retained): complete supplied proof, exact state calculus, class restriction, join closure and spectral reduction citations.
- source/notes/mixed-bellman-product-join/obstruction/OBSTRUCTION.md (corresponding obstruction.tex retained): six-page local quadratic/quartic-family barrier. Its floor is a method restriction, not an actual extremal lower bound.
- source/notes/mixed-bellman-product-join/sharpened/retained_quartic_large.md and check_retained_quartic_large.py: the all-large normalization, rational quartic bound and exact Bernstein certificate. The new check_sextic_large.py is adapted to alpha=431/10000,beta=9/2500,T=4867/100000, retains the prior quartic reduction, and drops the favorable positive sextic term.
- source/notes/mixed-bellman-product-join/sharpened/check_finite.py: strict-concavity tangent/log certificate pattern; check_sextic_finite.py adds the exact sextic moment and derivatives, with newly generated rational points.
- source/notes/mixed-bellman-product-join/sharpened/mixed_tail_core.py and check_mixed_tail.py: interval-tail framework. sextic_tail_core.py adds exact polynomially canceled sixth-power coefficients and their state gradients; check_sextic_tail.py uses a new complete certificate.
- ../mixed_bellman_received/source/research_log.md: earlier numerical mixed direction and lower-orbit exploratory history. No earlier search is represented as new.
- ../mixed_sharpened_adversarial_audit_20261007/pinned_v2/BELLMAN_UPPER_BOUND.md: quadratic ancestor and exact normalization.

The archive acknowledges the public entry005 repository read at commits 8ad38152eac75993659c1f128a382bbc1a19ceab through 3360e7191cf564a46d09edcbfbd107c9178bd98f. This continuation used the supplied on-disk source package; it makes no claim about the current remote repository head.

New work in this directory:
- positive even-power discovery LP through degree ten, resulting in a quadratic/quartic/sextic candidate
- rational coefficients alpha=431/10000,beta=9/2500,gamma=197/100000
- new finite tangent certificate
- sixth-power regular tail algebra and new tail certificate
- exact revised all-large rational constants and endpoint
- complete written reduction in PROOF.md

No source/release file was edited, no external account was used, and no publication was performed.
