#!/usr/bin/env python3
"""Independent exact verification; neither SciPy nor floating point is used."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
from sextic_tail_core import (ALPHA, BETA, GAMMA, TOTAL, CUTOFF, POINT_DENOMINATOR, require,
                             cell_endpoints, tail_bound)


def main():
    require(TOTAL == F(4867, 100000) and ALPHA > 0 and BETA > 0 and GAMMA > 0, "sharper constants differ")
    path = Path(__file__).resolve().parent / "sextic_tail_certificate.json"
    certificate = json.loads(path.read_text())
    require(certificate["schema"] == 1, "unsupported tail certificate schema")
    require(certificate["alpha"] == str(ALPHA) and certificate["beta"] == str(BETA) and certificate["gamma"] == str(GAMMA), "potential constants differ")
    require(certificate["cutoff"] == CUTOFF and certificate["point_denominator"] == POINT_DENOMINATOR, "certificate scales differ")
    ranges = {r: [] for r in range(1, CUTOFF)}
    worst = None
    for row in certificate["cells"]:
        require(isinstance(row, list) and len(row) == 5 and all(type(x) is int for x in row),
                "tail certificate coordinates must be integers")
        r, index, depth, hn, jn = row
        require(r in ranges and isinstance(index, int) and isinstance(depth, int), "invalid tail cell")
        require(0 <= depth <= 24 and 0 <= index < 2**depth, "invalid dyadic coordinates")
        left, right = cell_endpoints(index, depth)
        bound = tail_bound(r, left, right, F(hn, POINT_DENOMINATOR), F(jn, POINT_DENOMINATOR))
        require(bound is not None and bound < 0, f"failed tail supporting certificate: {row}")
        ranges[r].append((left, right))
        if worst is None or bound > worst[0]:
            worst = (bound, row)
    for r, cells in ranges.items():
        cursor = F(0)
        for left, right in sorted(cells):
            require(left == cursor, f"gap or overlap in r={r} tail coverage")
            cursor = right
        require(cursor == F(1, CUTOFF), f"incomplete r={r} tail coverage")
    require(worst[0] < F(-1, 10000000000), "tail margin below claimed universal endpoint")
    print(json.dumps({"status": "PASS", "all_integer_dimensions": "1<=r<200, s>=200",
                      "alpha": str(ALPHA), "beta": str(BETA), "gamma":str(GAMMA), "T": str(TOTAL),
                      "cells": len(certificate["cells"]), "maximum_depth": max(row[2] for row in certificate["cells"]),
                      "uniform_certified_upper_margin": "-1/10000000000",
                      "worst_cell": worst[1], "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
