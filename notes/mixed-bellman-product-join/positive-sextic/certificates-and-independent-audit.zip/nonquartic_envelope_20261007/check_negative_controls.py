"""Exact witnesses that the added sextic term matters to this certificate."""
from fractions import Fraction as F
import json
import check_sextic_finite as c

def require(ok,msg):
 if not ok:raise ArithmeticError(msg)

r=s=5;n=10;h=j=F(6)
logs={i:c.log_bounds(F(i)) for i in range(1,11)}
facts={0:(F(0),F(0))}
for i in range(1,11):facts[i]=c.add_intervals(facts[i-1],logs[i])
logc=(F(0),F(0))
for coefficient,interval in [(r,logs[r]),(s,logs[s]),(-n,logs[n]),(1,facts[n]),(-1,facts[r]),(-1,facts[s])]:
 logc=c.add_intervals(logc,c.scale_interval(coefficient,interval))
# Direct witness values, with the sextic coefficient removed but same alpha,beta.
x=h
G2=2*h*h/F(6)-h*h/F(11)
G4=2*h**4/F(6**3)-h**4/F(11**3)
logL=c.add_intervals(logc,c.log_bounds(x))
no6lo=logL[0]-c.ALPHA*(G2-1)-c.BETA*(G4-1)
require(no6lo>F(1,100),'quadratic/quartic removal should fail the simplex-product state')
# Incorrect omission of positive sixth-power penalty while keeping T also fails.
keepTlo=logL[0]-c.ALPHA*G2-c.BETA*G4+c.TARGET
require(keepTlo>F(1,100),'discarding sextic penalty in finite region should fail')
report={'status':'PASS','witness':'r=s=5,h=j=6 (actual simplices)',
 'remove_sextic_violation_lower':str(no6lo),'keep_T_drop_sextic_penalty_violation_lower':str(keepTlo),
 'meaning':'The added sixth-power term is substantive; these are method witness failures, not new extremal lower bounds.'}
print(json.dumps(report,indent=2))
