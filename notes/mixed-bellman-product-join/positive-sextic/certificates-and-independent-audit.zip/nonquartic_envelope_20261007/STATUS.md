# Complete status, 7 October 2026

PASS: the positive sextic global invariant and the all-class upper ceiling
Gamma_C<=exp(104867/100000)<2.85386 are certified.

- Finite rectangles: all 19,900 pairs below 200, rational tangent/log upper bounds with uniform margin -1/10^6.
- Imbalanced tails: all 157,872 cells, exact complete coverage for every r=1,...,199, maximum dyadic depth 11, uniform upper margin -1/10^10.
- Both-large dimensions: all r,s>=200 and every positive state, analytic moment reduction plus exact Bernstein positivity; upper product violation<-13/100000.
- Submitted ordinary and optimized component reports are byte-identical.
- Independent ordinary/optimized finite and tail reimplementation, separate all-large constants, 14 symbolic identities, and source/spectral checks all PASS; no mathematical correction required.
- Independent tests reject 28 corrupted fixtures and pass 106,892 supplementary exact checks.
- The inherited strict lower construction remains 2.8534; no new lower bound or optimality claim is made.
- All 63 supplied source files remain byte-identical. No release edits or publication.

The improvement is outside the previous positive quadratic/quartic local family: its method floor is not a lower bound on the actual optimum. This is model-conducted mathematical audit and exact arithmetic verification, not human peer review or proof-assistant formalization.

Main manuscript: PROOF.md.
Source provenance: SOURCE_PROVENANCE.md and SOURCE_INTEGRITY.json.
Independent audit: sibling sextic_bellman_independent_audit_20261007/AUDIT.md and SIGNOFF.json.
