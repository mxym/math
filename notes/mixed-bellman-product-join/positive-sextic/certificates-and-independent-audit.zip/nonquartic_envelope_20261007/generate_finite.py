exec(open('discover_positive_powers.py').read().split('constraints=[]')[0])
from fractions import Fraction
from pathlib import Path
A=np.array([.0431,.0036,.00197,0.,0.]);den=10**10;N=200
rows=[];worst=[]
for r in range(1,N):
 for s in range(r,N):
  v,h,j=maxi(r,s,A)
  rows.append([r,s,int(round(h*den)),int(round(j*den))]);worst.append((v,r,s,h,j))
 if r%20==0:print(r,len(rows),'worst',max(worst),flush=True)
cert={'schema':1,'coefficients':[[431,10000],[9,2500],[197,100000]],'T':[4867,100000],'dimension_max':N-1,'denominator':den,'points':rows}
Path('sextic_finite_points.json').write_text(json.dumps(cert,separators=(',',':'))+'\n')
worst.sort(reverse=True);Path('sextic_finite_discovery.json').write_text(json.dumps({'numerical_only':True,'worst':worst[:30]},indent=2)+'\n')
print(worst[:10],flush=True)
