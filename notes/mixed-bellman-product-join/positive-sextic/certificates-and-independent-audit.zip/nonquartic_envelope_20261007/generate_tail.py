"""Candidate point discovery; acceptance is independently exact rational."""
import numpy as np, json, math, time
from pathlib import Path
from scipy.optimize import minimize
from sextic_tail_core import *

def float_coeff(r,z):
 a,b,c,a4,d4,a6,d6=coefficients(r,z)
 return np.array([float(v) for v in [a,b,c,a4,d4,a6,d6]])

def point(r,z,initial=None):
 a,b,c,a4,d4,a6,d6=float_coeff(r,z)
 al,be,ga=float(ALPHA),float(BETA),float(GAMMA)
 def fun(v):
  h,j=v;first=h+r*(1+z)*j
  f=math.log(first)-al*(a*h*h+b*h*j+c*j*j)-be*(a4*h**4+d4*j**4)-ga*(a6*h**6+d6*j**6)
  gh=1/first-al*(2*a*h+b*j)-be*4*a4*h**3-ga*6*a6*h**5
  gj=r*(1+z)/first-al*(b*h+2*c*j)-be*4*d4*j**3-ga*6*d6*j**5
  return -f,np.array([-gh,-gj])
 if initial is None:initial=[min(r+1,max(2,math.sqrt(r/(3*al)))),min(1,math.sqrt(1/(3*al*r)))]
 sol=minimize(fun,initial,jac=True,bounds=[(2,r+1),(0,1)],method='L-BFGS-B',options={'ftol':1e-14,'gtol':1e-11,'maxiter':100})
 den=POINT_DENOMINATOR
 hn=max(2*den,min((r+1)*den,int(round(sol.x[0]*den))));jn=max(0,min(den,int(round(sol.x[1]*den))))
 return hn,jn

cells=[];start=time.monotonic();worst=None
for r in range(1,CUTOFF):
 todo=[(0,0)]
 while todo:
  index,depth=todo.pop();left,right=cell_endpoints(index,depth)
  hn,jn=point(r,float((left+right)/2))
  bound=tail_bound(r,left,right,F(hn,POINT_DENOMINATOR),F(jn,POINT_DENOMINATOR))
  if bound is not None and bound<F(-1,10**9):
   row=[r,index,depth,hn,jn];cells.append(row)
   if worst is None or bound>worst[0]:worst=(bound,row)
  else:
   require(depth<24,f'failed at r={r}, depth={depth}, bound={bound}')
   todo.extend([(2*index+1,depth+1),(2*index,depth+1)])
 if r%5==0:
  print(json.dumps({'completed_r':r,'cells':len(cells),'seconds':round(time.monotonic()-start,2),'worst':str(worst[0]),'maxdepth':max(x[2] for x in cells)}),flush=True)
  Path('sextic_tail_partial.json').write_text(json.dumps({'schema':1,'alpha':str(ALPHA),'beta':str(BETA),'gamma':str(GAMMA),'cutoff':CUTOFF,'point_denominator':POINT_DENOMINATOR,'cells':cells},separators=(',',':'))+'\n')
Path('sextic_tail_certificate.json').write_text(json.dumps({'schema':1,'alpha':str(ALPHA),'beta':str(BETA),'gamma':str(GAMMA),'cutoff':CUTOFF,'point_denominator':POINT_DENOMINATOR,'cells':cells},separators=(',',':'))+'\n')
print('COMPLETE',len(cells),worst,flush=True)
