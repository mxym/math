#!/usr/bin/env python3
"""Exact arithmetic component; analytic reductions are in PROOF.md, Section 4."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json,argparse

def require(ok,msg):
 if not ok:raise ArithmeticError(msg)

def add(a,b):
 c=[F(0)]*max(len(a),len(b))
 for i,x in enumerate(a):c[i]+=x
 for i,x in enumerate(b):c[i]+=x
 return c

def mul(a,b):
 c=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return c

def scale(a,c):return[x*c for x in a]
def power(a,n):
 out=[F(1)]
 for _ in range(n):out=mul(out,a)
 return out

a=F(431,10000);b=F(9,2500);gamma=F(197,100000);T=a+b+gamma
require(T==F(4867,100000),'parameter sum')
require(F(511,500)**3>F(16,15),'first cube-root rational bound')
require(F(63,100)**3>F(1,4),'second cube-root rational bound')
pi_lo=16*(F(1,5)-F(1,5)**3/3+F(1,5)**5/5-F(1,5)**7/7)-F(4,239)
require(pi_lo>F(314159,100000),'Machin pi bound')

X=[F(1),F(1)];d=[F(9,16),F(1003,1600),F(903,1600)];D=[F(413,250),F(21,40)]
p=scale(power(X,4),F(7,50))
p=add(p,scale(mul([F(0),F(1)],power(X,3)),-F(1,12)))
p=add(p,scale(power(X,5),F(200,2401)))
p=add(p,scale(mul(power(d,2),power(D,3)),-a*a/(4*b*F(123,125))))
require(len(p)==8,'degree-seven polynomial')
bern=[sum(p[k]*F(comb(i,k),comb(7,k)) for k in range(i+1)) for i in range(8)]
require(all(q>0 for q in bern),'strict Bernstein positivity')

x=F(901,1000);sm=F(1);term=F(1)
for j in range(1,11):term*=x/j;sm+=term
require(3*F(314159,100000)*a*sm>1,'limiting-margin exponential lower')
require(T-F(1,2)+F(901,2000)+F(7,10000)<F(-1,10000),'strict final margin')

x=1+T;N=12;sm=F(1);term=F(1)
for j in range(1,N+1):term*=x/j;sm+=term
upper=sm+(term*x/(N+1))/(1-x/(N+2))
require(upper<F(142693,50000),'new endpoint e^(1+T) <2.85386')

report={'schema':'positive-sextic-large-exact-1','alpha':str(a),'beta':str(b),'gamma':str(gamma),'T':str(T),'minimum_factor_dimension':200,'power_coefficients':[str(x) for x in p],'bernstein_coefficients':[str(x) for x in bern],'bernstein_lower_bound':str(min(bern)),'exp_upper':str(upper),'endpoint':'142693/50000','status':'PASS: exact constants; analytic reductions in PROOF.md Section 4'}
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
if args.output:args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,sort_keys=True))
