# Remaining scope — partial overall program

## Closed for the original root-leak OrderedTree model

The complete all-rate actual coefficient-Jacobian and formal partial-derivative
factorizations, exact multivariate coordinate multiplicities, signed resultant
identity and boundary singularity distinction are proved. Positive spectrum,
Stieltjes interlacing/reciprocal construction and every positive realization are
proved from their actual objects. The complete unrestricted-real full-response
fiber has a recursive labelled-allocation bijection and finite exact cardinality
n! / product_(nonroot v) |T_v|. Every real competitor is automatically strictly
positive and has nonzero actual coefficient Jacobian. Root leak identification
and actual discharge-transfer fibers are included.

The ODE bridges are now proved in BOTH directions for globally continuous real
inputs, classical trajectories and zero-initial observed responses. Actual
global existence/uniqueness, output formulas, input-output classification from
root or discharge histories, and differential/integrated storage balance are
proved. Exponential probe solutions prevent vacuous use of universal trajectory
predicates, even for initially unrestricted competing real matrices.

Both original-coordinate Kalman matrices are proved nonsingular. Actual state
trajectory observability on any nonempty open time interval is proved, not just
its rank criterion. Actual finite-horizon steering is also proved: every T>0
and every pair of initial/final state vectors admit a constructed continuous
real control with a unique classical trajectory and those exact endpoints.
The actual integral Gramian is proved positive before taking its inverse.

## 1. Independent finite rooted graph presentations — now closed

The representation is constructed from an arbitrary finite SimpleGraph with
IsTree and a root, using proved leaf deletion. Graph dart-rate and vertex
bijections, independently defined conservative matrices, characteristic/cofactor
polynomials, actual derivatives, actual state trajectories and endpoints are
transported by proved equalities. All-real response and continuous-discharge
fibers, positivity, signed steering and finite-window observability are now
exported without requiring a supplied parent presentation.

The all-rate graph Jacobian uses an explicitly disclosed transported ascending
coefficient basis. The count refers to the actual original graph parameter
fiber, with subtree sizes in the constructed graph-isomorphic representation.
It does not claim an unspecified external graph encoding is equal by definition.

## 2. Alternate leak site — positive matrix/fiber theory now closed

The actual single-edge rational rate transformation and its inverse are proved.
Its finite-tree cut and positive diagonal matrix similarity are constructed,
and finite walks give a full positive-rate equivalence between every pair of
leak sites. The observation vertex stays fixed; ALL diagonal resolvents are
preserved. Exact positive physical fiber classification and counting therefore
hold at any prescribed leak site. The model space with an unknown site is proved
finite of cardinality |V| times the prescribed-site count.

The normalized diagonal gauge now also transports actual ODE trajectories,
inputs and endpoints. Full continuous-input state-history fibers, their exact
counts including unknown leak sites, well-posedness, signed steering, finite-
window observability and exact minimum-energy equality are proved. The entire
all-input leakage non-identifiability result is proved for any positive tree,
not just a full-mode target. Solutions are constructed, so the universal history
condition is not vacuous.

The actual relocation derivatives are now proved. Their determinants telescope
with the leak coefficient, giving an exact leak-weighted transport of the actual
alternate-leak characteristic/cofactor Jacobian at every positive vector, even
at positive spectral collisions. All full positive alternate-leak models are
therefore regular. This is not an expanded zero-boundary polynomial theorem.

Automatic positivity of EVERY initially unrestricted REAL full-target model
at any leak site is now proved. A full diagonal realization theorem for arbitrary
real tree-supported matrices and an exact single-site conservation rigidity
theorem discharge all missing sign and similarity obligations. All-real
response fibers and actual continuous-output fibers, including unknown-site
counts, are closed. Reverse history identification uses actual exponential probe
solutions BEFORE positivity is derived; no vacuous existence premise is used.

Still required for the broader alternate-leak scope:
- Exact coordinate multiplicities of the all-real alternate-leak polynomial.
  The independently defined formal Jacobian, all-real polynomial factorization,
  original-matrix evaluation and common exact orientation are now proved in
  LocatedAllRateJacobian, including all zero-rate and repeated-root boundaries.
  The additional no-hidden-coordinate-factor witnesses and exact exponents
  are a separate extension, not assumptions of the proved polynomial formula.

Collocated input/state observation at o is distinct from measuring physical
outflow at a DIFFERENT leak vertex ell. No equality of those different data
models is asserted. The original co-located discharge theory is already closed.

## 3. Scope exclusions, not hidden assumptions

The full-fiber count requires N distinct positive target poles, all positive
weights summing to one, and N vertices. Fewer-mode targets and complex-rate
fibers are not enumerated by that statement. Signed real-valued controls are
allowed in the proved controllability theorem; arbitrary steering under a
nonnegative-rainfall restriction is NOT claimed. Merely measurable, impulsive
or discontinuous inputs require a separate solution notion and bridge. Nonlinear
catchments and empirical forecasting superiority remain outside these proofs.

## Verification boundary

Each source checkpoint must pass its own fresh build, complete audit, empty
trust-level-zero replay and rejected false mutations. A local compiler success
or historical receipt does not certify new sources. The original model's
matrix/fiber/continuous-ODE/system core is closed; the alternate-leak extension remains. No full-program Release or DOI is justified
until the declared intended scope has been completed and independently checked.


## Additional closed optimal-control refinement

For the root-leak model, the exact global minimum energy among all continuous
signed controls meeting arbitrary endpoints in T>0 is now proved, with a
constructed attaining input, exact inverse-Gramian cost and complete equality
classification on [0,T]. Moment feasibility is derived from the actual ODE.
The value is independent of modal coordinates. This does not resolve the
independent graph-presentation or alternate-leak variants stated above.
