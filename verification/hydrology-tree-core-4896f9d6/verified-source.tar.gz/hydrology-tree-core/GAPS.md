# Remaining scope — partial overall program

## Closed for the original root-leak OrderedTree model

The complete all-rate actual coefficient-Jacobian and formal partial-derivative
factorizations, exact multivariate coordinate multiplicities, signed resultant
identity and boundary singularity distinction are proved. Positive spectrum,
Stieltjes interlacing/reciprocal construction and every positive realization are
proved from their actual objects. The complete unrestricted-real full-response
fiber has a recursive labelled-allocation bijection and finite exact cardinality
n! / product_(nonroot v) |T_v|. Every real competitor is automatically strictly
positive and has nonzero actual coefficient Jacobian. Root leak identification
and actual discharge-transfer fibers are included.

The ODE bridges are now proved in BOTH directions for globally continuous real
inputs, classical trajectories and zero-initial observed responses. Actual
global existence/uniqueness, output formulas, input-output classification from
root or discharge histories, and differential/integrated storage balance are
proved. Exponential probe solutions prevent vacuous use of universal trajectory
predicates, even for initially unrestricted competing real matrices.

Both original-coordinate Kalman matrices are proved nonsingular. Actual state
trajectory observability on any nonempty open time interval is proved, not just
its rank criterion. Actual finite-horizon steering is also proved: every T>0
and every pair of initial/final state vectors admit a constructed continuous
real control with a unique classical trajectory and those exact endpoints.
The actual integral Gramian is proved positive before taking its inverse.

## 1. Independent finite rooted graph presentations

The principal theorem still uses OrderedTree: every nonroot vertex has one
strictly lower-numbered parent. An independently presented finite rooted simple
graph needs a proved root-parent construction, topological numbering and all
actual matrix/rate/coefficient transports. Do not silently count that presentation
bridge as established merely because every finite tree intuitively admits one.

## 2. Leak away from the observed root

The current exact model puts input, observation and sole leakage at the same
root. A leak at a different vertex needs the actual observation-root/leak-root
coordinate and reindexing proof. Its parameter Jacobian and physical fiber
variants are not silently inferred from the root-leak theorem.

## 3. Scope exclusions, not hidden assumptions

The full-fiber count requires N distinct positive target poles, all positive
weights summing to one, and N vertices. Fewer-mode targets and complex-rate
fibers are not enumerated by that statement. Signed real-valued controls are
allowed in the proved controllability theorem; arbitrary steering under a
nonnegative-rainfall restriction is NOT claimed. Merely measurable, impulsive
or discontinuous inputs require a separate solution notion and bridge. Nonlinear
catchments and empirical forecasting superiority remain outside these proofs.

## Verification boundary

Each source checkpoint must pass its own fresh build, complete audit, empty
trust-level-zero replay and rejected false mutations. A local compiler success
or historical receipt does not certify new sources. The original model's
matrix/fiber/continuous-ODE/system core is closed; the independent graph and
alternate-leak extensions remain. No full-program Release or DOI is justified
until the declared intended scope has been completed and independently checked.


## Additional closed optimal-control refinement

For the root-leak model, the exact global minimum energy among all continuous
signed controls meeting arbitrary endpoints in T>0 is now proved, with a
constructed attaining input, exact inverse-Gramian cost and complete equality
classification on [0,T]. Moment feasibility is derived from the actual ODE.
The value is independent of modal coordinates. This does not resolve the
independent graph-presentation or alternate-leak variants stated above.
